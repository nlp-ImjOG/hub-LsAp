"""ChatOpenAI 工厂 + DeepSeek 适配。

本文件集中处理三个**实测得到**的 DeepSeek 约束（详见 README「DeepSeek 适配」一节）：

1. ``ChatOpenAI.with_structured_output`` 的默认 ``method`` 是 ``"json_schema"``，
   它会向服务端发送 ``response_format={"type": "json_schema", ...}``；
   DeepSeek 直接返回 400
   ``This response_format type is unavailable now``。
   → 结构化输出必须显式指定 ``method="function_calling"``。

2. DeepSeek 的 ``deepseek-flash`` / ``deepseek-v4-pro`` 默认开启**思考模式**，
   而思考模式不支持强制 ``tool_choice``（结构化输出正是靠强制 tool_choice 实现的），
   服务端返回 400 ``Thinking mode does not support this tool_choice``。
   → 请求体必须带 ``extra_body={"thinking": {"type": "disabled"}}``。

3. 该 key 下可用的模型只有 ``deepseek-flash`` 与 ``deepseek-v4-pro``。

模型对象是**惰性构造**的：没有 API key 时导入本包不会报错（测试可以只 mock 编排层）。
"""

from __future__ import annotations

from functools import lru_cache
from typing import Any, TypeVar

from langchain_core.runnables import Runnable
from langchain_openai import ChatOpenAI
from pydantic import BaseModel

from .config import settings

SchemaT = TypeVar("SchemaT", bound=BaseModel)


class MissingAPIKeyError(RuntimeError):
    """未配置 API key。"""


def require_api_key() -> str:
    api_key = settings.api_key.strip()
    if not api_key:
        raise MissingAPIKeyError(
            "缺少 API key。请设置环境变量 SQL_AGENT_API_KEY（或 OPENAI_API_KEY），"
            "或在「作业二」目录下复制 .env.example 为 .env 并填写。"
        )
    return api_key


@lru_cache(maxsize=8)
def build_chat_model(
    model: str | None = None, *, temperature: float = 0.0
) -> ChatOpenAI:
    """构造（并缓存）一个 ChatOpenAI 实例。"""

    return ChatOpenAI(
        model=model or settings.primary_model,
        base_url=settings.base_url,
        api_key=require_api_key(),
        temperature=temperature,
        timeout=settings.request_timeout_seconds,
        max_retries=settings.max_retries,
        # DeepSeek 思考模式会拒绝强制 tool_choice，详见模块 docstring。
        extra_body={"thinking": {"type": settings.thinking_mode}},
    )


@lru_cache(maxsize=32)
def build_structured_chain(
    schema: type[SchemaT], model: str, temperature: float
) -> Runnable:
    """构造「模型 + Pydantic 结构化输出」的 Runnable，并按参数缓存。

    ``method="function_calling"`` 是硬性要求，不能省略 —— 见模块 docstring 第 1 条。
    """

    return build_chat_model(model, temperature=temperature).with_structured_output(
        schema, method="function_calling"
    )


def describe_model() -> dict[str, Any]:
    """给日志用的模型配置快照（不含 key）。"""

    return {
        "base_url": settings.base_url,
        "primary_model": settings.primary_model,
        "summary_model": settings.summary_model,
        "thinking": settings.thinking_mode,
        "structured_output_method": "function_calling",
    }


__all__ = [
    "MissingAPIKeyError",
    "build_chat_model",
    "build_structured_chain",
    "describe_model",
    "require_api_key",
]
