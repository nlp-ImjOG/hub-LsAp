"""命令行入口：``python -m langchain_sql_agent "查询问题"``。

日志走 stderr，最终 JSON 走 stdout，方便管道处理。
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from .config import settings
from .llm import MissingAPIKeyError, require_api_key
from .logging_config import configure_logging
from .workflow import SQLAgentWorkflow


def _read_question(args: list[str]) -> str:
    if args:
        return " ".join(args)
    if sys.stdin.isatty():
        print("请输入查询问题：", file=sys.stderr, end="", flush=True)
        return input()
    return sys.stdin.read().rstrip("\r\n")


def _force_utf8() -> None:
    """Windows 控制台默认是 GBK，答案里出现「ý」这类字符会直接抛 UnicodeEncodeError。

    统一把 stdout / stderr 切到 UTF-8；``errors="replace"`` 保证极端情况下
    也不至于让整个查询崩在打印这一步。
    """

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):  # 已被重定向到非文本流等情况
                pass


def main() -> None:
    _force_utf8()
    parser = argparse.ArgumentParser(
        description="Chinook 数据库 SQL Agent（LangChain 版）"
    )
    parser.add_argument("text", nargs="*", help="自然语言查询问题")
    parser.add_argument(
        "--log-level",
        default=os.getenv("SQL_AGENT_LOG_LEVEL", "INFO"),
        type=str.upper,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="日志级别，默认读取 SQL_AGENT_LOG_LEVEL 或 INFO",
    )
    args = parser.parse_args()
    configure_logging(args.log_level)

    try:
        require_api_key()
    except MissingAPIKeyError as exc:
        print(
            f"{exc}\n"
            "  export SQL_AGENT_API_KEY=sk-...\n"
            f"  export SQL_AGENT_BASE_URL={settings.base_url}  # 可选",
            file=sys.stderr,
        )
        raise SystemExit(1) from exc

    question = _read_question(args.text)
    output = SQLAgentWorkflow().run(question)
    print(json.dumps(output.model_dump(), ensure_ascii=False, indent=2))
    if output.error:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
