"""LangChain 版 SQL Agent 包。

这是 ``12-江洋明-第十二周作业/00-sql-agent``（openai-agents 版）的 LangChain 复刻：
同一条流水线、同一套数据契约、同一套安全边界，换用 LangChain 表达。
"""

from .models import WorkflowOutput
from .workflow import SQLAgentWorkflow

__all__ = ["SQLAgentWorkflow", "WorkflowOutput"]
