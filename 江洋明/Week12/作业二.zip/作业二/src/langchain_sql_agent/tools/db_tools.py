"""暴露给修复 Agent 的三个确定性工具。

openai-agents 版的 ``SQLRewriteAgent`` 是**盲写**的：它只拿到错误信息文本，
改完就交回去，能不能跑通全靠编排层再判一次。

LangChain 版的修复 Agent 多了三个工具，可以在**自己的推理循环里**做自检：

- ``validate_sql`` —— 只编译不执行（EXPLAIN），安全门禁 + 语法/对象校验；
- ``execute_sql``  —— 只读连接上试运行，返回前几行预览和行数；
- ``get_table_schema`` —— 查看某张表的字段结构（白名单校验）。

工具本身全部是确定性代码，模型只是「调用者」，不能绕过只读和行数上限。
"""

from __future__ import annotations

import json
import logging

from langchain_core.tools import BaseTool, tool

from ..db.catalog import SchemaCatalog
from ..db.executor import SQLExecutionError, SQLExecutor
from ..db.validator import SQLValidator

logger = logging.getLogger(__name__)

#: 试运行工具只回传这么多行，避免把上百行数据塞进 Agent 上下文。
PREVIEW_ROWS = 5


def build_db_tools(
    catalog: SchemaCatalog,
    validator: SQLValidator,
    executor: SQLExecutor,
    *,
    preview_executor: SQLExecutor | None = None,
) -> list[BaseTool]:
    """构造三个工具。闭包捕获 DB 组件，便于测试时注入替身。"""

    preview = preview_executor or SQLExecutor(
        catalog.db_path, max_rows=PREVIEW_ROWS, timeout_seconds=5.0
    )

    @tool("validate_sql")
    def validate_sql(sql: str) -> str:
        """校验一条 SQLite SELECT 是否安全、能否编译通过。

        只做安全门禁和语法/对象校验（EXPLAIN 编译），**不会真正执行**，
        因此可以放心用来试各种写法。返回形如
        「校验通过」或「校验未通过 | 错误码=unknown_object | 错误信息=...」。
        """

        result = validator.validate(sql)
        if result.ok:
            return "校验通过。"
        code = result.code.value if result.code else "unknown"
        return f"校验未通过 | 错误码={code} | 错误信息={result.message}"

    @tool("execute_sql")
    def execute_sql(sql: str) -> str:
        """在只读连接上试运行一条 SELECT，返回列名、行数和前几行预览。

        用于确认改写后的 SQL 能否真正取到数据。执行是只读的（有超时和行数上限），
        但返回的预览只是参考，最终结果以编排层自己的执行为准。
        返回形如「执行成功 | 行数=3 | 列名=... | 预览=...」或错误信息。
        """

        validation = validator.validate(sql)
        if not validation.ok:
            code = validation.code.value if validation.code else "unknown"
            return f"执行未开始 | 错误码={code} | 错误信息={validation.message}"

        try:
            result = preview.execute(validation.normalized_sql)
        except SQLExecutionError as exc:
            code = exc.code.value if exc.code else "runtime"
            return f"执行失败 | 错误码={code} | 错误信息={exc}"

        preview_rows = result.rows[:PREVIEW_ROWS]
        return (
            f"执行成功 | 行数={result.row_count} | 是否截断={result.truncated} | "
            f"列名={json.dumps(result.columns, ensure_ascii=False)} | "
            f"预览={json.dumps(preview_rows, ensure_ascii=False)}"
        )

    @tool("get_table_schema")
    def get_table_schema(table: str) -> str:
        """查看数据库中某张表的字段结构（字段名、类型、可空、主键、样例值）。

        只能查询白名单内的业务表；表名不在清单里会直接返回错误提示。
        """

        if table not in catalog.table_names:
            return (
                f"表 {table} 不存在。可选表：{', '.join(catalog.table_names)}"
            )
        try:
            return catalog.get_table_schema(table)
        except KeyError as exc:
            return f"表 {table} 不存在：{exc}"

    return [validate_sql, execute_sql, get_table_schema]


__all__ = ["PREVIEW_ROWS", "build_db_tools"]
