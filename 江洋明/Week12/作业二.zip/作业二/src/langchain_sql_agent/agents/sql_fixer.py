"""SQL 修复 Agent：``create_agent`` + ``ToolStrategy``。

这是两版实现里**框架差异最明显**的一处：

============================  ==========================================
openai-agents 版                LangChain 版
============================  ==========================================
``SQLRewriteAgent``             ``create_agent(tools=[...])``
``output_type=SQLDraft``        ``response_format=ToolStrategy(SQLDraft)``
无工具，错误靠 prompt 传递      带 validate_sql / execute_sql / get_table_schema
                                三个工具，错误通过工具返回值回灌
``await Runner.run(...)``       ``agent.invoke({"messages": [...]})``
============================  ==========================================

``ToolStrategy`` 用「人工工具调用」实现结构化输出，兼容性最好：
DeepSeek / DashScope 这类 OpenAI 兼容端点都支持 function calling，
但大多不支持原生 ``response_format=json_schema``。
"""

from __future__ import annotations

import logging

from langchain.agents import create_agent
from langchain.agents.structured_output import ToolStrategy
from langchain_core.tools import BaseTool

from ..config import settings
from ..llm import build_chat_model
from ..models import SQLAttempt, SQLDraft, ValidationResult
from ..prompts import SQL_REWRITE_HUMAN, SQL_REWRITE_SYSTEM

logger = logging.getLogger(__name__)


def build_sql_fixer_agent(tools: list[BaseTool]):
    """构造修复 Agent。

    ``tools`` 里的工具都是确定性代码，模型只是调用方，
    无法通过工具绕过只读连接、行数上限和修复预算。
    """

    llm = build_chat_model(settings.primary_model, temperature=0.2)
    return create_agent(
        model=llm,
        tools=tools,
        response_format=ToolStrategy(SQLDraft),
        system_prompt=SQL_REWRITE_SYSTEM,
    )


def build_repair_prompt(
    *,
    question: str,
    schema: str,
    sql: str,
    validation: ValidationResult,
    attempts: list[SQLAttempt],
    attempt_number: int,
    max_attempts: int,
) -> str:
    """把错误上下文拼成一条 user 消息。"""

    history = "\n".join(
        f"- [{item.source}] {item.sql}"
        + (f" | {item.code}: {item.error}" if item.error else "")
        for item in attempts[-5:]
    )
    return SQL_REWRITE_HUMAN.format(
        question=question,
        schema=schema,
        sql=sql,
        code=validation.code.value if validation.code else "unknown",
        message=validation.message,
        attempt=attempt_number,
        max_attempts=max_attempts,
        history=history or "（无）",
    )


def run_fixer(agent, prompt: str) -> SQLDraft:
    """调用修复 Agent 并取出结构化结果。

    Agent 内部会自己循环调用工具（validate_sql / execute_sql），
    ``recursion_limit`` 限制它的工具调用轮数，防止无限自检。
    """

    result = agent.invoke(
        {"messages": [{"role": "user", "content": prompt}]},
        {"recursion_limit": settings.max_fix_iterations * 2},
    )
    draft = result.get("structured_response")
    if not isinstance(draft, SQLDraft):
        raise TypeError(
            f"SQL 修复 Agent 返回了非 SQLDraft 结果：{type(draft).__name__}"
        )
    return draft


__all__ = [
    "build_repair_prompt",
    "build_sql_fixer_agent",
    "run_fixer",
]
