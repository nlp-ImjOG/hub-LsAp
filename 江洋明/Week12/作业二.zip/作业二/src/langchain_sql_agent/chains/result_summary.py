"""结果汇总链：``prompt | llm.with_structured_output(FinalAnswer)``。

对应 openai-agents 版的 ``result_summary_agent``，用更便宜的模型。
"""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable

from ..config import settings
from ..llm import build_structured_chain
from ..models import FinalAnswer
from ..prompts import RESULT_SUMMARY_HUMAN, RESULT_SUMMARY_SYSTEM

#: 汇总阶段的提示词模板。
SUMMARY_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", RESULT_SUMMARY_SYSTEM),
        ("human", RESULT_SUMMARY_HUMAN),
    ]
)


def build_summary_chain() -> Runnable:
    """返回汇总链：输入 question / sql / rows 等，输出 FinalAnswer。"""

    structured = build_structured_chain(
        FinalAnswer, settings.summary_model, temperature=0.3
    )
    return SUMMARY_PROMPT | structured
