"""选表链：LCEL 表达式 ``prompt | llm.with_structured_output(TableSelection)``。

这是 openai-agents 版 ``table_selector_agent`` 的 LangChain 对应物。
区别在于调用方式：那边是 ``await Runner.run(agent, prompt)``，
这边是 ``chain.invoke({...})``，返回值直接就是 Pydantic 实例。
"""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable

from ..config import settings
from ..llm import build_structured_chain
from ..models import TableSelection
from ..prompts import TABLE_SELECT_HUMAN, TABLE_SELECT_SYSTEM

#: 选表阶段的提示词模板（可直接单测，不需要模型）。
SELECT_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", TABLE_SELECT_SYSTEM),
        ("human", TABLE_SELECT_HUMAN),
    ]
)


def build_select_chain() -> Runnable:
    """返回选表链：输入 question / catalog，输出 TableSelection。"""

    structured = build_structured_chain(
        TableSelection, settings.primary_model, temperature=0.0
    )
    return SELECT_PROMPT | structured
