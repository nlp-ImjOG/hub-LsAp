# LangChain 版 SQL Agent 设计文档

> 版本：v1.0（2026-10-29）
> 范围：基于 `data/chinook.db` 的单库、单轮自然语言查询
> 参照实现：同级目录 `../00-sql-agent/`（openai-agents 版）
> 本文回答的问题是：**同一条 SQL Agent 流水线，换到 LangChain 上该怎么写，差别在哪。**

---

## 1. 目标与非目标

### 目标

1. 用 LangChain 完整实现一遍 `00-sql-agent` 的 SQL Agent，覆盖老师课件 `01-langchain教程` 中的
   模型调用、结构化输出、工具调用、Agent 四块内容。
2. 保持与 openai-agents 版**同构**：同样的流水线、同样的数据契约、同样的安全边界，
   这样两版可以逐行对照，差异只来自框架而不是来自设计。
3. 显式记录 LangChain 与 openai-agents 的概念映射，以及 DeepSeek 兼容端的实测约束。

### 非目标

- 多轮对话、上下文追问
- 多数据库 / 多方言切换
- 写操作（INSERT/UPDATE/DELETE/DDL）
- 完全自主的 Agent 规划
- 多模型路由、LangGraph 状态图、人工介入（老师课件里有，但不在本题范围内）

---

## 2. 两条流水线的同构关系

```text
openai-agents 版                      LangChain 版
─────────────────                     ──────────────────
Runner.run(agent, prompt)      ←→     chain.invoke({...})        # LCEL
Agent(output_type=TableSelection) ←→  llm.with_structured_output(TableSelection)
Agent(output_type=SQLDraft)    ←→     create_agent(response_format=ToolStrategy(SQLDraft))
（无工具）                       ←→     tools=[validate_sql, execute_sql, get_table_schema]
response.final_output           ←→     result["structured_response"]
```

**刻意不变的部分**（这些是设计，不是框架特性）：

- 编排由 Python 代码负责，不用 Agent handoff；
- 校验与执行是确定性代码，LLM 不能批准自己写的 SQL；
- 一个 Agent 只做一个决策；
- 上下文最小化（选表只看目录，生成/改写只看已选表的详细 schema）；
- 失败有界（修复预算 3 次）；
- 数据库全程只读。

**刻意变的部分**（这才是「用 LangChain 复刻」的答案）：

| 位置 | openai-agents 版 | LangChain 版 | 为什么 |
| --- | --- | --- | --- |
| 三个线性阶段 | `Agent` + `Runner.run` | LCEL 链 `prompt \| llm.with_structured_output` | 这三步是「提示词 → 模型 → 结构化输出」，用 Agent 包装是杀鸡用牛刀；LCEL 更短、更直白、可单测 |
| 修复阶段 | `Agent`，无工具，错误靠 prompt 文本传 | `create_agent` + 三个工具 | 修复需要**试错**，而 LangChain 的 tool-calling Agent 正是为试错设计的 |
| 工具边界 | 工具全部由编排层内部调用，模型看不到 | 工具暴露给修复 Agent，但工具本身是确定性代码 | 模型获得「手」（能自检），但拿不到「权限」（只读、有上限） |

---

## 3. 组件总览

| 组件 | 类型 | 职责 | LLM | 模型 |
| --- | --- | --- | --- | --- |
| `SQLAgentWorkflow` | 确定性代码 | 状态机、调用顺序、重试预算、降级 | 否 | — |
| `SchemaCatalog` | 确定性代码 | 解析 DB、缓存 schema/统计/外键/样例 | 否 | — |
| 选表链 | LLM | 选回答所需的最少表集合 | 是 | `deepseek-v4-pro` |
| 生成链 | LLM | 生成 SQLite SELECT | 是 | `deepseek-v4-pro` |
| `SQLValidator` | 确定性代码 | 安全门禁、`EXPLAIN` 编译校验 | 否 | — |
| 修复 Agent | LLM + 工具 | 按精确错误修复 SQL | 是 | `deepseek-v4-pro` |
| `SQLExecutor` | 确定性代码 | 只读执行、超时、截断 | 否 | — |
| 汇总链 | LLM | 结果转自然语言 | 是 | `deepseek-flash` |

```mermaid
flowchart LR
    U[用户问题] --> O[SQLAgentWorkflow]
    O --> C[SchemaCatalog]
    C --> T[选表链<br/>LCEL]
    T --> G[生成链<br/>LCEL]
    G --> V[SQLValidator]
    V -- 通过 --> E[SQLExecutor]
    V -- 不通过 --> R[修复 Agent<br/>create_agent + 工具]
    E -- 运行错误 --> R
    R --> V
    E -- 成功 --> S[汇总链<br/>LCEL]
    S --> A[最终 JSON<br/>代码组装]
```

> 回边由 `SQLAgentWorkflow` 控制，最多 3 次修复。

---

## 4. LangChain 概念映射表

老师课件 `Week12/.../01-langchain教程/` 里的每个概念，在本项目中的落点：

| 课件文件 | LangChain 概念 | 本项目用在哪 |
| --- | --- | --- |
| `01_调用模型.py` | `ChatOpenAI` + `invoke` | `llm.py:build_chat_model` |
| `02_Model基础使用.py` | `HumanMessage` / `SystemMessage` / `stream` / `batch` | `chains/*.py` 用 `ChatPromptTemplate` 生成消息 |
| `02_Model工具调用.py` | `bind_tools` / `tool_calls` | 修复 Agent 内部由 LangChain 自动处理 |
| `03_Agent基础使用.py` | `create_agent` + `agent.invoke` | `agents/sql_fixer.py` |
| `04_调用工具.py` | `@tool` / `args_schema` / `ToolRuntime` | `tools/db_tools.py` 三个工具 |
| `05_结构化输出.py` | `ToolStrategy` | `agents/sql_fixer.py` 的 `response_format` |
| `03_动态选择模型.py` | `@wrap_model_call` 中间件 | 未使用（本题只需固定分工，见 §8） |

补充用到的 LangChain 1.x 能力：

- `with_structured_output(schema, method="function_calling")` —— 选表/生成/汇总三段的结构化输出；
- `ChatPromptTemplate.from_messages` —— 提示词模板化，变量与字面量分离（SQL 里的 `{}` 不会被误当变量）；
- `result["structured_response"]` —— 取 Agent 的结构化输出（对应 openai-agents 的 `response.final_output`）；
- `recursion_limit` —— 限制修复 Agent 的工具调用轮数（对应自己写 `for` 循环的上限）；
- `functools.lru_cache` 惰性构造模型 —— 没有 API key 时也能导入整个包（测试友好）。

---

## 5. 数据契约

与 `00-sql-agent/src/sql_agent/models.py` **逐字段一致**，两版可对照：

```python
class TableSelection(BaseModel):
    tables: list[str]; reason: str; confidence: float
    needs_clarification: bool = False; clarification_question: str | None = None

class SQLDraft(BaseModel):
    sql: str; explanation: str = ""; assumptions: list[str] = []
    cannot_fix: bool = False

class ErrorCode(str, Enum):
    UNSAFE | SYNTAX | UNKNOWN_OBJECT | AMBIGUOUS | RUNTIME | TIMEOUT | EMPTY

class ValidationResult(BaseModel):
    ok: bool; code: ErrorCode | None = None; message: str = ""; normalized_sql: str = ""

class ExecutionResult(BaseModel):
    columns: list[str]; rows: list[list[str]]; row_count: int; truncated: bool = False

class FinalAnswer(BaseModel):
    answer: str; evidence: list[str] = []; caveats: list[str] = []

class WorkflowOutput(BaseModel):
    question; answer; sql; tables; row_count; truncated;
    repair_attempts; evidence; caveats; error
```

约定：

- 表名列名必须与 catalog 完全一致（Chinook 列名是 PascalCase：`AlbumId` / `TrackId` / `UnitPrice`）。
- `rows` 统一字符串化，避免 Decimal / 日期序列化差异。
- `repair_attempts` 由编排层维护，模型无权修改。
- 最终 `WorkflowOutput` 由代码组装，不由模型拼接。

---

## 6. 主流程与状态机

### 6.1 正常路径

1. `SchemaCatalog` 解析 DB（进程级单例，按 DB 文件 mtime 失效）。
2. **选表链**：输入「问题 + 目录摘要」，输出 `TableSelection`。
3. 编排层校验表名合法性、计算所选表的外键连接子图；不合法则把错误反馈给选表链，**最多重试 1 次**。
4. **生成链**：输入「问题 + 已选表详细 schema + 连接关系 + 3 行样例」，输出 `SQLDraft`。
5. `SQLValidator`：安全检查 + `EXPLAIN` 编译校验。
6. `SQLExecutor`：只读执行，限制超时和返回行数。
7. **汇总链**：输入「问题 + 最终 SQL + 列名 + 结果行」，输出 `FinalAnswer`。

### 6.2 失败与重试

| 场景 | 处理 | 上限 |
| --- | --- | --- |
| 选表返回不存在的表 | 把合法表清单和错误反馈给选表链重试 | 1 次 |
| 选表结果为多组不连通表 | 提示需要 JOIN，重试选表 | 1 次 |
| 需要澄清（歧义 / 无关问题） | 停止流程，返回澄清问题 | — |
| SQL 校验失败 | 修复 Agent 修复后重新校验 | 与执行错误共享 3 次 |
| SQL 执行运行错误 | 带错误码 + 原始错误信息交给修复 Agent | 共享 3 次 |
| 执行超时 | 带 `TIMEOUT` 提示简化查询 | 共享 3 次 |
| 修复 Agent 判定 `cannot_fix` | 立即停止，返回「当前数据库无法回答该问题」 | — |
| 查询结果为空 | **不重试**，直接回答「未查询到符合条件的数据」 | — |
| 汇总链调用失败 | 降级输出 Markdown 表格 + 行数 | — |

---

## 7. 修复 Agent 的工具自检设计（两版最关键的差异）

### 7.1 问题

openai-agents 版的 `SQLRewriteAgent` 拿到的只有一段错误文本：

```text
错误码：unknown_object
错误信息：(sqlite3.OperationalError) no such column: NonexistentColumn
```

它只能猜。改完交回编排层，编排层再校验一遍，不通过就再改一次 ——
每次都是**盲写 + 盲判**。

### 7.2 LangChain 版

修复 Agent 拿到三个工具：

| 工具 | 做什么 | 安全边界 |
| --- | --- | --- |
| `validate_sql(sql)` | 安全门禁 + `EXPLAIN` 编译校验 | **只编译不执行** |
| `execute_sql(sql)` | 只读连接上试运行，返回行数和前 5 行预览 | 只读 + 超时 + 行数上限 |
| `get_table_schema(table)` | 查看某张表字段结构 | 表名白名单 |

模型可以在自己的推理循环里「改 → 自检 → 再改」，而不是一次性盲写。

实测轨迹（真实 DeepSeek 调用）：

```text
初始校验 ok=False code=UNKNOWN_OBJECT msg=no such column: NonexistentColumn

HumanMessage: 用户问题 … 当前失败 SQL: SELECT COUNT(Title) … WHERE NonexistentColumn = 1
AIMessage:    发起工具调用 -> ['validate_sql']
ToolMessage:  校验通过。
AIMessage:    发起工具调用 -> ['SQLDraft']
ToolMessage:  Returning structured response: sql='SELECT COUNT(*) AS n FROM albums'

修复结果 SQL: SELECT COUNT(*) AS n FROM albums
修复后校验: True
```

注意 Agent **先自检、后作答** —— 它没有在第一次就交付一版未经验证的 SQL。

### 7.3 为什么这不破坏安全边界

设计原则是「LLM 不能批准自己生成的 SQL」。这里是否被破坏？否，理由：

1. 工具是**确定性代码**，模型只是调用方；模型无法通过工具做只读连接做不到的事。
2. `validate_sql` 只 `EXPLAIN` 不执行；`execute_sql` 用 `mode=ro` + `PRAGMA query_only=ON`，
   有 5 秒超时、5 行预览上限。
3. 修复 Agent 返回的 SQL **仍然要过编排层的 `SQLValidator` 和 `SQLExecutor`**，
   Agent 的工具调用不构成放行。Agent 的试运行结果只是参考，
   最终结果以编排层自己的执行为准（`tools/db_tools.py` 的 docstring 里也写明了）。
4. 外层修复预算（3 次）不因 Agent 内部自检而放宽 —— Agent 自检轮数另由 `recursion_limit` 控制。

---

## 8. 模型与 DeepSeek 兼容

### 8.1 分工

| 用途 | 模型 | 理由 |
| --- | --- | --- |
| 选表 / 生成 / 修复 | `deepseek-v4-pro` | 需要精确的 schema 理解与 SQL 正确性 |
| 结果汇总 | `deepseek-flash` | 只需要忠实复述数据，便宜快 |

对应 openai-agents 版的 `qwen-max` / `qwen-plus` 分工。

### 8.2 三条实测约束

全部固化在 `src/langchain_sql_agent/llm.py`，并各有一条测试守着
（`tests/test_chains.py::test_structured_output_uses_function_calling` 等）。

| # | 现象 | 根因 | 处理 |
| --- | --- | --- | --- |
| 1 | `400 This response_format type is unavailable now` | `ChatOpenAI.with_structured_output` 默认 `method="json_schema"` | 显式传 `method="function_calling"` |
| 2 | `400 Thinking mode does not support this tool_choice` | DeepSeek 默认开思考模式，思考模式不支持强制 `tool_choice` | 请求体带 `extra_body={"thinking": {"type": "disabled"}}` |
| 3 | 模型名 `deepseek-v4-flash` 不可用 | 课程资产 `asserts/llm.deepseek.env` 写的是不存在的模型，且其中 key 已 401 失效 | 默认改用 `deepseek-v4-pro` / `deepseek-flash` |

> 约束 1 和 2 都源于「结构化输出 = 强制一次工具调用」。
> `ToolStrategy` 走的是同一条路，所以修复 Agent 同样受约束 2 的影响 —— 关闭思考模式对两者都是必需的。

### 8.3 换服务商

只要端点兼容 OpenAI 的 function calling 即可切到通义千问等：

```bash
export SQL_AGENT_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
export SQL_AGENT_MODEL=qwen-max
export SQL_AGENT_SUMMARY_MODEL=qwen-plus
```

---

## 9. 安全与可靠性

| 风险 | 措施 |
| --- | --- |
| 模型生成写操作 | 只读连接 + 单语句 + `SELECT/WITH` 白名单 + 危险关键字拒绝（多层防御） |
| 多语句注入 | 拒绝分号分隔的多语句；校验前去除尾分号和 Markdown 围栏 |
| 访问内部表 | catalog 只暴露 11 张业务表（SQLAlchemy `inspect` 自动排除 `sqlite_%`） |
| 查询过慢 / 全表扫描 | 5 秒超时（`set_progress_handler`）+ 200 行上限 |
| 大结果拖垮上下文 | 执行层 200 行截断；汇总层 50 行；**修复 Agent 的试运行工具只回传 5 行** |
| 无限修复循环 | 外层 3 次修复预算 + Agent 内部 `recursion_limit` |
| LLM 自我批准 | 校验与执行是确定性代码，Agent 的工具调用不构成放行（见 §7.3） |
| API key 泄露 | 只从环境变量 / `.env` 读；日志不含 key；`describe_model()` 不返回 key |
| 提示注入 | 用户问题放进 `<question>` 标签并声明「仅作为数据」；schema 只来自 catalog |
| 控制台编码 | CLI 强制 stdout/stderr 为 UTF-8（Windows 默认 GBK 会让 `ý` 这类字符抛 `UnicodeEncodeError`） |

---

## 10. 可观测性

日志走 stderr，最终 JSON 走 stdout。每个阶段一行 key=value：

```text
stage=catalog_ready tables=11 elapsed=0.26s
stage=table_select attempt=1 tables=['albums'] confidence=1.00 elapsed=2.13s
stage=sql_generated sql=SELECT COUNT(*) AS TotalAlbums FROM albums
stage=validate attempt=1 ok=True code=None elapsed=0.002s
stage=execute ok=true rows=1 truncated=False elapsed=0.002s
stage=sql_rewrite_started attempt=1/3 code=unknown_object
stage=sql_rewrite_finished elapsed=3.10s cannot_fix=False sql=SELECT COUNT(*) AS n FROM albums
stage=final answer=数据库中共有 347 张专辑。 evidence=1 caveats=0
workflow finished elapsed=4.58s tables=['albums'] rows=1 repairs=0 error=None
```

用户问题、SQL、错误信息在日志里都压成单行并截断；不记录 API key。

---

## 11. 测试分层

| 层次 | 文件 | 覆盖 | 需要 key |
| --- | --- | --- | --- |
| 确定性层 | `tests/test_db_tools.py` | catalog 解析、外键图、安全门禁、`EXPLAIN`、只读执行、三个工具的行为 | 否 |
| 编排层 | `tests/test_workflow.py` | 正常路径、修复路径、空结果、非法表名、不连通表、修复预算耗尽、`cannot_fix`、汇总降级、澄清短路 | 否 |
| LangChain 接线 | `tests/test_chains.py` | 提示词渲染、SQL 里花括号不被当变量、`method="function_calling"`、思考模式关闭、无 key 时报错、模型描述不泄露 key | 否 |

```bash
pytest -q        # 41 passed
ruff check src tests
```

真实 LLM 的端到端验证（需要 key）：

```bash
PYTHONPATH=src python -m langchain_sql_agent "每个流派的歌曲数量 Top5"
PYTHONPATH=src python -m langchain_sql_agent "今天上海天气怎么样"      # 走澄清分支
PYTHONPATH=src python -m langchain_sql_agent "编号为 -1 的专辑是什么"    # 走空结果分支
```

---

## 12. 已知取舍

| 取舍 | 说明 |
| --- | --- |
| 编排用 Python 而非 LangGraph | 与 `00-sql-agent` 保持一致，使两版差异只来自 LLM 层；`create_agent` 本身底层就是 LangGraph 编译图 |
| 三条线性阶段用 LCEL 而非 `create_agent` | 这三步不需要工具调用，LCEL 更直白；用 Agent 包装反而增加中间层 |
| 确定性 DB 层逐字复制而非抽公共包 | 保证 `作业二` 自包含、可独立提交；两版若有出入不会被「公共代码变更」掩盖 |
| 不装 `langchain-community` | 老师课件全程只用 `langchain` + `langchain-openai`；`SQLDatabase` 那套会引入 `langchain-classic` 等额外依赖，而本项目需要的 schema 统计（distinct / 缺失数 / 众数 / 3 行样例）比它更细 |
| 修复 Agent 同时保留外层 Python 循环 | 内层自检解决「这一版对不对」，外层循环解决「最多试几次」，两层预算互相独立 |
