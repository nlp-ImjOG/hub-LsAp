"""编排层测试：全部 LLM 调用都用假实现，不需要 API key。"""

from __future__ import annotations

from pathlib import Path

import pytest
from conftest import FakeChain, FakeFixer

from langchain_sql_agent.chains import StageChains
from langchain_sql_agent.db.catalog import SchemaCatalog
from langchain_sql_agent.db.executor import SQLExecutor
from langchain_sql_agent.db.validator import SQLValidator
from langchain_sql_agent.models import FinalAnswer, SQLDraft, TableSelection
from langchain_sql_agent.workflow import SQLAgentWorkflow


@pytest.fixture
def workflow_parts(db_path: Path, catalog: SchemaCatalog):
    """返回 (构造 workflow 的工厂, 三个假链, 假修复 agent)。"""

    select = FakeChain([])
    generate = FakeChain([])
    summarize = FakeChain([])
    fixer = FakeFixer([])

    def make(**kwargs):
        chains = StageChains(
            select=kwargs.pop("select", select),
            generate=kwargs.pop("generate", generate),
            summarize=kwargs.pop("summarize", summarize),
        )
        return SQLAgentWorkflow(
            catalog=catalog,
            validator=SQLValidator(db_path),
            executor=SQLExecutor(db_path),
            chains=chains,
            fixer=kwargs.pop("fixer", fixer),
            **kwargs,
        )

    return make, select, generate, summarize, fixer


def test_happy_path(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [
        TableSelection(tables=["albums"], reason="统计专辑数量", confidence=0.9)
    ]
    generate.outputs = [
        SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="count")
    ]
    summarize.outputs = [
        FinalAnswer(answer="共 347 张专辑。", evidence=["347"])
    ]

    result = make().run("总共有多少张专辑？")

    assert result.error is None
    assert result.tables == ["albums"]
    assert result.row_count == 1
    assert result.answer == "共 347 张专辑。"
    assert result.sql == "SELECT COUNT(*) AS n FROM albums"
    assert len(select.calls) == 1
    assert len(generate.calls) == 1
    assert len(summarize.calls) == 1


def test_select_chain_receives_catalog(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [TableSelection(tables=["albums"], reason="r", confidence=0.9)]
    generate.outputs = [SQLDraft(sql="SELECT 1 AS n FROM albums", explanation="x")]
    summarize.outputs = [FinalAnswer(answer="ok")]

    make().run("有多少专辑？")

    payload = select.calls[0]
    assert "albums" in payload["catalog"]
    assert "外键关系" in payload["catalog"]


def test_generate_chain_receives_selected_schema_only(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [TableSelection(tables=["albums"], reason="r", confidence=0.9)]
    generate.outputs = [SQLDraft(sql="SELECT 1 AS n FROM albums", explanation="x")]
    summarize.outputs = [FinalAnswer(answer="ok")]

    make().run("有多少专辑？")

    schema = generate.calls[0]["schema"]
    assert "### albums" in schema
    # 上下文最小化：没选中的表不应该出现在生成阶段。
    assert "### tracks" not in schema


def test_rewrite_path(workflow_parts) -> None:
    make, select, generate, summarize, fixer = workflow_parts
    select.outputs = [TableSelection(tables=["albums"], reason="r", confidence=0.9)]
    generate.outputs = [
        SQLDraft(sql="SELECT COUNT(ArtistId FROM albums", explanation="bad")
    ]
    fixer.drafts = [
        SQLDraft(
            sql="SELECT COUNT(DISTINCT ArtistId) AS n FROM albums",
            explanation="fixed",
        )
    ]
    summarize.outputs = [FinalAnswer(answer="共有 275 位艺人。", evidence=["275"])]

    result = make().run("专辑里有多少位不同的艺人？")

    assert result.repair_attempts == 1
    assert result.error is None
    assert "COUNT(DISTINCT ArtistId)" in (result.sql or "")
    assert len(fixer.calls) == 1


def test_repair_prompt_carries_error_context(workflow_parts) -> None:
    make, select, generate, summarize, fixer = workflow_parts
    select.outputs = [TableSelection(tables=["albums"], reason="r", confidence=0.9)]
    generate.outputs = [SQLDraft(sql="SELECT nope FROM albums", explanation="bad")]
    fixer.drafts = [SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="ok")]
    summarize.outputs = [FinalAnswer(answer="ok")]

    make().run("测试修复")

    prompt = fixer.calls[0]["messages"][0]["content"]
    assert "unknown_object" in prompt
    assert "SELECT nope FROM albums" in prompt


def test_empty_result_skips_summary_chain(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [
        TableSelection(tables=["albums"], reason="查不存在的专辑", confidence=0.9)
    ]
    generate.outputs = [
        SQLDraft(sql="SELECT * FROM albums WHERE AlbumId = -1", explanation="empty")
    ]

    result = make().run("编号为 -1 的专辑是什么？")

    assert result.row_count == 0
    assert result.answer == "未查询到符合条件的数据。"
    assert len(summarize.calls) == 0


def test_unknown_table_is_rejected_and_retried(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [
        TableSelection(tables=["not_a_table"], reason="bad", confidence=0.1),
        TableSelection(tables=["albums"], reason="fixed", confidence=0.9),
    ]
    generate.outputs = [SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="c")]
    summarize.outputs = [FinalAnswer(answer="共 347 张专辑。")]

    result = make().run("总共有多少张专辑？")

    assert result.error is None
    assert result.tables == ["albums"]
    assert len(select.calls) == 2
    # 第二次调用要带上上一次的问题。
    assert "表不存在" in select.calls[1]["catalog"]


def test_disconnected_tables_are_rejected(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [
        TableSelection(tables=["albums", "customers"], reason="bad", confidence=0.5),
        TableSelection(tables=["albums"], reason="fixed", confidence=0.9),
    ]
    generate.outputs = [SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="c")]
    summarize.outputs = [FinalAnswer(answer="ok")]

    result = make().run("总共有多少张专辑？")

    assert result.tables == ["albums"]
    assert "没有外键连接" in select.calls[1]["catalog"]


def test_max_repair_attempts_returns_error(workflow_parts) -> None:
    make, select, generate, summarize, fixer = workflow_parts
    select.outputs = [TableSelection(tables=["albums"], reason="r", confidence=0.9)]
    generate.outputs = [SQLDraft(sql="SELECT nope FROM albums", explanation="bad")]
    fixer.drafts = [
        SQLDraft(sql="SELECT nope FROM albums", explanation="still bad"),
        SQLDraft(sql="SELECT nope FROM albums", explanation="still bad"),
        SQLDraft(sql="SELECT nope FROM albums", explanation="still bad"),
    ]

    result = make(max_repair_attempts=0).run("测试失败路径")

    assert result.error is not None
    assert result.repair_attempts == 0
    assert "最大修复次数" in result.answer
    assert len(fixer.calls) == 0


def test_cannot_fix_stops_early(workflow_parts) -> None:
    make, select, generate, summarize, fixer = workflow_parts
    select.outputs = [TableSelection(tables=["albums"], reason="r", confidence=0.9)]
    generate.outputs = [SQLDraft(sql="SELECT nope FROM albums", explanation="bad")]
    fixer.drafts = [
        SQLDraft(
            sql="SELECT 1",
            explanation="数据库里没有股票价格表",
            cannot_fix=True,
        )
    ]

    result = make().run("今天股票价格是多少？")

    assert result.error is not None
    assert "无法回答" in result.answer
    assert len(summarize.calls) == 0


def test_summary_failure_degrades_to_table(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [TableSelection(tables=["albums"], reason="r", confidence=0.9)]
    generate.outputs = [
        SQLDraft(sql="SELECT AlbumId, Title FROM albums LIMIT 3", explanation="c")
    ]

    class BrokenChain:
        def invoke(self, payload):
            raise RuntimeError("模型挂了")

    result = make(summarize=BrokenChain()).run("列出前 3 张专辑")

    assert result.error is None
    assert "查询返回 3 行" in result.answer
    assert "|" in result.answer
    assert result.caveats


def test_clarification_short_circuits(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts
    select.outputs = [
        TableSelection(
            tables=[],
            reason="与数据库无关",
            confidence=0.0,
            needs_clarification=True,
            clarification_question="你想问的是哪个艺人？",
        )
    ]

    result = make().run("随便问点什么")

    assert result.answer == "你想问的是哪个艺人？"
    assert len(generate.calls) == 0
    assert len(summarize.calls) == 0


def test_empty_question_returns_early(workflow_parts) -> None:
    make, select, generate, summarize, _ = workflow_parts

    result = make().run("   ")

    assert result.answer == "请输入要查询的问题。"
    assert len(select.calls) == 0
