"""公共测试夹具。"""

from __future__ import annotations

from pathlib import Path

import pytest

from langchain_sql_agent.config import settings
from langchain_sql_agent.db.catalog import SchemaCatalog


@pytest.fixture(scope="session")
def db_path() -> Path:
    path = settings.db_path
    assert path.exists(), f"找不到数据库：{path}"
    return path


@pytest.fixture(scope="session")
def catalog(db_path: Path) -> SchemaCatalog:
    return SchemaCatalog(db_path)


class FakeChain:
    """替代一条 LCEL 链：按调用顺序返回预设结果，并记录收到的 payload。"""

    def __init__(self, outputs):
        self.outputs = list(outputs)
        self.calls: list[dict] = []

    def invoke(self, payload):
        self.calls.append(payload)
        index = len(self.calls) - 1
        if index >= len(self.outputs):
            raise AssertionError(f"链被调用了 {len(self.calls)} 次，但只准备了 {len(self.outputs)} 个结果")
        return self.outputs[index]


class FakeFixer:
    """替代 create_agent 编译出来的修复 Agent。

    真实 Agent 的返回是一个 dict，结构化结果放在 ``structured_response``。
    """

    def __init__(self, drafts):
        self.drafts = list(drafts)
        self.calls: list[dict] = []

    def invoke(self, payload, config=None):
        self.calls.append(payload)
        index = len(self.calls) - 1
        if index >= len(self.drafts):
            raise AssertionError(f"修复 Agent 被调用了 {len(self.calls)} 次，但只准备了 {len(self.drafts)} 个结果")
        return {"structured_response": self.drafts[index]}
