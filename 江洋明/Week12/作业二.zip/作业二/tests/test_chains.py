"""LangChain 层测试：提示词渲染、结构化输出接线、模型配置。"""

from __future__ import annotations

import dataclasses

import pytest

from langchain_sql_agent import llm as llm_module
from langchain_sql_agent.agents.sql_fixer import build_repair_prompt
from langchain_sql_agent.chains import build_default_chains
from langchain_sql_agent.chains.result_summary import SUMMARY_PROMPT
from langchain_sql_agent.chains.sql_generate import GENERATE_PROMPT
from langchain_sql_agent.chains.table_select import SELECT_PROMPT
from langchain_sql_agent.config import settings
from langchain_sql_agent.models import ErrorCode, SQLAttempt, ValidationResult


# ----------------------------------------------------------------------
# 提示词模板
# ----------------------------------------------------------------------
def test_select_prompt_renders_system_and_human() -> None:
    messages = SELECT_PROMPT.format_messages(
        question="有多少专辑？", catalog="- albums（347 行）"
    )
    assert messages[0].type == "system"
    assert "SQLite 数据库分析专家" in messages[0].content
    assert "<question>" in messages[1].content
    assert "有多少专辑？" in messages[1].content
    assert "- albums（347 行）" in messages[1].content


def test_generate_prompt_renders_schema() -> None:
    messages = GENERATE_PROMPT.format_messages(
        question="每个流派有多少首歌？", schema="### genres"
    )
    assert "### genres" in messages[1].content


def test_summary_prompt_keeps_braces_in_values() -> None:
    """SQL 里可能带花括号，不能被当成模板变量。"""

    sql = "SELECT json_object('a', 1) FROM tracks"
    messages = SUMMARY_PROMPT.format_messages(
        question="q",
        sql=sql,
        columns='["x"]',
        row_count="1",
        truncated="否",
        max_rows="50",
        rows="[[\"a\"]]",
    )
    assert sql in messages[1].content


def test_repair_prompt_includes_error_context() -> None:
    validation = ValidationResult(
        ok=False, code=ErrorCode.UNKNOWN_OBJECT, message="no such column: nope"
    )
    prompt = build_repair_prompt(
        question="有多少专辑？",
        schema="### albums",
        sql="SELECT nope FROM albums",
        validation=validation,
        attempts=[SQLAttempt(sql="SELECT nope FROM albums", source="generator")],
        attempt_number=1,
        max_attempts=3,
    )
    assert "unknown_object" in prompt
    assert "no such column: nope" in prompt
    assert "1/3" in prompt
    assert "SELECT nope FROM albums" in prompt


# ----------------------------------------------------------------------
# 模型接线
# ----------------------------------------------------------------------
def test_structured_output_uses_function_calling(monkeypatch) -> None:
    """DeepSeek 不支持 response_format=json_schema，必须走 function_calling。"""

    captured: dict = {}

    class FakeLLM:
        def with_structured_output(self, schema, **kwargs):
            captured["schema"] = schema
            captured.update(kwargs)
            return "chain"

    monkeypatch.setattr(llm_module, "build_chat_model", lambda *a, **k: FakeLLM())
    llm_module.build_structured_chain.cache_clear()

    llm_module.build_structured_chain(dict, "deepseek-v4-pro", 0.0)

    assert captured["method"] == "function_calling"
    llm_module.build_structured_chain.cache_clear()


def test_build_chat_model_disables_thinking(monkeypatch) -> None:
    """思考模式不支持强制 tool_choice，必须关掉。"""

    fake_settings = dataclasses.replace(settings, api_key="sk-test", thinking_mode="disabled")
    monkeypatch.setattr(llm_module, "settings", fake_settings)
    llm_module.build_chat_model.cache_clear()

    model = llm_module.build_chat_model("deepseek-v4-pro", temperature=0.0)

    assert model.extra_body == {"thinking": {"type": "disabled"}}
    assert model.model_name == "deepseek-v4-pro"
    llm_module.build_chat_model.cache_clear()


def test_require_api_key_raises_when_missing(monkeypatch) -> None:
    fake_settings = dataclasses.replace(settings, api_key="")
    monkeypatch.setattr(llm_module, "settings", fake_settings)

    with pytest.raises(llm_module.MissingAPIKeyError):
        llm_module.require_api_key()


def test_default_chains_are_runnables(monkeypatch) -> None:
    """三条链都能构造出来（用假 key，不发真实请求）。"""

    fake_settings = dataclasses.replace(settings, api_key="sk-test")
    monkeypatch.setattr(llm_module, "settings", fake_settings)
    llm_module.build_chat_model.cache_clear()
    llm_module.build_structured_chain.cache_clear()

    chains = build_default_chains()

    assert chains.select is not None
    assert chains.generate is not None
    assert chains.summarize is not None
    llm_module.build_chat_model.cache_clear()
    llm_module.build_structured_chain.cache_clear()


def test_describe_model_does_not_leak_key() -> None:
    described = llm_module.describe_model()
    assert "api_key" not in described
    assert described["structured_output_method"] == "function_calling"
