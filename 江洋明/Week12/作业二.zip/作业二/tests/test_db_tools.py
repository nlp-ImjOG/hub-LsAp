"""确定性层测试：schema 解析、SQL 安全门禁、只读执行。"""

from __future__ import annotations

from pathlib import Path

import pytest

from langchain_sql_agent.db.catalog import SchemaCatalog
from langchain_sql_agent.db.executor import SQLExecutionError, SQLExecutor
from langchain_sql_agent.db.validator import SQLValidator, normalize_sql
from langchain_sql_agent.tools.db_tools import build_db_tools


@pytest.fixture(scope="module")
def validator(db_path: Path) -> SQLValidator:
    return SQLValidator(db_path)


def test_catalog_excludes_sqlite_internal_tables(catalog: SchemaCatalog) -> None:
    assert len(catalog.table_names) == 11
    assert "tracks" in catalog.table_names
    assert "sqlite_sequence" not in catalog.table_names
    assert "sqlite_stat1" not in catalog.table_names


def test_catalog_has_multiple_sample_rows(catalog: SchemaCatalog) -> None:
    profile = catalog._tables["albums"]
    assert profile.row_count == 347
    assert len(profile.sample_rows) == 3


def test_catalog_renders_join_edges(catalog: SchemaCatalog) -> None:
    edges = [edge.render() for edge in catalog.join_edges(["invoice_items", "invoices"])]
    assert "invoice_items.InvoiceId -> invoices.InvoiceId" in edges
    assert catalog.is_connected(["invoice_items", "invoices", "customers"])
    assert not catalog.is_connected(["albums", "customers"])


@pytest.mark.parametrize(
    ("sql", "ok"),
    [
        ("SELECT COUNT(DISTINCT ArtistId) FROM albums;", True),
        ("WITH x AS (SELECT 1 AS n) SELECT * FROM x", True),
        ("SELECT 'DROP' AS word", True),
        ("DROP TABLE tracks", False),
        ("SELECT 1; DROP TABLE tracks", False),
        ("SELECT nope FROM tracks", False),
        ("", False),
    ],
)
def test_validator(sql: str, ok: bool, validator: SQLValidator) -> None:
    result = validator.validate(sql)
    assert result.ok is ok
    if ok:
        assert not result.normalized_sql.endswith(";")
    else:
        assert result.code is not None


def test_validator_does_not_execute(validator: SQLValidator) -> None:
    result = validator.validate("CREATE TABLE should_not_exist(x int)")
    assert not result.ok
    assert result.code.value == "unsafe"


def test_normalize_sql_removes_fence_and_semicolon() -> None:
    assert normalize_sql("```sql\nSELECT 1;\n```") == "SELECT 1"


def test_executor_returns_rows_and_truncates(db_path: Path) -> None:
    executor = SQLExecutor(db_path, max_rows=5)
    result = executor.execute("SELECT TrackId, Name FROM tracks ORDER BY TrackId")
    assert result.columns == ["TrackId", "Name"]
    assert result.row_count == 5
    assert result.truncated is True
    assert result.rows[0][1] == "For Those About To Rock (We Salute You)"


def test_executor_is_readonly(db_path: Path) -> None:
    executor = SQLExecutor(db_path)
    with pytest.raises(SQLExecutionError):
        executor.execute("CREATE TABLE should_not_exist(x int)")


# ----------------------------------------------------------------------
# 工具层：这三个 @tool 是修复 Agent 的手和眼
# ----------------------------------------------------------------------
@pytest.fixture(scope="module")
def tools(catalog: SchemaCatalog, db_path: Path):
    return {
        tool.name: tool
        for tool in build_db_tools(
            catalog, SQLValidator(db_path), SQLExecutor(db_path)
        )
    }


def test_validate_sql_tool_accepts_good_sql(tools) -> None:
    out = tools["validate_sql"].invoke({"sql": "SELECT COUNT(*) FROM albums"})
    assert "校验通过" in out


def test_validate_sql_tool_reports_error_code(tools) -> None:
    out = tools["validate_sql"].invoke({"sql": "SELECT nope FROM albums"})
    assert "校验未通过" in out
    assert "unknown_object" in out


def test_execute_sql_tool_returns_preview(tools) -> None:
    out = tools["execute_sql"].invoke({"sql": "SELECT AlbumId FROM albums LIMIT 3"})
    assert "执行成功" in out
    assert "行数=3" in out


def test_execute_sql_tool_refuses_write(tools) -> None:
    out = tools["execute_sql"].invoke({"sql": "DROP TABLE tracks"})
    assert "执行未开始" in out
    assert "unsafe" in out


def test_get_table_schema_tool_whitelists_tables(tools) -> None:
    ok = tools["get_table_schema"].invoke({"table": "albums"})
    assert "AlbumId" in ok

    bad = tools["get_table_schema"].invoke({"table": "sqlite_master"})
    assert "不存在" in bad
