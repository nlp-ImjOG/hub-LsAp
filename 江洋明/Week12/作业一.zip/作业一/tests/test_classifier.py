"""分类器逻辑测试。全部离线，不消耗 API 额度。"""

from __future__ import annotations

import pytest

from src.core.classifier import RiskClassifier, extract_json
from src.core.models import AnalysisStatus, RiskLevel, normalize_level, normalize_scene
from src.core.providers import VisionError
from tests.conftest import (
    RISK_HIGH,
    SCENE_CORRIDOR,
    SCENE_NON_CORRIDOR,
    FakeVisionClient,
    json_text,
)


# ——————————————————————————— JSON 提取 ———————————————————————————


def test_extract_json_plain():
    assert extract_json('{"a": 1}') == {"a": 1}


def test_extract_json_from_code_fence():
    text = '```json\n{"scene": "corridor"}\n```'
    assert extract_json(text) == {"scene": "corridor"}


def test_extract_json_with_surrounding_text():
    text = '好的，结果如下：{"scene": "corridor", "evidence": []} 以上。'
    assert extract_json(text)["scene"] == "corridor"


def test_extract_json_with_chinese_quotes():
    assert extract_json('{“a”: 1}') == {"a": 1}


def test_extract_json_handles_nested_braces():
    text = '{"a": {"b": 1}, "c": [1,2]}'
    assert extract_json(text)["a"]["b"] == 1


def test_extract_json_returns_none_on_garbage():
    assert extract_json("完全不是 JSON") is None
    assert extract_json("") is None


# ——————————————————————————— 归一化 ———————————————————————————


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("高风险", RiskLevel.HIGH),
        ("中等风险", RiskLevel.MEDIUM),   # notebook 总纲的写法
        ("中风险", RiskLevel.MEDIUM),
        ("低风险", RiskLevel.LOW),
        ("无风险", RiskLevel.NONE),       # 作业原文的写法
        ("无隐患", RiskLevel.NONE),       # notebook 总纲的写法
        (" 高风险 ", RiskLevel.HIGH),
        ("高风险(楼道内有电动车充电)", RiskLevel.HIGH),
        ("存在高风险隐患", RiskLevel.HIGH),
        ("非楼道", RiskLevel.NON_CORRIDOR),
    ],
)
def test_normalize_level(raw, expected):
    assert normalize_level(raw) == expected


def test_normalize_level_rejects_unknown():
    assert normalize_level("轻微") is None
    assert normalize_level("") is None
    assert normalize_level(None) is None


def test_normalize_level_can_exclude_non_corridor():
    # 阶段二不允许「非楼道」
    assert normalize_level("非楼道", allow_non_corridor=False) is None
    assert normalize_level("高风险", allow_non_corridor=False) == RiskLevel.HIGH


def test_normalize_scene():
    assert normalize_scene("corridor") is not None
    assert normalize_scene("non_corridor") is not None
    assert normalize_scene("非楼道") is None


# ——————————————————————————— 两阶段流程 ———————————————————————————


def test_non_corridor_only_calls_model_once(classifier, fake_client):
    fake_client.responses = [SCENE_NON_CORRIDOR]
    result = classifier.analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.OK
    assert result.level == RiskLevel.NON_CORRIDOR
    assert len(fake_client.calls) == 1, "非楼道场景不应触发第二阶段"
    assert result.evidence == ["画面中央是茶几和沙发"]


def test_corridor_runs_both_stages(classifier, fake_client):
    result = classifier.analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.OK
    assert result.level == RiskLevel.HIGH
    assert len(fake_client.calls) == 2
    assert result.scene_label == "居民楼楼道"
    assert result.confidence == pytest.approx(0.93)
    assert result.evidence == ["画面右侧有一辆正在充电的电动车"]
    assert result.suggestion.startswith("立即劝离")


def test_stage_two_prompt_contains_rubric(classifier, fake_client):
    classifier.analyze("ZmFrZQ==")
    risk_prompt = fake_client.calls[1]
    # 判定标准原文必须在提示词里
    assert "高风险：楼道中出现电动车、电瓶、飞线充电" in risk_prompt
    assert "无风险：楼道干净，无堆放物品" in risk_prompt


def test_scene_prompt_asked_first(classifier, fake_client):
    classifier.analyze("ZmFrZQ==")
    assert "是否是居民楼楼道" in fake_client.calls[0]
    assert "专业消防专家" not in fake_client.calls[0]


# ——————————————————————————— 重试与兜底 ———————————————————————————


def test_empty_output_triggers_retry():
    """实测 deepseek-flash 偶尔返回空 content，必须能重试救回来。"""
    client = FakeVisionClient(["", SCENE_CORRIDOR, RISK_HIGH])
    result = RiskClassifier(client, max_retries=1).analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.OK
    assert result.level == RiskLevel.HIGH
    assert len(client.calls) == 3  # 1 次失败 + 重试 2 阶段


def test_retry_prompt_adds_strict_instruction():
    client = FakeVisionClient(["", SCENE_CORRIDOR, RISK_HIGH])
    RiskClassifier(client, max_retries=1).analyze("ZmFrZQ==")
    assert "上一次输出无法解析" in client.calls[1]


def test_invalid_level_is_rejected_and_retried():
    client = FakeVisionClient(
        [SCENE_CORRIDOR, json_text({"level": "有点危险"}), RISK_HIGH]
    )
    result = RiskClassifier(client, max_retries=1).analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.OK
    assert result.level == RiskLevel.HIGH


def test_unparseable_after_retries_returns_failed():
    client = FakeVisionClient(["完全不是 JSON", "依然不是 JSON"])
    result = RiskClassifier(client, max_retries=1).analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.FAILED
    assert result.level is None
    assert result.error


def test_missing_key_returns_offline():
    client = FakeVisionClient([], available=False)
    result = RiskClassifier(client).analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.OFFLINE
    assert result.level is None
    assert len(client.calls) == 0, "没有 key 时不应该发起调用"


def test_network_error_returns_offline():
    client = FakeVisionClient([], error="连接超时")
    result = RiskClassifier(client).analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.OFFLINE
    assert result.level is None
    assert "连接超时" in result.error


def test_stage_two_failure_keeps_scene():
    """阶段一成功、阶段二失败时，场景信息要保留。"""
    client = FakeVisionClient([SCENE_CORRIDOR, "", ""])
    result = RiskClassifier(client, max_retries=1).analyze("ZmFrZQ==")

    assert result.status == AnalysisStatus.FAILED
    assert result.scene is not None
    assert result.scene_label == "居民楼楼道"
