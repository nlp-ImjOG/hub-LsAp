"""SQLite 持久化测试。"""

from __future__ import annotations

from src.core import db


def _payload(level: str | None = "高风险", **overrides) -> dict:
    payload = {
        "created_at": "2026-10-29T10:00:00+08:00",
        "image_path": "abc.jpg",
        "status": "ok",
        "level": level,
        "confidence": 0.9,
        "scene": "corridor",
        "scene_label": "居民楼楼道",
        "evidence": '["画面右侧有一辆电动车"]',
        "reason": "存在充电行为",
        "suggestion": "立即劝离",
        "provider": "fake",
        "model": "fake-model",
        "latency_ms": 1234,
        "error": None,
    }
    payload.update(overrides)
    return payload


def test_insert_and_fetch():
    db.init_schema()
    record_id = db.insert_record(_payload())

    record = db.get_record(record_id)
    assert record is not None
    assert record["level"] == "高风险"
    assert record["evidence"] == ["画面右侧有一辆电动车"]


def test_get_missing_returns_none():
    assert db.get_record(999999) is None


def test_list_records_is_newest_first():
    db.init_schema()
    first = db.insert_record(_payload(level="高风险"))
    second = db.insert_record(_payload(level="低风险"))

    items = db.list_records()
    assert [i["id"] for i in items][:2] == [second, first]


def test_filter_by_level():
    db.init_schema()
    db.insert_record(_payload(level="高风险"))
    db.insert_record(_payload(level="非楼道"))

    items = db.list_records(level="高风险")
    assert len(items) == 1
    assert items[0]["level"] == "高风险"


def test_stats_by_level():
    db.init_schema()
    db.insert_record(_payload(level="高风险"))
    db.insert_record(_payload(level="高风险"))
    db.insert_record(_payload(level="无风险"))

    stats = {s["level"]: s["count"] for s in db.stats_by_level()}
    assert stats["高风险"] == 2
    assert stats["无风险"] == 1


def test_delete_record():
    db.init_schema()
    record_id = db.insert_record(_payload())

    assert db.delete_record(record_id) is True
    assert db.get_record(record_id) is None
    assert db.delete_record(record_id) is False


def test_evidence_is_parsed_from_json():
    db.init_schema()
    record_id = db.insert_record(_payload(evidence='["a", "b"]'))
    assert db.get_record(record_id)["evidence"] == ["a", "b"]


def test_bad_evidence_json_does_not_crash():
    db.init_schema()
    record_id = db.insert_record(_payload(evidence="不是 JSON"))
    assert db.get_record(record_id)["evidence"] == []
