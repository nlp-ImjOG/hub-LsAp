"""API 契约测试。用 FastAPI TestClient，模型调用被 mock，不需要 API Key。"""

from __future__ import annotations

import io

from PIL import Image

from src.core import db


def _png_bytes(width: int = 200, height: int = 150) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (width, height), "#666666").save(buf, format="PNG")
    return buf.getvalue()


def test_index_serves_frontend(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "楼道消防隐患识别" in resp.text


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert "model" in body
    assert "api_key_present" in body


def test_api_info_lists_endpoints(client):
    resp = client.get("/api")
    assert resp.status_code == 200
    assert any("/api/analyze" in item for item in resp.json()["endpoints"])


def test_providers_listed(client):
    resp = client.get("/api/providers")
    assert resp.status_code == 200
    body = resp.json()
    names = [p["name"] for p in body["providers"]]
    assert "deepseek" in names
    assert "dashscope" in names
    assert "zhipu" in names
    assert body["default_provider"]


def test_analyze_returns_high_risk(client):
    resp = client.post("/api/analyze", files={"file": ("photo.png", _png_bytes(), "image/png")})
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["level"] == "高风险"
    assert body["scene"] == "corridor"
    assert body["evidence"]
    assert body["record_id"] is not None


def test_analyze_persists_record(client):
    resp = client.post("/api/analyze", files={"file": ("photo.png", _png_bytes(), "image/png")})
    record_id = resp.json()["record_id"]

    record = client.get(f"/api/records/{record_id}")
    assert record.status_code == 200
    assert record.json()["level"] == "高风险"
    assert record.json()["image_url"].startswith("/uploads/")


def test_analyze_rejects_non_image(client):
    resp = client.post("/api/analyze", files={"file": ("note.txt", b"hello", "text/plain")})
    assert resp.status_code == 400
    assert "图片" in resp.json()["detail"]


def test_analyze_rejects_empty_file(client):
    resp = client.post("/api/analyze", files={"file": ("empty.jpg", b"", "image/jpeg")})
    assert resp.status_code == 400


def test_records_list_and_stats(client):
    client.post("/api/analyze", files={"file": ("photo.png", _png_bytes(), "image/png")})
    client.post("/api/analyze", files={"file": ("photo2.png", _png_bytes(), "image/png")})

    records = client.get("/api/records")
    assert records.status_code == 200
    assert records.json()["total"] >= 2

    stats = client.get("/api/stats")
    assert stats.status_code == 200
    levels = {s["level"]: s["count"] for s in stats.json()["by_level"]}
    assert levels.get("高风险", 0) >= 2


def test_delete_record(client):
    record_id = client.post(
        "/api/analyze", files={"file": ("photo.png", _png_bytes(), "image/png")}
    ).json()["record_id"]

    assert client.delete(f"/api/records/{record_id}").status_code == 200
    assert client.get(f"/api/records/{record_id}").status_code == 404


def test_missing_record_returns_404(client):
    assert client.get("/api/records/999999").status_code == 404


def test_uploaded_image_is_served(client):
    record_id = client.post(
        "/api/analyze", files={"file": ("photo.png", _png_bytes(), "image/png")}
    ).json()["record_id"]
    image_url = client.get(f"/api/records/{record_id}").json()["image_url"]

    resp = client.get(image_url)
    assert resp.status_code == 200
    assert resp.headers["content-type"] == "image/jpeg"


def test_upload_path_traversal_is_blocked(client):
    resp = client.get("/uploads/..%2F..%2F.env")
    assert resp.status_code == 404
