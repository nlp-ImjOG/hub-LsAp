"""pytest 公共 fixture。

核心约定：**测试不依赖 API Key**。模型调用用 `FakeVisionClient` 顶替，
所以整套链路（前端 -> 后端 -> 校验 -> 落库）都能离线跑通。
"""

from __future__ import annotations

import io
import json

import pytest
from PIL import Image

from src.core import db
from src.core.classifier import RiskClassifier
from src.core.providers import VisionError
from src.utils.config import settings


class FakeVisionClient:
    """按脚本返回预设输出的假客户端。

    responses 按调用顺序消费；用完返回空串（模拟 deepseek-flash 偶发空输出）。
    """

    def __init__(self, responses: list[str] | None = None, *, available: bool = True, error: str | None = None):
        self.responses = list(responses or [])
        self.calls: list[str] = []
        self.name = "fake"
        self.model = "fake-model"
        self._available = available
        self._error = error

    def available(self) -> bool:
        return self._available

    def complete(self, image_b64: str, prompt: str, *, json_mode: bool = True) -> str:
        self.calls.append(prompt)
        if self._error:
            raise VisionError(self._error)
        if not self.responses:
            return ""
        return self.responses.pop(0)


def make_image_bytes(width: int = 320, height: int = 240, color: str = "#8a8a8a") -> bytes:
    """造一张测试用的小图。"""
    buf = io.BytesIO()
    Image.new("RGB", (width, height), color).save(buf, format="JPEG", quality=80)
    return buf.getvalue()


def json_text(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False)


SCENE_CORRIDOR = json_text(
    {"scene": "corridor", "scene_label": "居民楼楼道", "evidence": ["画面两侧是灰白色墙壁"]}
)
SCENE_NON_CORRIDOR = json_text(
    {"scene": "non_corridor", "scene_label": "客厅", "evidence": ["画面中央是茶几和沙发"]}
)
RISK_HIGH = json_text(
    {
        "level": "高风险",
        "confidence": 0.93,
        "evidence": ["画面右侧有一辆正在充电的电动车"],
        "reason": "楼道内存在电动车充电，属高风险。",
        "suggestion": "立即劝离并切断充电电源。",
    }
)


@pytest.fixture(scope="session", autouse=True)
def isolated_storage(tmp_path_factory):
    """把数据库和上传目录指到临时目录，别污染真实 data/。"""
    root = tmp_path_factory.mktemp("storage")
    settings.db_path = root / "state.db"
    settings.upload_dir = root / "uploads"
    yield
    db.close_connections()


@pytest.fixture(autouse=True)
def clean_records():
    """每个用例前清空记录表 —— 临时库是 session 级的，不清会互相串数据。"""
    db.init_schema()
    with db.tx() as conn:
        conn.execute("DELETE FROM records")
    yield


@pytest.fixture
def fake_client():
    """默认脚本：先判场景（楼道），再判等级（高风险）。"""
    return FakeVisionClient([SCENE_CORRIDOR, RISK_HIGH])


@pytest.fixture
def classifier(fake_client):
    return RiskClassifier(fake_client, max_retries=1)


@pytest.fixture
def client(monkeypatch):
    """FastAPI 测试客户端，模型调用被替换成脚本化的假客户端。"""
    from fastapi.testclient import TestClient

    from src.api import app as app_module

    def _get_classifier(provider=None):
        fake = FakeVisionClient([SCENE_CORRIDOR, RISK_HIGH])
        return RiskClassifier(fake, max_retries=1)

    monkeypatch.setattr(app_module, "get_classifier", _get_classifier)

    with TestClient(app_module.app) as test_client:
        yield test_client
