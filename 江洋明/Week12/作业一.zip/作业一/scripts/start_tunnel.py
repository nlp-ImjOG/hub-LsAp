"""用 Cloudflare 快速隧道把本地服务暴露成一个**受信任的公网 https 地址**。

这是给手机开摄像头最省事的一条路：
- 不需要在手机上装 CA 证书、不需要点「继续前往」告警
- 证书是真实 CA 签发的，浏览器不会有任何拦截
- 手机连家里的 wifi 或者流量都行

前提：装一次 cloudflared（免费、不用注册账号）。

Windows:
    winget install --id Cloudflare.cloudflared
    # 或从 https://github.com/cloudflare/cloudflared/releases 下载 cloudflared-windows-amd64.exe
    # 放进项目目录 scripts/ 下即可（脚本会一并找）

macOS / Linux:
    brew install cloudflared          # macOS
    # 或 sudo apt install cloudflared  # Debian/Ubuntu

用法：
    # 先照常起本地服务（另开一个终端）
    python -X utf8 -m uvicorn src.api.app:app --port 8000
    # 再起隧道
    python -X utf8 scripts/start_tunnel.py --port 8000

安全提醒：隧道会把服务暴露到公网，**且本项目没有鉴权**。
任何拿到这个 URL 的人都能调用 /api/analyze 消耗你的 key 额度。
用完请 Ctrl+C 关掉，别把 URL 贴到公开的地方。
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import threading
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
URL_PATTERN = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")


def find_cloudflared() -> str | None:
    """先找 PATH，再找项目 scripts/ 目录下的可执行文件。"""
    found = shutil.which("cloudflared")
    if found:
        return found
    local = PROJECT_ROOT / "scripts" / "cloudflared.exe"
    if local.exists():
        return str(local)
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8000, help="本地服务端口")
    args = parser.parse_args()

    exe = find_cloudflared()
    if not exe:
        print("=" * 66)
        print("  没找到 cloudflared。先装一个（免费、不用注册）：")
        print("=" * 66)
        print("  Windows : winget install --id Cloudflare.cloudflared")
        print("            或从 https://github.com/cloudflare/cloudflared/releases")
        print("            下载 cloudflared-windows-amd64.exe 放到 scripts/ 目录下")
        print("  macOS   : brew install cloudflared")
        print("  Linux   : sudo apt install cloudflared")
        print("=" * 66)
        return 1

    local = f"http://127.0.0.1:{args.port}"
    print(f"本地服务：{local}")
    print("正在建立 Cloudflare 快速隧道…\n")

    proc = subprocess.Popen(
        [exe, "tunnel", "--url", local, "--no-autoupdate"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    tunnel_url: list[str] = []

    def watch() -> None:
        for line in proc.stdout or []:
            line = line.rstrip()
            if not line:
                continue
            match = URL_PATTERN.search(line)
            if match and not tunnel_url:
                tunnel_url.append(match.group(0))
                print("=" * 66)
                print("  隧道已建立，手机直接打开这个地址（真实 CA 证书，无需放行）：")
                print("=" * 66)
                print(f"    {match.group(0)}")
                print("=" * 66)
                print("\n  用完 Ctrl+C 关掉 —— 这个地址是公网可访问的，本项目没有鉴权。\n")
            elif "error" in line.lower() or "failed" in line.lower():
                print("  [cloudflared]", line)

    thread = threading.Thread(target=watch, daemon=True)
    thread.start()

    try:
        return proc.wait()
    except KeyboardInterrupt:
        print("\n正在关闭隧道…")
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
        return 0


if __name__ == "__main__":
    sys.exit(main())
