"""实测：https + 自签名证书下，手机浏览器能不能开摄像头。

模拟「用户在证书告警页点了『继续前往』」——对应 Playwright 的 ignore_https_errors。
同时用 http://<局域网IP> 做对照组，看浏览器是不是真的按 secure context 拦。
"""

from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path.home() / "AppData" / "Local" / "ms-playwright"
exe = str(sorted(ROOT.glob("chromium-*/chrome-win64/chrome.exe"), reverse=True)[0])

HTTPS = "https://127.0.0.1:8443"
HTTP_LAN = "http://172.16.19.92:8000"


def probe(page, url, label):
    print(f"\n───── {label} ─────")
    print("  URL:", url)
    try:
        page.goto(url, wait_until="domcontentloaded", timeout=15000)
    except Exception as exc:
        print("  打开失败:", str(exc).splitlines()[0][:160])
        return
    print("  isSecureContext :", page.evaluate("window.isSecureContext"))
    print("  有 mediaDevices  :", page.evaluate("!!navigator.mediaDevices"))
    print("  有 getUserMedia  :", page.evaluate("!!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)"))
    # 真去调一次，看浏览器拦不拦
    res = page.evaluate(
        """async () => {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return 'NO_API';
            try {
                const s = await navigator.mediaDevices.getUserMedia({video: true});
                const t = s.getVideoTracks()[0];
                const label = t.label || '(无标签)';
                s.getTracks().forEach(x => x.stop());
                return 'OK: ' + label;
            } catch (e) {
                return 'ERR: ' + e.name + ' / ' + e.message;
            }
        }"""
    )
    print("  getUserMedia 实调:", res)


with sync_playwright() as p:
    b = p.chromium.launch(
        executable_path=exe,
        args=["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"],
    )

    # —— 对照组：局域网 IP + http（模拟现在的手机访问方式）——
    ctx_http = b.new_context(permissions=["camera"])
    probe(ctx_http.new_page(), HTTP_LAN, "对照组：局域网 IP + http（现在的用法）")

    # —— 实验组：https + 自签名证书，用户点过「继续前往」——
    ctx_https = b.new_context(permissions=["camera"], ignore_https_errors=True)
    probe(ctx_https.new_page(), HTTPS, "实验组：https + 自签名证书（已放行证书告警）")

    b.close()
