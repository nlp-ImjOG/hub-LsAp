"""用 https 起服务 —— 手机开摄像头的前提。

浏览器只在 secure context（https 或 localhost）下开放 `getUserMedia`，
手机用 `http://192.168.x.x:8000` 访问会被直接拒掉摄像头。

用法：
    python -X utf8 scripts/start_https.py
    python -X utf8 scripts/start_https.py --port 8443 --host 0.0.0.0
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from scripts.make_cert import detect_ips, format_url, make_cert  # noqa: E402

DEFAULT_PORT = 8443


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--cert-dir", default=str(PROJECT_ROOT / "certs"))
    parser.add_argument("--regen", action="store_true", help="重新生成证书")
    args = parser.parse_args()

    cert_dir = Path(args.cert_dir)
    cert_path = cert_dir / "cert.pem"
    key_path = cert_dir / "key.pem"

    if args.regen or not (cert_path.exists() and key_path.exists()):
        print("正在生成自签名证书…")
        cert_path, key_path = make_cert(cert_dir)

    ips = detect_ips()
    print("\n" + "=" * 62)
    print("  https 已就绪，手机用下面任意一个地址访问：")
    print("=" * 62)
    for ip in ips:
        print("    " + format_url(ip, args.port))
    print(f"    https://localhost:{args.port}")
    print()
    print("  手机首次打开会提示证书不受信任 —— 点「高级 → 继续前往」放行，")
    print("  之后就是 secure context，摄像头可用。")
    print("=" * 62 + "\n")

    cmd = [
        sys.executable, "-X", "utf8", "-m", "uvicorn", "src.api.app:app",
        "--host", args.host,
        "--port", str(args.port),
        "--ssl-keyfile", str(key_path),
        "--ssl-certfile", str(cert_path),
    ]
    print("启动：", " ".join(cmd), "\n")
    try:
        return subprocess.call(cmd, cwd=str(PROJECT_ROOT))
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
