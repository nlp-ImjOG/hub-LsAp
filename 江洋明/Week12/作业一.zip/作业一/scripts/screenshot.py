"""用 Playwright 跑一遍前端，生成作业截图。

用法：
    # 先启动后端
    python -X utf8 -m uvicorn src.api.app:app --host 127.0.0.1 --port 8000
    # 再跑（另开一个终端）
    python scripts/screenshot.py --base http://127.0.0.1:8000 --image /path/to/corridor.jpg

产出（默认写到 docs/）：
    01-首页.png / 02-摄像头取景.png / 03-已选图片.png / 04-识别结果.png / 05-历史记录.png / 06-手机端.png

说明：Chromium 用 `--use-fake-device-for-media-stream` 起一个假摄像头，
所以「拍照」这条路径在无摄像头的机器上也能自动验证。
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def find_chromium() -> str | None:
    """找 Playwright 已下载的 chromium。版本号可能和当前 playwright 不匹配，手动定位。"""
    root = Path.home() / "AppData" / "Local" / "ms-playwright"
    if not root.exists():
        return None
    candidates = sorted(root.glob("chromium-*/chrome-win64/chrome.exe"), reverse=True)
    return str(candidates[0]) if candidates else None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="http://127.0.0.1:8000")
    parser.add_argument("--image", default=None, help="用于演示的图片，默认取测试素材")
    parser.add_argument("--out", default=str(PROJECT_ROOT / "docs"))
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    image = Path(args.image) if args.image else PROJECT_ROOT / "docs" / "samples" / "corridor-clean.jpg"
    if not image.exists():
        print(f"[提示] 演示图片不存在: {image}，跳过上传与识别步骤")
        image = None

    issues: list[str] = []
    executable = find_chromium()

    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path=executable,
            args=["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"],
        )
        ctx = browser.new_context(
            viewport={"width": 1280, "height": 900},
            permissions=["camera"],
        )
        page = ctx.new_page()
        page.on("console", lambda m: issues.append(f"[console.{m.type}] {m.text}") if m.type == "error" else None)
        page.on("pageerror", lambda e: issues.append(f"[pageerror] {e}"))

        page.goto(f"{args.base}/", wait_until="networkidle")
        page.wait_for_timeout(1500)
        print("标题:", page.title())
        print("健康徽标:", page.locator("header .badge").inner_text().replace("\n", " "))
        page.screenshot(path=str(out_dir / "01-首页.png"), full_page=True)

        # 摄像头通道（Chromium 假摄像头）
        page.locator("button", has_text="开启摄像头").first.click()
        # 按钮变成「拍摄 / 关闭摄像头」才算摄像头真的开了
        page.wait_for_selector("button:has-text('拍摄')", timeout=15000)
        page.wait_for_timeout(1500)
        print("摄像头:", "已开启" if page.locator("video").is_visible() else "未开启")
        print("取景分辨率:", page.evaluate("() => { const v=document.querySelector('video'); return v ? v.videoWidth + 'x' + v.videoHeight : '—' }"))
        page.screenshot(path=str(out_dir / "02-摄像头取景.png"), full_page=True)

        if image:
            page.locator("button", has_text="上传图片").first.click()
            page.wait_for_timeout(400)
            page.set_input_files("input[type=file]", str(image))
            page.wait_for_timeout(1500)
            page.screenshot(path=str(out_dir / "03-已选图片.png"), full_page=True)

            page.locator("button", has_text="开始识别").first.click()
            page.wait_for_selector(".level", timeout=180000)
            page.wait_for_timeout(800)
            print("识别结果:", page.locator(".level").inner_text().replace("\n", " | "))
            page.screenshot(path=str(out_dir / "04-识别结果.png"), full_page=True)

        page.wait_for_timeout(600)
        print("历史条数:", page.locator(".record").count())
        # 只截「识别历史」这一块，别跟识别结果那张重复
        page.locator(".card").last.screenshot(path=str(out_dir / "05-历史记录.png"))

        mob = ctx.new_page()
        mob.set_viewport_size({"width": 390, "height": 844})
        mob.goto(f"{args.base}/", wait_until="networkidle")
        mob.wait_for_timeout(1500)
        mob.screenshot(path=str(out_dir / "06-手机端.png"), full_page=True)

        browser.close()

    print("\n=== 控制台错误 ===")
    print("\n".join(issues) if issues else "（无）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
