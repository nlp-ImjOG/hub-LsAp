"""生成自签名证书，让手机用 https 访问（secure context 才能开摄像头）。

为什么需要它
------------
浏览器只在 **secure context**（https 或 localhost）下开放 `getUserMedia`。
用 `http://192.168.x.x:8000` 从手机访问时，Chrome / Safari 会直接拒绝摄像头权限，
本页 `index.html` 会提示「当前浏览器环境不允许访问摄像头」。

自签名证书能在**本机 / 局域网**解决这件事：手机首次访问会看到证书告警，
点「高级 → 继续前往」之后页面就是 secure context，摄像头可用。
浏览器会记住这次例外，之后不再打扰。

证书里必须写进三样 SAN，缺一个都会报错：
- DNS:localhost      —— 电脑本机访问
- IP:127.0.0.1 / ::1 —— 本机回环
- IP:<局域网 IP>     —— 手机访问；**必须是 IP 类型 SAN**，写成 DNS 名会报
                        ERR_CERT_COMMON_NAME_INVALID

用法：
    python -X utf8 scripts/make_cert.py            # 生成到 certs/
    python -X utf8 scripts/make_cert.py --out d:/tmp/certs
"""

from __future__ import annotations

import argparse
import ipaddress
import socket
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = PROJECT_ROOT / "certs"

# 公共 CA 对叶子证书的最长有效期是 398 天，这里给 825 天（自签不受限，但浏览器按 CA 规则对待）
VALID_DAYS = 825
KEY_SIZE = 2048  # RSA 2048，老版本 Android WebView 也认；EC 在部分机型上会出问题


def _lan_ip_udp() -> str | None:
    """连一个公网 UDP 地址（不发包），内核会挑出默认出口网卡。"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.3)
        s.connect(("223.5.5.5", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def _lan_ip_ipconfig() -> list[str]:
    """Windows：解析 ipconfig 输出，把所有 IPv4 捞出来。"""
    try:
        out = subprocess.run(
            ["ipconfig"], capture_output=True, text=True, timeout=10, encoding="utf-8", errors="ignore"
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    ips = []
    for line in out.splitlines():
        line = line.strip()
        if line.lower().startswith("ipv4"):
            value = line.split(":", 1)[-1].strip()
            try:
                ipaddress.IPv4Address(value)
            except ValueError:
                continue
            ips.append(value)
    return ips


def detect_ips() -> list[str]:
    """找出本机所有该写进证书的 IP。"""
    # 回环必须留 —— https://127.0.0.1 靠 IP Address SAN 才不会被判 ERR_CERT_COMMON_NAME_INVALID
    found: list[str] = ["127.0.0.1", "::1"]

    udp = _lan_ip_udp()
    if udp:
        found.append(udp)

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            found.append(info[4][0])
    except OSError:
        pass

    if sys.platform == "win32":
        found.extend(_lan_ip_ipconfig())

    # 去重；只丢掉 link-local / unspecified，回环和真实网卡地址都保留
    out: list[str] = []
    for ip in found:
        if ip in out:
            continue
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if addr.is_link_local or addr.is_unspecified:
            continue
        out.append(ip)
    return out


def make_cert(out_dir: Path) -> tuple[Path, Path]:
    """生成证书，返回 (证书路径, 私钥路径)。"""
    out_dir.mkdir(parents=True, exist_ok=True)
    cert_path = out_dir / "cert.pem"
    key_path = out_dir / "key.pem"

    key = rsa.generate_private_key(public_exponent=65537, key_size=KEY_SIZE)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, "楼道消防隐患识别"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "AI大模型应用 第十二周作业"),
    ])

    ips = detect_ips()
    san: list[x509.GeneralName] = [
        x509.DNSName("localhost"),
        x509.DNSName(socket.gethostname()),
    ]
    for ip in ips:
        san.append(
            x509.IPAddress(ipaddress.ip_address(ip))
            if ":" in ip
            else x509.IPAddress(ipaddress.IPv4Address(ip))
        )

    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=1))  # 留一天时钟偏移余量
        .not_valid_after(now + timedelta(days=VALID_DAYS))
        .add_extension(x509.SubjectAlternativeName(san), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                content_commitment=False,
                key_encipherment=True,
                data_encipherment=False,
                key_agreement=False,
                key_cert_sign=False,
                crl_sign=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]), critical=False
        )
        .sign(key, hashes.SHA256())
    )

    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(
        key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    # 私钥别让同目录的其他人读到
    try:
        key_path.chmod(0o600)
    except OSError:
        pass
    return cert_path, key_path


def format_url(ip: str, port: int) -> str:
    """拼 URL。IPv6 要加方括号，否则 https://::1:8443 解析不出来。"""
    host = f"[{ip}]" if ":" in ip else ip
    return f"https://{host}:{port}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(DEFAULT_OUT), help="输出目录，默认 certs/")
    parser.add_argument("--force", action="store_true", help="已存在也重新生成")
    parser.add_argument("--port", type=int, default=8000, help="只是打印 URL 时用")
    args = parser.parse_args()

    out_dir = Path(args.out)
    cert_path = out_dir / "cert.pem"
    key_path = out_dir / "key.pem"

    if cert_path.exists() and key_path.exists() and not args.force:
        print(f"证书已存在，跳过生成：{cert_path}")
        print("要重新生成请加 --force")
    else:
        cert_path, key_path = make_cert(out_dir)
        print(f"证书已生成：{cert_path}")
        print(f"私钥已生成：{key_path}")

    print("\n证书覆盖的地址：")
    print("  https://localhost:" + str(args.port))
    for ip in detect_ips():
        print("  " + format_url(ip, args.port))

    print("\n注意：自签名证书手机首次访问会告警，点「高级 / 继续前往」放行即可。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
