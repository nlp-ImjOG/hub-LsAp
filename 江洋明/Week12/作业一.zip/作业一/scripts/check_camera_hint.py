"""验证前端的摄像头提示：http 下要给出可操作的解法，https 下不该报错。"""

from __future__ import annotations

import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path.home() / "AppData" / "Local" / "ms-playwright"
executable = str(sorted(ROOT.glob("chromium-*/chrome-win64/chrome.exe"), reverse=True)[0])

CASES = [
    ("http  局域网 IP", "http://172.16.19.92:8000", False),
    ("https 局域网 IP", "https://172.16.19.92:8443", True),
]


def main() -> int:
    failed = []
    with sync_playwright() as p:
        b = p.chromium.launch(
            executable_path=executable,
            args=["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"],
        )
        for label, url, expect_ok in CASES:
            ctx = b.new_context(permissions=["camera"], ignore_https_errors=True)
            page = ctx.new_page()
            page.goto(url, wait_until="networkidle", timeout=30000)
            page.locator("button", has_text="开启摄像头").first.click()
            page.wait_for_timeout(2500)

            hint = page.locator(".hint").inner_text() if page.locator(".hint").count() else ""
            cam_on = page.locator("button", has_text="拍摄").count() > 0
            secure = page.evaluate("window.isSecureContext")

            print(f"\n───── {label} ─────")
            print("  isSecureContext:", secure)
            print("  摄像头已开启   :", cam_on)
            print("  提示条         :", (hint[:120] + "…") if hint else "(无)")

            if expect_ok:
                if not cam_on:
                    failed.append(f"{label}: 摄像头没开起来")
                if hint:
                    failed.append(f"{label}: https 下不该有提示条，实际是「{hint[:60]}」")
            else:
                if cam_on:
                    failed.append(f"{label}: http 下不应该能开摄像头")
                if "isSecureContext" not in hint and "https" not in hint:
                    failed.append(f"{label}: 提示条没给出解法，实际是「{hint[:60]}」")

            ctx.close()
        b.close()

    print("\n" + ("=" * 60))
    if failed:
        for f in failed:
            print("❌", f)
        return 1
    print("✅ 两种场景的前端行为都符合预期")
    return 0


if __name__ == "__main__":
    sys.exit(main())
