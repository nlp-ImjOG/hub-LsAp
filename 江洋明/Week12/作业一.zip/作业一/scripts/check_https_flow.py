"""端到端验证：手机视角（局域网 IP + https + 已放行证书告警）走通拍照全流程。

对照脚本 check_secure_context.py 只验了 API 存在性，这个脚本验真实交互：
开启摄像头 → 取景 → 拍摄 → 预览出图。
"""

from __future__ import annotations

import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ROOT = Path.home() / "AppData" / "Local" / "ms-playwright"

executable = str(sorted(ROOT.glob("chromium-*/chrome-win64/chrome.exe"), reverse=True)[0])
URL = sys.argv[1] if len(sys.argv) > 1 else "https://172.16.19.92:8443"


def main() -> int:
    ok = True
    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path=executable,
            args=["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"],
        )
        # ignore_https_errors == 用户在证书告警页点了「继续前往」
        ctx = browser.new_context(
            viewport={"width": 390, "height": 844},  # 手机尺寸
            permissions=["camera"],
            ignore_https_errors=True,
        )
        page = ctx.new_page()
        errors: list[str] = []
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errors.append(str(e)))

        page.goto(URL, wait_until="networkidle", timeout=30000)
        print("URL            :", URL)
        print("isSecureContext:", page.evaluate("window.isSecureContext"))

        # 1. 开启摄像头
        page.locator("button", has_text="开启摄像头").first.click()
        page.wait_for_selector("button:has-text('拍摄')", timeout=15000)
        page.wait_for_timeout(1200)
        print("摄像头         : 已开启，视频尺寸",
              page.evaluate("() => { const v=document.querySelector('video'); return v.videoWidth + 'x' + v.videoHeight }"))
        # 留一张「https 下手机摄像头可用」的证据图
        shot = PROJECT_ROOT / "docs" / "07-https手机端拍照.png"
        shot.parent.mkdir(parents=True, exist_ok=True)
        page.screenshot(path=str(shot))
        print("已保存         :", shot)

        # 2. 拍摄
        page.locator("button", has_text="拍摄").first.click()
        page.wait_for_timeout(2000)
        has_preview = page.evaluate("() => !!document.querySelector('.stage img')")
        meta = page.locator(".meta").inner_text().replace("\n", " ") if page.locator(".meta").count() else "(无)"
        print("拍摄出图       :", "成功" if has_preview else "失败", "|", meta)
        ok = ok and has_preview

        # 3. 识别（走真实模型）
        page.locator("button", has_text="开始识别").first.click()
        page.wait_for_selector(".level", timeout=180000)
        print("识别结果       :", page.locator(".level").inner_text().replace("\n", " | "))

        # 4. 页面提示条不应该再报「不允许访问摄像头」
        hint = page.locator(".hint").inner_text() if page.locator(".hint").count() else ""
        print("提示条         :", hint if hint else "(无)")

        print("控制台错误     :", "\n    ".join(errors) if errors else "(无)")
        browser.close()

    print("\n结论：", "✅ https 通道下手机拍照全流程走通" if ok else "❌ 拍照失败")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
