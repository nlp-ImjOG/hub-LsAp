@echo off
chcp 65001 >nul
cd /d %~dp0

echo ============================================
echo   楼道消防隐患多模态识别 · https 启动
echo   （手机开摄像头需要 https）
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [错误] 找不到 python，请先安装 Anaconda 并加入 PATH。
    pause
    exit /b 1
)

if not exist ".env" (
    echo [提示] 未找到 .env，正在从 .env.example 复制一份。
    copy ".env.example" ".env" >nul
    echo        请打开 .env 填入 API Key 后重新运行本脚本。
    pause
    exit /b 1
)

echo [检查] 依赖...
python -c "import fastapi, uvicorn, openai, PIL" >nul 2>nul
if errorlevel 1 (
    echo [安装] 正在安装依赖，请稍候...
    python -m pip install -r requirements.txt
)

python -c "import cryptography" >nul 2>nul
if errorlevel 1 (
    echo [安装] 正在安装 cryptography（生成自签名证书用）...
    python -m pip install cryptography
)

echo.
python -X utf8 scripts\start_https.py --port 8443
