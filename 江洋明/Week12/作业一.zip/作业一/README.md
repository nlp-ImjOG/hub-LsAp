# 楼道消防安全隐患多模态识别应用

> 第十二周 作业一 · 江洋明
> 参考案例：`Week12/Teacher/.../02-多模态大模型/案例-多模态内容理解.ipynb`
> 作业指定模型：**ds flash 4.1**（DeepSeek `deepseek-flash`）

拍照或上传一张楼道照片，网页实时给出消防隐患等级判定（无风险 / 低风险 / 中风险 / 高风险 / 非楼道），
并附画面依据、判定理由与处置建议，全过程落 SQLite 留痕。

---

## 一、快速开始

```bash
# 1. 进到项目目录
cd 12-江洋明-第十二周作业/作业一

# 2. 装依赖
pip install -r requirements.txt

# 3. 配 key（复制模板再填，.env 已在 .gitignore 里，不会被提交）
cp .env.example .env
#   Windows: copy .env.example .env
# 然后编辑 .env，把 DEEPSEEK_API_KEY 换成你自己的 key

# 4. 起服务
python -X utf8 -m uvicorn src.api.app:app --host 0.0.0.0 --port 8000
```

打开 **http://localhost:8000** 即可。

Windows 也可以双击 `start_server.bat`；Linux/macOS 用 `start_server.sh`。

### 跑测试

```bash
python -X utf8 -m pytest -q
```

51 个用例，**全部离线**——模型调用被 mock 掉，不需要 key、不消耗额度。

---

## 二、让手机能开摄像头（https）

### 为什么必须上 https

浏览器只在 **secure context**（`https` 或 `localhost`）下开放 `getUserMedia`。
用 `http://192.168.x.x:8000` 从手机访问，`navigator.mediaDevices` **整个对象都不存在**——
不是权限被拒，是 API 压根没暴露。

本机实测（`scripts/check_secure_context.py`，Chromium 真实引擎）：

| | `http://172.16.19.92:8000` | `https://…:8443`（自签名，已放行告警） |
| --- | --- | --- |
| `window.isSecureContext` | `False` | `True` |
| `navigator.mediaDevices` | **不存在** | 存在 |
| `getUserMedia()` 实调 | 拿不到 API | **成功返回 video track** |

### 方案 A：自签名证书（已内置，零外部依赖）

```bash
python -X utf8 scripts/start_https.py          # 默认 8443
# Windows 也可以双击 start_https.bat
```

脚本会：

1. 自动生成自签名证书到 `certs/`（SAN 里写进 `localhost`、`127.0.0.1`、本机所有局域网 IP）；
2. 用 uvicorn 的 `--ssl-keyfile/--ssl-certfile` 起 https；
3. 打印手机该访问的地址。

```
    https://172.16.19.92:8443    ← 手机用这个
```

**手机首次打开会提示证书不受信任**，点「高级 → 继续前往」放行，之后浏览器会记住这次例外。
放行之后页面就是 secure context，摄像头立刻可用 —— 上面的实测就是在「已放行」状态下跑通的。

证书要点（`scripts/make_cert.py`）：

- **SAN 里必须是 IP 类型**。写成 DNS 名的话，Chrome 报 `ERR_CERT_COMMON_NAME_INVALID`。
- `127.0.0.1` / `::1` / 局域网 IP 都要写进去，漏一个对应地址就连不上。
- RSA 2048 —— 部分老版本 Android WebView 对 EC 密钥不友好。
- 有效期 825 天，私钥 `chmod 600`，`certs/` 整个目录已在 `.gitignore` 里。

### 方案 B：Cloudflare 快速隧道（手机零设置）

想要一个**真实 CA 证书**、手机上连告警都不用点，用隧道：

```bash
# 另开一个终端，先照常起本地服务
python -X utf8 -m uvicorn src.api.app:app --port 8000

# 再起隧道
python -X utf8 scripts/start_tunnel.py --port 8000
```

脚本会打印一个 `https://xxx.trycloudflare.com` 地址，手机直接打开就能开摄像头，**不需要装任何证书**。

需要先装一次 cloudflared（免费、不用注册账号）：

```bash
winget install --id Cloudflare.cloudflared   # Windows
brew install cloudflared                      # macOS
sudo apt install cloudflared                  # Debian/Ubuntu
```

> ⚠️ **隧道把服务暴露到公网，而本项目没有鉴权** —— 任何拿到这个 URL 的人都能调
> `/api/analyze` 消耗你的 key 额度。用完立刻 Ctrl+C，别把 URL 贴到公开的地方。

### 方案 C：mkcert（局域网内完全受信任）

想要手机上也**零告警**，但又不想暴露到公网，用 mkcert 生成一个本地 CA 签发的证书，
再把 CA 根证书装到手机上（Android：设置 → 安全 → 加密与凭据 → 安装证书 → CA 证书）。

```bash
mkcert -install                      # 在电脑上装 CA
mkcert -cert-file certs/cert.pem -key-file certs/key.pem localhost 127.0.0.1 192.168.1.10
python -X utf8 scripts/start_https.py  # 会复用 certs/ 下已有的证书
```

### 三种方案怎么选

| | 手机要装东西吗 | 要点告警吗 | 暴露公网吗 | 适合 |
| --- | --- | --- | --- | --- |
| A 自签名 | 否 | **是**，一次 | 否 | 本机演示、老师当场看 |
| B Cloudflare 隧道 | 否 | 否 | **是** | 远程演示、发给同学 |
| C mkcert | **是**（CA 根证书） | 否 | 否 | 长期自用 |

**作业演示建议用 A**：离线、无公网暴露，只多点一次「继续前往」。

---

## 三、界面

| 截图 | 说明 |
| --- | --- |
| ![首页](docs/01-首页.png) | 首页：采集区 + 识别结果区 + 历史记录 |
| ![摄像头取景](docs/02-摄像头取景.png) | **拍照**通道：`getUserMedia` 取景（图为 Chromium 假摄像头） |
| ![已选图片](docs/03-已选图片.png) | **上传图片**通道：前端压缩后预览 |
| ![识别结果](docs/04-识别结果.png) | 识别结果：等级 + 置信度 + 画面依据 + 处置建议 + 原图回看 |
| ![历史记录](docs/05-历史记录.png) | 历史记录与分级统计 |
| ![手机端](docs/06-手机端.png) | 手机端自适应布局（390×844） |
| ![https手机端拍照](docs/07-https手机端拍照.png) | **https 下手机摄像头可用**（390×844，取景中） |

示例素材在 `docs/samples/`：`corridor-clean.jpg`（干净楼道 → 无风险）、`non-corridor-lobby.jpg`（门厅 → 非楼道）。

---

## 四、判定标准

判定标准的**唯一事实源**是作业原文（`src/core/prompts.py` 的 `RUBRIC`，逐字照抄，勿改写）：

> 你是一个专业消防专家，擅长识别各种风险。请帮我识别消防安全隐患以及隐患的危险程度。根据楼道中是否存在大量堆积物，堆积物是否可燃以及是否有起火风险将隐患分为无风险、低风险、中风险、高风险。
>
> - **高风险**：楼道中出现电动车、电瓶、飞线充电等可能起火的元素。
> - **中风险**：楼道中存在大量堆积物严重影响通行或堆放大量纸箱、木质家具等能造成火势蔓延的堵塞物。
> - **低风险**：存在楼道堆物现象但不严重。
> - **无风险**：楼道干净，无堆放物品。
> - **非楼道**：一些与楼道无关的图片。

### 关于「无隐患 / 中等风险」

作业原文写的是「无风险 / 中风险」，而 notebook 总纲那句写的是「无隐患 / 中等风险」。
**以作业原文为准**（作业原文才是评分标准），但模型很可能混用两种说法，
所以 `src/core/models.py` 做了别名归一化，两种写法都落到同一个等级：

| 输入 | 归一化结果 |
| --- | --- |
| `高风险` / `存在高风险隐患` | `高风险` |
| `中风险` / `中等风险` | `中风险` |
| `低风险` | `低风险` |
| `无风险` / `无隐患` | `无风险` |
| `非楼道` | `非楼道` |

---

## 五、架构

```
┌──────────────────────── 浏览器 ────────────────────────┐
│  Vue 3 (CDN, 单文件 index.html, 零构建)                 │
│    ① 拍照  getUserMedia → canvas 拍摄                    │
│    ② 上传  <input type=file> + canvas 压缩 (长边≤1280)   │
│    ③ 识别  FormData → POST /api/analyze                 │
│    ④ 展示  等级 / 置信度 / 画面依据 / 建议 / 原图         │
└───────────────────────────┬──────────────────────────────┘
                            │ HTTP(S)
┌───────────────────────────▼──────────────────────────────┐
│  FastAPI (src/api/)                                      │
│    /            前端页面        /api/analyze  识别       │
│    /health      健康检查        /api/records  历史        │
│    /api/providers 模型切换      /api/stats     统计        │
│    /uploads/{name} 原图回看                                │
└───────────────────────────┬──────────────────────────────┘
                            │
┌───────────────────────────▼──────────────────────────────┐
│  分类器 (src/core/classifier.py)  —— 两阶段              │
│    阶段一 场景判定：是不是楼道？                           │
│            ├─ 非楼道 → 直接出结论（只调 1 次模型）          │
│            └─ 是楼道 ↓                                   │
│    阶段二 风险分级：四档里选一档（再调 1 次模型）           │
│    解析失败 → 重试（追加更严格的输出指令）→ 仍失败则降级   │
└───────────────────────────┬──────────────────────────────┘
                            │
┌───────────────────────────▼──────────────────────────────┐
│  Provider 抽象层 (src/core/providers.py)                 │
│    VisionClient (ABC)                                    │
│      ├─ OpenAICompatVisionClient  image_url(base64)      │
│      └─ ProviderSpec 注册表：deepseek / dashscope / zhipu │
└───────────────────────────┬──────────────────────────────┘
                            │
                  OpenAI 兼容协议（base64 图片 + JSON 输出）
              deepseek-flash ｜ qwen-vl ｜ glm-4v-flash
                            │
┌───────────────────────────▼──────────────────────────────┐
│  持久化 (src/core/db.py)  SQLite(WAL) + 原图落盘          │
│    records 表：等级 / 置信度 / 依据 / 理由 / 建议 / 耗时   │
└──────────────────────────────────────────────────────────┘
```

### 为什么拆成两阶段

「非楼道」和另外四档**不是一个维度**：混在一起让模型一次回答时，它会在「非楼道」和「高风险」之间摇摆。
拆开之后：

- 阶段一要回答的只有「是不是楼道」，prompt 里不含等级枚举，判定更干净；
- 阶段二的输出被硬约束在四档内，**与阶段一不可能冲突**；
- 非楼道只需 1 次模型调用，楼道 2 次。

这遵循本仓库 `00-sql-agent/docs/agent-design.md` 里的划分原则：「一个 Agent 只做一个决策」「上下文最小化」。

---

## 六、目录结构

```
作业一/
├── README.md
├── requirements.txt
├── .env.example              # key 模板（.env 本身不入库）
├── .gitignore
├── start_server.bat / .sh    # http 启动
├── start_https.bat           # https 启动（手机开摄像头用）
├── frontend/
│   └── index.html            # 前端全部代码（Vue 3 CDN，零构建，单文件）
├── src/
│   ├── api/
│   │   ├── app.py            # FastAPI 应用与全部路由
│   │   ├── deps.py           # 图片校验/压缩/落盘、分类器缓存
│   │   └── schemas.py        # Pydantic 响应模型
│   ├── core/
│   │   ├── prompts.py        # 判定标准原文 + 两阶段提示词
│   │   ├── models.py         # 等级枚举、别名归一化、结果模型
│   │   ├── providers.py      # VisionClient 抽象 + 三家 provider 注册表
│   │   ├── classifier.py     # 两阶段流程、JSON 提取、重试、兜底
│   │   └── db.py             # SQLite 建表/读写/统计
│   └── utils/
│       ├── config.py         # 环境变量配置（.env 加载）
│       └── logger.py         # 带 request-id 的日志
├── scripts/
│   ├── make_cert.py          # 生成自签名证书（SAN 含本机所有 IP）
│   ├── start_https.py        # 生成证书 + 用 https 起 uvicorn
│   ├── start_tunnel.py       # Cloudflare 快速隧道（公网 https）
│   ├── screenshot.py         # Playwright 自动截图（本文档配图来源）
│   ├── check_secure_context.py  # 实测 http/https 的 secure context 差异
│   └── check_https_flow.py   # 实测 https 下拍照全流程
├── tests/                    # 51 个离线用例
│   ├── conftest.py
│   ├── test_classifier.py
│   ├── test_db.py
│   └── test_api.py
├── docs/
│   ├── 01-首页.png … 07-https手机端拍照.png
│   └── samples/              # 示例素材
├── certs/                    # 自签名证书（已 gitignore）
└── data/                     # 运行时产物（已 gitignore）
    ├── state.db
    └── uploads/
```

---

## 七、接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/` | 前端单页 |
| GET | `/health` | provider / 模型 / key 是否配置 / 记录数 |
| GET | `/api/providers` | 可用 provider 列表（前端模型切换器） |
| POST | `/api/analyze` | `multipart/form-data`：`file`（图片）、`provider`（可选）→ 判定结果 |
| GET | `/api/records` | 历史记录，支持 `limit` / `offset` / `level` 过滤 |
| GET | `/api/records/{id}` | 单条记录 |
| DELETE | `/api/records/{id}` | 删除记录 |
| GET | `/api/stats` | 按等级统计 |
| GET | `/uploads/{name}` | 回看识别时用的原图 |

交互式文档：http://localhost:8000/docs

`POST /api/analyze` 响应示例：

```json
{
  "record_id": 5,
  "status": "ok",
  "level": "无风险",
  "confidence": 0.95,
  "scene": "corridor",
  "scene_label": "居民楼楼道走廊",
  "evidence": ["走廊地面及两侧门边未见纸箱、家具等堆积物", "通道内未发现电动车、电瓶或飞线充电设备"],
  "reason": "楼道通行空间完整畅通，地面和门边没有可燃杂物，也没有电动车、电瓶、外接电线或充电设备。",
  "suggestion": "保持楼道畅通，不要堆放物品；同时建议改善走廊照明并定期检查疏散指示、保证疏散安全。",
  "image_url": "/uploads/20261029-182344-2a64e1e2.jpg",
  "provider": "deepseek",
  "model": "deepseek-flash",
  "latency_ms": 6185
}
```

`status` 有三态，前端会分别提示：

| status | 含义 |
| --- | --- |
| `ok` | 正常识别 |
| `offline` | 没配 key 或网络不通，走离线兜底，**不会发起模型调用** |
| `failed` | 模型输出解析不出来且重试仍失败 |

---

## 八、模型与 Provider 切换

作业指定的「ds flash 4.1」= DeepSeek 的 **`deepseek-flash`**——实测它是 DeepSeek 当前唯一确认能读图的模型
（`deepseek-v4-pro` 是纯文本模型，传图会被忽略）。

三家 provider 都是 OpenAI 兼容协议，共用一套 `VisionClient`，改环境变量即可切换：

```bash
# .env
VISION_PROVIDER=deepseek          # 或 dashscope / zhipu

DEEPSEEK_API_KEY=sk-xxx
DEEPSEEK_BASE_URL=https://api.deepseek.com/v1
DEEPSEEK_MODEL=deepseek-flash

DASHSCOPE_API_KEY=sk-xxx           # 通义千问 VL
DASHSCOPE_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
DASHSCOPE_MODEL=qwen-vl-max

ZHIPUAI_API_KEY=xxx                # 智谱 GLM-4V-Flash，免费
ZHIPUAI_BASE_URL=https://open.bigmodel.cn/api/paas/v4
ZHIPUAI_MODEL=glm-4v-flash
```

前端右上角的下拉框会列出所有 provider，已配 key 的可选；不配 key 的显示「（未配置 key）」且不可选。
也可以在单次请求上覆盖：`POST /api/analyze` 带上 `provider` 字段。

**key 一律从环境变量 / `.env` 读，代码里不硬编码，`.env` 不入库。**

---

## 九、实测结果

用真实照片跑（`deepseek-flash`，本机）：

| 图片 | 判定 | 备注 |
| --- | --- | --- |
| 居民楼走廊（干净） | **无风险**（0.93~0.95） | 走了两阶段，判定依据指出「未见可燃堆积物」「未发现电动车/飞线」 |
| 居民楼走廊（脏乱） | 非楼道 | 室内地毯 + 嵌入式抽屉柜 + 尽头冰箱，被判为「住宅内部走廊或家务通道」 |
| 古典门厅 | 非楼道 | 有立柱、拼花地面 |
| 豪华酒店大堂 | 非楼道 | 罗马柱、拱门格栅 |
| 乒乓球室 | 非楼道 | 两阶段，**只调了 1 次模型**就短路返回 |

单次识别耗时 2~7 秒，取决于模型排队。

https 通道下（`scripts/check_https_flow.py`，390×844 手机视口）走通全流程：
开启摄像头 → 取景 1920×1080 → 拍摄 → 压缩到 1280×720 → 识别返回结果，控制台零错误。

---

## 十、健壮性设计

这些都是实测踩出来的坑，不是防御性编程：

| 问题 | 处理 |
| --- | --- |
| `deepseek-flash` **偶发返回空 content**（`finish_reason=stop` 却没内容） | 当作解析失败 → 重试（追加更严格的输出指令）→ 实测能救回来 |
| 模型有时输出 ```json 代码块、前后带解释文字 | `extract_json()` 四策略兜底：直接 parse → 剥代码块 → 括号配平截取 → 中文引号转英文引号 |
| 模型返回「中等风险」这类作业原文没有的写法 | 别名归一化表（见第四节） |
| 某些 provider 不支持 `response_format={"type":"json_object"}` | 收到 400 自动去掉该参数重试 |
| 没配 key / 网络不通 | 直接返回 `offline`，**不发起调用**，前端给出明确提示 |
| 前端手机照片太大 | canvas 压缩到长边 ≤1280、JPEG 质量 0.82 |
| 有人传非图片 / 空文件 | PIL 校验格式与像素上限，超限返回 400 |
| `/uploads/{name}` 被路径穿越 | `Path(name).name` 取文件名后再拼路径 |
| 局域网 http 下 `navigator.mediaDevices` 整个不存在 | 前端提前判 `isSecureContext` 并给出 https 的具体解法，而不是让用户对着空白报错 |
| 前端构建 | 无。Vue 3 走 CDN，`index.html` 单文件直接改直接生效 |

---

## 十一、已知限制

1. **证书方案要在手机上放行一次**。自签名证书（方案 A）在手机上首次访问会告警，
   需要点「高级 → 继续前往」；要完全无感用方案 B（隧道）或方案 C（mkcert 装 CA）。
2. **判定质量取决于模型**。同一张图两次调用可能给出略有差异的置信度和措辞，属正常现象。
   `deepseek-flash` 在暗光、逆光、遮挡的楼道里识别会明显变差。
3. **没有做鉴权**。`/api/analyze` 是公开的，任何人拿到地址都能消耗 key 的额度。
   本作业场景默认在内网使用；**用 Cloudflare 隧道时是公网可访问，风险更高**，用完请立刻关掉。
4. **单机 SQLite**。WAL 模式 + 每线程独立连接，够单机用；多进程部署需要换掉 `src/core/db.py`。
5. **历史记录无上限**。会一直涨，长跑场景需要定期清理或加 TTL。
6. **`deepseek-flash` 偶发空输出**目前靠重试兜底，没有从根上解决（上游行为）。

---

## 十二、参考

- 作业要求：`../作业.txt`
- 参考案例：`Week12/Teacher/.../02-多模态大模型/案例-多模态内容理解.ipynb`
  （本地 Qwen2.5-VL-7B 版；需要 24GB 显存，本机跑不动，故走作业指定的 API 路线）
- 课程内唯一商用的视觉 API 示例：`Week12/Teacher/.../04-商业API.ipynb`（智谱 `glm-4v-flash`）
- 结构化输出参考：`Week12/Teacher/.../01-langchain教程/05_结构化输出.py`
