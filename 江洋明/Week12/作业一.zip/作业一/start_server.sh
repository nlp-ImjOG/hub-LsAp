#!/usr/bin/env bash
# 楼道消防隐患多模态识别 · 后端启动
set -e
cd "$(dirname "$0")"

echo "============================================"
echo "  楼道消防隐患多模态识别 · 后端启动"
echo "============================================"

if ! command -v python >/dev/null 2>&1; then
    echo "[错误] 找不到 python"
    exit 1
fi

if [ ! -f ".env" ]; then
    echo "[提示] 未找到 .env，正在从 .env.example 复制一份。"
    cp ".env.example" ".env"
    echo "       请编辑 .env 填入 API Key 后重新运行本脚本。"
    exit 1
fi

echo "[检查] 依赖..."
if ! python -c "import fastapi, uvicorn, openai, PIL" >/dev/null 2>&1; then
    echo "[安装] 正在安装依赖，请稍候..."
    python -m pip install -r requirements.txt
fi

echo
echo "[启动] http://127.0.0.1:8000"
echo "       想让手机直接开摄像头？改跑 scripts/start_https.py（https），"
echo "       或 python scripts/start_tunnel.py（拿公网 https 地址）"
echo
exec python -X utf8 -m uvicorn src.api.app:app --host 0.0.0.0 --port 8000
