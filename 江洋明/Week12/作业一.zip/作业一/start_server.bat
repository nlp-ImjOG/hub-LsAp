@echo off
chcp 65001 >nul
cd /d %~dp0

echo ============================================
echo   楼道消防隐患多模态识别 · 后端启动
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [错误] 找不到 python，请先安装 Anaconda 并加入 PATH。
    pause
    exit /b 1
)

if not exist ".env" (
    echo [提示] 未找到 .env，正在从 .env.example 复制一份。
    copy ".env.example" ".env" >nul
    echo        请打开 .env 填入 API Key 后重新运行本脚本。
    pause
    exit /b 1
)

echo [检查] 依赖...
python -c "import fastapi, uvicorn, openai, PIL" >nul 2>nul
if errorlevel 1 (
    echo [安装] 正在安装依赖，请稍候...
    python -m pip install -r requirements.txt
)

echo.
echo [启动] http://127.0.0.1:8000
echo        手机访问请用本机局域网 IP，例如 http://192.168.1.10:8000
echo        （注意：手机浏览器只在 https 或 localhost 下才允许页内摄像头，
echo          局域网 http 访问时请用「上传图片」通道，或用 capture 调起系统相机）
echo        想让手机直接开摄像头？改跑 start_https.bat（https），
echo        或 python scripts/start_tunnel.py（拿公网 https 地址）
echo.
python -X utf8 -m uvicorn src.api.app:app --host 0.0.0.0 --port 8000
