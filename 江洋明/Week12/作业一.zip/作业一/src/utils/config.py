"""全局配置。

约定（与 01-intent-classify 保持一致）：
- API key **只**从环境变量 / 同目录 .env 读取，代码里不出现真实 key
- 数值型环境变量做容错转换，解析失败回落到默认值而不是抛异常
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
FRONTEND_DIR = PROJECT_ROOT / "frontend"
DATA_DIR = PROJECT_ROOT / "data"
UPLOAD_DIR = DATA_DIR / "uploads"


def _load_dotenv(path: Path) -> None:
    """极简 .env 加载：解析 KEY=VALUE 行，# 开头为注释。不覆盖已有环境变量。"""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(PROJECT_ROOT / ".env")


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, "").strip() or default)
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, "").strip() or default)
    except (TypeError, ValueError):
        return default


@dataclass
class Settings:
    """运行期配置。所有字段都可以用环境变量覆盖。"""

    # —— 模型接入 ——
    provider: str = "deepseek"
    llm_base_url: str = "https://api.deepseek.com/v1"
    llm_api_key: str = ""
    llm_model: str = "deepseek-flash"

    # —— 服务 ——
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    request_timeout: float = 120.0
    max_retries: int = 1

    # —— 图片约束 ——
    max_upload_bytes: int = 8 * 1024 * 1024
    max_image_pixels: int = 4096 * 4096

    # —— 路径 ——
    project_root: Path = PROJECT_ROOT
    frontend_dir: Path = FRONTEND_DIR
    data_dir: Path = DATA_DIR
    upload_dir: Path = UPLOAD_DIR
    db_path: Path = DATA_DIR / "state.db"

    @classmethod
    def from_env(cls) -> "Settings":
        provider = os.getenv("VISION_PROVIDER", "deepseek").strip().lower()
        base_url = os.getenv("LLM_BASE_URL", "").strip()
        model = os.getenv("LLM_MODEL", "").strip()
        api_key = os.getenv("LLM_API_KEY", "").strip()

        # provider 专属的 key：显式给的 LLM_API_KEY 优先，否则按 provider 取
        if not api_key:
            api_key = {
                "deepseek": os.getenv("DEEPSEEK_API_KEY", "").strip(),
                "dashscope": os.getenv("DASHSCOPE_API_KEY", "").strip(),
                "zhipu": os.getenv("ZHIPUAI_API_KEY", "").strip(),
            }.get(provider, "")

        return cls(
            provider=provider,
            llm_base_url=base_url or cls.llm_base_url,
            llm_api_key=api_key,
            llm_model=model or cls.llm_model,
            api_host=os.getenv("API_HOST", cls.api_host).strip() or cls.api_host,
            api_port=_env_int("API_PORT", cls.api_port),
            request_timeout=_env_float("REQUEST_TIMEOUT", cls.request_timeout),
            max_retries=_env_int("MAX_RETRIES", cls.max_retries),
            max_upload_bytes=_env_int("MAX_UPLOAD_BYTES", cls.max_upload_bytes),
            max_image_pixels=_env_int("MAX_IMAGE_PIXELS", cls.max_image_pixels),
        )

    @property
    def api_key_present(self) -> bool:
        return bool(self.llm_api_key)


settings = Settings.from_env()
