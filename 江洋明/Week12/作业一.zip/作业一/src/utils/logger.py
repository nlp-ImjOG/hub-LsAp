"""日志。

约定：
- 格式带 request_id，便于把一次请求的多行日志串起来
- 日志走 stderr，最终响应体走 stdout（不污染 HTTP 响应）
"""

from __future__ import annotations

import logging
import os
import sys
from contextvars import ContextVar

_request_id: ContextVar[str] = ContextVar("request_id", default="-")

LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | [req=%(request_id)s] %(message)s"
LOG_DATEFMT = "%H:%M:%S"


class _RequestIdFilter(logging.Filter):
    """把 ContextVar 里的 request_id 注入到每条 LogRecord。"""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = _request_id.get()
        return True


def set_request_id(value: str) -> None:
    _request_id.set(value)


def get_request_id() -> str:
    return _request_id.get()


def get_logger(name: str = "risk", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT))
        handler.addFilter(_RequestIdFilter())
        logger.addHandler(handler)
        logger.propagate = False
    return logger


def configure_logging(level: str | None = None) -> None:
    """统一配置根 logger。"""
    resolved = (level or os.getenv("LOG_LEVEL", "INFO")).upper()
    logging.basicConfig(
        level=getattr(logging, resolved, logging.INFO),
        format=LOG_FORMAT,
        datefmt=LOG_DATEFMT,
        stream=sys.stderr,
        force=True,
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
