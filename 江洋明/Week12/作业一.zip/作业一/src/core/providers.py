"""模型接入层。

设计目标：**换 provider 不改业务代码**。

三个候选 provider 的传图协议其实是一致的（OpenAI 兼容的
`{"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,..."}}`），
差别只有 base_url / 模型名 / 鉴权，所以底层用一个通用的
`OpenAICompatVisionClient`，上层用 `ProviderSpec` 描述每个 provider。

provider 清单与作业的关系：
- deepseek  —— 作业原文说的「ds flash 4.1」就是这个：`GET /models` 只有
               `deepseek-flash` 和 `deepseek-v4-pro` 两个模型，其中**只有
               `deepseek-flash` 能读图**（`deepseek-v4-pro` 是纯文本推理模型，
               传图会回「无法查看图片」）。传 `deepseek-v4-flash` 也会被服务端
               别名到 `deepseek-flash`。
- dashscope —— 通义千问 VL 系列（qwen-vl-max 等），百炼开放平台。
- zhipu     —— 智谱 GLM-4V-Flash，老师课件 `04-商业API.ipynb` 里演示过的商业
               vision API，官方标注为免费模型，适合当没有百炼 key 时的备选。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from openai import OpenAI

from ..utils.config import settings
from ..utils.logger import get_logger

log = get_logger("providers")


class VisionError(RuntimeError):
    """模型调用失败（网络、鉴权、限流、超时等）。"""


class VisionClient(ABC):
    """视觉模型客户端接口。"""

    name: str
    model: str

    @abstractmethod
    def complete(self, image_b64: str, prompt: str, *, json_mode: bool = True) -> str:
        """带图提问，返回模型的原始文本输出。

        image_b64 是 **纯 base64 字符串**（不含 data: 前缀），由本类负责补前缀。
        """

    @abstractmethod
    def available(self) -> bool:
        """是否具备调用条件（主要是 key 有没有配）。"""

    def ping(self) -> bool:
        """连通性自检：能否完成一次最小调用。"""
        try:
            self.complete(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
                "回复两个字：正常",
                json_mode=False,
            )
            return True
        except Exception as exc:  # noqa: BLE001 —— 自检不抛异常，只返回布尔
            log.warning("provider=%s ping 失败: %s", self.name, exc)
            return False


class OpenAICompatVisionClient(VisionClient):
    """OpenAI 兼容协议客户端，覆盖 deepseek / dashscope / zhipu 三家。"""

    def __init__(self, name: str, base_url: str, api_key: str, model: str, timeout: float) -> None:
        self.name = name
        self.base_url = base_url
        self.model = model
        self.timeout = timeout
        self._api_key = api_key
        self._client: OpenAI | None = None

    @property
    def client(self) -> OpenAI:
        if self._client is None:
            if not self._api_key:
                raise VisionError(f"provider={self.name} 未配置 API key")
            self._client = OpenAI(
                api_key=self._api_key,
                base_url=self.base_url,
                timeout=self.timeout,
                max_retries=1,
            )
        return self._client

    def available(self) -> bool:
        return bool(self._api_key)

    def complete(self, image_b64: str, prompt: str, *, json_mode: bool = True) -> str:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"},
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": 800,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        try:
            return self._create(payload)
        except Exception as exc:  # noqa: BLE001
            # 部分 provider 不支持 response_format，去掉后重试一次
            if json_mode and "response_format" in str(exc).lower():
                log.info("provider=%s 不支持 response_format，去掉后重试", self.name)
                payload.pop("response_format", None)
                return self._create(payload)
            raise VisionError(f"provider={self.name} 调用失败: {exc}") from exc

    def _create(self, payload: dict[str, Any]) -> str:
        resp = self.client.chat.completions.create(**payload)
        if not resp.choices:
            raise VisionError(f"provider={self.name} 返回空 choices")
        message = resp.choices[0].message
        # deepseek 系列会额外返回 reasoning_content，真正的答案在 content
        text = (message.content or "").strip()
        if not text:
            # content 为空但有 reasoning_content，说明模型把答案放错字段了
            text = (getattr(message, "reasoning_content", "") or "").strip()
        return text


@dataclass(frozen=True)
class ProviderSpec:
    """一个 provider 的静态描述。"""

    name: str
    label: str
    base_url: str
    model: str
    api_key_env: str
    note: str = ""


PROVIDERS: dict[str, ProviderSpec] = {
    "deepseek": ProviderSpec(
        name="deepseek",
        label="DeepSeek · deepseek-flash（作业指定的 ds flash 4.1）",
        base_url="https://api.deepseek.com/v1",
        model="deepseek-flash",
        api_key_env="DEEPSEEK_API_KEY",
        note="唯一确认支持图像输入的 DeepSeek 模型；deepseek-v4-pro 是纯文本推理模型。",
    ),
    "dashscope": ProviderSpec(
        name="dashscope",
        label="通义千问 · qwen-vl-max（百炼）",
        base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
        model="qwen-vl-max",
        api_key_env="DASHSCOPE_API_KEY",
        note="百炼开放平台；需在控制台开通并创建 API Key。",
    ),
    "zhipu": ProviderSpec(
        name="zhipu",
        label="智谱 · glm-4v-flash",
        base_url="https://open.bigmodel.cn/api/paas/v4",
        model="glm-4v-flash",
        api_key_env="ZHIPUAI_API_KEY",
        note="老师课件 04-商业API.ipynb 演示过的商业视觉 API，官方标注为免费模型。",
    ),
}


def build_client(provider_name: str | None = None, *, timeout: float | None = None) -> VisionClient:
    """按名字构造客户端。provider_name 为空时用全局配置里的默认 provider。

    构造成功不代表可用 —— key 缺失时 `available()` 返回 False，
    由上层决定是走离线兜底还是直接报错。
    """
    name = (provider_name or settings.provider).strip().lower()
    spec = PROVIDERS.get(name)
    if spec is None:
        raise VisionError(f"未知 provider: {name}（可选: {', '.join(PROVIDERS)}）")

    # 默认 provider 允许用 LLM_BASE_URL / LLM_MODEL / LLM_API_KEY 覆盖；
    # 显式切换到别的 provider 时用该 provider 自己的 base_url / model / key
    if name == settings.provider:
        base_url = settings.llm_base_url or spec.base_url
        model = settings.llm_model or spec.model
        api_key = settings.llm_api_key
    else:
        import os

        base_url = os.getenv(f"{spec.api_key_env}_BASE_URL", "").strip() or spec.base_url
        model = os.getenv(f"{spec.api_key_env}_MODEL", "").strip() or spec.model
        api_key = os.getenv(spec.api_key_env, "").strip()

    return OpenAICompatVisionClient(
        name=spec.name,
        base_url=base_url,
        api_key=api_key,
        model=model,
        timeout=timeout if timeout is not None else settings.request_timeout,
    )


def available_providers() -> list[dict[str, Any]]:
    """列出各 provider 的配置情况，供前端「模型切换器」下拉使用。"""
    import os

    out: list[dict[str, Any]] = []
    for spec in PROVIDERS.values():
        key = os.getenv(spec.api_key_env, "").strip()
        if not key and spec.name == settings.provider:
            key = settings.llm_api_key
        out.append(
            {
                "name": spec.name,
                "label": spec.label,
                "model": spec.model,
                "base_url": spec.base_url,
                "api_key_env": spec.api_key_env,
                "note": spec.note,
                "available": bool(key),
            }
        )
    return out
