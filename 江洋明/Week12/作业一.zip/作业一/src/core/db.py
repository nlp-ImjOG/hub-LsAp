"""SQLite 持久化。

沿用 01-intent-classify 的 `src/api/ext/db.py` 里踩过的坑：
- **每个线程一份 Connection**：单例连接跨线程会触发
  `sqlite3.ProgrammingError: SQLite objects created in a thread can only be used in that thread`
- **WAL + busy_timeout**：避免杀毒软件/并发写导致的 `database is locked`
"""

from __future__ import annotations

import json
import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from ..utils.config import settings
from ..utils.logger import get_logger

log = get_logger("db")

_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS records (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at   TEXT    NOT NULL,
    image_path   TEXT    NOT NULL,
    status       TEXT    NOT NULL,
    level        TEXT,
    confidence   REAL,
    scene        TEXT,
    scene_label  TEXT    DEFAULT '',
    evidence     TEXT    DEFAULT '[]',
    reason       TEXT    DEFAULT '',
    suggestion   TEXT    DEFAULT '',
    provider     TEXT    DEFAULT '',
    model        TEXT    DEFAULT '',
    latency_ms   INTEGER DEFAULT 0,
    error        TEXT
);
CREATE INDEX IF NOT EXISTS idx_records_created_at ON records(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_records_level ON records(level);
"""


def _connect() -> sqlite3.Connection:
    path = Path(settings.db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=10.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def get_conn() -> sqlite3.Connection:
    """取当前线程的连接，没有就建一个。"""
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = _connect()
        _local.conn = conn
    return conn


def close_connections() -> None:
    """关掉当前线程的连接并清掉缓存（测试切换 db_path 时用）。"""
    conn = getattr(_local, "conn", None)
    if conn is not None:
        conn.close()
    _local.conn = None


@contextmanager
def tx() -> Iterator[sqlite3.Connection]:
    """事务助手：正常提交，异常回滚。"""
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def init_schema() -> None:
    with tx() as conn:
        conn.executescript(SCHEMA)
    log.info("数据库初始化完成: %s", settings.db_path)


def insert_record(payload: dict[str, Any]) -> int:
    """写入一条识别记录，返回自增 id。"""
    columns = [
        "created_at",
        "image_path",
        "status",
        "level",
        "confidence",
        "scene",
        "scene_label",
        "evidence",
        "reason",
        "suggestion",
        "provider",
        "model",
        "latency_ms",
        "error",
    ]
    values = [payload.get(col) for col in columns]
    placeholders = ", ".join("?" for _ in columns)
    with tx() as conn:
        cur = conn.execute(
            f"INSERT INTO records ({', '.join(columns)}) VALUES ({placeholders})",
            values,
        )
        return int(cur.lastrowid)


def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    data = dict(row)
    raw = data.get("evidence") or "[]"
    try:
        data["evidence"] = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        data["evidence"] = []
    return data


def list_records(limit: int = 50, offset: int = 0, level: str | None = None) -> list[dict[str, Any]]:
    sql = "SELECT * FROM records"
    params: list[Any] = []
    if level:
        sql += " WHERE level = ?"
        params.append(level)
    sql += " ORDER BY id DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    conn = get_conn()
    return [_row_to_dict(r) for r in conn.execute(sql, params).fetchall()]


def get_record(record_id: int) -> dict[str, Any] | None:
    conn = get_conn()
    row = conn.execute("SELECT * FROM records WHERE id = ?", (record_id,)).fetchone()
    return _row_to_dict(row) if row else None


def count_records() -> int:
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) AS n FROM records").fetchone()
    return int(row["n"]) if row else 0


def stats_by_level() -> list[dict[str, Any]]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT level, COUNT(*) AS n FROM records WHERE level IS NOT NULL GROUP BY level"
    ).fetchall()
    return [{"level": r["level"], "count": int(r["n"])} for r in rows]


def delete_record(record_id: int) -> bool:
    with tx() as conn:
        cur = conn.execute("DELETE FROM records WHERE id = ?", (record_id,))
        return cur.rowcount > 0
