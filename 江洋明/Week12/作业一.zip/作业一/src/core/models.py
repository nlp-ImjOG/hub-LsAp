"""领域模型：风险等级枚举、模型输出结构、最终结果结构。

设计要点：
- 等级用 `str` 枚举，值就是中文标签（前端直接显示，不用再映射一次）
- 模型输出的等级先过 `normalize_level()` 做**别名归一化**：作业原文写「无风险 / 中风险」，
  notebook 总纲写「无隐患 / 中等风险」，模型两个都可能吐出来，必须都接住
- 枚举校验不通过就算解析失败，交给上层重试；重试仍失败走离线兜底，
  **绝不把非法等级透传到前端**
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class RiskLevel(str, Enum):
    """五档隐患等级。取值与作业原文一致。"""

    HIGH = "高风险"
    MEDIUM = "中风险"
    LOW = "低风险"
    NONE = "无风险"
    NON_CORRIDOR = "非楼道"


class Scene(str, Enum):
    """场景判定结果。"""

    CORRIDOR = "corridor"
    NON_CORRIDOR = "non_corridor"


class AnalysisStatus(str, Enum):
    """一次识别的整体状态。

    OK      —— 模型正常返回且通过校验
    OFFLINE —— 模型不可用（缺 key / 网络不通 / 调用报错），走确定性兜底
    FAILED  —— 模型返回了内容但无法解析或枚举校验不通过，重试后仍失败
    """

    OK = "ok"
    OFFLINE = "offline"
    FAILED = "failed"


# —— 等级别名表：把模型可能吐出的各种写法收敛到 RiskLevel ——
_LEVEL_ALIASES: dict[str, RiskLevel] = {
    "高风险": RiskLevel.HIGH,
    "高危": RiskLevel.HIGH,
    "严重": RiskLevel.HIGH,
    "high": RiskLevel.HIGH,
    "中风险": RiskLevel.MEDIUM,
    "中等风险": RiskLevel.MEDIUM,
    "中度风险": RiskLevel.MEDIUM,
    "medium": RiskLevel.MEDIUM,
    "低风险": RiskLevel.LOW,
    "轻度风险": RiskLevel.LOW,
    "low": RiskLevel.LOW,
    "无风险": RiskLevel.NONE,
    "无隐患": RiskLevel.NONE,
    "安全": RiskLevel.NONE,
    "none": RiskLevel.NONE,
    "非楼道": RiskLevel.NON_CORRIDOR,
    "非楼道场景": RiskLevel.NON_CORRIDOR,
    "not_corridor": RiskLevel.NON_CORRIDOR,
}

# 阶段二允许出现的等级（阶段一已排除「非楼道」）
_CORRIDOR_LEVELS = {RiskLevel.HIGH, RiskLevel.MEDIUM, RiskLevel.LOW, RiskLevel.NONE}


def normalize_level(raw: object, *, allow_non_corridor: bool = True) -> RiskLevel | None:
    """把模型返回的等级字符串归一化成 RiskLevel；无法识别返回 None。

    容错点：去空白、去标点、全半角、大小写，以及「高风险（电动车）」这类带括号的补充说明。
    """
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    # 去掉括号里的补充说明，例如「高风险(楼道内有电动车)」-> 「高风险」
    for ch in "（(【[":  # noqa: B007
        idx = text.find(ch)
        if idx > 0:
            text = text[:idx]
    text = text.strip().strip("。.!！ \t\r\n").lower()
    if not text:
        return None
    level = _LEVEL_ALIASES.get(text)
    if level is None:
        # 再尝试前缀匹配，兜住「存在高风险隐患」这种带前缀的说法
        for alias, mapped in _LEVEL_ALIASES.items():
            if alias in text:
                level = mapped
                break
    if level is None:
        return None
    if not allow_non_corridor and level not in _CORRIDOR_LEVELS:
        return None
    return level


def normalize_scene(raw: object) -> Scene | None:
    """归一化场景判定结果。"""
    if raw is None:
        return None
    text = str(raw).strip().lower().replace("-", "_")
    if text in {"corridor", "true", "yes", "1", "是"}:
        return Scene.CORRIDOR
    if text in {"non_corridor", "noncorridor", "false", "no", "0", "否"}:
        return Scene.NON_CORRIDOR
    return None


class SceneDecision(BaseModel):
    """阶段一输出。"""

    scene: Scene
    scene_label: str = ""
    evidence: list[str] = Field(default_factory=list)


class RiskDecision(BaseModel):
    """阶段二输出。"""

    level: RiskLevel
    confidence: float = 0.0
    evidence: list[str] = Field(default_factory=list)
    reason: str = ""
    suggestion: str = ""


class AnalysisResult(BaseModel):
    """一次识别的最终结果，也是 API 的响应体。"""

    record_id: int | None = None
    status: AnalysisStatus = AnalysisStatus.OK
    level: RiskLevel | None = None
    confidence: float | None = None
    scene: Scene | None = None
    scene_label: str = ""
    evidence: list[str] = Field(default_factory=list)
    reason: str = ""
    suggestion: str = ""
    image_url: str | None = None
    provider: str = ""
    model: str = ""
    latency_ms: int = 0
    created_at: str = ""
    error: str | None = None


class RecordSummary(BaseModel):
    """历史记录列表项（不含 evidence 明细，避免列表过重）。"""

    id: int
    created_at: str
    level: RiskLevel | None = None
    status: AnalysisStatus
    scene_label: str = ""
    confidence: float | None = None
    reason: str = ""
    image_url: str | None = None
    provider: str = ""
    model: str = ""
    latency_ms: int = 0


class LevelStat(BaseModel):
    """按等级统计。"""

    level: RiskLevel
    count: int
