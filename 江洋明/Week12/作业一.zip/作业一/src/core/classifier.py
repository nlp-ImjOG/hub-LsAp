"""风险识别编排。

流程（两阶段，见 `prompts.py` 的说明）：

    阶段一：场景判定  ──►  非楼道 ──► 直接出「非楼道」，结束（1 次模型调用）
                        │
                        └► 楼道 ──► 阶段二：风险分级 ──► 四档之一（2 次模型调用）

失败处理分三种，都由**代码**兜底，不让异常透到前端：
- 缺 key / 网络不通 / 调用报错  → status=offline，level=None（照搬 01-intent-classify
  的 LLM 离线兜底思路：不抛 500，返回确定性结果并在结果里标明状态）
- 模型返回内容但解析不出来     → 带更严格的补充指令重试，仍失败则 status=failed
- 模型返回的等级不在枚举里     → 同上（非法等级绝不透传）

实测记录：`deepseek-flash` 偶尔会返回**空 content**（finish_reason 仍是 stop，
所以不能靠 finish_reason 判断），这里一律按解析失败处理并重试。
"""

from __future__ import annotations

import json
import re
import time
from typing import Any

from ..utils.logger import get_logger
from .models import (
    AnalysisResult,
    AnalysisStatus,
    RiskDecision,
    RiskLevel,
    Scene,
    SceneDecision,
    normalize_level,
    normalize_scene,
)
from .prompts import (
    NON_CORRIDOR_REASON,
    NON_CORRIDOR_SUGGESTION,
    RETRY_SUFFIX,
    RISK_PROMPT,
    SCENE_PROMPT,
)
from .providers import VisionClient, VisionError

log = get_logger("classifier")

_FENCE_RE = re.compile(r"^```[a-zA-Z]*\s*|\s*```$")


def extract_json(text: str) -> dict[str, Any] | None:
    """从模型输出里抠出 JSON 对象。

    依次尝试：整体解析 → 去掉 ``` 围栏后解析 → 截取第一个配平的 {...} 解析
    → 中文引号修一轮再解析。全部失败返回 None。
    """
    if not text:
        return None
    candidate = text.strip()
    if not candidate:
        return None

    for attempt in (_try_load, _strip_fence_and_load, _slice_balanced_and_load, _fix_quotes_and_load):
        result = attempt(candidate)
        if result is not None:
            return result
    return None


def _try_load(text: str) -> dict[str, Any] | None:
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return None
    return obj if isinstance(obj, dict) else None


def _strip_fence_and_load(text: str) -> dict[str, Any] | None:
    stripped = _FENCE_RE.sub("", text).strip()
    if stripped == text:
        return None
    return _try_load(stripped)


def _slice_balanced_and_load(text: str) -> dict[str, Any] | None:
    start = text.find("{")
    if start < 0:
        return None
    depth = 0
    in_string = False
    escape = False
    for idx in range(start, len(text)):
        ch = text[idx]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return _try_load(text[start : idx + 1])
    return None


def _fix_quotes_and_load(text: str) -> dict[str, Any] | None:
    fixed = text.replace("“", '"').replace("”", '"').replace("‘", "'").replace("’", "'")
    if fixed == text:
        return None
    return _try_load(fixed)


def _as_list(value: Any) -> list[str]:
    """把模型可能给的各种形态收敛成字符串列表。"""
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, (list, tuple)):
        out: list[str] = []
        for item in value:
            if isinstance(item, str):
                if item.strip():
                    out.append(item.strip())
            elif item is not None:
                out.append(str(item).strip())
        return out
    return [str(value).strip()] if str(value).strip() else []


def _clamp_confidence(value: Any) -> float:
    try:
        num = float(value)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, num))


class RiskClassifier:
    """把一张图变成一个风险等级结论。"""

    def __init__(self, client: VisionClient, *, max_retries: int = 1) -> None:
        self.client = client
        self.max_retries = max(0, max_retries)

    # ——————————————————————————— 对外入口 ———————————————————————————

    def analyze(self, image_b64: str) -> AnalysisResult:
        started = time.perf_counter()
        result = self._analyze(image_b64)
        result.latency_ms = int((time.perf_counter() - started) * 1000)
        result.provider = self.client.name
        result.model = self.client.model
        return result

    def _analyze(self, image_b64: str) -> AnalysisResult:
        if not self.client.available():
            return self._offline("未配置 API key，模型不可用")

        # ——— 阶段一：场景判定 ———
        scene: SceneDecision | None = None
        scene_error: str | None = None
        for attempt in range(self.max_retries + 1):
            prompt = SCENE_PROMPT + (RETRY_SUFFIX if attempt else "")
            try:
                raw = self.client.complete(image_b64, prompt)
            except VisionError as exc:
                log.warning("阶段一调用失败: %s", exc)
                return self._offline(str(exc))
            scene = self._parse_scene(raw)
            if scene is not None:
                break
            scene_error = "场景判定结果无法解析"
            log.warning("阶段一第 %s 次解析失败，原始输出: %.200s", attempt + 1, raw)

        if scene is None:
            return self._failed(scene_error or "场景判定失败", scene=None)

        # ——— 非楼道：到此为止，不再调模型 ———
        if scene.scene is Scene.NON_CORRIDOR:
            return AnalysisResult(
                status=AnalysisStatus.OK,
                level=RiskLevel.NON_CORRIDOR,
                confidence=None,
                scene=scene.scene,
                scene_label=scene.scene_label or "非楼道",
                evidence=scene.evidence,
                reason=NON_CORRIDOR_REASON,
                suggestion=NON_CORRIDOR_SUGGESTION,
            )

        # ——— 阶段二：风险分级 ———
        risk: RiskDecision | None = None
        risk_error: str | None = None
        for attempt in range(self.max_retries + 1):
            prompt = RISK_PROMPT + (RETRY_SUFFIX if attempt else "")
            try:
                raw = self.client.complete(image_b64, prompt)
            except VisionError as exc:
                log.warning("阶段二调用失败: %s", exc)
                return self._offline(str(exc), scene=scene)
            risk = self._parse_risk(raw)
            if risk is not None:
                break
            risk_error = "风险分级结果无法解析"
            log.warning("阶段二第 %s 次解析失败，原始输出: %.200s", attempt + 1, raw)

        if risk is None:
            return self._failed(risk_error or "风险分级失败", scene=scene)

        return AnalysisResult(
            status=AnalysisStatus.OK,
            level=risk.level,
            confidence=risk.confidence,
            scene=scene.scene,
            scene_label=scene.scene_label or "楼道",
            evidence=risk.evidence or scene.evidence,
            reason=risk.reason,
            suggestion=risk.suggestion,
        )

    # ——————————————————————————— 解析 ———————————————————————————

    def _parse_scene(self, raw: str) -> SceneDecision | None:
        payload = extract_json(raw)
        if payload is None:
            return None
        scene = normalize_scene(payload.get("scene"))
        if scene is None:
            return None
        return SceneDecision(
            scene=scene,
            scene_label=str(payload.get("scene_label") or "").strip(),
            evidence=_as_list(payload.get("evidence")),
        )

    def _parse_risk(self, raw: str) -> RiskDecision | None:
        payload = extract_json(raw)
        if payload is None:
            return None
        # 阶段二不允许「非楼道」——场景已在阶段一确认过
        level = normalize_level(payload.get("level"), allow_non_corridor=False)
        if level is None:
            return None
        return RiskDecision(
            level=level,
            confidence=_clamp_confidence(payload.get("confidence")),
            evidence=_as_list(payload.get("evidence")),
            reason=str(payload.get("reason") or "").strip(),
            suggestion=str(payload.get("suggestion") or "").strip(),
        )

    # ——————————————————————————— 兜底 ———————————————————————————

    def _offline(self, message: str, scene: SceneDecision | None = None) -> AnalysisResult:
        return AnalysisResult(
            status=AnalysisStatus.OFFLINE,
            level=None,
            scene=scene.scene if scene else None,
            scene_label=scene.scene_label if scene else "",
            error=message,
        )

    def _failed(self, message: str, scene: SceneDecision | None = None) -> AnalysisResult:
        return AnalysisResult(
            status=AnalysisStatus.FAILED,
            level=None,
            scene=scene.scene if scene else None,
            scene_label=scene.scene_label if scene else "",
            error=message,
        )
