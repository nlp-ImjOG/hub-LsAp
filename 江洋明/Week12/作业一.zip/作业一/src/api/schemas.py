"""API 请求 / 响应模型。"""

from __future__ import annotations

from pydantic import BaseModel, Field

from ..core.models import AnalysisResult, LevelStat


class HealthResponse(BaseModel):
    """健康检查。同时暴露 provider 配置情况，便于前端显示状态。"""

    status: str = "ok"
    app: str = "楼道消防隐患多模态识别"
    provider: str
    model: str
    api_key_present: bool
    db_ready: bool
    record_count: int


class ProviderInfo(BaseModel):
    """单个 provider 的配置情况。"""

    name: str
    label: str
    model: str
    base_url: str
    api_key_env: str
    note: str = ""
    available: bool = False


class ProviderListResponse(BaseModel):
    default_provider: str
    providers: list[ProviderInfo] = Field(default_factory=list)


class AnalyzeResponse(AnalysisResult):
    """识别结果。继承 AnalysisResult，字段含义见 core/models.py。"""


class RecordListResponse(BaseModel):
    total: int
    items: list[dict] = Field(default_factory=list)


class StatsResponse(BaseModel):
    total: int
    by_level: list[LevelStat] = Field(default_factory=list)
