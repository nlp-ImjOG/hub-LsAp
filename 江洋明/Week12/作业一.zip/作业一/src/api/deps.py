"""依赖装配：模型客户端、分类器、图片处理。

客户端按 provider 缓存，避免每次请求都重建 OpenAI 客户端（重建会丢失连接池）。
"""

from __future__ import annotations

import base64
import io
from dataclasses import dataclass

from PIL import Image, UnidentifiedImageError

from ..core.classifier import RiskClassifier
from ..core.providers import VisionClient, build_client
from ..utils.config import settings
from ..utils.logger import get_logger

log = get_logger("deps")

_client_cache: dict[str, VisionClient] = {}
_classifier_cache: dict[str, RiskClassifier] = {}

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}


class ImageRejected(ValueError):
    """图片不合法（格式不支持、超大、像素过多）。"""


@dataclass(frozen=True)
class PreparedImage:
    """预处理后的图片。"""

    jpeg_bytes: bytes
    base64: str
    width: int
    height: int
    size_bytes: int


def get_client(provider: str | None = None) -> VisionClient:
    name = (provider or settings.provider).strip().lower()
    client = _client_cache.get(name)
    if client is None:
        client = build_client(name)
        _client_cache[name] = client
    return client


def get_classifier(provider: str | None = None) -> RiskClassifier:
    name = (provider or settings.provider).strip().lower()
    classifier = _classifier_cache.get(name)
    if classifier is None:
        classifier = RiskClassifier(get_client(name), max_retries=settings.max_retries)
        _classifier_cache[name] = classifier
    return classifier


def prepare_image(raw: bytes) -> PreparedImage:
    """校验并归一化上传的图片：统一转成 RGB JPEG，返回 base64。

    前端已经做过 canvas 压缩，这里的检查是**服务端兜底**——
    防止有人绕过前端直接打接口传一个超大图把内存打爆。
    """
    if not raw:
        raise ImageRejected("上传内容为空")
    if len(raw) > settings.max_upload_bytes:
        limit_mb = settings.max_upload_bytes // (1024 * 1024)
        raise ImageRejected(f"图片超过 {limit_mb}MB 上限")

    try:
        with Image.open(io.BytesIO(raw)) as img:
            fmt = (img.format or "").upper()
            if fmt not in ALLOWED_FORMATS:
                raise ImageRejected(f"不支持的图片格式: {fmt or '未知'}（支持 JPEG / PNG / WEBP）")
            width, height = img.size
            if width * height > settings.max_image_pixels:
                raise ImageRejected(f"图片分辨率过大: {width}x{height}")
            rgb = img.convert("RGB")
    except UnidentifiedImageError as exc:
        raise ImageRejected("无法识别的图片文件") from exc

    buffer = io.BytesIO()
    rgb.save(buffer, format="JPEG", quality=90)
    jpeg_bytes = buffer.getvalue()
    return PreparedImage(
        jpeg_bytes=jpeg_bytes,
        base64=base64.b64encode(jpeg_bytes).decode("ascii"),
        width=width,
        height=height,
        size_bytes=len(jpeg_bytes),
    )


def save_upload(jpeg_bytes: bytes, suffix: str = ".jpg") -> str:
    """把图片存到 data/uploads/，返回相对路径（存进数据库）。"""
    import time
    import uuid

    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}{suffix}"
    (settings.upload_dir / filename).write_bytes(jpeg_bytes)
    return filename
