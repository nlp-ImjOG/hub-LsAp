"""FastAPI 后端入口。

路由：
    GET  /                 前端页面（单文件 index.html）
    GET  /api              接口自述
    GET  /health           健康检查 + provider 状态
    GET  /api/providers    可用 provider 列表（前端模型切换器用）
    POST /api/analyze      上传图片 -> 风险识别
    GET  /api/records      历史记录
    GET  /api/records/{id} 单条记录
    DELETE /api/records/{id}
    GET  /api/stats        按等级统计
    GET  /uploads/{name}   识别用的原图
"""

from __future__ import annotations

import json
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from ..core import db
from ..core.models import AnalysisStatus, RiskLevel
from ..core.providers import available_providers
from ..utils.config import settings
from ..utils.logger import configure_logging, get_logger, set_request_id
from .deps import ImageRejected, get_classifier, prepare_image, save_upload
from .schemas import (
    AnalyzeResponse,
    HealthResponse,
    ProviderInfo,
    ProviderListResponse,
    RecordListResponse,
    StatsResponse,
)

configure_logging()
log = get_logger("api")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """启动时建表。用 lifespan 而不是已废弃的 on_event。"""
    db.init_schema()
    log.info(
        "服务启动 provider=%s model=%s key=%s",
        settings.provider, settings.llm_model, "已配置" if settings.api_key_present else "未配置",
    )
    yield


app = FastAPI(
    title="楼道消防隐患多模态识别",
    description="上传或拍摄楼道照片，调用多模态大模型判定消防隐患等级",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 静态资源挂到 /static，**不要挂 "/"** —— FastAPI 会注册 /{path} catch-all
# 把所有 API 路由都吃掉（01-intent-classify 里踩过这个坑）
if settings.frontend_dir.exists():
    app.mount("/static", StaticFiles(directory=str(settings.frontend_dir)), name="static")


@app.middleware("http")
async def request_id_middleware(request, call_next):
    """给每个请求打一个短 id，日志里能对上。"""
    rid = request.headers.get("x-request-id") or uuid.uuid4().hex[:8]
    set_request_id(rid)
    response = await call_next(request)
    response.headers["X-Request-ID"] = rid
    return response


# ——————————————————————————— 页面与元信息 ———————————————————————————


@app.get("/", response_class=HTMLResponse, tags=["meta"])
def index() -> HTMLResponse:
    """返回前端单页。"""
    index_file = settings.frontend_dir / "index.html"
    if not index_file.exists():
        return HTMLResponse("<h1>frontend/index.html 未找到</h1>", status_code=500)
    return HTMLResponse(index_file.read_text(encoding="utf-8"))


@app.get("/api", tags=["meta"])
def api_info() -> dict:
    return {
        "name": "楼道消防隐患多模态识别",
        "version": app.version,
        "frontend": "/",
        "docs": "/docs",
        "health": "/health",
        "endpoints": [
            "GET  /api/providers",
            "POST /api/analyze",
            "GET  /api/records",
            "GET  /api/records/{id}",
            "GET  /api/stats",
            "GET  /uploads/{name}",
        ],
        "levels": [lv.value for lv in RiskLevel],
    }


@app.get("/health", response_model=HealthResponse, tags=["meta"])
def health() -> HealthResponse:
    return HealthResponse(
        status="ok",
        provider=settings.provider,
        model=settings.llm_model,
        api_key_present=settings.api_key_present,
        db_ready=settings.db_path.exists(),
        record_count=db.count_records(),
    )


@app.get("/api/providers", response_model=ProviderListResponse, tags=["model"])
def list_providers() -> ProviderListResponse:
    return ProviderListResponse(
        default_provider=settings.provider,
        providers=[ProviderInfo(**p) for p in available_providers()],
    )


# ——————————————————————————— 核心：识别 ———————————————————————————


@app.post("/api/analyze", response_model=AnalyzeResponse, tags=["analysis"])
async def analyze(
    file: UploadFile = File(..., description="楼道照片"),
    provider: str | None = Form(None, description="可选，覆盖默认 provider"),
) -> AnalyzeResponse:
    """上传一张图，返回隐患等级判定结果。"""
    started = time.perf_counter()

    raw = await file.read()
    try:
        prepared = prepare_image(raw)
    except ImageRejected as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    log.info(
        "收到图片 provider=%s 尺寸=%sx%s 体积=%.1fKB",
        provider or settings.provider, prepared.width, prepared.height, prepared.size_bytes / 1024,
    )

    classifier = get_classifier(provider)
    result = classifier.analyze(prepared.base64)

    # 原图落盘，数据库只存文件名
    filename = ""
    try:
        filename = save_upload(prepared.jpeg_bytes)
        result.image_url = f"/uploads/{filename}"
    except OSError as exc:
        log.warning("原图保存失败: %s", exc)

    result.created_at = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    result.latency_ms = int((time.perf_counter() - started) * 1000)

    result.record_id = db.insert_record(
        {
            "created_at": result.created_at,
            "image_path": filename,
            "status": result.status.value,
            "level": result.level.value if result.level else None,
            "confidence": result.confidence,
            "scene": result.scene.value if result.scene else None,
            "scene_label": result.scene_label,
            "evidence": json.dumps(result.evidence, ensure_ascii=False),
            "reason": result.reason,
            "suggestion": result.suggestion,
            "provider": result.provider,
            "model": result.model,
            "latency_ms": result.latency_ms,
            "error": result.error,
        }
    )
    log.info(
        "识别完成 id=%s 等级=%s 状态=%s 耗时=%sms",
        result.record_id, result.level.value if result.level else "-", result.status.value, result.latency_ms,
    )
    return result


# ——————————————————————————— 历史记录 ———————————————————————————


@app.get("/api/records", response_model=RecordListResponse, tags=["records"])
def list_records(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    level: str | None = Query(None, description="按等级过滤，如「高风险」"),
) -> RecordListResponse:
    items = db.list_records(limit=limit, offset=offset, level=level)
    return RecordListResponse(total=db.count_records(), items=items)


@app.get("/api/records/{record_id}", tags=["records"])
def get_record(record_id: int) -> dict:
    record = db.get_record(record_id)
    if record is None:
        raise HTTPException(status_code=404, detail="记录不存在")
    if record.get("image_path"):
        record["image_url"] = f"/uploads/{record['image_path']}"
    return record


@app.delete("/api/records/{record_id}", tags=["records"])
def delete_record(record_id: int) -> dict:
    if not db.delete_record(record_id):
        raise HTTPException(status_code=404, detail="记录不存在")
    return {"deleted": record_id}


@app.get("/api/stats", response_model=StatsResponse, tags=["records"])
def stats() -> StatsResponse:
    raw = db.stats_by_level()
    order = [lv.value for lv in RiskLevel]
    by_level = [
        {"level": item["level"], "count": item["count"]}
        for item in sorted(raw, key=lambda r: order.index(r["level"]) if r["level"] in order else 99)
    ]
    return StatsResponse(total=db.count_records(), by_level=by_level)


# ——————————————————————————— 原图 ———————————————————————————


@app.get("/uploads/{name}", tags=["records"])
def get_upload(name: str) -> FileResponse:
    """回看识别时用的原图。"""
    safe = Path(name).name
    path = settings.upload_dir / safe
    if not path.exists():
        raise HTTPException(status_code=404, detail="图片不存在")
    return FileResponse(path, media_type="image/jpeg")


@app.exception_handler(ImageRejected)
async def image_rejected_handler(_request, exc: ImageRejected) -> JSONResponse:
    return JSONResponse(status_code=400, content={"detail": str(exc)})


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("src.api.app:app", host=settings.api_host, port=settings.api_port, reload=False)
