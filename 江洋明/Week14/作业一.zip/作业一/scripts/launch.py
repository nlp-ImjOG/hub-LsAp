"""启动器：起中间件、跑演示、查状态。

为什么把提示逻辑放在 Python 里，而不是直接写进 ``.bat``？
    Windows 的批处理文件一旦含有非 ASCII 字符，cmd.exe 在
    「切换代码页 + ``cd`` 切目录 + ``goto`` 跳标签」同时出现时，
    会把批处理文件的字节读取位置算错 —— 表现是半行命令被当成命令执行，
    报错形如 ``'xxx' is not recognized as an internal or external command``。

    所以 ``.bat`` / ``.sh`` 里只保留纯 ASCII 的几行（切目录 + 调用本脚本），
    真正带中文的提示、依赖检查、地址打印全部放在这里 ——
    Python 往控制台写文本走 ``WriteConsoleW``，不受控制台代码页影响。

用法::

    python -X utf8 scripts/launch.py demo
    python -X utf8 scripts/launch.py infra-up
    python -X utf8 scripts/launch.py status
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
REQUIREMENTS_FILE = "requirements.txt"
ENV_FILE = ".env"
ENV_TEMPLATE = ".env.example"
COMPOSE_FILE = "docker-compose.yml"


def _setup_output() -> None:
    """把 stdout 改成行缓冲，避免提示压在缓冲区里。"""

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(line_buffering=True)
            except (ValueError, OSError):  # pragma: no cover - 极端情况
                pass


def _print_banner(title: str) -> None:
    print("=" * 52)
    print(f"  {title}")
    print("=" * 52)


def _has_docker() -> bool:
    return shutil.which("docker") is not None


def _compose_cmd() -> list[str]:
    """拼 docker compose 命令。"""

    return ["docker", "compose", "-f", str(PROJECT_ROOT / COMPOSE_FILE)]


def _run_compose(args: list[str]) -> int:
    """执行一条 docker compose 子命令。"""

    cmd = [*_compose_cmd(), *args]
    print(f"[执行] {' '.join(cmd)}")
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT))


def ensure_env(root: Path = PROJECT_ROOT) -> bool:
    """确保 .env 存在。不存在就从 .env.example 复制一份。"""

    env_path = root / ENV_FILE
    if env_path.exists():
        return True
    template = root / ENV_TEMPLATE
    if template.exists():
        shutil.copyfile(template, env_path)
        print(f"[提示] 未找到 {ENV_FILE}，已从 {ENV_TEMPLATE} 复制一份。")
    else:
        print(f"[提示] 未找到 {ENV_FILE}，示例模板 {ENV_TEMPLATE} 也不存在。")
    return False


def ensure_deps(root: Path = PROJECT_ROOT) -> bool:
    """确保运行依赖已安装；缺失就 pip install。"""

    modules = "redis, kafka"
    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"],
        capture_output=True,
        cwd=str(root),
    )
    if probe.returncode == 0:
        return True

    print("[安装] 依赖缺失，正在安装，请稍候…")
    req = root / REQUIREMENTS_FILE
    if req.exists():
        cmd = [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS_FILE)]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "redis", "kafka-python-ng"]
    subprocess.run(cmd, cwd=str(root))

    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"],
        capture_output=True,
        cwd=str(root),
    )
    if probe.returncode != 0:
        print("[错误] 依赖安装失败，请手动执行：")
        print(f"       {sys.executable} -m pip install -r {REQUIREMENTS_FILE}")
        return False
    return True


def _project_env() -> dict[str, str]:
    """构造子进程环境变量，把 src 挂到 PYTHONPATH 上。"""

    env = dict(os.environ)
    src = str(PROJECT_ROOT / "src")
    old = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{src}{os.pathsep}{old}" if old else src
    return env


# ------------------------------------------------------------------ 子命令


def cmd_infra_up(_args: argparse.Namespace) -> int:
    """起 Redis + Kafka。"""

    _print_banner("启动中间件（Redis + Kafka）")
    if not _has_docker():
        print("[错误] 找不到 docker，请先装 Docker Desktop 并确保它在运行。")
        return 1
    code = _run_compose(["up", "-d"])
    if code != 0:
        print("[错误] docker compose up 失败，看看上面的输出。")
        return code
    print()
    print("[提示] 第一次启动 Kafka 要等十几秒，等它变成 healthy 再跑演示：")
    print(f"       docker compose -f {COMPOSE_FILE} ps")
    return 0


def cmd_infra_down(args: argparse.Namespace) -> int:
    """停 Redis + Kafka。"""

    _print_banner("停止中间件")
    if not _has_docker():
        print("[错误] 找不到 docker。")
        return 1
    extra = ["-v"] if args.volumes else []
    return _run_compose(["down", *extra])


def cmd_status(_args: argparse.Namespace) -> int:
    """查中间件状态 + 应用自检。"""

    _print_banner("中间件状态")
    if not _has_docker():
        print("[错误] 找不到 docker。")
        return 1
    _run_compose(["ps"])
    print()
    return _run_app(["status"])


def cmd_demo(_args: argparse.Namespace) -> int:
    """跑端到端演示。"""

    _print_banner("端到端演示：Redis 存历史对话 · Kafka 传消息")
    ensure_env()
    if not ensure_deps():
        return 1
    print()
    return _run_app(["demo", *(_args.extra or [])])


def _run_app(app_args: list[str]) -> int:
    """跑 redis_kafka_demo CLI。"""

    cmd = [sys.executable, "-X", "utf8", "-m", "redis_kafka_demo", *app_args]
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=_project_env())


def main(argv: list[str] | None = None) -> int:
    """启动器入口。返回进程退出码。"""

    parser = argparse.ArgumentParser(description="第十四周作业一 · 启动器")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("infra-up", help="启动 Redis + Kafka").set_defaults(func=cmd_infra_up)
    p_down = sub.add_parser("infra-down", help="停止 Redis + Kafka")
    p_down.add_argument("--volumes", action="store_true", help="连数据卷一起删")
    p_down.set_defaults(func=cmd_infra_down)
    sub.add_parser("status", help="查看状态").set_defaults(func=cmd_status)
    p_demo = sub.add_parser("demo", help="跑端到端演示")
    p_demo.add_argument("extra", nargs="*", help="透传给 redis_kafka_demo demo 的参数")
    p_demo.set_defaults(func=cmd_demo)

    args = parser.parse_args(argv)
    handler = getattr(args, "func", None)
    if handler is None:
        parser.print_help()
        return 1
    _setup_output()
    return int(handler(args) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
