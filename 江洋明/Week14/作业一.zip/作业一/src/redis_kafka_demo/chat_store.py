"""程序一的核心：把历史对话存进 Redis。

Redis 数据结构设计（``{prefix}`` 默认 ``wk14``）::

    {prefix}:chat:sessions                     SET    所有会话 id
    {prefix}:chat:session:{sid}:messages       LIST   消息列表，每条一个 JSON
    {prefix}:chat:session:{sid}:meta           HASH   会话元信息

选这套结构的原因：

- **LIST 存消息**：``RPUSH`` 追加、``LRANGE`` 读取都是 O(1)/O(N)，天然适合「一问一答」的顺序追加。
- **HASH 存元信息**：字段可以单独改（比如只更新 ``title``），不会重写整个对象。
- **SET 存会话列表**：``SADD``/``SMEMBERS`` 维护「有哪些会话」，比扫 ``KEYS *`` 安全得多
  （``KEYS`` 会阻塞整个 Redis，生产环境永远别用）。
- **过期**：写消息时顺手刷新两个 key 的 TTL，过期后 Redis 自动回收，不需要定时任务。

写入用 pipeline 打包，避免每条消息发好几趟网络往返。
"""

from __future__ import annotations

import json
from typing import Any

from .config import Settings, settings as default_settings
from .models import ChatMessage, SessionMeta, TurnEvent, new_id, now_ms

try:  # redis 是必需依赖，但没装时给出中文提示而不是一堆 ImportError
    import redis
except ImportError as exc:  # pragma: no cover - 环境问题
    raise ImportError(
        "缺少 redis 依赖，请先执行：pip install -r requirements.txt"
    ) from exc


class ChatStore:
    """历史对话的 Redis 存储层。

    刻意把 Redis 的原始命令都收在这一层里，上层（CLI / 测试）只碰语义方法，
    换存储后端时改动面最小。
    """

    def __init__(self, client: Any | None = None, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings
        self._prefix = self._settings.redis_prefix
        self._client = client if client is not None else self._connect()

    # ------------------------------------------------------------------ 连接

    def _connect(self) -> Any:
        return redis.Redis.from_url(
            self._settings.redis_url,
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=5,
        )

    @property
    def client(self) -> Any:
        """底层 Redis 客户端（测试里会替换成 fake）。"""

        return self._client

    # ------------------------------------------------------------------ key

    def sessions_key(self) -> str:
        return f"{self._prefix}:chat:sessions"

    def messages_key(self, session_id: str) -> str:
        return f"{self._prefix}:chat:session:{session_id}:messages"

    def meta_key(self, session_id: str) -> str:
        return f"{self._prefix}:chat:session:{session_id}:meta"

    # ------------------------------------------------------------------ 写

    def append_turn(
        self,
        session_id: str,
        user_text: str,
        assistant_text: str,
        *,
        title: str | None = None,
    ) -> TurnEvent:
        """追加一轮「用户提问 + 模型回答」。

        返回本次追加产生的 ``TurnEvent`` —— 调用方可以直接把它发到 Kafka。
        """

        event = TurnEvent(
            session_id=session_id,
            turn_id=new_id("turn"),
            user_text=user_text,
            assistant_text=assistant_text,
            ts=now_ms(),
        )

        existing = self.get_meta(session_id)
        seq_base = existing.messages if existing else 0
        user_msg = ChatMessage(role="user", content=user_text, seq=seq_base + 1)
        assistant_msg = ChatMessage(
            role="assistant", content=assistant_text, seq=seq_base + 2
        )

        meta = SessionMeta(
            session_id=session_id,
            title=title or (existing.title if existing else _derive_title(user_text)),
            created_at=existing.created_at if existing else event.ts,
            updated_at=event.ts,
            turns=(existing.turns if existing else 0) + 1,
            messages=seq_base + 2,
        )

        pipe = self._client.pipeline(transaction=True)
        pipe.rpush(self.messages_key(session_id), user_msg.to_json(), assistant_msg.to_json())
        pipe.hset(self.meta_key(session_id), mapping=meta.to_dict())
        pipe.sadd(self.sessions_key(), session_id)
        pipe.expire(self.messages_key(session_id), self._settings.session_ttl_seconds)
        pipe.expire(self.meta_key(session_id), self._settings.session_ttl_seconds)
        pipe.execute()

        self._trim(session_id)
        return event

    def _trim(self, session_id: str) -> None:
        """超过上限就丢最旧的消息（LIST 从左往右是旧→新）。"""

        limit = self._settings.max_messages_per_session
        if limit <= 0:
            return
        key = self.messages_key(session_id)
        length = int(self._client.llen(key))
        if length > limit:
            self._client.ltrim(key, length - limit, -1)

    # ------------------------------------------------------------------ 读

    def get_meta(self, session_id: str) -> SessionMeta | None:
        raw = self._client.hgetall(self.meta_key(session_id))
        if not raw:
            return None
        return SessionMeta.from_dict(raw)

    def history(self, session_id: str, limit: int = 0) -> list[ChatMessage]:
        """读一个会话的历史消息，按时间正序。

        ``limit > 0`` 时只取最近 ``limit`` 条。
        """

        key = self.messages_key(session_id)
        if limit and limit > 0:
            raw_items = self._client.lrange(key, -limit, -1)
        else:
            raw_items = self._client.lrange(key, 0, -1)
        out: list[ChatMessage] = []
        for item in raw_items:
            try:
                out.append(ChatMessage.from_json(item))
            except json.JSONDecodeError:
                # 脏数据不应该让整个会话读不出来
                continue
        return out

    def list_sessions(self) -> list[SessionMeta]:
        """列出所有会话，按更新时间倒序。"""

        session_ids = sorted(self._client.smembers(self.sessions_key()))
        metas = [self.get_meta(sid) for sid in session_ids]
        found = [m for m in metas if m is not None]
        found.sort(key=lambda m: m.updated_at, reverse=True)
        return found

    def stats(self) -> dict[str, Any]:
        """给 ``/status`` 或 CLI 概览用的一组计数。"""

        session_ids = self._client.smembers(self.sessions_key())
        total_messages = 0
        for sid in session_ids:
            total_messages += int(self._client.llen(self.messages_key(sid)))
        return {
            "sessions": len(session_ids),
            "messages": total_messages,
            "redis_url": self._settings.redis_url,
            "prefix": self._prefix,
        }

    # ------------------------------------------------------------------ 删

    def clear(self, session_id: str) -> bool:
        """清空一个会话的消息和元信息。返回是否真的删掉了东西。"""

        existed = bool(self._client.exists(self.messages_key(session_id)))
        pipe = self._client.pipeline(transaction=True)
        pipe.delete(self.messages_key(session_id))
        pipe.delete(self.meta_key(session_id))
        pipe.srem(self.sessions_key(), session_id)
        pipe.execute()
        return existed

    def clear_all(self) -> int:
        """清掉本前缀下的所有会话，返回清掉的会话数。"""

        session_ids = sorted(self._client.smembers(self.sessions_key()))
        for sid in session_ids:
            self.clear(sid)
        return len(session_ids)

    # ------------------------------------------------------------------ 自检

    def ping(self) -> bool:
        """Redis 是否连得上。"""

        try:
            return bool(self._client.ping())
        except Exception:
            return False


def _derive_title(user_text: str) -> str:
    """用第一句提问当会话标题，最多 20 个字。"""

    text = (user_text or "").strip().replace("\n", " ")
    if len(text) <= 20:
        return text or "新会话"
    return text[:20] + "…"
