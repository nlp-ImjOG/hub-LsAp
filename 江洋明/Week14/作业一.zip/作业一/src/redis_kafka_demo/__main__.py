"""``python -m redis_kafka_demo`` 入口。"""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
