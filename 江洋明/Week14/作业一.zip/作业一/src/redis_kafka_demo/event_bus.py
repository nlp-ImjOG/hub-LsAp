"""程序二的核心：Kafka 消息总线。

封装三件事：

1. **发**（``publish``）—— 把 ``TurnEvent`` 之类的字典序列化成 JSON 发到 topic。
2. **收**（``consume``）—— 按消费组订阅 topic，逐条拿出来。
3. **管**（``ensure_topic`` / ``describe``）—— 建 topic、看分区。

关于 **message key**：
Kafka 用 key 的哈希值决定消息落到哪个分区。同一 key 的消息进同一分区，
消费时顺序得到保证。本作业用 ``session_id`` 当 key，
所以「同一个会话的多轮对话」在消费者那边一定是有序的 —— 这是本作业最想演示的点之一。
"""

from __future__ import annotations

import json
import logging
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

from .config import Settings, settings as default_settings
from .models import TurnEvent

try:  # 同上：缺依赖给中文提示
    from kafka import KafkaConsumer, KafkaProducer
    from kafka.admin import KafkaAdminClient, NewTopic
    from kafka.errors import KafkaError, TopicAlreadyExistsError
except ImportError as exc:  # pragma: no cover - 环境问题
    raise ImportError(
        "缺少 kafka 依赖，请先执行：pip install -r requirements.txt"
    ) from exc

log = logging.getLogger(__name__)


class EventBus:
    """Kafka 的薄封装。"""

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings
        self._producer: Any | None = None

    # ------------------------------------------------------------------ 生产者

    @property
    def producer(self) -> Any:
        """懒加载的生产者（第一次 publish 时才建连接）。"""

        if self._producer is None:
            self._producer = KafkaProducer(
                bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
                value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode("utf-8"),
                key_serializer=lambda k: k.encode("utf-8") if isinstance(k, str) else k,
                acks="all",
                retries=3,
                linger_ms=10,
                max_block_ms=int(self._settings.kafka_send_timeout_seconds * 1000),
            )
        return self._producer

    def publish(
        self,
        topic: str,
        value: dict[str, Any],
        *,
        key: str | None = None,
    ) -> dict[str, Any]:
        """发一条消息，返回 broker 的确认信息。"""

        return _retry_on_socket_race(
            lambda: self._publish_once(topic, value, key=key)
        )

    def _publish_once(
        self,
        topic: str,
        value: dict[str, Any],
        *,
        key: str | None = None,
    ) -> dict[str, Any]:
        future = self.producer.send(topic, value=value, key=key)
        metadata = future.get(timeout=self._settings.kafka_send_timeout_seconds)
        self.producer.flush(timeout=self._settings.kafka_send_timeout_seconds)
        return {
            "topic": metadata.topic,
            "partition": metadata.partition,
            "offset": metadata.offset,
            "key": key,
        }

    def publish_turn(self, event: TurnEvent, topic: str | None = None) -> dict[str, Any]:
        """发一轮对话。key 用 session_id，保证同一会话有序。"""

        target = topic or self._settings.kafka_topic_turns
        return self.publish(target, event.to_dict(), key=event.session_id)

    def close(self) -> None:
        """关掉生产者连接。"""

        if self._producer is not None:
            try:
                self._producer.flush(timeout=5)
                self._producer.close(timeout=5)
            finally:
                self._producer = None

    # ------------------------------------------------------------------ 消费者

    @contextmanager
    def consume(
        self,
        topic: str,
        *,
        group_id: str | None = None,
        auto_offset_reset: str = "earliest",
        timeout_ms: int = 10_000,
    ) -> Iterator[Any]:
        """订阅 topic 并逐条产出消息。

        用法::

            with bus.consume("wk14.chat.turn") as consumer:
                for message in consumer:
                    print(message.value)
        """

        consumer = KafkaConsumer(
            topic,
            bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
            group_id=group_id if group_id is not None else self._settings.kafka_consumer_group,
            auto_offset_reset=auto_offset_reset,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            key_deserializer=lambda k: k.decode("utf-8") if k is not None else None,
            consumer_timeout_ms=timeout_ms,
            enable_auto_commit=False,
            max_poll_records=self._settings.kafka_poll_max_records,
        )
        try:
            yield consumer
        finally:
            consumer.close()

    def poll_once(
        self,
        topic: str,
        *,
        group_id: str | None = None,
        auto_offset_reset: str = "earliest",
        timeout_ms: int = 10_000,
    ) -> list[dict[str, Any]]:
        """拉一批消息就返回（不阻塞等消息）。

        每条返回 ``{"topic", "partition", "offset", "key", "value"}``。
        """

        return _retry_on_socket_race(
            lambda: self._poll_once(
                topic,
                group_id=group_id,
                auto_offset_reset=auto_offset_reset,
                timeout_ms=timeout_ms,
            )
        )

    def _poll_once(
        self,
        topic: str,
        *,
        group_id: str | None = None,
        auto_offset_reset: str = "earliest",
        timeout_ms: int = 10_000,
    ) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        with self.consume(
            topic,
            group_id=group_id,
            auto_offset_reset=auto_offset_reset,
            timeout_ms=timeout_ms,
        ) as consumer:
            records = consumer.poll(
                timeout_ms=timeout_ms, max_records=self._settings.kafka_poll_max_records
            )
            for _tp, batch in records.items():
                for record in batch:
                    out.append(
                        {
                            "topic": record.topic,
                            "partition": record.partition,
                            "offset": record.offset,
                            "key": record.key,
                            "value": record.value,
                        }
                    )
        out.sort(key=lambda item: (item["partition"], item["offset"]))
        return out

    # ------------------------------------------------------------------ 管理

    def ensure_topic(self, topic: str, partitions: int | None = None) -> bool:
        """确保 topic 存在。

        返回 True 表示这次真的新建了；False 表示已经存在（或无权创建）。
        """

        count = partitions or self._settings.kafka_topic_partitions
        admin = KafkaAdminClient(
            bootstrap_servers=self._settings.kafka_bootstrap_servers.split(",")
        )
        try:
            admin.create_topics(
                [NewTopic(name=topic, num_partitions=count, replication_factor=1)]
            )
            return True
        except TopicAlreadyExistsError:
            return False
        except KafkaError:
            # broker 上开了 auto.create.topics 时通常走不到这里
            return False
        finally:
            admin.close()

    def describe(self, topic: str) -> dict[str, Any]:
        """看 topic 的分区情况（每个分区有几条消息）。

        这里用「简单消费者」（不订阅、只查 offset），
        因为已订阅的消费者不允许再 ``assign`` 分区。
        """

        consumer = KafkaConsumer(
            bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
            group_id=None,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        )
        try:
            partitions = consumer.partitions_for_topic(topic) or set()
            if not partitions:
                return {"topic": topic, "partitions": []}
            tps = [_topic_partition(topic, p) for p in sorted(partitions)]
            beginning = consumer.beginning_offsets(tps)
            end = consumer.end_offsets(tps)
            rows = [
                {
                    "partition": tp.partition,
                    "messages": max(0, end.get(tp, 0) - beginning.get(tp, 0)),
                }
                for tp in tps
            ]
            return {"topic": topic, "partitions": rows}
        finally:
            consumer.close()

    def ping(self) -> bool:
        """Kafka 是否连得上。"""

        try:
            admin = KafkaAdminClient(
                bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
                request_timeout_ms=5000,
            )
            admin.list_topics()
            admin.close()
            return True
        except Exception:
            return False


def _topic_partition(topic: str, partition: int) -> Any:
    from kafka import TopicPartition

    return TopicPartition(topic, partition)


#: kafka-python-ng 有个竞态：连接被并发关掉时，客户端会把一个**已经关闭**的
#: socket 注册进 selectors，于是报 ``ValueError: Invalid file descriptor: -1``。
#: 这不是本项目的 bug，重试一次（新开一条连接）就好了。
_SOCKET_RACE_MARKER = "Invalid file descriptor"


def _retry_on_socket_race(action: Any, attempts: int = 3) -> Any:
    """执行 ``action``，遇到 socket 竞态就重试。"""

    last: Exception | None = None
    for attempt in range(attempts):
        try:
            return action()
        except ValueError as exc:
            if _SOCKET_RACE_MARKER not in str(exc):
                raise
            last = exc
            log.warning("kafka 客户端 socket 竞态，重试第 %d 次", attempt + 1)
    assert last is not None
    raise last
