"""第十四周 · 作业一：Redis + Kafka 实践。

两个程序：

- **程序一**（:mod:`redis_kafka_demo.chat_store`）—— 用 Redis 存历史对话。
- **程序二**（:mod:`redis_kafka_demo.event_bus`）—— 用 Kafka 传递消息。

两者通过 ``TurnEvent`` 串起来：程序一写完 Redis，顺手把这一轮投递到 Kafka，
程序二再消费出来。
"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "1.0.0"
