"""数据契约。

Redis 里存什么、Kafka 上传什么，都由这里定义。
所有 dataclass 都提供 ``to_dict`` / ``from_dict``，方便直接 JSON 序列化。
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Literal

Role = Literal["user", "assistant", "system"]


def now_ms() -> int:
    """当前毫秒时间戳。统一走这里，方便测试时 mock。"""

    return int(time.time() * 1000)


def new_id(prefix: str) -> str:
    """带前缀的短 id。"""

    return f"{prefix}-{uuid.uuid4().hex[:12]}"


@dataclass(frozen=True)
class ChatMessage:
    """一条对话消息 —— Redis LIST 里的一个元素。"""

    role: Role
    content: str
    ts: int = field(default_factory=now_ms)
    seq: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "content": self.content,
            "ts": self.ts,
            "seq": self.seq,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "ChatMessage":
        return cls(
            role=raw.get("role", "user"),
            content=str(raw.get("content", "")),
            ts=int(raw.get("ts", 0)),
            seq=int(raw.get("seq", 0)),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_json(cls, text: str) -> "ChatMessage":
        return cls.from_dict(json.loads(text))


@dataclass(frozen=True)
class SessionMeta:
    """会话元信息 —— Redis HASH `chat:session:{sid}:meta` 的内容。"""

    session_id: str
    title: str = "新会话"
    created_at: int = field(default_factory=now_ms)
    updated_at: int = field(default_factory=now_ms)
    turns: int = 0
    messages: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "turns": self.turns,
            "messages": self.messages,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "SessionMeta":
        return cls(
            session_id=str(raw.get("session_id", "")),
            title=str(raw.get("title", "新会话")),
            created_at=int(raw.get("created_at", 0)),
            updated_at=int(raw.get("updated_at", 0)),
            turns=int(raw.get("turns", 0)),
            messages=int(raw.get("messages", 0)),
        )


@dataclass(frozen=True)
class TurnEvent:
    """一轮完整对话 —— 发到 Kafka 上的消息体。

    用 ``session_id`` 作为 Kafka 的 message key，
    这样同一个会话的消息一定落在同一个分区，消费时顺序不乱。
    """

    session_id: str
    turn_id: str
    user_text: str
    assistant_text: str
    ts: int = field(default_factory=now_ms)
    source: str = "redis"

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "turn_id": self.turn_id,
            "user_text": self.user_text,
            "assistant_text": self.assistant_text,
            "ts": self.ts,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "TurnEvent":
        return cls(
            session_id=str(raw.get("session_id", "")),
            turn_id=str(raw.get("turn_id", "")),
            user_text=str(raw.get("user_text", "")),
            assistant_text=str(raw.get("assistant_text", "")),
            ts=int(raw.get("ts", 0)),
            source=str(raw.get("source", "redis")),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_json(cls, text: str) -> "TurnEvent":
        return cls.from_dict(json.loads(text))
