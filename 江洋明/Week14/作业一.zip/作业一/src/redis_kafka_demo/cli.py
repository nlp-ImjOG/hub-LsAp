"""命令行入口。

两个程序共用一个 CLI，靠第一个参数区分：

- ``redis ...``  —— 程序一：把历史对话存进 Redis
- ``kafka ...``  —— 程序二：用 Kafka 传递消息
- ``demo ...``   —— 端到端联调：Redis 写入 → Kafka 投递 → 消费者消费

也可以直接跑两个入口脚本（等价，但只暴露各自的子命令）::

    python program1_redis_chat.py history --session s1
    python program2_kafka_bus.py consume --topic wk14.chat.turn
"""

from __future__ import annotations

import argparse
import json
import sys

from .chat_store import ChatStore
from .config import settings
from .event_bus import EventBus
from .models import TurnEvent

# ---------------------------------------------------------------- 终端输出


def _out(text: str = "") -> None:
    """所有输出统一走 stdout，并在 Windows 上强制 UTF-8。"""

    print(text, flush=True)


def _title(text: str) -> None:
    _out()
    _out("=" * 60)
    _out(f"  {text}")
    _out("=" * 60)


def _ok(text: str) -> None:
    _out(f"[成功] {text}")


def _info(text: str) -> None:
    _out(f"[信息] {text}")


def _warn(text: str) -> None:
    _out(f"[提示] {text}")


def _fail(text: str) -> int:
    print(f"[错误] {text}", file=sys.stderr, flush=True)
    return 1


# ---------------------------------------------------------------- 程序一


def _redis_add(args: argparse.Namespace) -> int:
    """往 Redis 写一轮对话，并顺手推到 Kafka（可选）。"""

    store = ChatStore()
    if not store.ping():
        return _fail(
            f"连不上 Redis（{settings.redis_url}）。"
            "先执行：docker compose up -d redis"
        )

    event = store.append_turn(
        args.session, args.user, args.assistant, title=args.title
    )
    _ok(f"已写入 Redis：session={args.session}  turn_id={event.turn_id}")
    _info(f"消息总数：{store.get_meta(args.session).messages}")

    if args.publish:
        bus = EventBus()
        if not bus.ping():
            _warn("连不上 Kafka，跳过投递（不影响 Redis 写入）")
            return 0
        bus.ensure_topic(settings.kafka_topic_turns)
        info = bus.publish_turn(event)
        bus.close()
        _ok(
            f"已投递到 Kafka：topic={info['topic']} partition={info['partition']} "
            f"offset={info['offset']}"
        )
    return 0


def _redis_history(args: argparse.Namespace) -> int:
    """读一个会话的历史对话。"""

    store = ChatStore()
    if not store.ping():
        return _fail(f"连不上 Redis（{settings.redis_url}）")

    messages = store.history(args.session, limit=args.limit)
    if not messages:
        _warn(f"session={args.session} 没有历史消息")
        return 0
    for msg in messages:
        _out(f"  [{msg.seq:>3}] {msg.role:<9} {msg.content}")
    meta = store.get_meta(args.session)
    if meta:
        _info(f"共 {meta.turns} 轮 / {meta.messages} 条消息")
    return 0


def _redis_list(args: argparse.Namespace) -> int:
    """列出所有会话。"""

    store = ChatStore()
    if not store.ping():
        return _fail(f"连不上 Redis（{settings.redis_url}）")
    metas = store.list_sessions()
    if not metas:
        _warn("还没有任何会话")
        return 0
    for meta in metas:
        _out(
            f"  {meta.session_id:<24} {meta.turns:>3} 轮 / {meta.messages:>4} 条  {meta.title}"
        )
    return 0


def _redis_clear(args: argparse.Namespace) -> int:
    """清空会话。"""

    store = ChatStore()
    if not store.ping():
        return _fail(f"连不上 Redis（{settings.redis_url}）")
    if args.all:
        count = store.clear_all()
        _ok(f"已清空 {count} 个会话")
        return 0
    if store.clear(args.session):
        _ok(f"已清空 session={args.session}")
    else:
        _warn(f"session={args.session} 本来就是空的")
    return 0


def _redis_stats(args: argparse.Namespace) -> int:
    """Redis 的 key 结构概览。"""

    store = ChatStore()
    if not store.ping():
        return _fail(f"连不上 Redis（{settings.redis_url}）")
    stats = store.stats()
    _title("Redis 概览")
    _out(f"  连接：{stats['redis_url']}")
    _out(f"  前缀：{stats['prefix']}")
    _out(f"  会话数：{stats['sessions']}")
    _out(f"  消息数：{stats['messages']}")
    _out()
    _info("key 结构：")
    _out(f"  {stats['prefix']}:chat:sessions                  SET   所有会话 id")
    _out(f"  {stats['prefix']}:chat:session:<sid>:messages    LIST  消息列表（JSON）")
    _out(f"  {stats['prefix']}:chat:session:<sid>:meta        HASH  会话元信息")
    return 0


# ---------------------------------------------------------------- 程序二


def _kafka_publish(args: argparse.Namespace) -> int:
    """发一条消息到 Kafka。"""

    bus = EventBus()
    if not bus.ping():
        return _fail(
            f"连不上 Kafka（{settings.kafka_bootstrap_servers}）。"
            "先执行：docker compose up -d kafka"
        )
    bus.ensure_topic(args.topic)
    payload = {"text": args.text, "source": "cli", "ts": int(__import__("time").time() * 1000)}
    info = bus.publish(args.topic, payload, key=args.key)
    bus.close()
    _ok(
        f"已发送：topic={info['topic']} partition={info['partition']} "
        f"offset={info['offset']} key={info['key'] or '(空)'}"
    )
    _info("同一 key 的消息会进同一分区 —— 顺序有保证")
    return 0


def _kafka_consume(args: argparse.Namespace) -> int:
    """消费一个 topic 并把消息打印出来。"""

    bus = EventBus()
    if not bus.ping():
        return _fail(f"连不上 Kafka（{settings.kafka_bootstrap_servers}）")

    records = bus.poll_once(
        args.topic,
        group_id=args.group,
        auto_offset_reset=args.offset_reset,
        timeout_ms=args.timeout * 1000,
    )
    if not records:
        _warn(f"topic={args.topic} 这一轮没有新消息")
        return 0
    for record in records:
        _out(
            f"  p{record['partition']}@{record['offset']:<6} key={record['key'] or '-':<12} "
            f"{json.dumps(record['value'], ensure_ascii=False)}"
        )
    _ok(f"共消费到 {len(records)} 条")
    return 0


def _kafka_describe(args: argparse.Namespace) -> int:
    """看 topic 的分区与消息分布。"""

    bus = EventBus()
    if not bus.ping():
        return _fail(f"连不上 Kafka（{settings.kafka_bootstrap_servers}）")
    info = bus.describe(args.topic)
    _title(f"Kafka topic：{info['topic']}")
    for row in info["partitions"]:
        _out(f"  partition {row['partition']}  消息数 {row['messages']}")
    _out()
    _info("分区数在 topic 创建时固定；同一 key 永远落在同一个分区。")
    return 0


def _kafka_status(args: argparse.Namespace) -> int:
    """Redis / Kafka 连通性自检。"""

    _title("基础设施自检")
    store = ChatStore()
    bus = EventBus()
    redis_ok = store.ping()
    kafka_ok = bus.ping()
    _out(f"  Redis  {settings.redis_url:<40} {'正常' if redis_ok else '连不上'}")
    _out(f"  Kafka  {settings.kafka_bootstrap_servers:<40} {'正常' if kafka_ok else '连不上'}")
    if not (redis_ok and kafka_ok):
        _out()
        _warn("先执行：docker compose up -d")
        return 1
    return 0


# ---------------------------------------------------------------- 端到端


_DEMO_TURNS = [
    ("Redis 和 Kafka 分别适合解决什么问题？", "Redis 是内存键值库，适合做缓存和会话存储；Kafka 是分布式消息队列，适合做日志和事件流。"),
    ("为什么历史对话放 Redis，事件放 Kafka？", "对话历史需要按会话随机读写，Redis 的 LIST/HASH 正好；事件需要顺序消费和回放，Kafka 更合适。"),
    ("Kafka 怎么保证同一会话的顺序？", "用 session_id 当消息 key，Kafka 按 key 哈希选分区，同 key 进同一分区，天然有序。"),
]


def _demo(args: argparse.Namespace) -> int:
    """端到端演示：Redis 存历史 → Kafka 传消息 → 消费者收。"""

    _title("端到端演示：Redis 存历史对话 · Kafka 传消息")

    store = ChatStore()
    bus = EventBus()

    if not store.ping():
        return _fail(f"连不上 Redis（{settings.redis_url}）。先执行：docker compose up -d redis")
    if not bus.ping():
        return _fail(
            f"连不上 Kafka（{settings.kafka_bootstrap_servers}）。先执行：docker compose up -d kafka"
        )
    _ok("Redis 与 Kafka 均连通")

    session_id = args.session
    topic = settings.kafka_topic_turns

    # 1) 建 topic
    created = bus.ensure_topic(topic)
    _info(f"topic={topic} {'已创建' if created else '已存在'}")

    # 2) 写 Redis + 投 Kafka
    _out()
    _out("--- 第一步：程序一写 Redis，并把每轮对话投递到 Kafka ---")
    events: list[TurnEvent] = []
    for user_text, assistant_text in _DEMO_TURNS:
        event = store.append_turn(session_id, user_text, assistant_text)
        events.append(event)
        info = bus.publish_turn(event, topic)
        _out(
            f"  [第 {event.turn_id[-6:]}] 写 Redis 成功 → "
            f"Kafka partition={info['partition']} offset={info['offset']}"
        )

    # 3) 看 Redis 里的东西
    _out()
    _out("--- 第二步：读 Redis 里的历史对话 ---")
    for msg in store.history(session_id):
        _out(f"  [{msg.seq:>3}] {msg.role:<9} {msg.content[:48]}")

    # 4) 消费 Kafka
    _out()
    _out("--- 第三步：程序二从 Kafka 消费 ---")
    records = bus.poll_once(
        topic, group_id=args.group, auto_offset_reset="earliest", timeout_ms=8000
    )
    for record in records:
        value = record["value"]
        _out(
            f"  p{record['partition']}@{record['offset']:<6} session={value.get('session_id')} "
            f"{str(value.get('user_text'))[:40]}"
        )
    _ok(f"消费到 {len(records)} 条消息")

    # 5) 展示分区分布
    _out()
    _out("--- 第四步：分区分布（同一 session 永远在同一分区） ---")
    info = bus.describe(topic)
    for row in info["partitions"]:
        _out(f"  partition {row['partition']}  消息数 {row['messages']}")

    bus.close()

    if not args.keep:
        store.clear(session_id)
        _info(f"演示数据已清理（session={session_id}）；加 --keep 可以保留")

    _out()
    _ok("演示结束")
    return 0


# ---------------------------------------------------------------- 参数解析


def build_parser() -> argparse.ArgumentParser:
    """构造参数解析器。

    结构是两层子命令：``redis <子命令>`` / ``kafka <子命令>``，
    这样两个程序的参数不会互相污染，``--help`` 也更好读。
    """

    parser = argparse.ArgumentParser(
        prog="redis_kafka_demo",
        description="程序一（Redis 存历史对话）/ 程序二（Kafka 传消息）",
    )
    top = parser.add_subparsers(dest="program")

    # --- 程序一：Redis ---
    redis_parser = top.add_parser("redis", help="程序一：用 Redis 存历史对话")
    redis_sub = redis_parser.add_subparsers(dest="command")

    p_add = redis_sub.add_parser("add", help="写一轮对话到 Redis")
    p_add.add_argument("--session", required=True, help="会话 id")
    p_add.add_argument("--user", required=True, help="用户提问")
    p_add.add_argument("--assistant", required=True, help="模型回答")
    p_add.add_argument("--title", default=None, help="会话标题")
    p_add.add_argument("--publish", action="store_true", help="同时投递到 Kafka")
    p_add.set_defaults(func=_redis_add)

    p_hist = redis_sub.add_parser("history", help="读会话历史")
    p_hist.add_argument("--session", required=True)
    p_hist.add_argument("--limit", type=int, default=0, help="只看最近 N 条")
    p_hist.set_defaults(func=_redis_history)

    p_list = redis_sub.add_parser("list", help="列出所有会话")
    p_list.set_defaults(func=_redis_list)

    p_clear = redis_sub.add_parser("clear", help="清空会话")
    p_clear.add_argument("--session", default="demo")
    p_clear.add_argument("--all", action="store_true", help="清空全部会话")
    p_clear.set_defaults(func=_redis_clear)

    p_stats = redis_sub.add_parser("stats", help="Redis key 结构概览")
    p_stats.set_defaults(func=_redis_stats)

    # --- 程序二：Kafka ---
    kafka_parser = top.add_parser("kafka", help="程序二：用 Kafka 传递消息")
    kafka_sub = kafka_parser.add_subparsers(dest="command")

    p_pub = kafka_sub.add_parser("publish", help="发一条消息")
    p_pub.add_argument("--topic", default=settings.kafka_topic_turns)
    p_pub.add_argument("--text", required=True)
    p_pub.add_argument("--key", default=None, help="消息 key（决定分区）")
    p_pub.set_defaults(func=_kafka_publish)

    p_con = kafka_sub.add_parser("consume", help="消费一个 topic")
    p_con.add_argument("--topic", default=settings.kafka_topic_turns)
    p_con.add_argument("--group", default=None, help="消费组 id")
    p_con.add_argument("--timeout", type=int, default=10, help="等待秒数")
    p_con.add_argument(
        "--offset-reset",
        default="earliest",
        choices=["earliest", "latest"],
        help="没有已提交位点时从哪儿开始",
    )
    p_con.set_defaults(func=_kafka_consume)

    p_desc = kafka_sub.add_parser("describe", help="看分区分布")
    p_desc.add_argument("--topic", default=settings.kafka_topic_turns)
    p_desc.set_defaults(func=_kafka_describe)

    # --- 端到端 ---
    p_demo = top.add_parser("demo", help="端到端演示")
    p_demo.add_argument("--session", default="demo-session")
    p_demo.add_argument("--group", default=settings.kafka_consumer_group)
    p_demo.add_argument("--keep", action="store_true", help="保留演示数据")
    p_demo.set_defaults(func=_demo)

    # --- 自检 ---
    p_status = top.add_parser("status", help="Redis / Kafka 连通性自检")
    p_status.set_defaults(func=_kafka_status)

    return parser


def main(argv: list[str] | None = None) -> int:
    """CLI 入口。返回进程退出码。"""

    args = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    if not args:
        parser.print_help()
        return 1

    namespace = parser.parse_args(args)
    handler = getattr(namespace, "func", None)
    if handler is None:
        # 只给了程序名没给子命令 —— 打印对应的帮助
        try:
            parser.parse_args([namespace.program, "--help"])
        except SystemExit:
            pass
        return 1
    try:
        return int(handler(namespace) or 0)
    except KeyboardInterrupt:  # pragma: no cover - 交互中断
        _out()
        _warn("已中断")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
