"""运行配置。

设计约定（与仓库既有做法一致）：

- **密钥 / 口令只从环境变量 / 同目录 .env 读取**，代码里不出现任何真实凭据。
- 解析顺序：环境变量 > ``<项目根>/.env``。
- 所有字段都可以用环境变量覆盖，便于同一份代码跑不同环境。

本作业不涉及任何大模型 API Key —— Redis 与 Kafka 都是本地 Docker 服务，
默认配置直接对着 ``docker-compose.yml`` 起的容器。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

# src/redis_kafka_demo/config.py -> parents[2] 即「作业一」目录
PROJECT_ROOT = Path(__file__).resolve().parents[2]

#: 便利回退的 .env 列表（按顺序取第一个能提供值的文件）。
_ENV_FILES = (
    PROJECT_ROOT / ".env",
)


def _parse_env_file(path: Path) -> dict[str, str]:
    """极简 .env 解析器：只认 KEY=VALUE，忽略注释和空行，不处理引号转义。"""

    values: dict[str, str] = {}
    if not path.is_file():
        return values
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return values
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _load_env_files() -> dict[str, str]:
    """合并所有可读 .env；靠前的文件优先。"""

    merged: dict[str, str] = {}
    for path in reversed(_ENV_FILES):
        merged.update(_parse_env_file(path))
    return merged


_FILE_ENV = _load_env_files()


def _env_str(name: str, default: str = "", *also: str) -> str:
    """读环境变量，兼容多个变量名；都没有时读 .env 文件。"""

    names = (name, *also)
    for key in names:
        value = os.getenv(key)
        if value:
            return value
    for key in names:
        if key in _FILE_ENV:
            return _FILE_ENV[key]
    return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(_env_str(name, str(default)))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(_env_str(name, str(default)))
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    raw = _env_str(name, "1" if default else "0").strip().lower()
    return raw in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    """一次运行所需的全部可调参数。"""

    # --- Redis ---
    redis_url: str = "redis://127.0.0.1:6380/0"
    #: 会话数据的 key 前缀，换前缀可以和其他实验共存。
    redis_prefix: str = "wk14"
    #: 会话过期时间（秒）。0 表示不过期。
    session_ttl_seconds: int = 7 * 24 * 3600
    #: 单个会话最多保留多少条消息，超出后丢弃最旧的。
    max_messages_per_session: int = 200

    # --- Kafka ---
    kafka_bootstrap_servers: str = "127.0.0.1:9095"
    #: 演示用的 topic 名。
    kafka_topic_turns: str = "wk14.chat.turn"
    kafka_topic_events: str = "wk14.chat.event"
    #: 生产者等待 broker 确认的最长时间（秒）。
    kafka_send_timeout_seconds: float = 10.0
    #: 消费者单次 poll 拿到的最大消息数。
    kafka_poll_max_records: int = 20
    #: 消费者 poll 的等待时间（秒）。
    kafka_poll_timeout_seconds: float = 1.0
    #: 消费者组 id —— 同一组里的多个消费者会分摊分区。
    kafka_consumer_group: str = "wk14-demo-group"
    #: 是否自动建 topic（没有这个开关的话要手工建）。
    kafka_auto_create_topics: bool = True
    #: 自动建 topic 时的分区数。
    kafka_topic_partitions: int = 3

    @classmethod
    def from_env(cls) -> "Settings":
        # 端口和连接串共用同一组变量：docker-compose 也读 .env 里的
        # REDIS_PORT / KAFKA_PORT，所以改一个地方两边就都对上了。
        redis_port = _env_int("REDIS_PORT", 6380)
        kafka_port = _env_int("KAFKA_PORT", 9095)
        return cls(
            redis_url=_env_str("REDIS_URL", f"redis://127.0.0.1:{redis_port}/0"),
            redis_prefix=_env_str("REDIS_PREFIX", cls.redis_prefix),
            session_ttl_seconds=_env_int("SESSION_TTL_SECONDS", cls.session_ttl_seconds),
            max_messages_per_session=_env_int(
                "MAX_MESSAGES_PER_SESSION", cls.max_messages_per_session
            ),
            kafka_bootstrap_servers=_env_str(
                "KAFKA_BOOTSTRAP_SERVERS", f"127.0.0.1:{kafka_port}"
            ),
            kafka_topic_turns=_env_str("KAFKA_TOPIC_TURNS", cls.kafka_topic_turns),
            kafka_topic_events=_env_str("KAFKA_TOPIC_EVENTS", cls.kafka_topic_events),
            kafka_send_timeout_seconds=_env_float(
                "KAFKA_SEND_TIMEOUT", cls.kafka_send_timeout_seconds
            ),
            kafka_poll_max_records=_env_int(
                "KAFKA_POLL_MAX_RECORDS", cls.kafka_poll_max_records
            ),
            kafka_poll_timeout_seconds=_env_float(
                "KAFKA_POLL_TIMEOUT", cls.kafka_poll_timeout_seconds
            ),
            kafka_consumer_group=_env_str(
                "KAFKA_CONSUMER_GROUP", cls.kafka_consumer_group
            ),
            kafka_auto_create_topics=_env_bool(
                "KAFKA_AUTO_CREATE_TOPICS", cls.kafka_auto_create_topics
            ),
            kafka_topic_partitions=_env_int(
                "KAFKA_TOPIC_PARTITIONS", cls.kafka_topic_partitions
            ),
        )


settings = Settings.from_env()
