@echo off
REM Week 14 homework 1 - stop Redis and Kafka containers.
REM Usage: stop_infra.bat
REM NOTE: this file MUST stay pure ASCII.
REM cmd.exe mis-tracks the byte offset of a UTF-8 batch file when
REM chcp + cd + goto are combined, and executes half a line as a
REM command. All Chinese messages live in scripts\launch.py.
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 goto no_python

python -X utf8 scripts\launch.py infra-down
goto done

:no_python
echo [ERROR] Python was not found in PATH.
echo         Install Anaconda or Python 3.10+, add it to PATH, retry.
pause
exit /b 1

:done
pause
