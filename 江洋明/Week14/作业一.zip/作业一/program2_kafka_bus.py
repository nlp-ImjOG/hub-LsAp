#!/usr/bin/env python
"""程序二：用 Kafka 传递消息。

这是作业一要求的**两个程序之二**，可以单独运行::

    python program2_kafka_bus.py publish --text "hello" --key user-1
    python program2_kafka_bus.py consume --topic wk14.chat.turn
    python program2_kafka_bus.py describe --topic wk14.chat.turn

消息体是 JSON；``--key`` 决定消息落到哪个分区（同一 key 一定同分区，顺序有保证）。
"""

from __future__ import annotations

import sys
from pathlib import Path

# 让 `python program2_kafka_bus.py` 直接能 import 到 src/ 下的包
_SRC = Path(__file__).resolve().parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from redis_kafka_demo.cli import main  # noqa: E402


def _program_two(argv: list[str]) -> int:
    """只暴露 Kafka 相关的子命令。"""

    return main(["kafka", *argv])


if __name__ == "__main__":
    raise SystemExit(_program_two(sys.argv[1:]))
