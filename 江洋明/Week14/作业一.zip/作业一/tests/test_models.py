"""数据契约的测试。"""

from __future__ import annotations

import json

from redis_kafka_demo.models import ChatMessage, SessionMeta, TurnEvent, new_id, now_ms


def test_消息能原样往返_json() -> None:
    msg = ChatMessage(role="user", content="你好", ts=123, seq=7)
    restored = ChatMessage.from_json(msg.to_json())
    assert restored == msg


def test_会话元信息能原样往返_json() -> None:
    meta = SessionMeta(session_id="s1", title="标题", turns=3, messages=6)
    restored = SessionMeta.from_dict(meta.to_dict())
    assert restored == meta


def test_轮次事件能原样往返_json() -> None:
    event = TurnEvent(
        session_id="s1", turn_id="t1", user_text="问题", assistant_text="回答", ts=999
    )
    restored = TurnEvent.from_json(event.to_json())
    assert restored == event


def test_事件序列化成中文不被转义() -> None:
    event = TurnEvent(session_id="s1", turn_id="t1", user_text="中文", assistant_text="回答")
    raw = event.to_json()
    assert "中文" in raw
    assert "\\u" not in raw


def test_角色非法时也不炸() -> None:
    # from_dict 对缺字段/坏字段要宽容，不能让整个会话读不出来
    msg = ChatMessage.from_dict({"role": "user"})
    assert msg.content == ""
    assert msg.ts == 0


def test_新_id_带前缀且不重复() -> None:
    a = new_id("turn")
    b = new_id("turn")
    assert a.startswith("turn-")
    assert a != b


def test_时间戳是毫秒() -> None:
    assert now_ms() > 1_600_000_000_000


def test_解析坏的_json会抛_json错误() -> None:
    try:
        ChatMessage.from_json("不是 json")
    except json.JSONDecodeError:
        return
    raise AssertionError("应该抛 JSONDecodeError")
