"""Redis 存储层的测试（用内存版 Redis，不需要起容器）。"""

from __future__ import annotations

from redis_kafka_demo.chat_store import ChatStore, _derive_title


def _store(fake_redis, settings) -> ChatStore:
    return ChatStore(client=fake_redis, settings=settings)


def test_写一轮对话产生两条消息(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    messages = store.history("s1")
    assert len(messages) == 2
    assert messages[0].role == "user"
    assert messages[1].role == "assistant"
    assert messages[0].seq == 1
    assert messages[1].seq == 2


def test_多轮对话的序号连续(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题1", "回答1")
    store.append_turn("s1", "问题2", "回答2")
    messages = store.history("s1")
    assert [m.seq for m in messages] == [1, 2, 3, 4]
    assert [m.role for m in messages] == ["user", "assistant", "user", "assistant"]


def test_元信息记录轮数(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题1", "回答1")
    store.append_turn("s1", "问题2", "回答2")
    meta = store.get_meta("s1")
    assert meta is not None
    assert meta.turns == 2
    assert meta.messages == 4


def test_会话列表按更新时间倒序(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "第一个", "回答")
    store.append_turn("s2", "第二个", "回答")
    store.append_turn("s1", "第三个", "回答")
    ids = [m.session_id for m in store.list_sessions()]
    assert ids[0] == "s1"  # 最近更新的排前面
    assert set(ids) == {"s1", "s2"}


def test_读历史支持只取最近几条(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    for i in range(4):
        store.append_turn("s1", f"问题{i}", f"回答{i}")
    recent = store.history("s1", limit=2)
    assert [m.content for m in recent] == ["问题3", "回答3"]


def test_超过上限会丢掉最旧的(fake_redis, settings) -> None:
    # 配置里 max_messages_per_session = 4
    store = _store(fake_redis, settings)
    for i in range(5):
        store.append_turn("s1", f"问题{i}", f"回答{i}")
    messages = store.history("s1")
    assert len(messages) == 4
    assert messages[0].content == "问题3"  # 最早的已经被丢掉


def test_清空会话后读不到(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    assert store.clear("s1") is True
    assert store.history("s1") == []
    assert store.get_meta("s1") is None
    assert store.clear("s1") is False  # 再清一次就没有了


def test_清空全部会话(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    store.append_turn("s2", "问题", "回答")
    assert store.clear_all() == 2
    assert store.list_sessions() == []


def test_统计计数(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    store.append_turn("s2", "问题", "回答")
    stats = store.stats()
    assert stats["sessions"] == 2
    assert stats["messages"] == 4


def test_写入时设置了过期时间(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    assert settings.session_ttl_seconds in fake_redis.expiries.values()


def test_写入时刷新过期时间(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    first = fake_redis.expiries[store.messages_key("s1")]
    fake_redis.expiries[store.messages_key("s1")] = 1
    store.append_turn("s1", "问题2", "回答2")
    assert fake_redis.expiries[store.messages_key("s1")] != 1
    assert first == settings.session_ttl_seconds


def test_key_都带前缀(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    assert store.messages_key("s1").startswith(settings.redis_prefix)
    assert store.meta_key("s1").startswith(settings.redis_prefix)
    assert store.sessions_key().startswith(settings.redis_prefix)


def test_脏数据不影响读历史(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "问题", "回答")
    fake_redis.lists[store.messages_key("s1")].insert(0, "坏数据")
    messages = store.history("s1")
    assert len(messages) == 2


def test_标题默认取第一句提问(fake_redis, settings) -> None:
    store = _store(fake_redis, settings)
    store.append_turn("s1", "帮我查一下天气", "好的")
    meta = store.get_meta("s1")
    assert meta.title == "帮我查一下天气"


def test_标题超长会被截断() -> None:
    title = _derive_title("啊" * 50)
    assert len(title) == 21
    assert title.endswith("…")


def test_标题为空时用默认() -> None:
    assert _derive_title("   ") == "新会话"
