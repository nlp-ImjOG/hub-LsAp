"""pytest 公共夹具。

提供一个内存版 Redis（``FakeRedis``），让「存储层」的测试
**不需要真的起 Redis 容器**。
真正连 Redis / Kafka 的用例放在 ``test_integration.py`` 里，
连不上会自动跳过。
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

# 让测试能 import 到 src/ 下的包
_SRC = Path(__file__).resolve().parent.parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


class FakePipeline:
    """``redis`` pipeline 的最小实现：把命令攒起来，execute 时按顺序执行。"""

    def __init__(self, client: "FakeRedis") -> None:
        self._client = client
        self._commands: list[tuple[str, tuple[Any, ...], dict[str, Any]]] = []

    def __getattr__(self, name: str) -> Any:
        def _record(*args: Any, **kwargs: Any) -> "FakePipeline":
            self._commands.append((name, args, kwargs))
            return self

        return _record

    def execute(self) -> list[Any]:
        results: list[Any] = []
        for name, args, kwargs in self._commands:
            results.append(getattr(self._client, name)(*args, **kwargs))
        self._commands.clear()
        return results

    def __enter__(self) -> "FakePipeline":
        return self

    def __exit__(self, *exc: Any) -> None:
        return None


class FakeRedis:
    """够用的内存 Redis。

    只实现本项目用到的命令，语义照抄 redis-py：
    ``rpush`` 返回新长度、``lrange`` 越界返回空、``ltrim`` 保留 [start, end]。
    """

    def __init__(self) -> None:
        self.lists: dict[str, list[str]] = {}
        self.hashes: dict[str, dict[str, str]] = {}
        self.sets: dict[str, set[str]] = {}
        self.expiries: dict[str, int] = {}
        self.calls: list[tuple[str, tuple[Any, ...]]] = []

    # --- 连接 ---
    def ping(self) -> bool:
        return True

    def pipeline(self, transaction: bool = True) -> FakePipeline:
        return FakePipeline(self)

    # --- 通用 ---
    def exists(self, key: str) -> int:
        return int(self._has(key))

    def delete(self, *keys: str) -> int:
        removed = 0
        for key in keys:
            if self._has(key):
                removed += 1
            self.lists.pop(key, None)
            self.hashes.pop(key, None)
            self.sets.pop(key, None)
            self.expiries.pop(key, None)
        return removed

    def expire(self, key: str, seconds: int) -> bool:
        if not self._has(key):
            return False
        self.expiries[key] = seconds
        return True

    def _has(self, key: str) -> bool:
        return key in self.lists or key in self.hashes or key in self.sets

    # --- LIST ---
    def rpush(self, key: str, *values: str) -> int:
        bucket = self.lists.setdefault(key, [])
        bucket.extend(values)
        return len(bucket)

    def llen(self, key: str) -> int:
        return len(self.lists.get(key, []))

    def lrange(self, key: str, start: int, end: int) -> list[str]:
        bucket = list(self.lists.get(key, []))
        length = len(bucket)
        if length == 0:
            return []
        if start < 0:
            start = max(length + start, 0)
        if end < 0:
            end = length + end
        end = min(end, length - 1)
        if start > end:
            return []
        return bucket[start : end + 1]

    def ltrim(self, key: str, start: int, end: int) -> bool:
        bucket = self.lists.get(key)
        if bucket is None:
            return True
        kept = self.lrange(key, start, end)
        self.lists[key] = kept
        return True

    # --- HASH ---
    def hset(self, key: str, mapping: dict[str, Any] | None = None, **_kwargs: Any) -> int:
        bucket = self.hashes.setdefault(key, {})
        added = 0
        for field, value in (mapping or {}).items():
            if field not in bucket:
                added += 1
            bucket[field] = str(value)
        return added

    def hgetall(self, key: str) -> dict[str, str]:
        return dict(self.hashes.get(key, {}))

    # --- SET ---
    def sadd(self, key: str, *members: str) -> int:
        bucket = self.sets.setdefault(key, set())
        before = len(bucket)
        bucket.update(members)
        return len(bucket) - before

    def smembers(self, key: str) -> set[str]:
        return set(self.sets.get(key, set()))

    def srem(self, key: str, *members: str) -> int:
        bucket = self.sets.get(key)
        if bucket is None:
            return 0
        before = len(bucket)
        bucket.difference_update(members)
        return before - len(bucket)


@pytest.fixture
def fake_redis() -> FakeRedis:
    """一个干净的内存 Redis。"""

    return FakeRedis()


@pytest.fixture
def settings():
    """测试用的配置：前缀带随机后缀，避免互相干扰。"""

    from redis_kafka_demo.config import Settings

    return Settings(
        redis_url="redis://127.0.0.1:6379/15",
        redis_prefix="wk14-test",
        session_ttl_seconds=60,
        max_messages_per_session=4,
        kafka_bootstrap_servers="127.0.0.1:9092",
        kafka_topic_turns="wk14.test.turn",
        kafka_consumer_group="wk14-test-group",
    )
