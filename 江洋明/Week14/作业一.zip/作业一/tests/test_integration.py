"""集成测试：真的连 Redis 和 Kafka。

中间件没起的时候**自动跳过**，不会让 CI 变红。
起中间件：``python scripts/launch.py infra-up``。
"""

from __future__ import annotations

import uuid

import pytest

from redis_kafka_demo.chat_store import ChatStore
from redis_kafka_demo.config import settings
from redis_kafka_demo.event_bus import EventBus


def _redis_available() -> bool:
    try:
        return ChatStore().ping()
    except Exception:
        return False


def _kafka_available() -> bool:
    try:
        return EventBus().ping()
    except Exception:
        return False


needs_redis = pytest.mark.skipif(
    not _redis_available(), reason="Redis 没起（docker compose up -d redis）"
)
needs_kafka = pytest.mark.skipif(
    not _kafka_available(), reason="Kafka 没起（docker compose up -d kafka）"
)


@pytest.fixture
def session_id() -> str:
    """每次跑用一个新的会话 id，跑完清掉。"""

    return f"pytest-{uuid.uuid4().hex[:10]}"


@needs_redis
def test_真_redis_能读写(session_id: str) -> None:
    store = ChatStore()
    try:
        store.append_turn(session_id, "问题", "回答")
        messages = store.history(session_id)
        assert len(messages) == 2
        assert messages[0].content == "问题"
        meta = store.get_meta(session_id)
        assert meta is not None and meta.turns == 1
    finally:
        store.clear(session_id)


@needs_redis
def test_真_redis_的_key_结构符合设计(session_id: str) -> None:
    store = ChatStore()
    try:
        store.append_turn(session_id, "问题", "回答")
        assert store.client.exists(store.messages_key(session_id)) == 1
        assert store.client.exists(store.meta_key(session_id)) == 1
        assert session_id in store.client.smembers(store.sessions_key())
        assert store.client.type(store.messages_key(session_id)) == "list"
        assert store.client.type(store.meta_key(session_id)) == "hash"
        assert store.client.type(store.sessions_key()) == "set"
    finally:
        store.clear(session_id)


@needs_redis
def test_真_redis_的过期时间已设置(session_id: str) -> None:
    store = ChatStore()
    try:
        store.append_turn(session_id, "问题", "回答")
        ttl = store.client.ttl(store.messages_key(session_id))
        assert 0 < ttl <= settings.session_ttl_seconds
    finally:
        store.clear(session_id)


@needs_kafka
def test_真_kafka_能收发() -> None:
    bus = EventBus()
    topic = f"wk14.pytest.{uuid.uuid4().hex[:8]}"
    bus.ensure_topic(topic, partitions=1)
    info = bus.publish(topic, {"text": "你好"}, key="k1")
    assert info["topic"] == topic
    assert info["partition"] == 0

    records = bus.poll_once(
        topic, group_id=f"pytest-{uuid.uuid4().hex[:8]}", timeout_ms=8000
    )
    assert len(records) == 1
    assert records[0]["value"]["text"] == "你好"
    assert records[0]["key"] == "k1"
    bus.close()


@needs_kafka
def test_真_kafka_同_key_进同一分区() -> None:
    """这是本作业最想演示的机制：同一会话的消息顺序有保证。"""

    bus = EventBus()
    topic = f"wk14.pytest.{uuid.uuid4().hex[:8]}"
    bus.ensure_topic(topic, partitions=3)
    key = f"session-{uuid.uuid4().hex[:8]}"
    partitions = {
        bus.publish(topic, {"n": i}, key=key)["partition"] for i in range(5)
    }
    assert len(partitions) == 1, "同一个 key 应该落在同一个分区"
    bus.close()


@needs_kafka
def test_真_kafka_消费组能拿到消息() -> None:
    bus = EventBus()
    topic = f"wk14.pytest.{uuid.uuid4().hex[:8]}"
    group = f"pytest-{uuid.uuid4().hex[:8]}"
    bus.ensure_topic(topic, partitions=1)
    bus.publish(topic, {"text": "组消费"}, key="k1")
    records = bus.poll_once(topic, group_id=group, timeout_ms=8000)
    assert any(r["value"].get("text") == "组消费" for r in records)
    bus.close()
