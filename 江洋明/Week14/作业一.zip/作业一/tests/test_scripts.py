"""启动脚本的回归测试。

这些约束都是实测踩出来的坑，用测试钉住，别再改回去：

1. **``.bat`` 必须是纯 ASCII**。
   cmd.exe 在 UTF-8 批处理文件里同时遇到「切换代码页 + ``cd`` 切目录 +
   ``goto`` 跳标签」时，会把字节读取位置算错，把半行命令当命令执行，
   报错形如 ``'xxx' is not recognized as an internal or external command``。
   所以中文提示一律放 ``scripts/launch.py``。
2. **``.bat`` 必须是 CRLF**。LF-only 的批处理在部分 Windows 上会出问题。
3. **``.bat`` 里不许有括号**。``(`` / ``)`` 会让 cmd 用「字符数」去续读批处理文件，
   同样会算错位置。
4. **``.sh`` 必须是 LF**，且不许有 CRLF。
"""

from __future__ import annotations

from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
BAT_FILES = sorted(ROOT.glob("*.bat"))
SH_FILES = sorted(ROOT.glob("*.sh"))


def test_有批处理脚本() -> None:
    assert BAT_FILES, "作业一目录下应该有 .bat 启动脚本"
    assert SH_FILES, "作业一目录下应该有 .sh 启动脚本"


@pytest.mark.parametrize("path", BAT_FILES, ids=lambda p: p.name)
def test_bat_是纯_ascii(path: Path) -> None:
    path.read_bytes().decode("ascii")  # 报错即失败


@pytest.mark.parametrize("path", SH_FILES, ids=lambda p: p.name)
def test_sh_是纯_ascii(path: Path) -> None:
    path.read_bytes().decode("ascii")


@pytest.mark.parametrize("path", BAT_FILES, ids=lambda p: p.name)
def test_bat_用_crlf_换行(path: Path) -> None:
    raw = path.read_bytes()
    assert b"\r\n" in raw, "批处理文件要用 CRLF 换行"
    bare_lf = raw.count(b"\n") - raw.count(b"\r\n")
    assert bare_lf == 0, f"批处理文件里有 {bare_lf} 个裸 LF"


@pytest.mark.parametrize("path", SH_FILES, ids=lambda p: p.name)
def test_sh_用_lf_换行(path: Path) -> None:
    raw = path.read_bytes()
    assert b"\r\n" not in raw, "shell 脚本要用 LF 换行"


@pytest.mark.parametrize("path", BAT_FILES, ids=lambda p: p.name)
def test_bat_里没有括号块(path: Path) -> None:
    text = path.read_text(encoding="ascii")
    assert "(" not in text, "批处理文件里不要出现左括号"
    assert ")" not in text, "批处理文件里不要出现右括号"


@pytest.mark.parametrize("path", BAT_FILES, ids=lambda p: p.name)
def test_bat_切到项目根目录(path: Path) -> None:
    text = path.read_text(encoding="ascii")
    assert 'cd /d "%~dp0"' in text


@pytest.mark.parametrize("path", BAT_FILES, ids=lambda p: p.name)
def test_bat_调用_python_启动器(path: Path) -> None:
    text = path.read_text(encoding="ascii")
    assert "scripts\\launch.py" in text
    assert "python" in text


@pytest.mark.parametrize("path", SH_FILES, ids=lambda p: p.name)
def test_sh_切到项目根目录(path: Path) -> None:
    text = path.read_text(encoding="ascii")
    assert 'cd "$(dirname "$0")"' in text


@pytest.mark.parametrize("path", SH_FILES, ids=lambda p: p.name)
def test_sh_调用_python_启动器(path: Path) -> None:
    text = path.read_text(encoding="ascii")
    assert "scripts/launch.py" in text


def test_启动器里有中文提示() -> None:
    """中文必须留在 Python 侧 —— 这正是 .bat 保持纯 ASCII 的原因。"""

    text = (ROOT / "scripts" / "launch.py").read_text(encoding="utf-8")
    assert "启动" in text or "中间件" in text


def test_启动器_能_自举_依赖(monkeypatch, tmp_path: Path) -> None:
    """ensure_deps 在依赖缺失时会去 pip install。"""

    import importlib.util

    spec = importlib.util.spec_from_file_location(
        "wk14_launch", ROOT / "scripts" / "launch.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    calls: list[list[str]] = []

    class FakeResult:
        returncode = 1

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return FakeResult()

    monkeypatch.setattr(module.subprocess, "run", fake_run)
    monkeypatch.setattr(module, "REQUIREMENTS_FILE", "requirements.txt")
    assert module.ensure_deps(tmp_path) is False
    assert any("pip" in " ".join(cmd) for cmd in calls)


def test_启动器_缺_env_时从模板复制(tmp_path: Path) -> None:
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        "wk14_launch", ROOT / "scripts" / "launch.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    (tmp_path / ".env.example").write_text("KAFKA_PORT=9095\n", encoding="utf-8")
    assert module.ensure_env(tmp_path) is False
    assert (tmp_path / ".env").exists()
    assert "KAFKA_PORT" in (tmp_path / ".env").read_text(encoding="utf-8")
