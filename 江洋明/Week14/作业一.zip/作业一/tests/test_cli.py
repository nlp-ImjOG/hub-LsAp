"""CLI 的测试。

命令处理函数会自己去建 ``ChatStore`` / ``EventBus``，
所以测试里用 monkeypatch 把它们换成内存实现。
"""

from __future__ import annotations

import pytest

from redis_kafka_demo import cli
from redis_kafka_demo.chat_store import ChatStore


class FakeBus:
    """记录 publish 调用的假 EventBus。"""

    def __init__(self) -> None:
        self.published: list[tuple[str, dict, str | None]] = []
        self.topics_created: list[str] = []
        self.closed = False

    def ping(self) -> bool:
        return True

    def ensure_topic(self, topic: str, partitions: int | None = None) -> bool:
        self.topics_created.append(topic)
        return True

    def publish(self, topic: str, value: dict, *, key: str | None = None) -> dict:
        self.published.append((topic, value, key))
        return {"topic": topic, "partition": 0, "offset": len(self.published), "key": key}

    def publish_turn(self, event, topic: str | None = None) -> dict:
        return self.publish(topic or "t", event.to_dict(), key=event.session_id)

    def poll_once(self, topic: str, **kwargs) -> list[dict]:
        return []

    def describe(self, topic: str) -> dict:
        return {"topic": topic, "partitions": []}

    def close(self) -> None:
        self.closed = True


@pytest.fixture
def wired(monkeypatch, fake_redis, settings):
    """把 CLI 里的 Redis / Kafka 换成内存实现。"""

    store = ChatStore(client=fake_redis, settings=settings)
    bus = FakeBus()
    monkeypatch.setattr(cli, "ChatStore", lambda: store)
    monkeypatch.setattr(cli, "EventBus", lambda: bus)
    return store, bus


def test_没有参数时打印帮助(capsys) -> None:
    assert cli.main([]) == 1
    assert "redis" in capsys.readouterr().out.lower()


def test_只给程序名时打印该程序的帮助(capsys) -> None:
    assert cli.main(["redis"]) == 1
    out = capsys.readouterr().out
    assert "add" in out
    assert "history" in out


def test_未知程序会报错(capsys) -> None:
    with pytest.raises(SystemExit):
        cli.main(["nope"])


def test_redis_add_写进内存_redis(wired, capsys) -> None:
    store, _bus = wired
    code = cli.main(
        ["redis", "add", "--session", "s1", "--user", "问题", "--assistant", "回答"]
    )
    assert code == 0
    assert len(store.history("s1")) == 2
    assert "已写入 Redis" in capsys.readouterr().out


def test_redis_add_带_publish_会投递到_kafka(wired) -> None:
    _store, bus = wired
    cli.main(
        [
            "redis",
            "add",
            "--session",
            "s1",
            "--user",
            "问题",
            "--assistant",
            "回答",
            "--publish",
        ]
    )
    assert len(bus.published) == 1
    topic, value, key = bus.published[0]
    assert value["user_text"] == "问题"
    assert key == "s1"  # 用 session_id 当 key，同会话进同一分区


def test_redis_history_打印消息(wired, capsys) -> None:
    store, _bus = wired
    store.append_turn("s1", "问题", "回答")
    capsys.readouterr()
    assert cli.main(["redis", "history", "--session", "s1"]) == 0
    out = capsys.readouterr().out
    assert "问题" in out
    assert "回答" in out


def test_redis_history_空会话不报错(wired, capsys) -> None:
    assert cli.main(["redis", "history", "--session", "没有这个"]) == 0
    assert "没有历史消息" in capsys.readouterr().out


def test_redis_list(wired, capsys) -> None:
    store, _bus = wired
    store.append_turn("s1", "问题", "回答")
    capsys.readouterr()
    assert cli.main(["redis", "list"]) == 0
    assert "s1" in capsys.readouterr().out


def test_redis_stats_打印_key_结构(wired, capsys) -> None:
    assert cli.main(["redis", "stats"]) == 0
    out = capsys.readouterr().out
    assert "chat:sessions" in out
    assert "chat:session" in out


def test_redis_clear_all(wired, capsys) -> None:
    store, _bus = wired
    store.append_turn("s1", "问题", "回答")
    capsys.readouterr()
    assert cli.main(["redis", "clear", "--all"]) == 0
    assert store.list_sessions() == []


def test_kafka_publish(wired, capsys) -> None:
    _store, bus = wired
    assert cli.main(["kafka", "publish", "--text", "hello", "--key", "k1"]) == 0
    assert len(bus.published) == 1
    assert bus.published[0][1]["text"] == "hello"
    assert bus.published[0][2] == "k1"


def test_kafka_consume_没消息也不报错(wired, capsys) -> None:
    assert cli.main(["kafka", "consume"]) == 0
    assert "没有新消息" in capsys.readouterr().out


def test_kafka_describe(wired, capsys) -> None:
    assert cli.main(["kafka", "describe"]) == 0
    assert "分区" in capsys.readouterr().out


def test_status_两个都通(wired, capsys) -> None:
    assert cli.main(["status"]) == 0
    out = capsys.readouterr().out
    assert "正常" in out


def test_demo_端到端(wired, capsys) -> None:
    store, bus = wired
    assert cli.main(["demo", "--session", "demo-1"]) == 0
    # 三轮对话 → 三条 Kafka 消息
    assert len(bus.published) == 3
    # 演示结束会清掉演示数据
    assert store.history("demo-1") == []


def test_demo_带_keep_会保留数据(wired) -> None:
    store, _bus = wired
    cli.main(["demo", "--session", "demo-2", "--keep"])
    meta = store.get_meta("demo-2")
    assert meta is not None
    assert meta.turns == 3
    # 消息条数受 max_messages_per_session 限制（测试配置里是 4）
    assert len(store.history("demo-2")) == 4


def test_程序一入口脚本只暴露_redis_子命令() -> None:
    import importlib.util
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    spec = importlib.util.spec_from_file_location(
        "program1_redis_chat", root / "program1_redis_chat.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # 加了 "redis" 前缀，所以子命令是 add/history/list/clear/stats
    assert module._program_one(["history", "--session", "x"]) >= 0


def test_程序二入口脚本只暴露_kafka_子命令() -> None:
    import importlib.util
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    spec = importlib.util.spec_from_file_location(
        "program2_kafka_bus", root / "program2_kafka_bus.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module._program_two(["describe"]) >= 0
