"""配置读取的测试。"""

from __future__ import annotations

import os
from pathlib import Path

from redis_kafka_demo import config


def test_默认_redis_走_6380() -> None:
    """6380 是刻意选的 —— 6379 经常被别的容器占了。"""

    assert config.Settings.redis_url == "redis://127.0.0.1:6380/0"


def test_默认_kafka_走_9095() -> None:
    assert config.Settings.kafka_bootstrap_servers == "127.0.0.1:9095"


def test_环境变量优先于默认值(monkeypatch) -> None:
    monkeypatch.setenv("REDIS_URL", "redis://example:1234/2")
    monkeypatch.setenv("KAFKA_BOOTSTRAP_SERVERS", "example:19092")
    settings = config.Settings.from_env()
    assert settings.redis_url == "redis://example:1234/2"
    assert settings.kafka_bootstrap_servers == "example:19092"


def test_端口变量能同时推导连接串(monkeypatch) -> None:
    monkeypatch.delenv("REDIS_URL", raising=False)
    monkeypatch.delenv("KAFKA_BOOTSTRAP_SERVERS", raising=False)
    monkeypatch.setenv("REDIS_PORT", "7000")
    monkeypatch.setenv("KAFKA_PORT", "7001")
    settings = config.Settings.from_env()
    assert settings.redis_url == "redis://127.0.0.1:7000/0"
    assert settings.kafka_bootstrap_servers == "127.0.0.1:7001"


def test_布尔变量能解析(monkeypatch) -> None:
    monkeypatch.setenv("KAFKA_AUTO_CREATE_TOPICS", "false")
    assert config.Settings.from_env().kafka_auto_create_topics is False
    monkeypatch.setenv("KAFKA_AUTO_CREATE_TOPICS", "1")
    assert config.Settings.from_env().kafka_auto_create_topics is True


def test_数字变量坏了会退回默认值(monkeypatch) -> None:
    monkeypatch.setenv("KAFKA_TOPIC_PARTITIONS", "不是数字")
    assert config.Settings.from_env().kafka_topic_partitions == 3


def test_解析_env_文件的极简逻辑(tmp_path: Path) -> None:
    path = tmp_path / ".env"
    path.write_text(
        "\n".join(
            [
                "# 注释",
                "",
                "A=1",
                'B="带引号"',
                "C='单引号'",
                "没有等号的行",
            ]
        ),
        encoding="utf-8",
    )
    values = config._parse_env_file(path)
    assert values == {"A": "1", "B": "带引号", "C": "单引号"}


def test_不存在的_env_文件返回空字典(tmp_path: Path) -> None:
    assert config._parse_env_file(tmp_path / "没有这个文件") == {}


def test_项目根目录指向作业一() -> None:
    assert config.PROJECT_ROOT.name == "作业一"
    assert (config.PROJECT_ROOT / "src" / "redis_kafka_demo").is_dir()


def test_env_示例文件存在() -> None:
    assert (config.PROJECT_ROOT / ".env.example").is_file()


def test_gitignore_里忽略了_env() -> None:
    text = (config.PROJECT_ROOT / ".gitignore").read_text(encoding="utf-8")
    assert ".env" in text.splitlines()


def test_代码里没有硬编码的密钥() -> None:
    """本作业不涉及 API Key，但也要守住「不写死凭据」这条线。"""

    # 用拼接写出来，免得这个测试文件自己被判成「含密钥」
    needle = "sk" + "-"
    for path in config.PROJECT_ROOT.rglob("*.py"):
        parts = path.parts
        if "__pycache__" in parts or "tests" in parts:
            continue
        text = path.read_text(encoding="utf-8")
        assert needle not in text, f"{path} 里出现了疑似密钥"


def test_环境变量_不会污染_测试(monkeypatch) -> None:
    for key in ("REDIS_URL", "KAFKA_BOOTSTRAP_SERVERS"):
        monkeypatch.delenv(key, raising=False)
    assert os.getenv("REDIS_URL") is None
