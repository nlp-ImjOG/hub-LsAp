#!/usr/bin/env python
"""程序一：用 Redis 存储历史对话。

这是作业一要求的**两个程序之一**，可以单独运行::

    python program1_redis_chat.py add --session s1 --user "问题" --assistant "回答"
    python program1_redis_chat.py add --session s1 --user "问题" --assistant "回答" --publish
    python program1_redis_chat.py history --session s1
    python program1_redis_chat.py list
    python program1_redis_chat.py stats
    python program1_redis_chat.py clear --session s1

加 ``--publish`` 会把这一轮对话同时投递到 Kafka（topic 见 ``KAFKA_TOPIC_TURNS``），
这就是「Redis 存历史、Kafka 传消息」两种技术的衔接点。
"""

from __future__ import annotations

import sys
from pathlib import Path

# 让 `python program1_redis_chat.py` 直接能 import 到 src/ 下的包
_SRC = Path(__file__).resolve().parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from redis_kafka_demo.cli import main  # noqa: E402


def _program_one(argv: list[str]) -> int:
    """只暴露 Redis 相关的子命令。"""

    return main(["redis", *argv])


if __name__ == "__main__":
    raise SystemExit(_program_one(sys.argv[1:]))
