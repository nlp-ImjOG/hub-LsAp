# 第十四周 · 作业一：Redis + Kafka 实践

作业原文：

> 写两个程序实践下 redis 和 kafka 的使用，比如通过 redis 存储历史对话，通过 kafka 传递消息。

本目录交付**两个独立的可运行程序**，外加把它们串起来的端到端演示：

| 程序 | 入口 | 干什么 |
| --- | --- | --- |
| **程序一** | `program1_redis_chat.py` | 用 **Redis** 存历史对话（LIST + HASH + SET 三种数据结构） |
| **程序二** | `program2_kafka_bus.py` | 用 **Kafka** 传递消息（生产 / 消费 / 消费组 / 分区） |

两个程序不是各玩各的：**程序一写完 Redis，顺手把这一轮对话投递到 Kafka；程序二再消费出来。**
这就是「Redis 存历史、Kafka 传消息」两种技术的衔接点，也是 `demo` 子命令演示的内容。

---

## 1. 快速开始

```bash
cd "14-江洋明-第十四周作业/作业一"

# 1) 起中间件（Redis + Kafka）
start_infra.bat            # Windows
./start_infra.sh           # Linux / macOS

# 2) 跑端到端演示
run_demo.bat               # Windows
./run_demo.sh              # Linux / macOS
```

演示输出长这样（完整版见 `docs/01-端到端演示输出.txt`）：

```
--- 第一步：程序一写 Redis，并把每轮对话投递到 Kafka ---
  [第 91efd8] 写 Redis 成功 → Kafka partition=2 offset=0
  [第 d1f212] 写 Redis 成功 → Kafka partition=2 offset=1
  [第 adb054] 写 Redis 成功 → Kafka partition=2 offset=2

--- 第二步：读 Redis 里的历史对话 ---
  [  1] user      Redis 和 Kafka 分别适合解决什么问题？
  [  2] assistant Redis 是内存键值库，适合做缓存和会话存储；Kafka 是分布式消息队列…

--- 第三步：程序二从 Kafka 消费 ---
  p2@0      session=demo-session Redis 和 Kafka 分别适合解决什么问题？
  p2@1      session=demo-session 为什么历史对话放 Redis，事件放 Kafka？
  p2@2      session=demo-session Kafka 怎么保证同一会话的顺序？

--- 第四步：分区分布（同一 session 永远在同一分区） ---
  partition 0  消息数 0
  partition 1  消息数 0
  partition 2  消息数 3
```

**三条消息全部落在 partition 2** —— 因为 key 用的是 `session_id`，
Kafka 按 key 哈希选分区，同一个会话永远进同一个分区，顺序天然有保证。

不想用脚本的话，等价的命令是：

```bash
docker compose up -d
pip install -r requirements.txt
PYTHONPATH=src python -X utf8 -m redis_kafka_demo demo
```

---

## 2. 两个程序怎么用

### 程序一 · Redis 存历史对话

```bash
# 写一轮对话
python program1_redis_chat.py add --session s1 --user "问题" --assistant "回答"

# 写的时候顺手投到 Kafka
python program1_redis_chat.py add --session s1 --user "问题" --assistant "回答" --publish

# 看历史
python program1_redis_chat.py history --session s1
python program1_redis_chat.py history --session s1 --limit 4      # 只看最近 4 条

# 列会话 / 看 key 结构 / 清空
python program1_redis_chat.py list
python program1_redis_chat.py stats
python program1_redis_chat.py clear --session s1
python program1_redis_chat.py clear --all
```

### 程序二 · Kafka 传消息

```bash
# 发一条消息
python program2_kafka_bus.py publish --text "你好" --key user-1

# 消费（--group 换消费组就是另一份位点）
python program2_kafka_bus.py consume --topic wk14.chat.turn
python program2_kafka_bus.py consume --topic wk14.chat.turn --group other-group

# 看分区分布
python program2_kafka_bus.py describe --topic wk14.chat.turn
```

### 通用入口

两个程序共用一个 CLI，也可以这么用：

```bash
PYTHONPATH=src python -X utf8 -m redis_kafka_demo redis  add --session s1 --user "问题" --assistant "回答"
PYTHONPATH=src python -X utf8 -m redis_kafka_demo kafka  publish --text "你好"
PYTHONPATH=src python -X utf8 -m redis_kafka_demo status        # 连通性自检
PYTHONPATH=src python -X utf8 -m redis_kafka_demo demo          # 端到端
```

---

## 3. Redis 数据结构设计

```
wk14:chat:sessions                     SET    所有会话 id
wk14:chat:session:<sid>:messages       LIST   消息列表，每条一个 JSON
wk14:chat:session:<sid>:meta           HASH   会话元信息
```

| 需求 | 用什么 | 为什么 |
| --- | --- | --- |
| 一问一答按顺序追加 | **LIST** | `RPUSH` 追加、`LRANGE` 读取都便宜，天然是顺序队列 |
| 会话元信息（标题 / 轮数 / 时间） | **HASH** | 字段能单独改，不用整个对象重写 |
| 有哪些会话 | **SET** | `SADD`/`SMEMBERS`，比 `KEYS *` 安全（`KEYS` 会阻塞整个 Redis） |
| 自动回收 | **TTL** | 写消息时顺手 `EXPIRE` 两个 key，过期后 Redis 自己清 |

一条消息的 JSON 长这样：

```json
{"role": "user", "content": "Redis 和 Kafka 分别适合解决什么问题？", "ts": 1762849200123, "seq": 1}
```

写入用 **pipeline** 打包（`RPUSH` + `HSET` + `SADD` + 2 个 `EXPIRE` 一次往返），不是发六趟网络。

另外有两个保护：

- **条数上限**（`MAX_MESSAGES_PER_SESSION`，默认 200）：超了 `LTRIM` 掉最旧的。
- **脏数据跳过**：LIST 里混进一条坏 JSON，读取时跳过它而不是让整个会话读不出来。

---

## 4. Kafka 设计

| topic | 内容 | key |
| --- | --- | --- |
| `wk14.chat.turn` | 一轮完整对话（user + assistant） | `session_id` |
| `wk14.chat.event` | 预留：通用事件流 | 业务主键 |

**为什么 key 一定要用 `session_id`？**
Kafka 用 key 的哈希值决定消息落到哪个分区：

```
key = session_id  →  同一个会话的所有消息进同一个分区  →  消费时顺序不乱
```

这不是「配置得好不好」的问题，是 Kafka 的机制。演示里 3 条消息全在 partition 2 就是这个道理。

消费侧用了**手动提交**（`enable_auto_commit=False`）——
至少一次语义，程序崩溃时消息会被重新投递，而不是悄悄丢掉。

---

## 5. 架构

```mermaid
graph LR
    CLI[命令行 / demo] --> S1[程序一]
    CLI --> S2[程序二]
    S1 -->|RPUSH / HSET / SADD| R[(Redis)]
    S1 -->|publish key=session_id| K[(Kafka<br/>wk14.chat.turn)]
    S2 -->|subscribe + poll| K
    S2 -->|打印 / 落库| OUT[消费者处理]
```

- **Redis**：会话的**当前状态**（要能随机读写、要能按会话查）。
- **Kafka**：会话的**事件流**（要能顺序消费、要能回放、要能多消费者分摊）。

这正是作业原文举的两个例子 —— 两个中间件解决的是两类不同的问题。

---

## 6. 目录结构

```
作业一/
├── program1_redis_chat.py        程序一入口（Redis）
├── program2_kafka_bus.py         程序二入口（Kafka）
├── docker-compose.yml            Redis + Kafka（KRaft 单节点）
├── src/redis_kafka_demo/
│   ├── __init__.py
│   ├── __main__.py               python -m redis_kafka_demo
│   ├── cli.py                    命令行（两个程序共用）
│   ├── chat_store.py             程序一：Redis 会话存储
│   ├── config.py                 配置（环境变量 / .env）
│   ├── event_bus.py              程序二：Kafka 封装
│   └── models.py                 数据契约
├── scripts/
│   └── launch.py                 启动器（查依赖 / 起中间件 / 跑演示）
├── tests/                        92 个用例，不需要 Redis / Kafka 也能跑
├── docs/
│   ├── design.md                 设计文档
│   ├── 01-端到端演示输出.txt
│   ├── 02-基础设施自检.txt
│   ├── 03-Redis-key结构.txt
│   └── 04-Kafka分区分布.txt
├── start_infra.bat / .sh         起中间件
├── stop_infra.bat / .sh          停中间件
├── run_demo.bat / .sh            跑端到端演示
├── .env.example
└── requirements.txt
```

---

## 7. 测试

```bash
python -X utf8 -m pytest -q              # 92 个用例
python -X utf8 -m ruff check src tests scripts
```

- **92 个用例全部通过**，其中 **大部分不需要 Redis / Kafka**（用内存版 Redis + 假 EventBus）。
- `tests/test_integration.py` 里的 6 个用例会**真的连** Redis / Kafka，中间件没起时自动跳过。

```bash
python -X utf8 -m pytest -q tests/test_integration.py   # 中间件起着的时候跑这个
```

---

## 8. 常见问题

**Q：起中间件报 `ports are not available`？**
宿主机的 6379 / 9092 已经被别的容器占了（本机就有个 `ota-redis` 占着 6379）。
本作业默认用 **6380（Redis）/ 9095（Kafka）**，并在 `.env` 里配好了。
要改就改 `.env` 的 `REDIS_PORT` / `KAFKA_PORT` —— docker-compose 和程序读的是同一份 `.env`，两边自动对上。

**Q：Kafka 容器起来又立刻退出？**
两个已知原因（都已经在 `docker-compose.yml` 里处理好了）：

1. `advertised.listeners` 里**必须同时列 CONTROLLER**。
   只写 `PLAINTEXT://localhost:9095` 的话，Kafka 会拿 `listeners` 里的
   `CONTROLLER://0.0.0.0:9093` 兜底，然后拒绝启动：
   `advertised.listeners cannot use the nonroutable meta-address 0.0.0.0`。
2. 数据目录不能挂在 `/tmp/kraft-combined-logs` —— 命名卷属主是 root，
   容器里的 Kafka（uid 1000）写不进去，会报 `AccessDeniedException`。
   本作业挂在 `/home/appuser` 下，这个路径在镜像里就属于 appuser。

**Q：`.bat` 脚本为什么全是英文？**
Windows 的 cmd.exe 处理 UTF-8 批处理文件有个坑：文件里同时出现「切换代码页 + `cd` 切目录 +
`goto` 跳标签」时，它会把字节读取位置算错，把半行命令当命令执行，报
`'xxx' is not recognized as an internal or external command`。

所以 `.bat` / `.sh` 里**只放纯 ASCII 的几行**，所有中文提示都放在 `scripts/launch.py` 里
（Python 往控制台写文本走 `WriteConsoleW`，不受代码页影响）。
`tests/test_scripts.py` 里有对应的回归测试钉住这条规则。

**Q：跑测试时 Kafka 那个用例偶尔失败？**
kafka-python-ng 有个竞态：连接被并发关掉时会把一个已关闭的 socket 注册进 selectors，
报 `ValueError: Invalid file descriptor: -1`。
`event_bus.py` 里加了 `_retry_on_socket_race()`，重试一次（新开一条连接）就好。

**Q：怎么确认没有把密钥写进代码？**
`tests/test_config.py::test_代码里没有硬编码的密钥` 盯着这件事。
（本作业本来就不需要任何 API Key。）

---

## 9. 设计取舍

| 决定 | 理由 |
| --- | --- |
| Redis 存状态、Kafka 存事件，不混用 | 两类负载的特征不同：状态要随机读写，事件要顺序消费和回放 |
| 消息 key 用 `session_id` | 同一会话进同一分区，顺序有保证；不同会话可以并行消费 |
| 消费用手动提交 | 至少一次语义，处理失败可以重投，不会悄悄丢消息 |
| 写入用 pipeline | 一次网络往返做完 5 个命令 |
| 用 `SMEMBERS` 而不是 `KEYS *` | `KEYS` 会阻塞整个 Redis |
| 解析层单独一个模块 | 换 Redis 客户端 / Kafka 客户端时只改一个文件 |
| 默认端口 6380 / 9095 | 本机 6379 / 9092 经常被别的容器占 |

更完整的设计说明见 [`docs/design.md`](docs/design.md)。

---

## 10. 交付物清单

| 类别 | 数量 | 说明 |
| --- | --- | --- |
| 程序 | 2 | `program1_redis_chat.py`（Redis）、`program2_kafka_bus.py`（Kafka） |
| 源码模块 | 7 | `src/redis_kafka_demo/` 下 7 个 `.py` |
| 中间件编排 | 1 | `docker-compose.yml`（Redis 7 + Kafka 3.9 KRaft） |
| 启动脚本 | 7 | 3 个 `.bat` + 3 个 `.sh` + `scripts/launch.py` |
| 测试用例 | **92** | 全部通过，不需要 API Key；6 个集成用例会真连中间件 |
| 文档 | 2 | `README.md` + `docs/design.md` |
| 实测输出 | 4 | `docs/*.txt` |
| ruff | 干净 | `python -X utf8 -m ruff check src tests scripts` |

自检：

```bash
python -X utf8 -m pytest -q
python -X utf8 -m ruff check src tests scripts
docker compose ps          # 两个容器都是 healthy
python program1_redis_chat.py stats
python program2_kafka_bus.py describe --topic wk14.chat.turn
```
