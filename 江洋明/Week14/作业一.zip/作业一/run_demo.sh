#!/usr/bin/env bash
# Week 14 homework 1 - run the end-to-end demo.
set -e
cd "$(dirname "$0")"
exec python -X utf8 scripts/launch.py demo
