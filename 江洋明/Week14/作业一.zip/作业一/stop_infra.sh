#!/usr/bin/env bash
# Week 14 homework 1 - stop Redis and Kafka containers.
set -e
cd "$(dirname "$0")"
exec python -X utf8 scripts/launch.py infra-down
