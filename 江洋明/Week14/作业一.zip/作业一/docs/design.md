# 作业一 · 设计文档：Redis 存历史对话 · Kafka 传消息

> 对应作业原文：*写两个程序实践下 redis 和 kafka 的使用，比如通过 redis 存储历史对话，通过 kafka 传递消息。*

---

## 1. 需求拆解

作业要的是**两个程序**，分别练 Redis 和 Kafka。拆成可验证的目标：

| 目标 | 验收标准 |
| --- | --- |
| 程序一：Redis 存历史对话 | 多轮对话写进去能按顺序读出来；能列会话；能清空；有过期策略 |
| 程序二：Kafka 传消息 | 能发能收；能指定消费组；能看分区分布 |
| 两者衔接 | 程序一写完能投递到 Kafka，程序二能消费到同一批消息 |

「衔接」这一条是作业里没写但必须有的 —— 不然两个程序就是两个互不相干的 demo，
评审的时候说不清「Redis 和 Kafka 一起用」长什么样。

---

## 2. 架构

```
┌──────────────┐   RPUSH/HSET/SADD    ┌─────────┐
│   程序一      │ ───────────────────▶ │  Redis  │  会话当前状态
│ Redis 存历史  │                      └─────────┘
│              │   publish(key=session_id)
│              │ ───────────────────▶ ┌─────────┐
└──────────────┘                       │  Kafka  │  会话事件流
                                       └─────────┘
┌──────────────┐   subscribe + poll         │
│   程序二      │ ◀───────────────────────── ┘
│ Kafka 传消息  │
└──────────────┘
```

**为什么是两个中间件，不是二选一？**

| 负载 | 特征 | 合适的中间件 |
| --- | --- | --- |
| 会话当前状态 | 按会话随机读写、低延迟、要能过期回收 | Redis |
| 会话事件流 | 顺序消费、可回放、多个消费者分摊 | Kafka |

Redis 的 LIST 也能当队列，但它是「取出来就没了」的语义，不支持回放，
也不支持多个消费者组各自读一份。Kafka 正好补上这两点。

---

## 3. Redis 侧设计

### 3.1 Key 布局

```
wk14:chat:sessions                     SET    所有会话 id
wk14:chat:session:<sid>:messages       LIST   消息列表
wk14:chat:session:<sid>:meta           HASH   会话元信息
```

前缀 `wk14`（`REDIS_PREFIX`）是为了不和别的实验共用一个 Redis 实例时互相干扰。

### 3.2 选型理由

| 数据结构 | 用途 | 替代方案与为什么不选 |
| --- | --- | --- |
| LIST | 消息列表 | 用 STRING 存整个 JSON 数组：每次追加都要「读全量 → 改 → 写全量」，O(n) 且有并发覆盖风险 |
| HASH | 会话元信息 | 用 STRING 存 JSON：改一个字段要重写整个对象 |
| SET | 会话 id 集合 | 用 `KEYS *` 扫描：会阻塞整个 Redis，生产环境绝对不能用 |

### 3.3 写入路径

一次「一轮对话」的写入包含 5 个命令：

```
RPUSH  wk14:chat:session:<sid>:messages  <user_json> <assistant_json>
HSET   wk14:chat:session:<sid>:meta      session_id=... title=... turns=... messages=...
SADD   wk14:chat:sessions                <sid>
EXPIRE wk14:chat:session:<sid>:messages  604800
EXPIRE wk14:chat:session:<sid>:meta      604800
```

用 pipeline 一次往返做完，不是发五趟。`transaction=True` 保证这 5 个命令原子生效。

**TTL 为什么刷新？**
会话是「活跃时不该消失，闲置久了该回收」。每次写入都刷新 TTL，
等于「最后一句话之后 7 天没说话就回收」—— 比「创建后 7 天回收」合理得多。

### 3.4 两个保护

1. **条数上限**：`MAX_MESSAGES_PER_SESSION`（默认 200）。
   超过就 `LTRIM key (len-limit) -1` 丢掉最旧的。防止一个长会话把 Redis 撑爆。
2. **脏数据跳过**：LIST 里混进坏 JSON 时，`history()` 跳过它继续往下读。
   一个坏消息不该让整个会话读不出来。

### 3.5 消息结构

```json
{"role": "user", "content": "…", "ts": 1762849200123, "seq": 1}
```

- `seq` 是会话内的全局序号（第几条消息），前端可以据此排序、标号。
- `ts` 是毫秒时间戳。
- `role` 取 `user` / `assistant` / `system`。

---

## 4. Kafka 侧设计

### 4.1 Topic

| topic | 内容 | key |
| --- | --- | --- |
| `wk14.chat.turn` | 一轮完整对话 | `session_id` |
| `wk14.chat.event` | 预留：通用事件流 | 业务主键 |

### 4.2 分区与顺序（核心）

Kafka 的分区选择规则：

```
partition = murmur2(key) % numPartitions
```

所以 —— **只要 key 相同，消息就一定进同一个分区；同一个分区里的消息按 offset 严格有序。**

本作业用 `session_id` 当 key，于是：

- 同一个会话的多轮对话，消费侧看到的一定是「第一轮 → 第二轮 → 第三轮」。
- 不同会话落在不同分区，可以并行消费，吞吐随分区数线性扩展。

这不是配置技巧，是 Kafka 的机制保证的。演示里 3 条消息全在 partition 2 就是证据。

**如果 key 用 `None` 呢？** 消息会轮询进各分区，同一会话的消息就散开了，顺序没了。
所以 `publish_turn()` 强制把 `session_id` 作为 key。

### 4.3 消费语义

`enable_auto_commit=False` —— **手动提交**。

- 至少一次（at-least-once）：处理失败可以重新投递，不会悄悄丢消息。
- 代价是可能重复消费，消费侧要能容忍重复（用 `turn_id` 去重）。

自动提交（默认开）会在 `poll()` 返回后提交位点，一旦处理逻辑在提交之后崩溃，
那条消息就永远丢了。对「聊天记录」这种场景，宁可重复也不能丢。

### 4.4 `describe()` 为什么用简单消费者

`KafkaConsumer` 一旦 `subscribe()` 了 topic，就不能再 `assign()` 分区
（kafka-python 直接抛 `IllegalStateError`）。
而查「每个分区有几条消息」需要的是「读 offset」而不是「消费消息」，
所以单独开一个 `group_id=None` 的简单消费者，用 `beginning_offsets()` /
`end_offsets()` 拿数。

### 4.5 socket 竞态的兜底

kafka-python-ng 有个竞态：broker 连接被并发关掉时，客户端会把一个**已经关闭**的
socket 注册进 `selectors`，报：

```
ValueError: Invalid file descriptor: -1
```

这不是本项目的 bug。`event_bus.py` 里的 `_retry_on_socket_race()` 捕获这个特定异常，
重开一条连接重试（最多 3 次），其他异常照常抛出。

---

## 5. 分层

```
cli.py          命令行：解析参数、打印结果。不含业务逻辑。
chat_store.py   Redis 存储层：会话的增删查。所有 redis 命令收在这一层。
event_bus.py    Kafka 封装：发 / 收 / 建 topic / 看分区。
models.py       数据契约：ChatMessage / SessionMeta / TurnEvent。
config.py       配置：环境变量 > .env > 默认值。
```

**为什么把 redis / kafka 命令收进两个模块？**
换存储后端（Redis → MongoDB）时只需要重写 `chat_store.py`，
CLI 和演示脚本一行都不用动。

---

## 6. 可测试性

测试分两层：

| 层 | 文件 | 依赖 | 数量 |
| --- | --- | --- | --- |
| 单元 | `test_models.py` / `test_chat_store.py` / `test_cli.py` / `test_config.py` / `test_scripts.py` | 无（用内存版 Redis + 假 EventBus） | 86 |
| 集成 | `test_integration.py` | 真 Redis / 真 Kafka | 6（连不上自动跳过） |

`tests/conftest.py` 里的 `FakeRedis` 实现了本项目用到的命令，语义照抄 redis-py
（`rpush` 返回新长度、`lrange` 越界返回空、`ltrim` 保留 `[start, end]`）。

集成用例测的是「真中间件上才成立」的性质：

- Redis 的 key 类型真的是 `list` / `hash` / `set`；
- TTL 真的设上了；
- **同一个 key 的 5 条消息真的落在同一个分区**。

---

## 7. 中间件编排

`docker-compose.yml` 里两个服务：

| 服务 | 镜像 | 模式 | 宿主端口 |
| --- | --- | --- | --- |
| redis | `redis:7-alpine` | 单实例 + AOF | 6380 |
| kafka | `apache/kafka:3.9.0` | **KRaft**（无 ZooKeeper），broker+controller 合一 | 9095 |

### 7.1 为什么默认端口不是 6379 / 9092

本机 6379 已经被 `ota-redis` 容器占了，9092 也被某个进程占着。
与其让使用者去猜，改成 6380 / 9095 —— 而且这两个变量在 `.env` 里，
**docker-compose 和程序读的是同一份 `.env`**，改一处两边都对得上。

### 7.2 Kafka 配 KRaft 的两个坑

**坑一：`advertised.listeners` 必须同时列 CONTROLLER。**

只写 `PLAINTEXT://localhost:9095` 时，Kafka 会拿 `listeners` 里的
`CONTROLLER://0.0.0.0:9093` 兜底，然后拒绝启动：

```
IllegalArgumentException: requirement failed: advertised.listeners cannot use
the nonroutable meta-address 0.0.0.0. Use a routable IP address.
```

正确写法：

```yaml
KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,CONTROLLER://0.0.0.0:9093
KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://localhost:9095,CONTROLLER://localhost:9093
```

`listeners` 用 `0.0.0.0`（容器内监听所有网卡），`advertised.listeners` 用可路由地址
（告诉客户端「连哪儿」）。

**坑二：数据目录不能挂在 `/tmp/kraft-combined-logs`。**

命名卷的属主默认是 root，镜像里的 Kafka 跑在 uid 1000（appuser），
格式化元数据时写不进去：

```
Error while writing meta.properties file /tmp/kraft-combined-logs:
java.nio.file.AccessDeniedException: bootstrap.checkpoint.tmp
```

挂在 `/home/appuser` 就没事 —— 这个路径在镜像里本来就存在且属于 appuser，
Docker 会把命名卷的属主设成 uid 1000。

---

## 8. 脚本约定（`.bat` 纯 ASCII）

Windows 的 cmd.exe 处理 UTF-8 批处理文件时有个坑：文件里同时出现
「切换代码页 + `cd` 切目录 + `goto` 跳标签」时，它会把**字节读取位置**算错，
把半行命令当命令执行：

```
'是「字节数」去续读批处理文件，' is not recognized as an internal or external command
```

所以约定：

1. `.bat` / `.sh` 里**只放纯 ASCII**；中文提示全在 `scripts/launch.py`。
2. `.bat` 用 **CRLF** 换行，`.sh` 用 **LF**。
3. `.bat` 里**不许出现括号** —— 括号块会让 cmd 改用「字符数」去续读文件，同样算错位置。
4. Python 往控制台写文本走 `WriteConsoleW`，不受控制台代码页影响。

这四条由 `tests/test_scripts.py` 钉住，改坏了测试会红。

---

## 9. 安全与资源

| 项 | 做法 |
| --- | --- |
| 凭据 | 本作业不需要任何 API Key；代码里不写死任何口令 |
| Redis 暴露面 | 只监听宿主机端口，未开密码 —— **本机演示用**；对外暴露必须加 `requirepass` |
| Kafka 暴露面 | 同上，`PLAINTEXT` 无认证；**不要**把 9095 映射到公网 |
| 数据量 | 单会话最多 200 条消息；会话 7 天过期；Redis 内存自动回收 |
| 清理 | `clear --all` 清全部会话；`docker compose down -v` 连数据卷一起删 |
