# 作业二 · 设计文档：基于 Kafka 的多模态 RAG 问答

> 作业原文：
>
> - 功能1，前端网页可以上传多个pdf，通过kafka 到后端，后端通过mineru 解析pdf 进行存储。
> - 功能2，前端网页需要暂时解析的状态，解析中，待解析，解析完成。
> - 功能3，支持多模态问答：
>   - 用户的提问，输出支持图文混排
>   - 用户的提问，支持 图问 一起送到llm 进行回答

---

## 1. 需求拆解

把作业的三条功能翻译成技术需求：

| 作业原话 | 技术含义 | 难点 |
| --- | --- | --- |
| 前端上传多个 PDF | 一个上传接口要收多个文件，要能并发传 | 多文件要一个一个建文档、投消息，不能因为一个失败全回滚 |
| 通过 Kafka 到后端 | 上传请求和解析执行分离 | 解析是慢操作（渲染/抽图/切片/向量化），不能占着 HTTP 线程 |
| 后端通过 MinerU 解析 PDF | 有个真正的版面解析器 | MinerU 装不上（见 §6），必须留退路 |
| 进行存储 | 切块 + 向量可检索 | 存储要能扛住「删了文档还得删干净」 |
| 显示待解析/解析中/解析完成 | 一个跨进程可见的状态机 | Web 和 Worker 是两个进程，状态要有第三方存储 |
| 输出支持图文混排 | 答案里要有内联图片 | 大模型**不产图**，得靠引用 |
| 支持图问一起送 LLM | 多模态请求体 | 要把图转成模型认得的格式 |

第 6 行是最容易踩坑的一条：**DeepSeek 没有出图能力**（`deepseek-v4-pro` 是纯文本，
只有 `deepseek-flash` 能读图）。所以「图文混排」只能做成
「模型在 Markdown 里引用我们提供的图片地址 → 前端内联渲染」，
而不是「模型生成一张图」。

---

## 2. 架构

```
┌──────────────┐
│  浏览器       │  单文件 Vue 3（CDN，零构建）
└──────┬───────┘
       │ ① POST /api/documents  (multipart, 多个 files)
       ▼
┌──────────────────────────────────────────────┐
│ FastAPI  (src/mmrag/api/app.py)             │
│  · 校验扩展名 / 大小 / 数量                   │
│  · 落盘 data/uploads/<doc_id>__<原名>        │
│  · 写 Redis: doc:{id}:meta = status=待解析   │
│  · produce → Kafka  wk14.pdf.parse           │
└──────┬───────────────────────────────────────┘
       │ ②
       ▼
┌──────────────────────────────────────────────┐
│ Kafka  wk14.pdf.parse  (3 分区)              │
└──────┬───────────────────────────────────────┘
       │ ③ consume（key=doc_id）
       ▼
┌──────────────────────────────────────────────┐
│ Worker  (src/mmrag/worker.py)                │
│  · status=解析中                              │
│  · MinerU / PyMuPDF 解析 → 文本 + 图片        │
│  · 切块 → 本地嵌入模型 → numpy 向量索引        │
│  · status=解析完成（页数/块数/图片数）         │
│  · produce → Kafka  wk14.pdf.parsed           │
└──────┬───────────────────────────────────────┘
       │ ④ 前端每 1.2s 轮询 GET /api/documents
       ▼
   Redis  (状态 / 会话历史)   ←→  磁盘 (PDF/图片/块/向量)

┌──────────────────────────────────────────────┐
│ 问答  (src/mmrag/qa.py)                      │
│  问题 → 嵌入 → 余弦检索 top_k 文本块(+图)      │
│       → 多模态提示词 → DeepSeek 流式输出        │
│       → SSE: sources → delta → done          │
└──────────────────────────────────────────────┘
```

**为什么 Web 和 Worker 要拆成两个进程**：解析一个 PDF 要几秒到几十秒。
如果放在 FastAPI 的请求里，10 个文件就得串行等，上传接口直接超时。
拆开之后上传立刻返回「待解析」，Worker 在后台慢慢消化队列。

**为什么状态要放 Redis**：Web 只管收，Worker 只管解析，中间没有共享内存。
必须有一个两边都能读写的地方放状态，Redis 是现成的。

---

## 3. Redis 侧设计

### 3.1 Key 布局

```
wk14mmrag:doc:<doc_id>:meta      HASH    文档状态（status/pages/chunks/images/error…）
wk14mmrag:doc:<doc_id>:chunks    STRING  切块结果（JSON 数组）
wk14mmrag:chat:<session_id>      LIST    会话历史（JSON，每条一行）
wk14mmrag:uploads:<session_id>   LIST    用户自己上传的图片
```

前缀 `wk14mmrag` 可配（`MMRAG_REDIS_PREFIX`），**作业一用的是 `wk14redis`**，
两者不冲突 —— 这两套作业共用同一批 Redis / Kafka 容器但用不同的前缀和 topic，
互不干扰。

### 3.2 存什么、不存什么

- **Redis 只放「小而热」的东西**：状态、会话历史。
- **大文件放磁盘**：
  - 原 PDF → `data/uploads/<doc_id>__<原名>`
  - 图片 → `data/images/<doc_id>/`
  - 文本块 → `data/chunks/<doc_id>.json`
  - 向量 → `data/vectors/<doc_id>.npy`

  向量索引用 numpy 而不是 faiss / chromadb：512 维 × 几千块 = 几 MB，
  全量点积是毫秒级，**引入一个向量库反而是负担**。
  向量已经 L2 归一化，所以点积 == 余弦相似度。

### 3.3 一个真实的坑：`update_status` 会凭空造出文档

Redis 的 `hset` 遇到不存在的 key 会**直接创建**。
写状态机时如果先 `update_status` 再判断文档存不存在，
就会在 Redis 里留下一堆「只有状态、没有内容」的幽灵文档。

现在的做法是先 `exists` 再写，不存在就抛 `KeyError`：

```python
if not self._client.exists(self.doc_key(doc_id)):
    # 不先查一下的话，hset 会凭空造出一个空文档。
    raise KeyError(f"文档不存在: {doc_id}")
```

### 3.4 上传路径必须统一

上传的文件在磁盘上叫 `<doc_id>__<原文件名>`（带 doc_id 前缀是防止同名文件互相覆盖）。
一开始 Worker 的「重投未完成任务」逻辑去找的是 `upload_dir/<原文件名>`，
跟 API 写入的路径对不上 —— 结果 Worker 重启后找不到文件。

现在这个约定只有一个出处：`Settings.upload_path()`，
API、Worker、CLI 三处都调它，不各自拼路径。

---

## 4. Kafka 侧设计

### 4.1 Topic

| Topic | 方向 | 消息体 |
| --- | --- | --- |
| `wk14.pdf.parse` | Web → Worker | `ParseRequest`：doc_id / path / filename / size |
| `wk14.pdf.parsed` | Worker → Web（预留） | 解析结果摘要 |

`wk14.pdf.parsed` 目前只是**把结果再广播一遍**，没有消费者。
留着是因为作业一的主题是「用 Kafka 传递消息」，这条 topic 证明
「解析完成」这个事件也走了 Kafka，而不是 Worker 直接改 Redis ——
将来加「解析完自动推送摘要」「多 worker 负载均衡统计」都在这条链路上接。

### 4.2 分区与顺序

3 个分区，消息 **key 用 `doc_id`**。
同一个文档的多次解析请求会哈希到同一个分区，不会交错执行；
不同文档可以并行解析。

### 4.3 消费语义

- 消费者组 `wk14-mmrag-worker`，`auto_offset_reset=earliest`。
- 一次最多取 5 条（`poll_max_records`），处理完再取下一批。
- **手动提交 offset**：处理完才提交，中途崩溃重启会重投这一批。
- 重投是安全的：解析是幂等的（同样输入 → 同样输出），状态机也允许
  「解析完成 → 解析中 → 解析完成」。

### 4.4 Worker 重启后的自愈

`recover_pending()`：Worker 启动时扫一遍 Redis，
把状态是「待解析」的文档重新投一次 Kafka。
覆盖两种情况：消息发出去了但 Worker 还没消费就崩了；消息被消费了但还没改状态就崩了。

### 4.5 socket 竞态的兜底

Windows 上 `kafka-python` 关闭消费者时偶尔抛
`ValueError: Invalid file descriptor: -1`（心跳线程没退干净）。
消息这时候**已经取到手了**，不能因为关连接失败把整批丢掉：

```python
finally:
    try:
        consumer.close()
    except Exception as exc:  # pragma: no cover - 平台相关
        log.warning("关闭消费者时出错（忽略）：%s", exc)
```

**建 topic 也会撞上同一个坑** —— `KafkaAdminClient` 的建连和 `close()`
都可能抛这个错。而且它比收发消息更隐蔽：`close()` 写在 `finally` 里，
一抛就把 try 里的返回值盖掉了 —— 表现是「明明 topic 建好了，函数却报错」。
所以 `ensure_topic()` 现在也走同一套重试：

```python
def attempt() -> bool:
    admin = KafkaAdminClient(...)
    try:
        admin.create_topics([...])
        return True
    except TopicAlreadyExistsError:
        return False
    finally:
        try:
            admin.close()
        except Exception as exc:      # ← 关连接出错不能盖掉结果
            log.warning("关闭 admin 客户端时出错（忽略）：%s", exc)

return _retry_on_socket_race(attempt)
```

`tests/test_bus.py` 守着这套逻辑（不发真消息，纯单元测试）。
这个竞态在实机上确实会偶发 —— 集成测试偶尔挂一次，
查下来就是它。

---

## 5. 解析层设计

### 5.1 插件式后端

```
ParserBackend (协议)
├── MinerUParser      调 mineru-kit 子进程
└── PyMuPDFParser     纯 Python，直接调 pymupdf
```

`parser_backend` 三种取值：

- `auto`（默认）—— 有 MinerU 就用 MinerU，**失败自动降级**到 PyMuPDF，
  文档状态里写成 `pymupdf(mineru失败降级)`；
- `mineru` —— 强制 MinerU，失败就是失败（写「解析失败」）；
- `pymupdf` —— 强制 PyMuPDF。

这个设计不是「图省事」，而是 §6 的结论逼出来的：
**MinerU 在这个环境里装不稳**，作业点名要 MinerU，
但整条链路必须先能跑通 —— 于是把「用哪个解析器」变成可切换的配置项。

### 5.2 MinerU 的调用约定

```bash
mineru-kit parse <pdf路径> -o <输出目录> -f zip --tier basic [--ocr-mode <模式>]
```

**`--tier basic` 是必须的，不能省** —— 详见 §6.5。

产物是一个 zip，解开后有：

| 文件 | 用途 |
| --- | --- |
| `markdown.md` | 整篇 Markdown（带 `![](images/xxx.jpg)` 引用） |
| `middle_json.json` | 中间结构（页码、块类型、bbox） |
| `structured_content.json` | 结构化内容（标题、段落、表格、图片） |
| `images/` | 抽出来的插图 |

解析器把这些汇总成统一的输出：

```python
ParsedDocument(
    pages=[PageText(page=1, text="..."), ...],
    images=[ImageAsset(doc_id=..., filename=..., page=1), ...],
)
```

### 5.3 MinerU 输出的真实结构（认错了就丢内容）

这一节是**实测**出来的，不是照着文档猜的。4.1.7 的两份 JSON 的页面结构一致：

```jsonc
{
  "pages": [
    {
      "page_idx": 0,                    // 0 起
      "blocks": [
        {"type": "text",  "bbox": [...], "content": "正文"},
        {"type": "image", "bbox": [...], "content": "", "image_source": "images/page_0_image_7.jpg"}
      ]
    }
  ]
}
```

两个坑：

1. **页码在 page 对象上，不在 block 上** —— 先取页码再摊块。
2. **两份 JSON 的块内容形状不一样**：
   - `structured_content.json` 的 `content` 是**字符串**，图片在 `image_source`；
   - `middle_json.json` 的 `content` 是**列表**
     （`[{"type": "text", "content": "正文"}]`），图片在 `image_path`。

最早的实现按「顶层就是一个块列表」的旧结构去认，结果是：
**图片全被丢掉**（MinerU 明明抽出了流程图和柱状图），页面文字变成了
Python 的 `dict` repr（`[{'type': 'text', 'content': '正文'}]`）。

现在按「页面 → 块 → 内容项」三层摊平，两种形状都认：

```python
def _iter_page_blocks(doc) -> list[tuple[int, list[dict]]]: ...   # 页面 → 块
def _walk_block(block) -> tuple[list[str], list[str]]: ...          # 块 → (文字, 图片路径)
```

另外，**MinerU 认出来的拉丁词有时是带空格的** —— `K a f k a`、`R A G`。
一开始以为这是 MinerU 的版面模型把拉丁词拆成了单字符框，
后来实测发现**不是**：把样例 PDF 的字体换掉之后（MinerU 那边什么都没动），
同样的词就干净了。

真正的原因在**渲染层**：MuPDF 自带的 CJK 字体 `china-s` 里，
**拉丁字母是全角的** —— 一个字母占一个字宽。PDF 的**文字层**是干净的
（`get_text()` 出来就是 `FastAPI`），但**渲染出来的像素**是一格一个字母，
MinerU 照着像素 OCR，自然就读成 `F a s t A P I`。
换句话说，MinerU 是**忠实**的，问题出在造样例的代码（§14.8）。

解析层保留了一个还原，把「3 个及以上单字母用单空格连起来」的片段合回去：

```python
_SPACED_LATIN = re.compile(r"(?<![A-Za-z0-9])([A-Za-z](?: [A-Za-z]){2,})(?![A-Za-z0-9])")
```

只认 3 个及以上 —— 免得把「见 A B 两列」这种本来就分开的两个字母误伤成 `AB`。
现在它对样例文档是**不生效**的（样例已经干净了），
留着当兜底：真实世界的 PDF 里，版面模型确实可能把拉丁词拆成单字符框。

### 5.4 页码统一成 1 起

MinerU 用的是 **0 起的 `page_idx`**，别的结构用 1 起的 `page` / `page_no`。
前端要显示「第 N 页」，得跟人看的页码一致，所以统一转成 1 起：

```python
def _page_number(item: dict[str, Any], fallback: int = 0) -> int:
    """从各种结构的页码字段里取出一个 **1 起** 的页码。"""
```

（这个函数是踩坑后才写的：最早版本同时用 `page_idx` 和 `or (index + 1)` 兜底，
结果两页的文档页码都是「1」。）

### 5.5 PyMuPDF 后端做什么

- **正文**：`page.get_text("text")`
- **内嵌插图**：`page.get_images(full=True)` → `doc.extract_image(xref)`
- **整页渲染**：`page.get_pixmap(dpi=...)` → PNG（图文混排要的就是这个）

整页渲染是图文混排的关键：**只要有整页图，模型就能「看到」页面排版**，
即使它读不懂矢量图形，也能把流程图里的文字描述出来。

### 5.6 页码和图片怎么关联

图片存在 `data/images/<doc_id>/` 下，命名 `<页码>_img<序号>.<ext>`。
切块时把块所在页的图片挂到 `Chunk.images` 上，
检索命中这个块时，这些图就跟着进提示词。

### 5.7 样例 PDF 怎么造（字体坑）

样例是自己造的（`scripts/sample_pdf.py`），因为作业环境不一定有能公开
分发的论文 PDF，而且内容确定 → 问什么问题、应该答什么都可预期，方便回归。

造的时候踩了一个**渲染层**的坑：MuPDF 自带的 CJK 字体 `china-s`
里，**拉丁字母是全角的**（一个字母占一个字宽）。所以
`page.insert_text(..., fontname="china-s", "FastAPI")` 画出来是
`F a s t A P I`，宽度正好 `7 × 字号` —— 全角的铁证。

处理办法：**按字符分成两段画** ——

- 汉字、全角标点、箭头 → `china-s`（一个字宽 = 字号）；
- 拉丁字母、数字、空格 → 默认的 Helvetica（比例字体，用
  `pymupdf.get_text_length()` 量宽度）。

分界处按各自字体的实际宽度把光标往前挪，标签在框里也能居中。
改完之后 MinerU 的 OCR 跟着变干净了，模型也能正确读出
「浏览器 → FastAPI → Kafka」（见 §5.3）。

```python
def _is_wide(ch: str) -> bool: ...     # 判断是不是全角字符
def _split_runs(text) -> list[tuple[bool, str]]: ...   # 切成（全角?, 片段）
```

---

## 6. MinerU 装不上：实测过程与结论

作业明确要求「后端通过 mineru 解析 pdf」，所以认真试了，结果如下。

### 6.1 `mineru==4.2.0` 装不上

```
ERROR: Cannot install mineru==4.2.0 ... because these package versions have conflicting dependencies.
The conflict is caused by:
    mineru 4.2.0 depends on shapely>=3,<4
```

PyPI 上 shapely 的最新版本是 **2.2.0**，**根本不存在 3.x**。
所以 `mineru==4.2.0` 的依赖元数据目前是坏的 —— 不是环境问题，是上游发布问题。

### 6.2 退到 `mineru==4.1.7`

4.1.7 要的是 `shapely>=2.0.7,<3`，能装上，
而且 `mineru-kit parse` 的命令行接口和 4.2.0 **完全一致** ——
所以对解析逻辑零影响。

### 6.3 必须独立虚拟环境

MinerU 4.x 要 `tokenizers>=0.22`，
而本仓库共用的 `transformers 4.49` 要求 `tokenizers<0.22`。
装到同一个环境里 pip 会来回降级，最后两边都坏。

结论：MinerU 装在 `.venv-mineru`（独立虚拟环境）里，
Worker 通过 `Settings.mineru_python()` 找到那个解释器，
用 `-m mineru` 或 `mineru-kit` 调它。**主环境的 `requirements.txt` 里故意没有 MinerU。**

### 6.4 为什么不把它做成硬依赖

即便装上了，MinerU 还要下模型（`mineru-kit models download`，几个 G，很久），
而且 CPU 上解析一页要几秒。整个链路的可用性不应该被它绑架。

所以：**MinerU 是「配置项 + 一个安装脚本」，PyMuPDF 是「今天就能跑」的默认退路。**
自动降级让功能 1 在两种情况下都成立。

### 6.5 档位必须显式写成 `basic`

装好了、模型也下了，命令行还是报：

```
错误: 解析 ... 失败: No mapping for the Unicode character exists in the target multi-byte code page.
```

一开始怀疑是中文文件名、怀疑是控制台编码，试了一圈：
换 ASCII 文件名 —— 还是同样的错；
加 `PYTHONIOENCODING=utf-8` / `PYTHONUTF8=1` —— 还是同样的错。

最后把调用拆开、单独调 `local_parse()` 才发现真正的原因：

```
File ".../mineru/model/vlm/runtime.py", line 295, in _create_model
    llama_cpp_engine = Engine(model_gguf, mmproj_gguf, **engine_kwargs)
RuntimeError: No mapping for the Unicode character exists in the target multi-byte code page.
```

**`mineru-kit parse` 的默认档位是 `standard`**（源码：
`mineru/kit/commands/parse.py` 里 `path_tier = validate_tier(parse_tier) if parse_tier is not None else "standard"`），
而 `standard` 档要加载 **llama.cpp 的 VLM 模型** ——
那个原生扩展往 Windows 的 GBK 控制台写一个非 ASCII 字符就抛 `UnicodeEncodeError`。

`basic` 档只用 ONNX 的版面分析 + OCR 模型，没有这个问题：

```bash
mineru-kit parse 论文.pdf -o out -f zip --tier basic     # ✅ 成功
```

所以 `_build_command()` 里**写死** `--tier basic`（`MMRAG_MINERU_TIER` 可覆盖）。
这个坑的迷惑性在于：报错信息一个字都没提档位，只说「Unicode 映射失败」，
看起来像环境编码问题。

### 6.6 装得慢怎么办

默认 PyPI 的 CDN 在国内下大 wheel（gradio 有 31 MB）经常卡住不动。
`scripts/setup_mineru.py` 支持 `--index-url`：

```bash
python -X utf8 scripts/setup_mineru.py --models --index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

实测清华源几分钟就装完了。模型用 modelscope 源（`--source modelscope`），也快很多。

---

## 7. 多模态问答设计

### 7.1 检索

问题 → 本地嵌入模型（`bge-small-zh-v1.5`，512 维，CPU）
→ 在所有文档的向量里做归一化点积 → 取 top_k 文本块。

被选中的块连同它的页码、关联图片一起组成「上下文」。

**两个必要的约束**：

1. **只在「还活着的文档」里检索**。文档元信息有 TTL（默认 7 天），
   过期后 Redis 里的记录没了，但磁盘上的向量索引还在。
   不限定的话，答案会引用用户根本看不到的文档 —— 而且那个文档的图片地址会 404。
   所以检索前先取一次 `store.doc_ids()`（只读集合，不逐个拉 HASH），把它当过滤条件传下去。

   > 配套的坑：`VectorStore.search(doc_ids=[])` 里，
   > 空的 `doc_ids` 表示「一个文档都没有」，**不能**当成「不限制」。
   > 写成 `if doc_ids:` 的话，空列表会被当成 falsy → 退化成全库搜索。

2. **选图要「先覆盖页面，再补细节」**。一路按相似度塞满的话，
   某一页的三张图会把其它页挤掉 —— 实测模型因此看不到第 1 页的流程图，
   回答里直接说「资料里没有流程图」。
   所以取图的顺序是：**先给每个出现过的页面各挑一张，位置还有富余再补同一页里的其它图**。

   修完这一步，同一个问题的回答从「没有流程图」变成了
   准确说出流程图里的三个组件（浏览器 / FastAPI / Kafka）和柱状图的坐标轴名。

### 7.2 提示词

强制模型做三件事：

1. **引用页码**：每个结论后面标 `[第 N 页]`，用户能对得上原文；
2. **引用图片**：需要展示图时，写标准 Markdown 图片语法，地址用本服务的
   `/api/documents/<doc_id>/images/<file>`；
3. **先看用户上传的图**：用户随问题传进来的图**就是问题要问的对象**，
   要直接看图作答，且不标页码（§7.4 详述）。

图片语法在提示词里是这么写的：

```
![说明](图片地址)
```

模型照着写就行，前端负责渲染。

### 7.3 图文混排：引用，不是生成

DeepSeek 不能生成图片，所以：

```
解析 → 每页渲染 PNG + 抽出内嵌图
                ↓
检索命中某块 → 该块的图转成 data URL
                ↓
多模态消息：[{type:text, text:问题+上下文}, {type:image_url, image_url:{url:data:image/png;base64,...}}]
                ↓
模型输出 Markdown：  ![第 1 页](/api/documents/d1/images/page_1.png)
                ↓
前端迷你渲染器 → <img src="...">  内联显示
```

图片最终是以 **URL 引用** 的形式出现在答案里的（不是 base64 内嵌），
好处是答案文本本身可复制、可存 Markdown，换个环境也能渲染。

### 7.4 用户自己上传的图（图问）

走同一条路，只是图片的归属从「文档」变成「会话」：

```
POST /api/chat  { question, session_id, images: [base64...] }
   ↓
存到 data/images/<session_id>/，转 data URL
   ↓
和用户问题、检索到的上下文一起，作为同一条多模态消息发出去
```

#### 7.4.1 两类图片必须分开说

图是发出去了，模型却**不看你这张图** —— 这是这一节最费劲的地方。

最早的做法是：用户上传的图也塞进【可引用的图片】清单，
和文档页的图片**一个格式**列出来：

```
【可引用的图片】
- 第 1 页：/api/documents/d1/images/page_1.png
- 第 0 页：/api/documents/web-xxxx4q8c2/images/探针图片.png   ← 用户传的
```

配上系统提示词里那句「只使用【参考资料】里的内容作答」，
模型看到的是「第 0 页、来源 web-xxxx」，于是判定：

> 所附图片中，**探针图片.png 的来源标注为 web-xxxx4q8c2、位于第 0 页**，
> 与本文档的页面图片并非同一来源，属于与文档主题无关的干扰内容，
> 不能作为本文档的信息来源。

于是它答：「根据提供的文档内容，无法确定房间号、参会人数和议题」。

**图就在那儿，它就是没看** —— 而且答得挺像回事，肉眼扫一眼根本看不出来。

根因有两条，缺一不可：

1. **清单里混了** —— 用户图片被当成「文档的某一页」，还给个荒谬的「第 0 页」；
2. **系统提示词没说** —— 「只使用【参考资料】里的内容作答」这句话，
   等于告诉模型：这张图不在参考资料里，所以不用看。

现在的做法（`prompts.py`）：

| | 文档页的图 | 用户上传的图 |
| --- | --- | --- |
| 在提示词里 | 【可引用的图片】，带地址 + 页码 | 【用户随问题上传的图片】，单独成段 |
| 能不能在答案里引用 | 能（Markdown 图片语法） | 不能（没有对外地址，它属于会话不属于文档） |
| 要不要标页码 | 要 | 不要 |
| 消息体里的位置 | 在后 | **在前**（问题问的就是它） |

系统提示词里也加了一条：

```
1. 先看用户随问题上传的图片。**这类图片就是问题要问的对象**——
   要直接看图作答：图里有的就答出来，图里没有的不要编，
   这类图片**不要**标页码（它本来就不是文档的某一页）。
```

改完之后同一个问题，模型答：

> 根据用户上传的会议卡图片（MEETING CARD），三项信息分别为：
>
> | 项目 | 内容 |
> |---|---|
> | 房间号（ROOM） | **B-207** |
> | 参会人数（GUESTS） | **9** |
> | 议题（AGENDA） | **Q4 RETRO** |

代码上体现为 `build_user_content()` 的两组参数
（`doc_images` / `user_images`），而不是把两类图拼成一个列表。

#### 7.4.2 怎么证明模型真的读了图？

「上传一张图 + 问这张图里有什么」说明不了什么 ——
检索出来的文档图片也在提示词里，模型照着文档答也说得通。

所以做了一张**探针图片**（`data/samples/探针图片.png`），
里面的内容**和文档毫无关系**：

```
MEETING CARD
ROOM:    B-207
GUESTS:  9
AGENDA:  Q4 RETRO
```

文档讲的是 Kafka / Redis / MinerU，这三个值在文档里**一个字都搜不到**。
模型答对了，就只能是**看图看出来的**。

`scripts/screenshot.py` 每次生成截图时都会验一遍：

```
[检查] 答案里读到了 ['B-207', '9', 'RETRO']
```

没读到就会打印 `[警告] 答案里没读到 [...] —— 这次图问没读准`。
这个检查**当场就抓到了 §7.4.1 那个 bug** —— 那次截图跑出来是：

```
[警告] 答案里没读到 ['B-207', 'RETRO'] —— 这次图问没读准
```

### 7.5 流式输出：SSE over POST

用 `fetch` + `ReadableStream` 手撸 SSE（`EventSource` 不能 POST），
帧按 `\n\n` 切。事件顺序：

```
event: sources   data: {"chunks":[...]}   检索到的上下文
event: delta     data: {"text":"..."}      逐字增量
event: done      data: {"sources":[...]}   结束
```

先用 `sources` 把「引用了哪几段」告诉前端，让用户先看到依据，
再逐字吐答案 —— 比一口气等完体验好。

### 7.6 前端的 Markdown 渲染

单文件前端自带一个迷你渲染器（约 60 行），支持
标题、列表、加粗、行内代码、表格、链接、图片。

两个安全点：

1. **先转义再渲染** —— `<script>` 会被转成 `&lt;script&gt;`，不会被当标签执行；
2. **图片地址白名单** —— 只认 `/api/documents/...` 和 `http(s)://`，
   `javascript:alert(1)` 直接丢掉。

渲染器有真浏览器测试（`tests/test_frontend.py`），
把 JS 从 HTML 里抠出来扔进 Chromium 跑，断言 `<img>` / `<table>` 真的生成了 ——
这类问题肉眼容易漏，测起来很便宜。

---

## 8. 切块与索引

- **切块**：段落 → 句子 → 硬切，逐级降级；
  目标 600 字、重叠 80 字。中文按标点断句，不按空格。
- **嵌入**：`bge-small-zh-v1.5`，`normalize_embeddings=True`，CPU。
  这是仓库 `asserts/` 下已有的模型，跨周复用，不重复下载。
- **索引**：每个文档一个 `.npy`（向量矩阵）+ 一个 `.json`（块内容）。
  删除文档时两个一起删，不留孤儿文件。

### 8.1 向量库必须能被别的进程看见

**Worker 和 Web 是两个进程。** Worker 解析完会把索引写到磁盘上，
Web 进程要能看见 —— 否则「服务一直开着，新文档解析完了，问答还是说
『没找到相关内容』」。

最早的实现是**启动时读一次磁盘**，当成一次性快照。
后来改成**增量同步**：每次检索前扫一遍目录，
按 `(mtime, size)` 判断哪个文档变了，变了才重新读：

```python
stamp = (stat.st_mtime, stat.st_size)
if self._stamps.get(doc_id) == stamp:
    continue   # 没变，内存里那份就是最新的
```

写入顺序也有讲究：**先写块文件，再写向量文件** ——
向量文件的 mtime 当作「这个文档写完了」的标记，
读的时候先看向量文件变没变，所以块文件一定先于它就位。

磁盘上已经没有的文档（被删了），内存里也同步去掉。

### 8.2 僵尸文档要清

文档元信息有 TTL，过期后 Redis 里的记录没了，
但磁盘上的向量、块、图片还留着 —— 不清就一直在涨，
而且检索还会命中它们（§7.1 已经挡了，但磁盘还是在涨）。

Worker 每轮开始前跑一次 `prune_orphans()`：
Redis 里已经没有的文档，磁盘上的向量 / 块 / 图片目录一起删掉。

---

## 9. 状态机

```
        上传成功
           │
           ▼
      ┌─────────┐   Worker 消费到    ┌─────────┐   解析成功   ┌─────────┐
      │  待解析  │ ───────────────▶ │  解析中  │ ───────────▶ │ 解析完成 │
      └─────────┘                  └─────────┘              └─────────┘
           │                            │
           │ 解析异常                    │ 解析异常
           ▼                            ▼
      ┌─────────┐                  ┌─────────┐
      │ 解析失败 │                  │ 解析失败 │
      └─────────┘                  └─────────┘
```

- 状态值就是**中文原文**（`DocStatus.PENDING = "待解析"`），
  前端直接显示，不用做映射表；样式用 `status.code`（`pending` / `parsing` / `done` / `failed`）。
- 「解析失败」是作业要求的三态之外**多加的一态**。
  理由很实际：解析失败必须让用户看见，不能让文档永远卡在「解析中」，
  那比报错更难排查。失败原因写在 `error` 字段里，前端直接显示。
- 状态迁移全部在 Worker 里，Web 只负责「写待解析」和「读状态」。

---

## 10. 分层

```
api/app.py       HTTP 边界：校验、路由、SSE
      ↓
qa.py            问答编排：检索 → 提示词 → 流式
      ↓
retriever.py     检索：问题 → 块 + 图
chunker.py       切块
embedder.py      嵌入
llm.py           DeepSeek 客户端（流式 + 图片）
prompts.py       提示词
      ↓
store.py         Redis
bus.py           Kafka
vector_store.py  向量（numpy）
      ↓
parsers/         MinerU / PyMuPDF
models.py        数据契约
config.py        配置
```

**判定标准**：任何一层都不许直接碰别的层的内部实现。
比如 `qa.py` 不知道 Redis 怎么连，只知道 `store.append_message(...)`。

---

## 11. 可测试性

| 层 | 怎么测 |
| --- | --- |
| 纯逻辑（切块、向量、提示词、状态枚举） | 直接调函数，无依赖 |
| 存储 / 消息 | `FakeStore` / `FakeBus`（内存实现，接口一致） |
| 解析 | `FakeParser` 返回固定结构 |
| HTTP | `TestClient`，断言「上传后 Kafka 里确实有一条消息」 |
| 前端 | 真 Chromium 里跑渲染器 |
| 端到端 | **真 Redis + 真 Kafka** 跑完整条链路 |

端到端测试用**带 PID 的专属前缀和 topic**，不会污染开发环境的数据；
连不上中间件就 `pytest.skip`，不会让没装 Docker 的人跑红。

---

## 12. 脚本约定（`.bat` 纯 ASCII）

Windows 的 `cmd.exe` 批处理对编码很敏感：GBK 存的文件里如果有中文，
在别的代码页下会解析出错；而括号 `()` 在 `if` / `for` 里没转义会直接语法错误。

所以定了一条规矩：

> **`.bat` / `.sh` 文件只写纯 ASCII，所有中文提示都放在 `scripts/launch.py` 里。**

`.bat` 只做一件事 —— 调 `scripts/launch.py`：

```bat
@echo off
python -X utf8 scripts\launch.py start
```

并且 `.bat` 必须是 **CRLF** 换行、**不含中文**、**不含未转义的括号**。
`tests/test_scripts.py` 把这三条都断言了 —— 换台机器、换个代码页也不会炸。

### 12.1 端口只有一个来源

**默认端口是 8010，不是 8000。** 8000 是本机的「重灾区」—— 别的 Docker
容器常年发布在 `127.0.0.1:8000`（本机上就有一个），写死 8000 的直接后果是
`[Errno 10048] error while attempting to bind on address ('127.0.0.1', 8000)`，
Web 服务直接起不来。

更坑的是**启动器以前压根不看 `.env`**：`launch.py` 里写的是
`port = args.port or 8000`，而 `.env.example` 里明明有 `MMRAG_API_PORT` ——
配了也白配。所以「改配置里的端口」这条路以前是断的。

现在端口的解析只有一个来源（`mmrag.config.Settings.api_port`，
优先级：环境变量 > `.env` > 默认值）：

```
--port  >  MMRAG_API_PORT（环境变量 / .env）  >  默认 8010
```

被占的时候分两种情况：

| 情况 | 行为 | 为什么 |
| --- | --- | --- |
| **显式指定**（`--port`） | 报错退出（退出码 1），并给出换端口的两种办法 | 用户点了这个端口，就该他自己决定换不换，不偷偷改 |
| **配置里的** | 自动往后挪一个空闲端口，把新地址打出来 | 目的是「先让它起来」，总比甩一句 10048 强 |

端口检查**放在依赖探针前面** —— 那个探针要 `import torch`，得等几十秒；
端口都不对的时候没必要让用户干等（实测报错只花 0.1 秒）。

`tests/test_launch.py` 有 11 条用例守着这套行为。

---

## 13. 安全与资源

| 面 | 措施 |
| --- | --- |
| 密钥 | 只从环境变量 / `.env` 读，代码里没有真实 key，`.env` 在 `.gitignore` 里 |
| 上传 | 只收 `.pdf`；单文件 ≤ 50 MB；一次 ≤ 10 个 |
| 路径穿越 | 图片接口校验文件名，`/`、`\`、`..` 一律 400 |
| XSS | 前端 Markdown 先转义再渲染；图片地址白名单 |
| SQL 注入 | 没有数据库，SQL 层面无风险 |
| 资源 | Redis 文档 TTL 7 天、会话 TTL 1 天；会话最多留 40 条消息 |
| 鉴权 | **无** —— 只适合本机 / 内网演示，对外暴露要自己加网关 |

---

## 14. 已知取舍

1. **向量索引用 numpy 而不是 faiss**：几千块的量级下，全量点积比引入一个
   向量库更省事；上到百万级再换。
2. **图片以 URL 引用而非 base64 内嵌**：答案文本可复制、可存 Markdown；
   代价是图片要能访问到本服务。
3. **MinerU 是可选的**：见 §6 —— 这是被上游依赖问题逼出来的设计，
   不是偷懒；功能 1 在两种配置下都成立。
4. **前端轮询而不是 WebSocket**：三态变化频率低（一次解析几十秒），
   轮询 1.2 秒足够，实现简单、连接稳定。
5. **没有鉴权**：作业没有要求，且这是本机演示项目。
6. **MinerU 的档位钉在 `basic`**：`standard` 档更准（版面理解更细），
   但要加载 llama.cpp 的 VLM 模型，在 Windows 的 GBK 控制台上必炸（§6.5）。
   作业演示够用；真要上 `standard` 得先把控制台切到 UTF-8 代码页。
7. **字母间距的还原是启发式的**：只认「3 个及以上单字母用单空格连起来」。
   表格里如果有一行正好是 `A B C D` 这种单字母列头，会被并成 `ABCD` ——
   概率低，但确实存在。
8. **样例 PDF 的拉丁字母曾经被「拉宽」**：MuPDF 自带的 CJK 字体（`china-s`）
   里拉丁字母是**全角**的 —— 一个字母占一个字宽，画出来的流程图上
   "FastAPI" 是 `F a s t A P I`。这是**造样例的代码**的问题，
   不是解析的问题（PDF 的文字层一直是干净的）：已改成中文走 `china-s`、
   拉丁走默认的 Helvetica，见 `scripts/sample_pdf.py:_is_wide`。
   解析端的 `_normalize_spaced_latin` 保留着当兜底 —— 真实世界的 PDF
   里，MinerU 的版面模型确实会把拉丁词拆成单字符框。
9. **提示词里两类图片必须分开**：用户上传的图和文档页的图混在一起列，
   模型会把用户那张判成「第 0 页的无关材料」然后拒答 —— 见 §7.4.1。
   这是本项目里**最隐蔽的一个 bug**：模型答得言之凿凿（还附了推理过程），
   截图上完全看不出是模型没看图。
10. **`.drop` 必须显式 `display: block`**：上传框是个 `<label>`（默认 inline），
    里面塞了三个 `<div>`。行内框里出现块级元素，浏览器会把这个行内框
    **拆成片段**，虚线边框于是画得七零八落 —— 截图上就是左边一截、
    底边整条没了。改成 block 之后 `getClientRects()` 才是 1。
    `tests/test_frontend.py` 里有一条真浏览器测试守着它。
11. **默认端口不是 8000**：那个端口在本机被别的容器常年占着，写死它的
    直接后果是 `winerror 10048`，Web 服务起不来。端口改成只有一个来源
    （配置），启动器终于会看 `.env` 里配的 `MMRAG_API_PORT` 了 —— 详见 §12.1。

---

## 15. 交付证据

`docs/` 下的东西都是能重跑出来的，不是手抄的：

| 文件 | 怎么来的 |
| --- | --- |
| `01-上传页.png` / `02-解析完成.png` / `03-图文混排问答.png` | `scripts/screenshot.py`（真浏览器跑一遍前端） |
| `04-图问.png` | 同上 —— 第四步：上传探针图片 + 提问，并**校验答案里读到了图里的字**（§7.4.2） |
| `01-端到端演示输出.txt` | `scripts/evidence.py` 的 `evidence_pipeline` |
| `02-基础设施自检.txt` | `scripts/evidence.py` 的 `evidence_health` |
| `03-Redis-key结构.txt` | `scripts/evidence.py` 的 `evidence_redis` |
| `04-Kafka分区分布.txt` | `scripts/evidence.py` 的 `evidence_kafka` |
| `05-多模态问答.txt` | `scripts/evidence.py` 的 `evidence_qa` |
| `06-图问验证.txt` | `scripts/evidence.py` 的 `evidence_image_qa` —— 跑一遍图问，并**校验答案里读没读到图里的字样**（§7.4.2） |

```bash
python -X utf8 scripts/evidence.py          # 全部重生成
python -X utf8 scripts/screenshot.py --base http://127.0.0.1:8010
```

`evidence.py` 默认先清空本作业在 Redis 里的数据，保证每次都是一次干净的运行。
**这个脚本是写的过程中真正抓出 bug 的地方** ——
位点没提交、删掉的文档还在刷 ERROR、向量索引成了「一次性的快照」、
空的 `doc_ids` 被当成「不限制」，四个 bug 都是它先复现出来的。

`screenshot.py` 里的「图问」校验也一样（§7.4.2）——
它当场抓出了提示词把用户图片误标成「第 0 页」那个 bug。
