# 第十四周 · 作业二：基于 Kafka 的多模态 RAG 问答

作业原文：

> 基于 kafka 自己复刻一下多模态rag问答的实现：
>
> - 功能1，前端网页可以上传多个pdf，通过kafka 到后端，后端通过mineru 解析pdf 进行存储。
> - 功能2，前端网页需要暂时解析的状态，解析中，待解析，解析完成。
> - 功能3，支持多模态问答：
>   - 用户的提问，输出支持图文混排
>   - 用户的提问，支持 图问 一起送到llm 进行回答

一句话概括这条链路：

```
浏览器 ──上传多个 PDF──▶ FastAPI ──写 Redis(待解析)──▶ Kafka ──▶ Worker
   ▲                                                            │
   │                                                    MinerU / PyMuPDF 解析
   │                                                            │
   └──── 轮询 Redis 拿三态 ◀── Redis(解析中 → 解析完成) ◀── 切块 + 向量索引
                                                                    │
                     多模态问答 ◀── 图文混排答案 ◀── DeepSeek ◀── 检索 + 图片
```

---

## 1. 快速开始

```bash
cd "14-江洋明-第十四周作业/作业二"

# 1) 装依赖
pip install -r requirements.txt

# 2) 配 Key（DeepSeek，看得懂图的只有 deepseek-flash）
copy .env.example .env        # Windows
# cp .env.example .env        # Linux / macOS
# 然后把 MMRAG_API_KEY 填成真的 key

# 3) 一键启动：中间件 + Worker + Web
start.bat                    # Windows
./start.sh                   # Linux / macOS
```

浏览器打开 <http://127.0.0.1:8010>。

> 端口约定：Redis `6380`、Kafka `9095`、Web `8010`。
>
> **为什么 Web 不用 8000**：那个端口本机常年被别的容器占着，
> 写死 8000 的直接后果是 `winerror 10048` —— Web 服务根本起不来。
> 现在端口只有一个来源（`.env` 里的 `MMRAG_API_PORT`），
> 启动器读的就是它；端口被占时会自动往后挪一个空闲端口并把新地址打出来。
>
> 想自己指定：`python -X utf8 scripts/launch.py serve --port 8014`
> （指定了还占，启动器会直接报错，不会偷偷换）。

想拆开跑就分三个窗口：

```bash
start_infra.bat          # 1) 只起 Redis + Kafka
start_worker.bat         # 2) 只起解析 Worker
start_server.bat         # 3) 只起 Web
```

---

## 2. 作业要求逐条对照

| 作业要求 | 在哪儿 | 怎么做到的 |
| --- | --- | --- |
| **功能1** 前端上传多个 PDF → 经 Kafka 到后端 → 解析 → 存储 | `src/mmrag/api/app.py`、`src/mmrag/worker.py` | 前端 `POST /api/documents`（multipart 多文件）→ 写 Redis「待解析」→ `produce` 到 `wk14.pdf.parse` → Worker 消费 → 解析 → 切块 → 向量入库 → 回写「解析完成」 |
| **后端通过 MinerU 解析 PDF** | `src/mmrag/parsers/mineru_parser.py` | 调 `mineru-kit parse <pdf> -o <dir> -f zip`，读回 `markdown.md` / `middle_json.json` / `structured_content.json` + 图片 |
| **功能2** 前端显示待解析 / 解析中 / 解析完成 | `src/mmrag/models.py`、`frontend/index.html` | `DocStatus` 枚举（中文原文 + 英文代号）；前端每 1.2 秒轮询 `GET /api/documents`，徽章按状态变色，「解析中」还带呼吸动画 |
| **功能3a** 提问，输出图文混排 | `src/mmrag/prompts.py`、`frontend/index.html` | 大模型在答案里写 `![说明](/api/documents/<doc_id>/images/xxx.png)`，前端自带的迷你 Markdown 渲染器把它变成内联 `<img>` |
| **功能3b** 图问：图 + 问题一起送给 LLM | `src/mmrag/qa.py`、`src/mmrag/prompts.py` | 用户上传的图转成 data URL，和问题、检索到的上下文一起塞进同一条多模态消息；提示词里把「用户上传的图」和「文档页的图」**分开说**（见 3.4） |

---

## 3. 三个设计要点

### 3.1 为什么要 Kafka？为什么要 Redis？

分工和作业一一样，但这里更硬：

- **Kafka 传任务**：解析 PDF 是慢操作（渲染、抽图、切片、向量化）。放进 FastAPI 的请求线程会把 Web 服务卡住。
  拆成独立 Worker 进程后，Web 永远快；Kafka 天然就是任务队列 —— 传 10 个 PDF 就是 10 条消息，排队慢慢解析。
- **Redis 存状态**：Web 和 Worker 是两个进程，前端要实时看到「解析中」，状态必须有一个两边都能读的地方。
- **消息 key 用 `doc_id`**：同一个文档的多次解析请求进同一个分区，不会交错执行。

### 3.2 三态状态机

```
待解析 ──Worker 消费到消息──▶ 解析中 ──解析成功──▶ 解析完成
                                │
                                └──解析异常──▶ 解析失败（带错误信息）
```

「解析失败」是额外加的第四态 —— 解析失败必须让用户看见，
不能让文档永远卡在「解析中」。

状态写在 Redis 的 HASH 里（`{prefix}:doc:{doc_id}:meta`），前端轮询读取。
Worker 重启时会调 `recover_pending()`，把卡在「待解析」的文档重新投一遍 Kafka。

### 3.3 图文混排怎么做？

DeepSeek **不生成图片**（`deepseek-v4-pro` 是纯文本，只有 `deepseek-flash` 能读图），
所以图文混排靠「引用」而不是「生成」：

1. 解析时把每一页渲染成 PNG（`data/images/<doc_id>/page_N.png`），
   同时把 PDF 里内嵌的插图**单独抽出来**（MinerU 后端叫 `mineru_page_0_image_7.jpg`）；
2. 检索命中某个文本块时，把它所在页的图一起转成 data URL 送给多模态大模型；
3. 大模型在答案里写 Markdown 图片语法，指向本服务的图片地址；
4. 前端的迷你渲染器把这段 Markdown 变成内联 `<img>`，图片直接显示在答案里。

用户自己上传的图（图问）走同一条路：存到 `data/images/<session_id>/`，转 data URL，和问题一起发。

**选图要「先覆盖页面，再补细节」**：如果一路按相似度塞满，
某一页的三张图会把其它页挤掉 —— 实测模型因此看不到第 1 页的流程图，
回答里直接说「资料里没有流程图」。
所以取图的顺序是：先给每个出现过的页面各挑一张，位置还有富余再补同一页里的其它图。

### 3.4 图问：用户传的图和文档的图得分清楚

「图问」就是用户传一张图、提一个问题。听起来只是把图塞进消息体，
但提示词里**两类图必须分开说**，否则模型会拒绝读图。

踩过的坑：早先把用户传的图也列进了【可引用的图片】，
还给它安了个「第 0 页」；系统提示词又写着「只使用【参考资料】里的内容作答」。
于是模型看到的是「第 0 页、来源 web-xxxx」，
判定这是「与本文档并非同一来源的干扰内容」，理直气壮地答：

> 根据提供的文档内容，无法确定房间号、参会人数和议题。

图就在那儿，它就是没看 —— 而且答得还挺像回事。

现在的做法：

| | 文档页的图 | 用户上传的图 |
| --- | --- | --- |
| 在提示词里 | 【可引用的图片】，带地址 + 页码 | 【用户随问题上传的图片】，单独成段 |
| 能不能在答案里引用 | 能（Markdown 图片语法） | 不能（没有对外地址） |
| 要不要标页码 | 要 | 不要 |
| 消息体里的位置 | 在后 | **在前**（问题问的就是它） |

系统提示词里也加了一条：用户随问题上传的图片**就是问题要问的对象**，
要直接看图作答。

验证方式见 3.5 —— 用一张**内容与文档毫无关系**的探针图片，
答案里只要出现图里的字，就说明模型是真的读了一遍。

### 3.5 怎么证明模型真的读了图？

光问「这张图里画了什么」说明不了什么 —— 检索出来的文档图片也在提示词里，
模型照着文档答也说得通。

所以准备了一张**探针图片**（`data/samples/探针图片.png`，
由 `scripts/sample_pdf.py:make_probe_png` 生成），里面写着：

```
MEETING CARD
ROOM:    B-207
GUESTS:  9
AGENDA:  Q4 RETRO
```

这三个值在文档里**一个字都搜不到**（文档讲的是 Kafka / Redis / MinerU）。
模型答对了，就只能是**看图看出来的**。

`scripts/screenshot.py` 每次生成截图时都会验一遍，
答案里缺哪个字样就会在控制台报出来。

---

## 4. 目录结构

```
作业二/
├── frontend/index.html          # 单文件前端（Vue 3 走 CDN，零构建）
├── src/mmrag/
│   ├── config.py                # 配置（只从环境变量 / .env 读）
│   ├── models.py                # 数据契约：DocStatus / DocumentMeta / Chunk
│   ├── store.py                 # Redis：文档状态 + 会话历史
│   ├── bus.py                   # Kafka：生产 / 消费 / 建 topic
│   ├── parsers/                 # 解析后端：MinerU / PyMuPDF
│   ├── chunker.py               # 切块（段落 → 句子 → 硬切，带重叠）
│   ├── embedder.py              # 本地嵌入模型（bge-small-zh-v1.5）
│   ├── vector_store.py          # 向量索引（numpy，落盘）
│   ├── retriever.py             # 检索：问题 → top_k 文本块 + 图片
│   ├── llm.py                   # DeepSeek 客户端（流式 + 图片 data URL）
│   ├── prompts.py               # 提示词（中文，强制标页码 + 图片语法）
│   ├── qa.py                    # 问答编排（事件流：sources → delta → done）
│   ├── worker.py                # Kafka 消费者 + 状态机
│   ├── cli.py                   # 命令行：status / upload / worker / docs / ask
│   └── api/app.py               # FastAPI 路由
├── scripts/
│   ├── launch.py                # 启动器（所有中文提示都在这）
│   ├── sample_pdf.py            # 造样例 PDF（中文 + 流程图 + 柱状图）+ 探针图片
│   ├── setup_mineru.py          # 装 MinerU（独立虚拟环境）
│   ├── evidence.py              # 生成 docs/ 里的证据文本（可复现）
│   ├── screenshot.py            # 生成交付截图（并校验图问读没读准）
│   └── check_render.py          # 校验前端 Markdown 渲染
├── data/
│   └── samples/                 # 样例文档.pdf + 探针图片.png（生成物）
├── tests/                       # 204 个用例（含真 Redis / Kafka 集成测试）
├── docs/                        # 设计文档 + 交付截图 + 证据文本
├── docker-compose.yml           # Redis + Kafka（KRaft 模式，单机）
├── requirements.txt
└── .env.example
```

---

## 5. 接口一览

| 方法 | 路径 | 干什么 |
| --- | --- | --- |
| GET | `/` | 前端页面 |
| GET | `/api/health` | 自检：Redis / Kafka / 解析后端 / 嵌入模型 / 大模型 |
| POST | `/api/documents` | 上传多个 PDF（multipart `files`） |
| GET | `/api/documents` | 文档列表（含三态） |
| GET | `/api/documents/{doc_id}` | 单个文档 |
| DELETE | `/api/documents/{doc_id}` | 删文档（含向量、图片） |
| GET | `/api/documents/{doc_id}/images/{name}` | 取图片（答案里的内联图靠它） |
| POST | `/api/chat` | 多模态问答，SSE 流式返回，可带图 |
| POST | `/api/chat/json` | 同一个问答，普通 JSON（调试 / 脚本用） |
| GET | `/api/sessions/{sid}/history` | 会话历史 |
| DELETE | `/api/sessions/{sid}` | 清会话历史 |

命令行也有一整套等价子命令：

```bash
python -X utf8 -m mmrag status                  # 自检
python -X utf8 -m mmrag upload 论文.pdf         # 模拟前端上传
python -X utf8 -m mmrag worker --once           # 跑一轮解析
python -X utf8 -m mmrag docs                    # 看文档状态
python -X utf8 -m mmrag ask "这篇讲了什么？"    # 命令行问答
python -X utf8 -m mmrag ask "这图里写了什么" --image 探针图片.png   # 图问
```

---

## 6. MinerU（作业点名的解析器）

MinerU 装在**独立的虚拟环境** `.venv-mineru` 里，不污染主环境：

```bash
python -X utf8 scripts/setup_mineru.py            # 只装包
python -X utf8 scripts/setup_mineru.py --models   # 再下模型（几个 G，很久）
```

三个坑（都是实测踩出来的）：

1. **版本钉在 `mineru==4.1.7`**。`mineru==4.2.0` 的元数据写的是 `shapely>=3,<4`，
   但 PyPI 上 shapely 最新只到 2.2.0 —— **根本不存在 3.x**，
   `pip install mineru==4.2.0` 会在依赖解析阶段直接失败。
   4.1.7 要的是 `shapely>=2.0.7,<3`，能装上，而且 `mineru-kit parse`
   的命令行接口和 4.2.0 完全一致。
2. **必须独立虚拟环境**。MinerU 4.x 要 `tokenizers>=0.22`，
   而仓库里共用的 `transformers 4.49` 要 `tokenizers<0.22` —— 装一起就炸。
   所以主环境的 `requirements.txt` 里**故意没有** MinerU。
3. **档位必须显式写成 `basic`**。`mineru-kit parse` 的默认档位是 `standard`，
   而 standard 档要加载 llama.cpp 的 VLM 模型 —— 那个原生扩展往 Windows 的
   GBK 控制台写一个非 ASCII 字符就抛
   `UnicodeEncodeError: No mapping for the Unicode character exists in the
   target multi-byte code page`，整个解析直接失败，看起来像「PDF 坏了」。
   `basic` 档只用 ONNX 的版面分析 + OCR 模型，没有这个问题。
   本项目在 `_build_command()` 里写死了 `--tier basic`（`MMRAG_MINERU_TIER` 可改）。

下载慢的话可以换镜像源：

```bash
python -X utf8 scripts/setup_mineru.py --models --index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

**没装 MinerU 也能跑**：解析后端是插件式的，`auto` 模式下会自动退回 PyMuPDF
（抽文本 + 抽内嵌图 + 整页渲染），文档状态里会显示 `pymupdf`。
装了 MinerU 就自动优先用它，中途失败也会降级，状态里显示 `pymupdf(mineru失败降级)`。

MinerU 抽出来的东西和 PyMuPDF 不一样，值得说一句：

- **版面更准**：MinerU 认出「这是流程图、这是柱状图」，把图**单独抽出来**
  （`mineru_page_0_image_7.jpg` 这种），而不是只有整页截图；
- **图片更有用**：抽出来的图就是插图本身，尺寸小、内容干净；
  整页渲染（`page_1.png`）留着当兜底 —— 「这一页长什么样」这类问题靠它。

还有一条**不是 MinerU 的锅**、但很值得记的坑：

> 样例 PDF 的流程图上，"FastAPI" 一开始被画成了 `F a s t A P I`。
> 这不是解析错了 —— MuPDF 自带的 CJK 字体（`china-s`）里**拉丁字母是全角的**，
> 一个字母占一个字宽，渲染出来就是那样（PDF 的**文字层**一直是干净的，
> 拉开的是**渲染出来的像素**）。改成中文走 `china-s`、拉丁走默认的
> Helvetica 就好了，见 `scripts/sample_pdf.py:_is_wide`。

改完 MinerU 的 OCR 结果也跟着变干净了 —— 之前它把图里被拉宽的字母
读成 "F a s t A P I"，模型只能照着念；现在能正确读出
「浏览器 → FastAPI → Kafka」。
- **文字要修一下**：MinerU 的版面模型会把连续拉丁字母拆成单字符框再拼回去，
  拼的时候塞了空格 —— `Kafka` 变成 `K a f k a`。
  本项目在解析层把「3 个及以上单字母用单空格连起来」的片段还原回去。

详细设计见 [`docs/design.md`](docs/design.md)。

---

## 7. 测试

```bash
PYTHONPATH=src python -X utf8 -m pytest -q     # 204 个用例
python -m ruff check src tests scripts
```

测试分三层：

| 文件 | 覆盖什么 | 要不要外部依赖 |
| --- | --- | --- |
| `test_models / test_store / test_chunker / test_vector_store / test_prompts / test_llm` | 各模块的纯逻辑 | 不要 |
| `test_bus` | kafka socket 竞态的识别与重试（Windows 上真会偶发） | 不要 |
| `test_parsers / test_worker / test_api / test_cli / test_retriever` | 用假 Redis / 假 Kafka / 假解析器 | 不要 |
| `test_sample_pdf` | 样例 PDF 的字体（拉丁必须用比例字体，不能是全角） | 不要 |
| `test_launch` | 启动器的端口解析：默认端口、`MMRAG_API_PORT` 生效、端口被占怎么办 | 不要 |
| `test_scripts / test_frontend` | 批处理编码约定、前端 Markdown 渲染 | 前端要 Chromium |
| `test_integration` | **真 Redis + 真 Kafka 跑完整条链路** | 要 `docker compose up -d` |

连不上 Redis / Kafka 的用例会**自动跳过**，不会让没装 Docker 的人跑红。

### 证据文本可以一键重生成

`docs/` 里的六个 `.txt`（端到端输出、基础设施自检、Redis key 结构、
Kafka 分区分布、多模态问答、图问验证）不是手抄的，是脚本跑出来的：

```bash
python -X utf8 scripts/evidence.py            # 全部重生成
python -X utf8 scripts/evidence.py --only 03  # 只重生成第 3 个
python -X utf8 scripts/evidence.py --no-clean # 不清 Redis，直接在现有数据上跑
```

脚本默认会先把本作业在 Redis 里的数据清干净，保证证据是一次**干净的运行**。
这个脚本是写的过程中真正抓出 bug 的地方 —— 位点没提交、删掉的文档还在报错、
向量索引成了「一次性的快照」、空 doc_ids 被当成「不限制」，
四个 bug 都是它先复现出来的。

其中 `06-图问验证.txt` 会跑一遍图问，并**校验答案里到底读没读到图里的字样**：

```
  校验（图里的字样，文档里一个都搜不到）：
      ✓ B-207
      ✓ 9
      ✓ RETRO
  结论：全部读到 —— 模型确实把图读了一遍。
```

### 交付截图

`docs/` 下四张截图对应作业的三条功能（`scripts/screenshot.py` 真浏览器跑出来）：

| 文件 | 对应作业要求 | 看什么 |
| --- | --- | --- |
| `01-上传页.png` | 功能1 | 上传入口（可多选，走 Kafka 异步解析） |
| `02-解析完成.png` | 功能2 | 文档列表 + 「解析完成」徽章 + 页数/块数/图数 |
| `03-图文混排问答.png` | 功能3a | 答案里内联出文档第 1 页的流程图（浏览器 → FastAPI → Kafka） |
| `04-图问.png` | 功能3b | 用户上传的探针图片 + 问题 + 模型读出来的房间号/人数/议题 |

```bash
python -X utf8 scripts/screenshot.py --base http://127.0.0.1:8010
```

截图脚本会顺手校验图问读没读准 —— 没读到就在控制台报 `[警告]`。

---

## 8. 排错

| 现象 | 原因 / 怎么办 |
| --- | --- |
| 启动报 `error while attempting to bind on address ('127.0.0.1', 8000)` | 8000 被别的容器占着（Docker 发布端口常见）。本项目默认用 **8010**；要改就改 `.env` 里的 `MMRAG_API_PORT`，或 `python -X utf8 scripts/launch.py serve --port 8014` |
| 提示「端口 xx 已被占用，自动改用 yy」 | 正常 —— 启动器会自己挪一个空闲端口，按它打出来的地址访问即可 |
| `/api/health` 里 `redis: false` | 中间件没起：`start_infra.bat`，或 `docker compose ps` 看容器 |
| `/api/health` 里 `kafka: false` | Kafka 第一次启动要十几秒，等 `healthy` 再操作 |
| 文档一直停在「待解析」 | Worker 没起：`start_worker.bat`；或看 Worker 窗口的日志 |
| 文档卡在「解析中」很久 | MinerU 在跑（慢）；或 Worker 崩了 —— Worker 起来时会自动重投待解析的文档 |
| MinerU 报 `No mapping for the Unicode character exists in the target multi-byte code page` | 档位被改成了 `standard` —— 那个档要加载 llama.cpp 的 VLM 模型，在 GBK 控制台上必炸。保持 `MMRAG_MINERU_TIER=basic` |
| MinerU 报「没有产出结果文件」 | 模型没下：`python -X utf8 scripts/setup_mineru.py --models` |
| 答案里图不显示 | 前端只认 `/api/documents/...` 和 `http(s)://` 开头的图片地址 |
| 图问的答案说「无法确定」，明明图里有 | 用户上传的图被当成了「第 0 页」的文档图片，模型判定它是无关的干扰内容 —— 见 3.4 |
| 问答报「大模型不可用」 | `.env` 里没填 `MMRAG_API_KEY`，或者 key 失效 |
| 答案里没有图片 | 大模型这次没引用图 —— 换个问法，或用 `scripts/screenshot.py` 里那种明确要求贴图的问法 |
| Windows 控制台中文乱码 | 用 `python -X utf8` 启动（本项目所有脚本都这么写） |

---

## 9. 安全约定

- **API Key 只从环境变量 / `.env` 读**，代码里没有任何真实密钥；`.env` 在 `.gitignore` 里，不入库。
- 上传只接受 `.pdf`，单文件上限 50 MB、一次最多 10 个。
- 取图片的接口挡了路径穿越（文件名里有 `/`、`\`、`..` 一律 400）。
- 前端的 Markdown 渲染器是**白名单**的：先转义再渲染，图片地址只认本服务和 `http(s)://`。
- 本项目**没有鉴权**，只适合本机 / 内网演示；要对外暴露请自行加一层网关鉴权。
