"""启动器：起中间件、起 Worker、起服务、跑端到端演示。

为什么把提示逻辑放在 Python 里，而不是直接写进 ``.bat``？

    Windows 的批处理文件一旦含有非 ASCII 字符，cmd.exe 在
    「切换代码页 + ``cd`` 切目录 + ``goto`` 跳标签」同时出现时，
    会把批处理文件的字节读取位置算错 —— 表现是半行命令被当成命令执行，
    报错形如 ``'xxx' is not recognized as an internal or external command``。

    所以 ``.bat`` / ``.sh`` 里只保留纯 ASCII 的几行（切目录 + 调用本脚本），
    真正带中文的提示、依赖检查、地址打印全部放在这里 ——
    Python 往控制台写文本走 ``WriteConsoleW``，不受控制台代码页影响。

用法::

    python -X utf8 scripts/launch.py infra-up     # 起 Redis + Kafka
    python -X utf8 scripts/launch.py setup-mineru # 装 MinerU（可选，很久）
    python -X utf8 scripts/launch.py start        # 一键：中间件 + Worker + Web
    python -X utf8 scripts/launch.py status       # 自检
    python -X utf8 scripts/launch.py demo         # 端到端演示
"""

from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# 让 ``from mmrag.config import Settings`` 能用 ——
# 端口只有一个来源（配置），启动器不自己另开一个。
_SRC = PROJECT_ROOT / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from mmrag.config import Settings  # noqa: E402  （必须在 sys.path 调整之后）

#: 默认端口（和 ``Settings.api_port`` 一致）。
DEFAULT_API_PORT = Settings.api_port

REQUIREMENTS_FILE = "requirements.txt"
ENV_FILE = ".env"
ENV_TEMPLATE = ".env.example"
COMPOSE_FILE = "docker-compose.yml"
SAMPLE_DIR = PROJECT_ROOT / "data" / "samples"


def _setup_output() -> None:
    """把 stdout 改成行缓冲，避免提示压在缓冲区里。"""

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(line_buffering=True)
            except (ValueError, OSError):  # pragma: no cover - 极端情况
                pass


def _print_banner(title: str) -> None:
    print("=" * 56)
    print(f"  {title}")
    print("=" * 56)


def _has_docker() -> bool:
    return shutil.which("docker") is not None


def _compose_cmd() -> list[str]:
    return ["docker", "compose", "-f", str(PROJECT_ROOT / COMPOSE_FILE)]


def _run_compose(args: list[str]) -> int:
    cmd = [*_compose_cmd(), *args]
    print(f"[执行] {' '.join(cmd)}")
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT))


def _project_env() -> dict[str, str]:
    """构造子进程环境变量，把 src 挂到 PYTHONPATH 上。"""

    env = dict(os.environ)
    src = str(PROJECT_ROOT / "src")
    old = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{src}{os.pathsep}{old}" if old else src
    env.setdefault("PYTHONIOENCODING", "utf-8")
    return env


# ------------------------------------------------------------------ 端口


def port_occupied(host: str, port: int) -> bool:
    """端口是不是已经被别的进程占着了。

    做法是真的去 ``bind`` 一下 —— 比翻 netstat 准，也不用认系统语言。
    故意**不**开 ``SO_REUSEADDR``：Windows 上这个选项会让「已经有进程
    在 listen 的端口」也能被绑上，检查就白做了。
    """

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((host, port))
        except OSError:
            return True
    return False


def find_free_port(host: str, start: int, limit: int = 20) -> int:
    """从 ``start`` 开始往上找一个没人用的端口。"""

    for candidate in range(start, start + limit):
        if not port_occupied(host, candidate):
            return candidate
    return start


def resolve_port(host: str, args_port: int = 0) -> int | None:
    """算出 Web 服务最终用哪个端口。

    优先级：命令行 ``--port`` > 环境变量 / ``.env`` 里的 ``MMRAG_API_PORT``
    > 默认值（见 ``mmrag.config.Settings.api_port``）。

    - **显式指定的端口被占** → 返回 ``None``，由调用方报错退出。
      不偷偷换：用户明确点了这个端口，就该他自己决定换不换。
    - **配置里的端口被占** → 自动往后挪一个空闲端口，并把新地址打出来。
      目的是「先让它起来」，总比甩一句 ``[Errno 10048]`` 强。

    以前这里写死 8000，``.env`` 里配的 ``MMRAG_API_PORT`` 完全不生效 ——
    本机上 8000 被别的容器占着，就只能干瞪眼。
    """

    if args_port:
        port = int(args_port)
        explicit = True
    else:
        port = int(Settings.from_env().api_port)
        explicit = False

    if not port_occupied(host, port):
        return port

    if explicit:
        print(f"[错误] 端口 {port} 已经被别的程序占着了，Web 服务起不来。")
        print(f"       本机 {host}:{port} 上有个进程在监听。")
        print("       换端口的两种办法：")
        free = find_free_port(host, port + 1)
        print(f"         1) 命令行：python -X utf8 scripts/launch.py start --port {free}")
        print(f"         2) 配置文件：改 .env 里的 MMRAG_API_PORT（当前默认 {DEFAULT_API_PORT}）")
        print("       改完记得同步 docs/ 里的截图和 README 里的地址。")
        return None

    fallback = find_free_port(host, port + 1)
    print(f"[提示] 端口 {port} 已被占用，自动改用 {fallback}。")
    print(f"       想固定端口就改 .env 里的 MMRAG_API_PORT（当前默认 {DEFAULT_API_PORT}）。")
    print(f"       浏览器打开 http://{host}:{fallback}")
    return fallback


def ensure_env(root: Path = PROJECT_ROOT) -> bool:
    """确保 .env 存在。不存在就从 .env.example 复制一份。"""

    env_path = root / ENV_FILE
    if env_path.exists():
        return True
    template = root / ENV_TEMPLATE
    if template.exists():
        shutil.copyfile(template, env_path)
        print(f"[提示] 未找到 {ENV_FILE}，已从 {ENV_TEMPLATE} 复制一份。")
        print("       记得在里面填 MMRAG_API_KEY。")
    else:
        print(f"[提示] 未找到 {ENV_FILE}，示例模板 {ENV_TEMPLATE} 也不存在。")
    return False


def ensure_deps(root: Path = PROJECT_ROOT) -> bool:
    """确保运行依赖已安装；缺失就 pip install。"""

    modules = "redis, kafka, fastapi, pymupdf, sentence_transformers, openai"
    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"], capture_output=True, cwd=str(root)
    )
    if probe.returncode == 0:
        return True

    print("[安装] 依赖缺失，正在安装，请稍候…")
    req = root / REQUIREMENTS_FILE
    if req.exists():
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS_FILE)],
            cwd=str(root),
        )
    else:
        print(f"[错误] 找不到 {REQUIREMENTS_FILE}")
        return False

    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"], capture_output=True, cwd=str(root)
    )
    if probe.returncode != 0:
        print("[错误] 依赖安装失败，请手动执行：")
        print(f"       {sys.executable} -m pip install -r {REQUIREMENTS_FILE}")
        return False
    return True


def _run_app(app_args: list[str]) -> int:
    cmd = [sys.executable, "-X", "utf8", "-m", "mmrag", *app_args]
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=_project_env())


# ------------------------------------------------------------------ 子命令


def cmd_infra_up(_args: argparse.Namespace) -> int:
    _print_banner("启动中间件（Redis + Kafka）")
    if not _has_docker():
        print("[错误] 找不到 docker，请先装 Docker Desktop 并确保它在运行。")
        return 1
    code = _run_compose(["up", "-d"])
    if code != 0:
        print("[错误] docker compose up 失败，看看上面的输出。")
        return code
    print()
    print("[提示] 第一次启动 Kafka 要等十几秒，等它变成 healthy 再跑演示：")
    print(f"       docker compose -f {COMPOSE_FILE} ps")
    return 0


def cmd_infra_down(args: argparse.Namespace) -> int:
    _print_banner("停止中间件")
    if not _has_docker():
        print("[错误] 找不到 docker。")
        return 1
    extra = ["-v"] if args.volumes else []
    return _run_compose(["down", *extra])


def cmd_status(_args: argparse.Namespace) -> int:
    _print_banner("中间件 + 应用自检")
    if _has_docker():
        _run_compose(["ps"])
        print()
    return _run_app(["status"])


def cmd_worker(_args: argparse.Namespace) -> int:
    _print_banner("解析 Worker（消费 Kafka，解析 PDF）")
    ensure_env()
    if not ensure_deps():
        return 1
    print()
    return _run_app(["worker"])


def cmd_serve(args: argparse.Namespace) -> int:
    _print_banner("Web 服务")
    ensure_env()
    host = args.host or "127.0.0.1"
    # 端口先查 —— ``ensure_deps`` 那个依赖探针要 import torch，得等几十秒，
    # 端口不对的话没必要让用户干等。
    port = resolve_port(host, args.port)
    if port is None:
        return 1
    if not ensure_deps():
        return 1
    print(f"[地址] http://{host}:{port}")
    print("[提示] 按 Ctrl+C 停止")
    print()
    cmd = [
        sys.executable,
        "-X",
        "utf8",
        "-m",
        "uvicorn",
        "mmrag.api.app:app",
        "--host",
        host,
        "--port",
        str(port),
    ]
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=_project_env())


def cmd_start(args: argparse.Namespace) -> int:
    """一键：中间件 + Worker + Web。"""

    _print_banner("一键启动")
    ensure_env()
    host = args.host or "127.0.0.1"
    # 端口先定下来：被占就早说，
    # 别等中间件和 Worker 都起来了才发现 Web 起不来。
    port = resolve_port(host, args.port)
    if port is None:
        return 1
    if not ensure_deps():
        return 1

    if _has_docker():
        print("[中间件] 启动 Redis + Kafka…")
        _run_compose(["up", "-d"])
        print("[中间件] 等 Kafka 就绪…")
        _wait_kafka()
    else:
        print("[提示] 没找到 docker，跳过中间件启动（假设 Redis/Kafka 已在跑）")

    worker = subprocess.Popen(
        [sys.executable, "-X", "utf8", "-m", "mmrag", "worker"],
        cwd=str(PROJECT_ROOT),
        env=_project_env(),
    )
    print(f"[Worker] 已启动（pid={worker.pid}），Ctrl+C 一起停")
    try:
        print(f"[地址] http://{host}:{port}")
        cmd = [
            sys.executable,
            "-X",
            "utf8",
            "-m",
            "uvicorn",
            "mmrag.api.app:app",
            "--host",
            host,
            "--port",
            str(port),
        ]
        return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=_project_env())
    finally:
        worker.terminate()
        try:
            worker.wait(timeout=10)
        except subprocess.TimeoutExpired:  # pragma: no cover
            worker.kill()


def _wait_kafka(timeout: float = 90.0) -> bool:
    """等 Kafka 端口能连上。"""

    import time

    host, port = "127.0.0.1", 9095
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=2):
                return True
        except OSError:
            time.sleep(2)
    print("[提示] 等不到 Kafka 9095，先确认中间件起来了。")
    return False


def cmd_demo(_args: argparse.Namespace) -> int:
    """端到端演示：造 PDF → 上传 → 解析 → 问答。"""

    _print_banner("端到端演示：上传 → Kafka → 解析 → 图文混排问答")
    ensure_env()
    if not ensure_deps():
        return 1
    print()

    sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
    from sample_pdf import make_sample_pdf

    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    pdf_path = SAMPLE_DIR / "示例文档.pdf"
    make_sample_pdf(pdf_path)
    print(f"[样例] 已生成 {pdf_path}")

    code = _run_app(["upload", str(pdf_path)])
    if code != 0:
        return code
    print()
    print("[提示] 上传完状态是「待解析」，需要 Worker 在跑才会推进：")
    print("       python -X utf8 scripts/launch.py worker")
    print()
    _run_app(["docs"])
    return 0


def cmd_setup_mineru(args: argparse.Namespace) -> int:
    _print_banner("安装 MinerU（独立虚拟环境）")
    cmd = [sys.executable, "-X", "utf8", str(PROJECT_ROOT / "scripts" / "setup_mineru.py")]
    if args.models:
        cmd.append("--models")
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=_project_env())


def cmd_screenshot(args: argparse.Namespace) -> int:
    _print_banner("生成交付截图")
    cmd = [sys.executable, "-X", "utf8", str(PROJECT_ROOT / "scripts" / "screenshot.py")]
    if args.base:
        cmd += ["--base", args.base]
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=_project_env())


# ------------------------------------------------------------------ 入口


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="第十四周作业二 · 启动器")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("infra-up", help="启动 Redis + Kafka").set_defaults(func=cmd_infra_up)
    p_down = sub.add_parser("infra-down", help="停止 Redis + Kafka")
    p_down.add_argument("--volumes", action="store_true", help="连数据卷一起删")
    p_down.set_defaults(func=cmd_infra_down)
    sub.add_parser("status", help="查看状态").set_defaults(func=cmd_status)
    sub.add_parser("worker", help="启动解析 Worker").set_defaults(func=cmd_worker)

    p_serve = sub.add_parser("serve", help="启动 Web 服务")
    p_serve.add_argument("--host", default="")
    p_serve.add_argument("--port", type=int, default=0)
    p_serve.set_defaults(func=cmd_serve)

    p_start = sub.add_parser("start", help="一键：中间件 + Worker + Web")
    p_start.add_argument("--host", default="")
    p_start.add_argument("--port", type=int, default=0)
    p_start.set_defaults(func=cmd_start)

    sub.add_parser("demo", help="端到端演示").set_defaults(func=cmd_demo)

    p_mineru = sub.add_parser("setup-mineru", help="安装 MinerU")
    p_mineru.add_argument("--models", action="store_true", help="顺便下载模型（很大）")
    p_mineru.set_defaults(func=cmd_setup_mineru)

    p_shot = sub.add_parser("screenshot", help="生成交付截图")
    p_shot.add_argument("--base", default="")
    p_shot.set_defaults(func=cmd_screenshot)

    args = parser.parse_args(argv)
    handler = getattr(args, "func", None)
    if handler is None:
        parser.print_help()
        return 1
    _setup_output()
    return int(handler(args) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
