"""安装 MinerU（可选，但作业原文要的就是它）。

MinerU 装在**独立的虚拟环境** ``.venv-mineru`` 里，不污染主环境。
原因：MinerU 4.x 要 ``tokenizers>=0.22``，而仓库里共用的
``transformers 4.49`` 要 ``tokenizers<0.22`` —— 装一起就炸。

**版本为什么钉在 4.1.7？**

MinerU 4.2.0 的元数据写的是 ``shapely>=3,<4``，但 PyPI 上 shapely 的
最新版本是 2.2.0 —— **根本不存在 3.x**。所以 ``pip install mineru==4.2.0``
会在依赖解析阶段直接失败：

    ERROR: Could not find a version that satisfies the requirement shapely>=3

4.1.7 要求的是 ``shapely>=2.0.7,<3``，能装上，而且 ``mineru-kit parse``
的命令行接口和 4.2.0 **完全一致**（同样是 ``-o`` / ``-f markdown|middle_json|zip``）。

用法::

    python -X utf8 scripts/setup_mineru.py            # 只装包
    python -X utf8 scripts/setup_mineru.py --models   # 再下模型（很大，几个 G）
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
VENV_DIR = PROJECT_ROOT / ".venv-mineru"

#: 默认装的版本 —— 4.2.0 的 shapely>=3 在 PyPI 上无解，见模块文档。
DEFAULT_MINERU_VERSION = "4.1.7"


def _print_banner(title: str) -> None:
    print("=" * 56)
    print(f"  {title}")
    print("=" * 56)


def _venv_python() -> Path:
    if os.name == "nt":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def _mineru_kit() -> Path:
    """``mineru-kit`` 命令的位置。"""

    if os.name == "nt":
        return VENV_DIR / "Scripts" / "mineru-kit.exe"
    return VENV_DIR / "bin" / "mineru-kit"


def _run(cmd: list[str], **kwargs) -> int:
    print(f"[执行] {' '.join(cmd)}")
    return subprocess.call(cmd, **kwargs)


def ensure_venv() -> Path:
    """建虚拟环境（已存在就复用）。"""

    python = _venv_python()
    if python.is_file():
        print(f"[跳过] 虚拟环境已存在：{VENV_DIR}")
        return python
    _print_banner("创建虚拟环境")
    _run([sys.executable, "-m", "venv", str(VENV_DIR)])
    if not python.is_file():
        raise SystemExit(f"[错误] 虚拟环境创建失败：{VENV_DIR}")
    return python


def install_mineru(version: str, index_url: str = "") -> bool:
    """装 MinerU。

    ``index_url`` 给了就走指定的源 —— PyPI 的 CDN 在国内下大 wheel
    （gradio 有 31 MB）经常卡住不动，换清华源会快很多。
    """

    python = _venv_python()
    _print_banner(f"安装 mineru=={version}")
    source = ["--index-url", index_url] if index_url else []
    if index_url:
        print(f"[提示] 用镜像源：{index_url}")
    _run([str(python), "-m", "pip", "install", "--upgrade", "pip", *source])
    code = _run([str(python), "-m", "pip", "install", f"mineru=={version}", *source])
    if code != 0:
        print()
        print("[错误] 安装失败。常见原因：")
        print("  1) 网络慢 —— 依赖树有几百 MB，可以重试，pip 会复用已下的缓存。")
        print("     卡住的话换个镜像源：")
        print(
            "     python -X utf8 scripts/setup_mineru.py "
            "--index-url https://pypi.tuna.tsinghua.edu.cn/simple"
        )
        print("  2) 依赖无解 —— 换版本试试：")
        print(f"     python -X utf8 scripts/setup_mineru.py --version {DEFAULT_MINERU_VERSION}")
        return False
    return True


def download_models(tier: str = "basic", source: str = "modelscope") -> bool:
    """下模型。"""

    python = _venv_python()
    exe = _mineru_kit()
    _print_banner(f"下载模型（tier={tier}, source={source}）")
    print("[提示] 模型有几个 G，下载很慢；下完之前解析会失败。")
    print("[提示] 国内用 modelscope 源，比 huggingface 快很多。")
    print()
    if exe.is_file():
        command = [str(exe), "models", "download", "--tier", tier, "--source", source]
    else:
        command = [
            str(python), "-m", "mineru.kit.main", "models", "download",
            "--tier", tier, "--source", source,
        ]
    return _run(command, cwd=str(PROJECT_ROOT)) == 0


def verify() -> None:
    """装完检查一下。"""

    python = _venv_python()
    _print_banner("安装结果检查")
    probe = subprocess.run(
        [str(python), "-c", "import mineru; print('mineru', getattr(mineru, '__version__', 'ok'))"],
        capture_output=True,
        text=True,
    )
    print(probe.stdout.strip() or probe.stderr.strip()[:400])
    exe = _mineru_kit()
    if exe.is_file():
        print(f"mineru-kit: {exe}")
    else:
        print("mineru-kit: 没找到（包可能没装全）")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="安装 MinerU 到独立虚拟环境")
    parser.add_argument("--version", default=DEFAULT_MINERU_VERSION, help="要装的 mineru 版本")
    parser.add_argument("--models", action="store_true", help="顺便下载模型")
    parser.add_argument("--tier", default="basic", help="模型档位：basic / standard")
    parser.add_argument("--source", default="modelscope", help="模型源：modelscope / huggingface")
    parser.add_argument(
        "--index-url",
        default="",
        help="pip 源（国内可以换清华源：https://pypi.tuna.tsinghua.edu.cn/simple）",
    )
    args = parser.parse_args(argv)

    ensure_venv()
    if not install_mineru(args.version, index_url=args.index_url):
        return 1
    verify()
    if args.models:
        if not download_models(tier=args.tier, source=args.source):
            return 1
    else:
        print()
        print("[下一步] 要下模型再跑一次：")
        print("         python -X utf8 scripts/setup_mineru.py --models")
    print()
    print("[提示] 没装 MinerU 也能跑 —— 解析会自动退回 PyMuPDF 后端。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
