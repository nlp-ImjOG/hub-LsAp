"""校验前端的 Markdown 渲染器。

把 ``frontend/index.html`` 里的渲染函数抽出来，在真实 Chromium 里执行，
喂一条真实的大模型回答，检查图片和表格有没有被正确渲染。

``tests/test_frontend.py`` 是这件事的自动化版本（跑在 pytest 里）；
这个脚本是给人手动看的 —— 改完渲染器想立刻看一眼效果时用。

    python -X utf8 scripts/check_render.py
"""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

SAMPLE = """## 系统设计要点（第 1 页）

| 环节 | 做法 |
|---|---|
| 消息队列 | 采用 Kafka 作为上传事件与解析任务之间的消息队列 |
| 状态管理 | 采用 Redis 保存文档解析状态 |

![第 1 页：多模态 RAG 系统的设计要点]( /api/documents/doc-abc/images/page_1.png)

![检索延迟柱状图](/api/documents/doc-abc/images/p1_img1.png)

正文里的 **加粗** 和 `代码`。
"""


def main() -> int:
    from playwright.sync_api import sync_playwright

    from screenshot import _find_chromium

    html = (PROJECT_ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    js = html[html.index("/* ── 迷你 Markdown 渲染") : html.index("/* ── 健康检查")]

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=_find_chromium())
        page = browser.new_page()
        page.set_content("<div id='out'></div>")
        out = page.evaluate(
            "([js, raw]) => {"
            "  const f = new Function('raw', js + '; return render(raw);');"
            "  return f(raw);"
            "}",
            [js, SAMPLE],
        )
        browser.close()

    print("渲染结果片段：")
    print(out)
    print()
    print("含 <img>   :", "<img" in out)
    print("含 <table> :", "<table" in out)
    print("残留竖线   :", "|---|" in out)
    return 0 if ("<img" in out and "<table" in out and "|---|" not in out) else 1


if __name__ == "__main__":
    raise SystemExit(main())
