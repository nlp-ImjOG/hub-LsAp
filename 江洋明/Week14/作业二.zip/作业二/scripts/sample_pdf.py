"""生成一份样例 PDF（演示 / 自测用）。

为什么要自己造 PDF：

- 作业环境不一定有能公开分发的论文 PDF；
- 样例里能放**中文正文 + 一张图**，正好覆盖「文本 + 图」两条路；
- 内容是确定的，所以「问什么问题、应该答什么」是可预期的，方便回归测试。

用法::

    python -X utf8 scripts/sample_pdf.py [输出路径]
"""

from __future__ import annotations

import sys
from pathlib import Path

#: 样例正文 —— 故意写得短小、事实明确，方便问出确定答案。
PAGES: list[tuple[str, list[str]]] = [
    (
        "多模态 RAG 系统的设计要点",
        [
            "本节说明一个多模态检索增强生成（RAG）系统的基本设计要点。",
            "第一，系统采用 Kafka 作为上传事件与解析任务之间的消息队列。",
            "生产者把文档标识作为消息键，同一个文档的多次解析请求会进入同一个分区，"
            "从而保证处理顺序。",
            "第二，系统采用 Redis 保存文档的解析状态，状态分为待解析、解析中、解析完成三种。",
            "第三，文档解析由 MinerU 完成，解析结果切块后使用本地嵌入模型建立向量索引。",
        ],
    ),
    (
        "检索与大模型调用",
        [
            "用户提问后，系统先把问题编码成向量，在向量索引中检索最相关的若干个文本块。",
            "命中的文本块连同所在页面的图片一起送入多模态大模型。",
            "DeepSeek 平台中只有 deepseek-flash 模型能够读取图片，deepseek-v4-pro 仅支持纯文本。",
            "由于大模型不会生成图片，图文混排通过在答案中引用文档图片地址来实现。",
        ],
    ),
]


#: 流程图在第 1 页上的位置（PDF 点，左上角 + 右下角）。
#: 算出来的：正文从 y=120 开始、每行 34，第 1 页有 5 行 → y=290，
#: 流程图画在 y+20=310，高 150。
FIGURE_RECT = (60.0, 310.0, 360.0, 460.0)


def make_sample_pdf(path: Path) -> Path:
    """造一份两页的样例 PDF。"""

    import pymupdf

    path.parent.mkdir(parents=True, exist_ok=True)
    doc = pymupdf.open()
    try:
        for index, (title, lines) in enumerate(PAGES):
            page = doc.new_page(width=595, height=842)  # A4
            _draw_header(page, title, index + 1)
            y = 120.0
            for line in lines:
                _draw_text(page, line, 60, y)
                y += 34
            if index == 0:
                _draw_figure(page, 60, y + 20)
                _insert_raster(page, 60, y + 190)
        doc.save(str(path))
    finally:
        doc.close()
    return path


def export_figure_png(pdf_path: Path, png_path: Path, dpi: int = 220) -> Path:
    """把第 1 页的流程图单独导出一张 PNG。

    给「图问」演示用 —— 用户上传一张图 + 提一个问题，
    看看多模态模型是不是真能读图（而不是靠检索蒙对答案）。
    """

    import pymupdf

    png_path.parent.mkdir(parents=True, exist_ok=True)
    doc = pymupdf.open(pdf_path)
    try:
        pix = doc[0].get_pixmap(dpi=dpi, clip=pymupdf.Rect(*FIGURE_RECT))
        pix.save(str(png_path))
    finally:
        doc.close()
    return png_path


def _insert_raster(page: object, x: float, y: float) -> None:
    """插一张真正的位图 —— 用来覆盖「PDF 内嵌图片」这条解析路径。"""

    try:
        from PIL import Image, ImageDraw
    except ImportError:  # pragma: no cover - 没装 pillow 就跳过
        return

    image = Image.new("RGB", (420, 120), (246, 248, 252))
    draw = ImageDraw.Draw(image)
    draw.rectangle((2, 2, 417, 117), outline=(150, 165, 195), width=2)
    for i, height in enumerate((38, 62, 48, 84, 70)):
        left = 30 + i * 78
        draw.rectangle((left, 104 - height, left + 46, 104), fill=(59, 130, 246))
    draw.text((30, 8), "retrieval latency (ms)", fill=(60, 70, 95))

    import io

    import pymupdf

    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    page.insert_image(  # type: ignore[attr-defined]
        pymupdf.Rect(x, y, x + 420, y + 120), stream=buffer.getvalue()
    )


def _draw_header(page: object, title: str, number: int) -> None:
    _draw_text(page, title, 60, 70, size=17)
    _draw_text(page, f"第 {number} 页", 500, 70, size=10, color=(0.45, 0.47, 0.55))
    page.draw_line(  # type: ignore[attr-defined]
        (60, 88), (535, 88), color=(0.8, 0.82, 0.88), width=0.8
    )


#: 需要用 CJK 字体（``china-s``）画的字符 —— 汉字、全角标点、箭头。
#:
#: **为什么要按字分开画？** MuPDF 自带的 CJK 字体里，**拉丁字母是全角的** ——
#: 一个字母占一个字宽（实测 ``FastAPI`` 的包围盒正好是 7 × 字号）。
#: 画出来就是 "F a s t A P I"、"K a f k a"，一眼假。
#: 所以拉丁和数字改用默认的 Helvetica（比例字体），中文仍然用 china-s，
#: 分界处按各字体的实际宽度往前挪。
def _is_wide(ch: str) -> bool:
    """这个字符要不要用全角的 CJK 字体画。"""

    cp = ord(ch)
    return (
        0x2E80 <= cp <= 0x303E  # CJK 部首、中日韩符号与标点
        or 0x3041 <= cp <= 0x33FF  # 假名、注音、兼容字符
        or 0x3400 <= cp <= 0x4DBF  # 扩展 A
        or 0x4E00 <= cp <= 0x9FFF  # 基本汉字
        or 0xA000 <= cp <= 0xA4CF  # 彝文
        or 0xAC00 <= cp <= 0xD7A3  # 韩文音节
        or 0xF900 <= cp <= 0xFAFF  # 兼容汉字
        or 0xFE10 <= cp <= 0xFE6F  # 竖排标点、CJK 兼容形式
        or 0xFF00 <= cp <= 0xFF60  # 全角形式（，（）等）
        or 0xFFE0 <= cp <= 0xFFE6  # 全角符号
        or cp in (0x2190, 0x2191, 0x2192, 0x2193)  # 箭头
    )


def _split_runs(text: str) -> list[tuple[bool, str]]:
    """把一行文字切成 ``[(是不是全角, 片段), ...]``。"""

    runs: list[tuple[bool, str]] = []
    for ch in text:
        wide = _is_wide(ch)
        if runs and runs[-1][0] == wide:
            runs[-1] = (wide, runs[-1][1] + ch)
        else:
            runs.append((wide, ch))
    return runs


def _draw_text(
    page: object,
    text: str,
    x: float,
    y: float,
    size: float = 11.5,
    color: tuple[float, float, float] = (0.12, 0.14, 0.2),
) -> None:
    """写一行文字（中文 + 拉丁混排）。

    MuPDF 自带了 CJK 字体（``china-s``），不依赖系统字体文件。
    中文用 ``china-s``、拉丁用默认的 Helvetica —— 原因见 :func:`_is_wide`。
    """

    import pymupdf

    try:
        cursor = x
        for wide, run in _split_runs(text):
            if wide:
                page.insert_text(  # type: ignore[attr-defined]
                    (cursor, y), run, fontname="china-s", fontsize=size, color=color
                )
                # CJK 字体里一个字宽正好是一个字号（实测 ``浏览器`` = 3 × 字号）。
                cursor += size * len(run)
            else:
                page.insert_text(  # type: ignore[attr-defined]
                    (cursor, y), run, fontsize=size, color=color
                )
                cursor += pymupdf.get_text_length(run, fontname="helv", fontsize=size)
    except Exception:
        # 字体不可用就退回英文（至少不报错）
        page.insert_text((x, y), text, fontsize=size, color=color)  # type: ignore[attr-defined]


def _text_width(text: str, size: float) -> float:
    """算一行文字有多宽 —— 和 :func:`_draw_text` 用的宽度口径保持一致。"""

    import pymupdf

    total = 0.0
    for wide, run in _split_runs(text):
        if wide:
            total += size * len(run)
        else:
            total += pymupdf.get_text_length(run, fontname="helv", fontsize=size)
    return total


def _draw_figure(page: object, x: float, y: float) -> None:
    """画一张示意图 —— 顺便当「文档里内嵌的图」用。"""

    width, height = 300.0, 150.0
    page.draw_rect(  # type: ignore[attr-defined]
        (x, y, x + width, y + height),
        color=(0.55, 0.6, 0.72),
        fill=(0.95, 0.96, 0.99),
        width=1.0,
    )
    box_w = 72.0
    boxes = [
        ("浏览器", 0.05),
        ("FastAPI", 0.36),
        ("Kafka", 0.67),
    ]
    lefts = [x + width * offset for _label, offset in boxes]
    for (label, _offset), bx in zip(boxes, lefts):
        page.draw_rect(  # type: ignore[attr-defined]
            (bx, y + 40, bx + box_w, y + 78),
            color=(0.23, 0.51, 0.96),
            fill=(0.88, 0.93, 1.0),
            width=1.0,
        )
        # 标签在框里居中 —— 中英文混排时宽度不一样，只能按算出来的宽摆。
        label_x = bx + (box_w - _text_width(label, 9.5)) / 2
        _draw_text(page, label, label_x, y + 63, size=9.5, color=(0.15, 0.3, 0.65))
    # 连线：上一个框的右边缘 → 下一个框的左边缘（别再写死偏移量了，
    # 框一变宽连线就跑到框里去了）。
    for index in range(len(boxes) - 1):
        start = lefts[index] + box_w
        end = lefts[index + 1]
        page.draw_line(  # type: ignore[attr-defined]
            (start, y + 59), (end, y + 59), color=(0.35, 0.4, 0.5), width=1.2
        )
        # 箭头
        page.draw_line(  # type: ignore[attr-defined]
            (end - 5, y + 56), (end, y + 59), color=(0.35, 0.4, 0.5), width=1.2
        )
        page.draw_line(  # type: ignore[attr-defined]
            (end - 5, y + 62), (end, y + 59), color=(0.35, 0.4, 0.5), width=1.2
        )
    _draw_text(page, "上传 → 解析 → 检索 → 回答", x + 12, y + 130, size=9.5,
               color=(0.35, 0.4, 0.5))


def make_probe_png(path: Path) -> Path:
    """造一张「图问」专用的探针图片。

    作业功能 3b 要证明**图问**真的能读图。但只问「这张图里画了什么」
    说明不了什么 —— 检索出来的文档图片也在提示词里，模型照着文档答也说得通。

    所以这张图里的内容**故意和文档毫无关系**：

    - 房间号 ``B-207``
    - 参会人数 ``9``
    - 议题 ``Q4 RETRO``

    这几个值在文档里一个字都搜不到。模型答对了，就只能是**看图看出来的**。

    图片里只用拉丁字母 —— PIL 的默认位图字体没有中文字形，
    免得为了演示去依赖系统字体。
    """

    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:  # pragma: no cover - 没装 pillow 就跳过
        return path

    path.parent.mkdir(parents=True, exist_ok=True)
    image = Image.new("RGB", (720, 380), (250, 251, 253))
    draw = ImageDraw.Draw(image)
    draw.rectangle((3, 3, 716, 376), outline=(118, 134, 166), width=4)
    draw.rectangle((3, 3, 716, 66), fill=(226, 234, 248))

    def _font(size: int) -> object:
        for name in ("arial.ttf", "C:/Windows/Fonts/arial.ttf", "DejaVuSans.ttf"):
            try:
                return ImageFont.truetype(name, size)
            except Exception:
                continue
        return ImageFont.load_default()

    title = _font(30)
    body = _font(38)

    draw.text((28, 18), "MEETING CARD", font=title, fill=(30, 42, 66))
    draw.text((28, 120), "ROOM:    B-207", font=body, fill=(24, 34, 54))
    draw.text((28, 190), "GUESTS:  9", font=body, fill=(24, 34, 54))
    draw.text((28, 260), "AGENDA:  Q4 RETRO", font=body, fill=(24, 34, 54))
    image.save(path)
    return path


def main(argv: list[str] | None = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])
    target = Path(args[0]) if args else Path(__file__).resolve().parent.parent / "data" / "samples" / "示例文档.pdf"
    make_sample_pdf(target)
    print(f"已生成 {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
