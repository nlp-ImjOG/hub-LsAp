"""生成交付证据文件。

把整条链路真跑一遍，把控制台输出原样存进 ``docs/`` 下 —— 跟作业一
``docs/01-*.txt`` 一个路子。**这些文件是可以随时重新生成的**，
不是手工抄的，所以老师随时能验证。

    python -X utf8 scripts/evidence.py

产出：

``docs/01-端到端演示输出.txt``   上传 → 待解析 → 解析中 → 解析完成
``docs/02-基础设施自检.txt``     Redis / Kafka / 解析后端 / 模型 自检
``docs/03-Redis-key结构.txt``    Redis 里实际长什么样
``docs/04-Kafka分区分布.txt``    topic 的分区和消息数
``docs/05-多模态问答.txt``       带图片引用的真实回答
``docs/06-图问验证.txt``         图 + 问题一起送 LLM，并校验读没读准

跑之前需要：

- Redis 和 Kafka 已经起好（``start_infra.bat``）；
- **常驻 Worker 最好先停掉** —— 否则消息会被它抢走，
  下面「跑一轮 Worker」那步就显示 0 条了；
- ``.env`` 里填好 ``MMRAG_API_KEY``（第 5 步要真调大模型）。
"""

from __future__ import annotations

import argparse
import io
import os
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

DOCS_DIR = PROJECT_ROOT / "docs"
SAMPLE_PDF = PROJECT_ROOT / "data" / "samples" / "示例文档.pdf"
PROBE_PNG = PROJECT_ROOT / "data" / "samples" / "探针图片.png"

#: 问法要能引出「图文混排」—— 让模型把相关页面的图也贴出来。
QUESTION = (
    "这篇文档讲了什么？文档里的流程图有哪几个步骤？"
    "请在回答里用 Markdown 图片语法 ![说明](图片地址) 把相关页面的图片也放出来。"
)

#: 图问的问法。
IMAGE_QUESTION = "这张图上的房间号、参会人数和议题分别是什么？"

#: 答案里必须出现的字样 —— 探针图里的内容**和文档毫无关系**，
#: 文档里一个字都搜不到，答对了就说明模型是真的把图读了一遍。
EXPECTED_IN_ANSWER = ("B-207", "9", "RETRO")


def _force_utf8() -> None:
    """Windows 控制台默认 GBK，中文会乱码。"""

    if hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace"
        )


def _rule(title: str, width: int = 60) -> str:
    return f"\n{'=' * width}\n  {title}\n{'=' * width}"


def run_cli(*args: str) -> str:
    """跑一个 mmrag 子命令，把输出原样返回。

    stderr 里全是 kafka / sentence-transformers 的 INFO 日志（连接过程、
    模型加载），对交付证据来说是噪声 —— 只留自己 ``mmrag.*`` 的日志。
    """

    cmd = [sys.executable, "-X", "utf8", "-m", "mmrag", *args]
    env = {**os.environ, "PYTHONPATH": str(PROJECT_ROOT / "src")}
    proc = subprocess.run(
        cmd,
        cwd=str(PROJECT_ROOT),
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    out = proc.stdout or ""
    kept = []
    for line in (proc.stderr or "").splitlines():
        if " mmrag." in line:
            kept.append(line)
    if kept:
        out += "\n[日志]\n" + "\n".join(kept)
    return out.rstrip()


def clean_redis() -> str:
    """清掉本作业在 Redis 里的全部数据，让证据是一次干净的运行。"""

    from mmrag.config import Settings
    from mmrag.store import StateStore

    settings = Settings.from_env()
    store = StateStore(settings=settings)
    client = store.client
    keys = list(client.scan_iter(match=f"{settings.redis_prefix}:*"))
    if keys:
        client.delete(*keys)
    return f"清掉 {len(keys)} 个 key（前缀 {settings.redis_prefix}:*）"


def evidence_health() -> str:
    """02-基础设施自检"""

    from mmrag.config import Settings
    from mmrag.store import StateStore
    from mmrag.bus import Bus

    settings = Settings.from_env()
    store = StateStore(settings=settings)
    bus = Bus(settings)

    lines = [_rule("基础设施自检")]
    lines.append(f"  Redis  {settings.redis_url:<30} {'正常' if store.ping() else '连不上'}")
    lines.append(
        f"  Kafka  {settings.kafka_bootstrap_servers:<30} "
        f"{'正常' if bus.ping() else '连不上'}"
    )

    from mmrag.parsers import describe_parsers

    for line in describe_parsers(settings):
        lines.append(f"  解析后端  {line}")

    from mmrag.embedder import Embedder
    from mmrag.llm import LLMClient

    lines.append(f"  嵌入模型  {Embedder(settings).describe()}")
    lines.append(f"  大模型    {LLMClient(settings).describe()}")
    lines.append("")
    lines.append(run_cli("status"))
    return "\n".join(lines)


def evidence_redis() -> str:
    """03-Redis-key结构"""

    from mmrag.config import Settings
    from mmrag.store import StateStore

    settings = Settings.from_env()
    store = StateStore(settings=settings)
    client = store.client
    prefix = settings.redis_prefix

    lines = [_rule("Redis key 结构")]
    lines.append(f"  前缀：{prefix}:*")
    lines.append(f"  连接：{settings.redis_url}")
    lines.append("")

    keys = sorted(client.scan_iter(match=f"{prefix}:*"))
    if not keys:
        lines.append("  （Redis 里还没有数据，先跑一遍端到端演示）")
        return "\n".join(lines)

    type_name = {
        "hash": "HASH",
        "list": "LIST",
        "set": "SET ",
        "string": "STR ",
        "zset": "ZSET",
    }

    for key in keys:
        kind = client.type(key)
        lines.append(f"  {key}    {type_name.get(kind, kind)}")
        if kind == "hash":
            for field, value in client.hgetall(key).items():
                text = str(value)
                if len(text) > 120:
                    text = text[:120] + "…"
                lines.append(f"      {field:<12} = {text}")
        elif kind == "list":
            for item in client.lrange(key, 0, 4):
                text = str(item)
                if len(text) > 120:
                    text = text[:120] + "…"
                lines.append(f"      · {text}")
            total = client.llen(key)
            if total > 5:
                lines.append(f"      … 共 {total} 条")
        elif kind == "set":
            members = sorted(client.smembers(key))
            for member in members[:8]:
                lines.append(f"      · {member}")
            if len(members) > 8:
                lines.append(f"      … 共 {len(members)} 个")
        lines.append("")

    lines.append("  说明：")
    lines.append(f"    {prefix}:docs                文档 id 集合")
    lines.append(f"    {prefix}:doc:<id>:meta       文档元信息（含三态）")
    lines.append(f"    {prefix}:chat:<session>      会话历史")
    return "\n".join(lines)


def evidence_kafka() -> str:
    """04-Kafka分区分布"""

    from mmrag.config import Settings
    from mmrag.bus import Bus

    settings = Settings.from_env()
    bus = Bus(settings)

    lines = [_rule("Kafka topic 与分区分布")]
    lines.append(f"  broker  {settings.kafka_bootstrap_servers}")
    lines.append(f"  消费者组 {settings.kafka_consumer_group}")
    lines.append("")

    for topic in (settings.kafka_topic_parse, settings.kafka_topic_parsed):
        lines.append(f"  {topic}")
        try:
            info = bus.describe(topic)
        except Exception as exc:  # pragma: no cover - 自检不该挂
            lines.append(f"      读取失败：{exc}")
            continue
        rows = info.get("partitions", [])
        if not rows:
            lines.append("      （topic 还没有分区）")
            continue
        lines.append(f"      分区数 {len(rows)}")
        for row in rows:
            lines.append(
                f"      分区 {row['partition']}   消息数 {row['messages']}"
            )
        lines.append("")

    lines.append("  说明：")
    lines.append(f"    {settings.kafka_topic_parse}   上传事件（Web → Worker）")
    lines.append(f"    {settings.kafka_topic_parsed}  解析完成事件（Worker → 广播）")
    lines.append("    消息 key 用 doc_id —— 同一文档的多次任务进同一分区，不会交错执行。")
    return "\n".join(lines)


def evidence_pipeline() -> str:
    """01-端到端演示输出"""

    if not SAMPLE_PDF.is_file():
        sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
        from sample_pdf import make_sample_pdf

        make_sample_pdf(SAMPLE_PDF)

    lines = [_rule("端到端演示：上传 → 待解析 → 解析中 → 解析完成")]
    lines.append(f"  样例 PDF：{SAMPLE_PDF.relative_to(PROJECT_ROOT)}")
    lines.append("")

    lines.append(_rule("第 1 步：上传（写 Redis 待解析 + 投 Kafka）", 60))
    lines.append(run_cli("upload", str(SAMPLE_PDF)))

    lines.append(_rule("第 2 步：上传后立刻看状态", 60))
    lines.append(run_cli("docs"))

    lines.append(_rule("第 3 步：Worker 消费 Kafka（待解析 → 解析中 → 解析完成）", 60))
    lines.append(run_cli("worker", "--once"))

    lines.append(_rule("第 4 步：解析完成后看状态", 60))
    lines.append(run_cli("docs"))

    lines.append(
        "\n  注：这一步的输出取决于装了 MinerU 没 ——\n"
        "      装了走 MinerU（backend=mineru），没装自动降级到 PyMuPDF（backend=pymupdf）。\n"
        "      两种情况下「解析完成」都是真的解析完了，不是假的。"
    )
    return "\n".join(lines)


def evidence_qa() -> str:
    """05-多模态问答"""

    lines = [_rule("多模态问答（图文混排）")]
    lines.append(f"  问题：{QUESTION}")
    lines.append("")
    lines.append(run_cli("ask", QUESTION, "--session", "evidence"))
    lines.append("")
    lines.append("  注：回答里的 ![](...) 是模型写的 Markdown 图片语法，")
    lines.append("      前端把它渲染成内联图片 —— 地址都是本服务的 /api/documents/.../images/...")
    return "\n".join(lines)


def evidence_image_qa() -> str:
    """06-图问验证"""

    if not PROBE_PNG.is_file():
        sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
        from sample_pdf import make_probe_png

        make_probe_png(PROBE_PNG)

    lines = [_rule("图问：图片 + 问题一起送给多模态大模型")]
    lines.append(f"  图片：{PROBE_PNG.relative_to(PROJECT_ROOT)}")
    lines.append(f"  问题：{IMAGE_QUESTION}")
    lines.append("")

    # 只调一次 —— 证据文件里的答案和校验结论必须是同一次调用的。
    answer = run_cli("ask", IMAGE_QUESTION, "--session", "evidence-img",
                     "--image", str(PROBE_PNG))
    lines.append(answer)
    lines.append("")

    # 校验答案里到底读没读到图里的东西 ——
    # 探针图的内容和文档毫无关系，答对了就只能是看图看出来的。
    missing = [word for word in EXPECTED_IN_ANSWER if word not in answer]
    lines.append("  校验（图里的字样，文档里一个都搜不到）：")
    for word in EXPECTED_IN_ANSWER:
        mark = "✓" if word in answer else "✗"
        lines.append(f"      {mark} {word}")
    if missing:
        lines.append(f"  结论：这次没读准，缺 {missing}")
    else:
        lines.append("  结论：全部读到 —— 模型确实把图读了一遍。")
    lines.append("")
    lines.append("  注：这一条能成立，靠的是提示词里把「用户上传的图」和")
    lines.append("      「文档页的图」分开说（详见 docs/design.md §7.4）。")
    lines.append("      混在一起的时候模型会把用户那张判成「第 0 页的无关材料」，")
    lines.append("      然后答「根据提供的文档无法确定」。")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="生成交付证据文件")
    parser.add_argument(
        "--only",
        default="",
        help="只生成某一份（01 / 02 / 03 / 04 / 05 / 06），默认全生成",
    )
    parser.add_argument(
        "--no-clean",
        action="store_true",
        help="不清 Redis 里的旧数据（默认会先清一次，保证证据是一次干净的运行）",
    )
    args = parser.parse_args(argv)

    _force_utf8()
    DOCS_DIR.mkdir(parents=True, exist_ok=True)

    if not args.no_clean:
        try:
            print(f"[清理] {clean_redis()}")
        except Exception as exc:
            print(f"[提示] 清 Redis 失败（继续）：{exc}")

    steps = {
        "01": ("01-端到端演示输出.txt", evidence_pipeline),
        "02": ("02-基础设施自检.txt", evidence_health),
        "03": ("03-Redis-key结构.txt", evidence_redis),
        "04": ("04-Kafka分区分布.txt", evidence_kafka),
        "05": ("05-多模态问答.txt", evidence_qa),
        "06": ("06-图问验证.txt", evidence_image_qa),
    }

    for key, (filename, func) in steps.items():
        if args.only and args.only != key:
            continue
        print(f"[生成] docs/{filename} …")
        content = func()
        (DOCS_DIR / filename).write_text(content + "\n", encoding="utf-8")
        print(f"[完成] docs/{filename}（{len(content)} 字符）")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
