"""生成交付截图。

跑之前先起服务::

    python -X utf8 scripts/launch.py start      # 另开一个窗口
    python -X utf8 scripts/launch.py screenshot

截图落在 ``docs/`` 下：

``01-上传页.png``            刚打开页面的样子
``02-解析完成.png``          上传后、解析完成时的文档列表（带三态）
``03-图文混排问答.png``      问完之后的回答（含内联图片）
``04-图问.png``              附一张图 + 提一个问题（图问）
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DOCS_DIR = PROJECT_ROOT / "docs"
SAMPLE_PDF = PROJECT_ROOT / "data" / "samples" / "示例文档.pdf"
#: 给「图问」演示用的探针图片 —— 里面的内容**和文档毫无关系**，
#: 模型答对了就只能是看图看出来的（详见 sample_pdf.make_probe_png）。
PROBE_PNG = PROJECT_ROOT / "data" / "samples" / "探针图片.png"

# 端口只有一个来源：应用自己的配置（环境变量 > .env > 默认值）。
_SRC = PROJECT_ROOT / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from mmrag.config import Settings  # noqa: E402  （必须在 sys.path 调整之后）

DEFAULT_BASE = f"http://127.0.0.1:{Settings.from_env().api_port}"

#: 问法要能引出「图文混排」—— 让模型把相关页面的图也贴出来。
QUESTION = (
    "这篇文档讲了什么？文档里的流程图有哪几个步骤？"
    "请在回答里用 Markdown 图片语法 ![说明](图片地址) 把相关页面的图片也放出来。"
)

#: 模型偶尔不贴图，追问一次，把图片语法说清楚。
FOLLOWUP = "请把第 1 页的页面截图用 Markdown 图片语法 ![第 1 页](图片地址) 贴出来。"

#: 图问的问题。
IMAGE_QUESTION = "这张图上的房间号、参会人数和议题分别是什么？"

#: 答案里必须出现的字样 —— 文档里一个都搜不到，答对了就说明模型真读了图。
EXPECTED_IN_ANSWER = ("B-207", "9", "RETRO")


def _find_chromium() -> str | None:
    """找一个能用的 Chromium。

    playwright 自带的版本号可能和已下载的浏览器对不上（报
    ``Executable doesn't exist``），这时退回到已安装的旧版本，
    用 ``executable_path`` 直接指定 —— 基本功能都够用。
    """

    import os

    roots = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "ms-playwright",
        Path.home() / ".cache" / "ms-playwright",
        Path.home() / "AppData" / "Local" / "ms-playwright",
    ]
    candidates: list[Path] = []
    for root in roots:
        if not root.is_dir():
            continue
        for folder in sorted(root.glob("chromium-*"), reverse=True):
            for rel in ("chrome-win64/chrome.exe", "chrome-win/chrome.exe",
                        "chrome-linux/chrome", "chrome-mac/Chromium.app/Contents/MacOS/Chromium"):
                path = folder / rel
                if path.is_file():
                    candidates.append(path)
    return str(candidates[0]) if candidates else None


def _launch(playwright: object) -> object:
    """起浏览器，先用 playwright 自带的，不行就退回已安装的旧版本。"""

    chromium = playwright.chromium  # type: ignore[attr-defined]
    try:
        return chromium.launch()
    except Exception as exc:
        print(f"[提示] playwright 自带的浏览器用不了（{str(exc)[:120]}），改用已安装的旧版本")
        executable = _find_chromium()
        if not executable:
            raise
        print(f"[提示] 用 {executable}")
        return chromium.launch(executable_path=executable)


def _clear_docs(page, base: str) -> int:
    """把已有的文档都删掉。

    两个理由：
    1. 截图要干净 —— 列表里堆着七八个「示例文档.pdf」不好看；
    2. **更要紧的是**：脚本要等「刚上传的那个」变成解析完成，
       如果列表里已经有上一轮留下的「解析完成」，
       ``wait_for_selector(".badge.done")`` 会立刻命中，截出来的还是「解析中」。
    """

    try:
        response = page.request.get(f"{base}/api/documents")
        items = response.json()
    except Exception as exc:
        print(f"[提示] 读旧文档列表失败（继续）：{exc}")
        return 0
    if not isinstance(items, list):
        return 0
    for item in items:
        doc_id = item.get("doc_id") if isinstance(item, dict) else None
        if not doc_id:
            continue
        try:
            page.request.delete(f"{base}/api/documents/{doc_id}")
        except Exception:  # pragma: no cover - 清理是尽力而为
            pass
    return len(items)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="生成交付截图")
    parser.add_argument("--base", default=DEFAULT_BASE, help="服务地址")
    parser.add_argument(
        "--keep-docs",
        action="store_true",
        help="不清理已有文档（默认会先删干净，截图才好看）",
    )
    args = parser.parse_args(argv)

    from playwright.sync_api import sync_playwright

    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    if not SAMPLE_PDF.is_file():
        sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
        from sample_pdf import make_sample_pdf

        make_sample_pdf(SAMPLE_PDF)
    if not PROBE_PNG.is_file():
        sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
        from sample_pdf import make_probe_png

        make_probe_png(PROBE_PNG)

    with sync_playwright() as playwright:
        browser = _launch(playwright)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        try:
            if not args.keep_docs:
                removed = _clear_docs(page, args.base)
                print(f"[清理] 删掉 {removed} 个旧文档")

            page.goto(args.base, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(1200)
            page.screenshot(path=str(DOCS_DIR / "01-上传页.png"), full_page=True)
            print("[截图] 01-上传页.png")

            # 上传样例 PDF（页面里有两个 file input，用 accept 精确挑 PDF 那个）
            page.set_input_files("input[accept*='pdf']", str(SAMPLE_PDF))
            print("[等待] 解析中…")
            # 等**刚上传的那个**变成「解析完成」——
            # 列表里只有一个文档，直接盯它的徽章。
            page.wait_for_selector(".doc .badge.done", timeout=180000)
            page.wait_for_timeout(800)
            page.screenshot(path=str(DOCS_DIR / "02-解析完成.png"), full_page=True)
            print("[截图] 02-解析完成.png")

            # 提问
            page.fill("textarea", QUESTION)
            page.click("button:has-text('发送')")
            # 回答是 SSE 一点一点吐出来的，图片语法往往在最后才出现 ——
            # 等它，别用固定几秒去猜。
            try:
                page.wait_for_selector(".msg.assistant .bubble img", timeout=120000)
            except Exception:
                print("[提示] 第一轮没等到内联图片，追问一次")
                page.fill("textarea", FOLLOWUP)
                page.click("button:has-text('发送')")
                try:
                    page.wait_for_selector(".msg.assistant .bubble img", timeout=120000)
                except Exception:
                    print("[提示] 回答里还是没有内联图片（模型没引用图），先截能截到的")
            page.wait_for_timeout(1500)
            # 图片是 ``loading="lazy"`` 的 —— 不滚到它跟前，浏览器根本不去下载，
            # full_page 截图里就是一排裂图。所以先把所有图改成 eager 让它们立刻开始加载，
            # 再等它们真的 load 完。
            page.evaluate(
                """() => {
                    document.querySelectorAll('img[loading="lazy"]')
                        .forEach(img => { img.loading = 'eager'; });
                }"""
            )
            # 回答完会自动滚到底。把对话区滚到「第一张图」的位置 ——
            # 这样截图里既有文字，也有图。
            #
            # 但要**优先滚到抽出来的插图**（mineru_*），别滚到整页渲染
            # （page_N.png）：整页 A4 缩到聊天框那么宽，字比蚂蚁还小，
            # 截图上看不出名堂。抽出来的流程图 / 柱状图才说明得了问题。
            page.evaluate(
                """() => {
                    const body = document.querySelector('.chat-body');
                    const imgs = Array.from(
                        document.querySelectorAll('.msg.assistant .bubble img'));
                    const figure = imgs.find(img =>
                        /mineru_|chart|image_/.test(img.getAttribute('src') || ''));
                    const img = figure || imgs[0];
                    if (!img) { body.scrollTop = 0; return; }
                    const top = img.getBoundingClientRect().top
                              - body.getBoundingClientRect().top + body.scrollTop;
                    body.scrollTop = Math.max(0, top - 140);
                }"""
            )
            # 等图真的加载完（naturalWidth > 0 才算加载成功）
            try:
                page.wait_for_function(
                    """() => Array.from(
                            document.querySelectorAll('.msg.assistant .bubble img'))
                        .every(img => img.complete && img.naturalWidth > 0)""",
                    timeout=30000,
                )
            except Exception:
                print("[提示] 有图片没加载完，先截能截到的")
            page.wait_for_timeout(600)
            page.screenshot(path=str(DOCS_DIR / "03-图文混排问答.png"), full_page=True)
            print("[截图] 03-图文混排问答.png")

            # ---------------------------------------------------------------- 图问
            # 作业功能 3b：图 + 问题一起送给 LLM。
            # 这一步不靠检索 —— 只给一张图，让模型自己看图回答。
            print("[截图] 04-图问.png …")
            # 等上一轮问完（发送按钮从「回答中…」变回「发送」）
            page.wait_for_selector("button:has-text('发送')", timeout=180000)
            page.wait_for_timeout(800)
            # 先清空对话，截出来就只有「图问」这一轮，干干净净
            page.click("button:has-text('清空对话')")
            # **要等旧气泡真的从 DOM 里没了** —— 清空是 Vue 的响应式更新，
            # 不等的话下一步的 wait_for_selector 会命中上一轮的气泡。
            page.wait_for_selector(
                ".msg.assistant .bubble", state="detached", timeout=15000
            )
            page.set_input_files("input[accept='image/*']", str(PROBE_PNG))
            # 等缩略图出来 —— 说明图已经挂上了
            page.wait_for_selector(".attached .it img", timeout=15000)
            page.fill("textarea", IMAGE_QUESTION)
            page.click("button:has-text('发送')")
            page.wait_for_selector(".msg.assistant .bubble", timeout=180000)
            page.wait_for_timeout(1500)
            # **验一验**：这几个字样在文档里一个都没有 ——
            # 答案里出现了，就说明模型是真的把图读了一遍。
            answer = page.inner_text(".msg.assistant .bubble")
            missing = [word for word in EXPECTED_IN_ANSWER if word not in answer]
            if missing:
                print(f"[警告] 答案里没读到 {missing} —— 这次图问没读准")
            else:
                print(f"[检查] 答案里读到了 {list(EXPECTED_IN_ANSWER)}")
            # 滚回顶部 —— 要看见**用户上传的那张图**和它下面的问题，
            # 这才是「图问」的证据（只看答案看不出图是哪来的）。
            page.evaluate(
                """() => {
                    const body = document.querySelector('.chat-body');
                    if (body) body.scrollTop = 0;
                }"""
            )
            page.wait_for_timeout(500)
            page.screenshot(path=str(DOCS_DIR / "04-图问.png"), full_page=True)
            print("[截图] 04-图问.png")
        finally:
            browser.close()
    print(f"[完成] 截图在 {DOCS_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
