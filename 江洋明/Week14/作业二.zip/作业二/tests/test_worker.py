"""解析 Worker 的测试（假总线 + 假解析器 + 假嵌入模型）。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from mmrag.models import Chunk, DocStatus, DocumentMeta, ParseRequest
from mmrag.parsers.base import ParsedDoc, ParsedPage
from mmrag.store import StateStore
from mmrag.worker import ParseWorker


class FakeParser:
    """假解析器：直接返回固定内容。"""

    name = "fake"

    def __init__(self, fail: bool = False) -> None:
        self.fail = fail

    def available(self) -> bool:
        return True

    def parse(self, path: Path, doc_id: str, filename: str) -> ParsedDoc:
        if self.fail:
            raise RuntimeError("故意失败")
        return ParsedDoc(
            doc_id=doc_id,
            filename=filename,
            pages=[ParsedPage(page=1, text="第一页正文", images=["page_1.png"])],
            backend=self.name,
        )


class FakeEmbedder:
    """假嵌入模型：按文本长度造一个向量。"""

    def encode(self, texts: list[str]) -> Any:
        matrix = np.zeros((len(texts), 4), dtype="float32")
        for index, text in enumerate(texts):
            matrix[index, 0] = min(1.0, len(text) / 100.0)
            matrix[index, 1] = 1.0
        return matrix


def _worker(fake_redis, fake_bus, settings, parser: FakeParser) -> ParseWorker:
    store = StateStore(client=fake_redis, settings=settings)
    worker = ParseWorker(settings=settings, store=store, bus=fake_bus)
    worker._embedder = FakeEmbedder()  # noqa: SLF001 - 测试里换掉真模型
    return worker


def _patch_parser(monkeypatch, parser: FakeParser) -> None:
    import mmrag.worker as worker_module

    monkeypatch.setattr(worker_module, "build_parser", lambda settings: parser)


def _pdf(tmp_path: Path, name: str = "x.pdf") -> str:
    """造一个「存在」的 PDF 文件，返回路径字符串。"""

    path = tmp_path / name
    path.write_bytes(b"%PDF-1.4 fake")
    return str(path)


def test_解析成功状态从待解析走到解析完成(
    monkeypatch, fake_redis, fake_bus, settings, tmp_path
):
    _patch_parser(monkeypatch, FakeParser())
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    payload = worker.handle(
        ParseRequest(doc_id="d1", path=_pdf(tmp_path), filename="a.pdf")
    )

    meta = store.get_doc("d1")
    assert meta is not None
    assert meta.status is DocStatus.DONE
    assert meta.backend == "fake"
    assert meta.pages == 1
    assert meta.chunks == 1
    assert payload["status"] == "解析完成"


def test_解析失败状态标成解析失败并带错误信息(
    monkeypatch, fake_redis, fake_bus, settings, tmp_path
):
    _patch_parser(monkeypatch, FakeParser(fail=True))
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    try:
        worker.handle(
            ParseRequest(doc_id="d1", path=_pdf(tmp_path), filename="a.pdf")
        )
    except RuntimeError:
        pass

    meta = store.get_doc("d1")
    assert meta is not None
    assert meta.status is DocStatus.FAILED
    assert "故意失败" in meta.error


def test_解析完成会发事件(monkeypatch, fake_redis, fake_bus, settings, tmp_path):
    _patch_parser(monkeypatch, FakeParser())
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    worker.handle(ParseRequest(doc_id="d1", path=_pdf(tmp_path), filename="a.pdf"))

    topics = [item["topic"] for item in fake_bus.published]
    assert "wk14.test.parsed" in topics


def test_文件不存在会失败(monkeypatch, fake_redis, fake_bus, settings):
    _patch_parser(monkeypatch, FakeParser())
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    try:
        worker.handle(
            ParseRequest(doc_id="d1", path="不存在的.pdf", filename="a.pdf")
        )
    except FileNotFoundError:
        pass
    else:  # pragma: no cover
        raise AssertionError("应该抛 FileNotFoundError")

    meta = store.get_doc("d1")
    assert meta is not None
    assert meta.status is DocStatus.FAILED


def test_向量索引被写进去了(monkeypatch, fake_redis, fake_bus, settings, tmp_path):
    _patch_parser(monkeypatch, FakeParser())
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    worker.handle(ParseRequest(doc_id="d1", path=_pdf(tmp_path), filename="a.pdf"))

    assert worker._vectors.stats()["chunks"] == 1  # noqa: SLF001


def test_重启后会把待解析的文档重新投递(fake_redis, fake_bus, settings):
    store = StateStore(client=fake_redis, settings=settings)
    settings.ensure_dirs()
    upload = settings.upload_dir / "d1__a.pdf"
    upload.write_bytes(b"%PDF-1.4 fake")
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))

    worker = _worker(fake_redis, fake_bus, settings, FakeParser())
    count = worker.recover_pending()

    assert count == 1
    assert fake_bus.published[0]["topic"] == "wk14.test.parse"
    assert fake_bus.published[0]["key"] == "d1"


def test_待解析但文件没了会标失败(fake_redis, fake_bus, settings):
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))

    worker = _worker(fake_redis, fake_bus, settings, FakeParser())
    worker.recover_pending()

    meta = store.get_doc("d1")
    assert meta is not None
    assert meta.status is DocStatus.FAILED


def test_文档被删了就跳过而不是报错(monkeypatch, fake_redis, fake_bus, settings, tmp_path):
    """排队期间用户把文档删了 —— 跳过就行，别刷一屏 ERROR。"""

    _patch_parser(monkeypatch, FakeParser())
    store = StateStore(client=fake_redis, settings=settings)
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    payload = worker.handle(
        ParseRequest(doc_id="d1", path=_pdf(tmp_path), filename="a.pdf")
    )

    assert payload["skipped"] is True
    assert store.get_doc("d1") is None


def test_会清理僵尸文档的索引和图片(fake_redis, fake_bus, settings):
    """Redis 里已经没有的文档，磁盘上留下的向量/块/图片要一起清掉。

    文档元信息有 TTL，过期后 Redis 里的记录没了，
    磁盘上的东西却还在 —— 不清就一直在涨。
    """

    settings.ensure_dirs()
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    # 造一个「孤儿」：向量索引里有，Redis 里没有
    orphan = Chunk(
        chunk_id="d9-1", doc_id="d9", page=1, text="僵尸内容", images=["page_1.png"], seq=0
    )
    worker._vectors.add("d9", [orphan], np.array([[1.0, 0.0]], dtype="float32"))  # noqa: SLF001
    image_dir = settings.image_dir / "d9"
    image_dir.mkdir(parents=True, exist_ok=True)
    (image_dir / "page_1.png").write_bytes(b"png")

    removed = worker.prune_orphans()

    assert removed == 1
    assert worker._vectors.stats()["documents"] == 0  # noqa: SLF001
    assert not image_dir.exists()


def test_活着的文档不会被清理(fake_redis, fake_bus, settings):
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    worker = _worker(fake_redis, fake_bus, settings, FakeParser())

    chunk = Chunk(chunk_id="d1-1", doc_id="d1", page=1, text="正文", images=[], seq=0)
    worker._vectors.add("d1", [chunk], np.array([[1.0, 0.0]], dtype="float32"))  # noqa: SLF001

    assert worker.prune_orphans() == 0
    assert worker._vectors.stats()["documents"] == 1  # noqa: SLF001


# --------------------------------------------------------------- socket 竞态


class _StopWorker(Exception):
    """内部信号：让 ``run_forever`` 的测试跑完就停。"""


class _RacingConsumer:
    """第一次 poll 抛 socket 竞态，第二次抛 StopWorker 让循环停下来。"""

    def __init__(self, race: bool) -> None:
        self._race = race
        self.polls = 0

    def poll(self, timeout_ms=None, max_records=None):
        self.polls += 1
        if self._race:
            self._race = False
            raise ValueError("Invalid file descriptor: -1")
        raise _StopWorker()

    def commit(self):
        return None


class RacingBus:
    """假总线：第一次建消费者时抛 socket 竞态。"""

    def __init__(self, settings) -> None:
        self._settings = settings
        self.consumers: list[_RacingConsumer] = []

    def ensure_topics(self) -> list[str]:
        return []

    def publish_parse_request(self, request) -> dict:
        return {}

    def publish_parsed_event(self, doc_id, payload) -> dict:
        return {}

    def consume(self, topic, *, group_id=None, auto_offset_reset="earliest", timeout_ms=10_000):
        from contextlib import contextmanager

        @contextmanager
        def _cm():
            consumer = _RacingConsumer(race=len(self.consumers) == 0)
            self.consumers.append(consumer)
            yield consumer

        return _cm()


def test_遇到socket竞态Worker不会挂掉(fake_redis, settings):
    """kafka-python-ng 在 Windows 上有个已知竞态：连接被并发关掉时
    ``poll()`` 会抛 ``ValueError: Invalid file descriptor: -1``。

    之前这个异常没人接 —— Worker 直接崩了，作业跑着跑着就没 worker 了。
    现在应该重建消费者接着跑。
    """

    import pytest

    store = StateStore(client=fake_redis, settings=settings)
    bus = RacingBus(settings)
    worker = ParseWorker(settings=settings, store=store, bus=bus)
    worker._embedder = FakeEmbedder()  # noqa: SLF001

    with pytest.raises(_StopWorker):
        worker.run_forever(poll_timeout_ms=1)

    # 第一次消费者撞上竞态，第二次重建后正常往下走
    assert len(bus.consumers) == 2
    assert bus.consumers[0].polls == 1
    assert bus.consumers[1].polls == 1

