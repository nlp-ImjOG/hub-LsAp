"""解析器的测试。"""

from __future__ import annotations

from pathlib import Path

from mmrag.parsers import build_parser, describe_parsers
from mmrag.parsers.mineru_parser import (
    MinerUParser,
    _iter_page_blocks,
    _normalize_spaced_latin,
    _walk_block,
)
from mmrag.parsers.pymupdf_parser import PyMuPDFParser
from mmrag.parsers.render import render_all_pages


def test_pymupdf能解析出文本(settings, sample_pdf: Path):
    parser = PyMuPDFParser(settings)
    assert parser.available() is True

    parsed = parser.parse(sample_pdf, "d1", "示例.pdf")
    assert parsed.page_count == 2
    assert "RAG" in parsed.text
    assert parsed.backend == "pymupdf"


def test_pymupdf每页都渲染成图(settings, sample_pdf: Path):
    parsed = PyMuPDFParser(settings).parse(sample_pdf, "d1", "示例.pdf")
    page_images = [name for name in parsed.image_names() if name.startswith("page_")]
    assert page_images == ["page_1.png", "page_2.png"]
    assert (settings.image_dir / "d1" / "page_1.png").is_file()


def test_pymupdf能抽出内嵌图(settings, sample_pdf: Path):
    parsed = PyMuPDFParser(settings).parse(sample_pdf, "d1", "示例.pdf")
    embedded = [name for name in parsed.image_names() if "_img" in name]
    assert embedded, "样例 PDF 里应该有一张内嵌位图"


def test_每页都带着自己的图(settings, sample_pdf: Path):
    parsed = PyMuPDFParser(settings).parse(sample_pdf, "d1", "示例.pdf")
    for page in parsed.pages:
        assert any(name.startswith("page_") for name in page.images)


def test_渲染全部页(settings, sample_pdf: Path):
    rendered = render_all_pages(sample_pdf, settings.image_dir / "d1", dpi=72)
    assert set(rendered) == {1, 2}
    assert rendered[1] == "page_1.png"


def test_auto会挑一个可用后端(settings):
    parser = build_parser(settings)
    assert parser.name in {"mineru", "pymupdf"}


def test_强制指定后端(settings):
    from dataclasses import replace

    forced = replace(settings, parser_backend="pymupdf")
    assert build_parser(forced).name == "pymupdf"


def test_后端状态描述(settings):
    lines = describe_parsers(settings)
    assert len(lines) == 2
    assert any("pymupdf" in line for line in lines)


def test_mineru不可用时说清楚原因(settings):
    from dataclasses import replace

    empty = replace(settings, mineru_venv_dir=settings.data_dir / "不存在的venv")
    parser = MinerUParser(empty)
    assert parser.available() is False
    assert "venv-mineru" in parser.describe()


# --------------------------------------------------------------- 结构解析
#
# 下面是 MinerU 4.1.7 实测出来的真实结构（不是猜的）：
#   structured_content.json → {"pages": [{"page_idx": 0, "blocks": [...]}]}
#       块里的 content 是**字符串**，图片在 image_source
#   middle_json.json        → 同上，但 content 是**列表**，图片在 image_path
#
# 之前的实现只认「顶层就是一个块列表」的旧结构，
# 于是图片全被丢掉、页面文本变成 Python 的 dict repr。


def test_能读出MinerU真实的页面结构():
    structured = {
        "pages": [
            {
                "page_idx": 0,
                "blocks": [
                    {"type": "header", "content": "多模态 R A G 系统的设计要点"},
                    {
                        "type": "image",
                        "content": "",
                        "image_source": "images/page_0_image_7.jpg",
                    },
                ],
            },
            {"page_idx": 1, "blocks": [{"type": "text", "content": "第二页"}]},
        ]
    }
    pages = _iter_page_blocks(structured)
    assert [number for number, _ in pages] == [1, 2]
    assert pages[0][1][0]["content"] == "多模态 R A G 系统的设计要点"


def test_middle_json的真实结构也能读():
    middle = {
        "pages": [
            {
                "page_idx": 0,
                "blocks": [
                    {
                        "type": "image",
                        "content": [
                            {
                                "type": "image_body",
                                "image_path": "images/page_0_image_7.jpg",
                                "content": "",
                            }
                        ],
                    }
                ],
            }
        ]
    }
    pages = _iter_page_blocks(middle)
    assert pages[0][0] == 1
    assert pages[0][1][0]["type"] == "image"


def test_结构认不出来不报错():
    assert _iter_page_blocks(None) == []
    assert _iter_page_blocks("乱七八糟") == []
    assert _iter_page_blocks({"pages": "不是列表"}) == []
    assert _iter_page_blocks({"pages": [{"page_idx": 0}]}) == []


def test_块的文字是字符串时能读出来():
    texts, images = _walk_block({"type": "text", "content": "正文"})
    assert texts == ["正文"]
    assert images == []


def test_块的文字是列表时能读出来():
    block = {"type": "text", "content": [{"type": "text", "content": "正文"}]}
    texts, images = _walk_block(block)
    assert texts == ["正文"]
    assert images == []


def test_structured的image_source能读出图片():
    texts, images = _walk_block(
        {"type": "image", "content": "", "image_source": "images/a.jpg"}
    )
    assert images == ["images/a.jpg"]
    assert texts == []


def test_middle的image_path能读出图片():
    block = {
        "type": "chart",
        "content": [
            {"type": "chart_body", "image_path": "images/b.jpg", "content": ""}
        ],
    }
    texts, images = _walk_block(block)
    assert images == ["images/b.jpg"]
    assert texts == []


# --------------------------------------------------------------- 字母间距


def test_字母间距会被还原():
    assert _normalize_spaced_latin("系统采用 K a f k a 作为队列") == (
        "系统采用 Kafka 作为队列"
    )
    assert _normalize_spaced_latin("（R A G）系统") == "（RAG）系统"


def test_两个字母不会被误合并():
    # 只有 3 个及以上才还原 —— "A B" 保持原样
    assert _normalize_spaced_latin("见 A B 两列") == "见 A B 两列"


def test_正常的英文不受影响():
    assert _normalize_spaced_latin("Kafka is fast") == "Kafka is fast"


def test_还原之后还能再还原():
    # 幂等
    once = _normalize_spaced_latin("d e e p s e e k-f l a s h")
    assert once == "deepseek-flash"
    assert _normalize_spaced_latin(once) == once


# --------------------------------------------------------------- 命令行


def test_调用MinerU时档位写死成basic(settings):
    """CLI 的默认档位是 standard，会加载 llama.cpp 的 VLM 模型，
    在 Windows 的 GBK 控制台上直接抛 UnicodeEncodeError —— 必须显式指定。"""

    parser = MinerUParser(settings)
    command = parser._build_command(  # noqa: SLF001 - 测的就是内部命令
        Path("mineru-kit"), None, Path("a.pdf"), Path("/tmp/out")
    )
    assert "--tier" in command
    assert command[command.index("--tier") + 1] == "basic"


def test_档位可以被环境变量改掉(settings, monkeypatch):
    from dataclasses import replace

    monkeypatch.setenv("MMRAG_MINERU_TIER", "flash")
    tuned = replace(settings, mineru_tier="flash")
    command = MinerUParser(tuned)._build_command(  # noqa: SLF001
        Path("mineru-kit"), None, Path("a.pdf"), Path("/tmp/out")
    )
    assert command[command.index("--tier") + 1] == "flash"
