"""HTTP 接口的测试（用 TestClient，全部依赖都替换成假的）。"""

from __future__ import annotations

import json
from typing import Any

from fastapi.testclient import TestClient

from mmrag.api.app import create_app
from mmrag.models import Chunk, DocumentMeta
from mmrag.qa import QAService
from mmrag.retriever import Retrieved
from mmrag.store import StateStore


class FakeLLM:
    """假大模型：按固定脚本吐字。"""

    def __init__(self) -> None:
        self.calls: list[list[dict[str, Any]]] = []

    def available(self) -> bool:
        return True

    def describe(self) -> str:
        return "大模型（可用：fake）"

    def stream(self, messages: list[dict[str, Any]], **_kwargs: Any):
        self.calls.append(messages)
        for piece in ["答案是", "深色"]:
            yield piece

    def complete(self, messages: list[dict[str, Any]], **_kwargs: Any) -> str:
        self.calls.append(messages)
        return "答案是深色"


class FakeRetriever:
    """假检索器：固定返回一段。"""

    def __init__(self) -> None:
        self.store = self
        #: 每次检索传进来的 doc_ids —— 用来断言「只搜活着的文档」。
        self.calls: list[list[str] | None] = []

    def stats(self) -> dict[str, Any]:
        return {"documents": 0, "chunks": 0}

    def retrieve(self, question: str, top_k: int = 0, doc_ids: list[str] | None = None):
        chunk = Chunk(chunk_id="c1", doc_id="d1", page=2, text="文档里的正文", images=[], seq=0)
        return [Retrieved(chunk=chunk, score=0.9)]

    def retrieve_with_images(
        self,
        question: str,
        top_k: int = 0,
        max_images: int = 0,
        doc_ids: list[str] | None = None,
    ):
        self.calls.append(doc_ids)
        chunk = Chunk(
            chunk_id="c1", doc_id="d1", page=2, text="正文", images=["page_2.png"], seq=0
        )
        return [Retrieved(chunk=chunk, score=0.9)], [("page_2.png", 2, "d1")]


def _make_app(fake_redis, fake_bus, settings):
    app = create_app(settings)
    store = StateStore(client=fake_redis, settings=settings)
    app.state.store = store
    app.state.bus = fake_bus
    llm = FakeLLM()
    qa = QAService(
        settings=settings,
        store=store,
        retriever=FakeRetriever(),
        llm=llm,
    )
    app.state.qa = qa
    return app, llm


def _client(fake_redis, fake_bus, settings) -> TestClient:
    app, llm = _make_app(fake_redis, fake_bus, settings)
    client = TestClient(app)
    client.llm = llm  # type: ignore[attr-defined]
    return client


def _pdf_bytes() -> bytes:
    return b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF\n"


# ------------------------------------------------------------------ 自检


def test_健康检查(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    data = client.get("/api/health").json()
    assert data["redis"] is True
    assert data["kafka"] is True
    assert data["ok"] is True


def test_首页能打开(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    response = client.get("/")
    assert response.status_code == 200
    assert "多模态" in response.text


# ------------------------------------------------------------------ 上传


def test_上传pdf会变成待解析(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    response = client.post(
        "/api/documents",
        files=[("files", ("a.pdf", _pdf_bytes(), "application/pdf"))],
    )
    assert response.status_code == 200
    body = response.json()
    assert len(body["accepted"]) == 1
    assert body["accepted"][0]["status"] == "待解析"
    assert body["accepted"][0]["status_code"] == "pending"


def test_上传会投到kafka(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    client.post(
        "/api/documents",
        files=[("files", ("a.pdf", _pdf_bytes(), "application/pdf"))],
    )
    assert len(fake_bus.published) == 1
    assert fake_bus.published[0]["topic"] == "wk14.test.parse"
    assert fake_bus.published[0]["key"]


def test_非pdf会被拒(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    response = client.post(
        "/api/documents",
        files=[("files", ("a.txt", b"hello", "text/plain"))],
    )
    body = response.json()
    assert body["accepted"] == []
    assert body["rejected"][0]["reason"] == "只接受 PDF"


def test_一次上传超过上限会被拒(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    files = [
        ("files", (f"a{i}.pdf", _pdf_bytes(), "application/pdf"))
        for i in range(settings.max_files_per_upload + 1)
    ]
    response = client.post("/api/documents", files=files)
    assert response.status_code == 400


def test_空文件会被拒(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    response = client.post(
        "/api/documents", files=[("files", ("a.pdf", b"", "application/pdf"))]
    )
    assert response.json()["rejected"][0]["reason"] == "文件是空的"


def test_列表能看到三态(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    client.post(
        "/api/documents",
        files=[("files", ("a.pdf", _pdf_bytes(), "application/pdf"))],
    )
    docs = client.get("/api/documents").json()
    assert len(docs) == 1
    assert docs[0]["status"] == "待解析"


def test_删除文档(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    body = client.post(
        "/api/documents",
        files=[("files", ("a.pdf", _pdf_bytes(), "application/pdf"))],
    ).json()
    doc_id = body["accepted"][0]["doc_id"]

    assert client.delete(f"/api/documents/{doc_id}").status_code == 200
    assert client.get("/api/documents").json() == []


def test_取不存在的文档会404(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    assert client.get("/api/documents/没有这个").status_code == 404


# ------------------------------------------------------------------ 图片


def test_图片能取到(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    image_dir = settings.image_dir / "d1"
    image_dir.mkdir(parents=True, exist_ok=True)
    (image_dir / "page_1.png").write_bytes(b"\x89PNG\r\n\x1a\n")

    response = client.get("/api/documents/d1/images/page_1.png")
    assert response.status_code == 200
    assert response.content.startswith(b"\x89PNG")


def test_图片路径穿越会被挡(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    response = client.get("/api/documents/d1/images/..%2F..%2Fetc%2Fpasswd")
    assert response.status_code in (400, 404)


def test_图片不存在会404(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    assert client.get("/api/documents/d1/images/没有.png").status_code == 404


# ------------------------------------------------------------------ 问答


def test_问答会流式返回(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    response = client.post("/api/chat", data={"question": "问题", "session_id": "s1"})

    assert response.status_code == 200
    body = response.text
    assert "data:" in body
    assert "答案是" in body


def test_问答事件顺序(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    response = client.post("/api/chat", data={"question": "问题", "session_id": "s1"})

    events = []
    for line in response.text.splitlines():
        if line.startswith("data:"):
            events.append(json.loads(line[5:].strip())["type"])
    assert events[0] == "start"
    assert "sources" in events
    assert "delta" in events
    assert events[-1] == "end"


def test_问答会写进会话历史(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    client.post("/api/chat", data={"question": "问题", "session_id": "s1"})

    history = client.get("/api/sessions/s1/history").json()
    assert [m["role"] for m in history["messages"]] == ["user", "assistant"]
    assert history["messages"][1]["content"] == "答案是深色"


def test_问答会带上图片(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    image = b"\x89PNG\r\n\x1a\n"
    response = client.post(
        "/api/chat",
        data={"question": "这是什么", "session_id": "s1"},
        files=[("images", ("a.png", image, "image/png"))],
    )
    assert response.status_code == 200
    # 用户上传的图片被存到了会话目录下
    saved = list((settings.image_dir / "s1").glob("*.png"))
    assert saved, "上传的图片应该被保存下来"


def test_用户上传的图真的会发给大模型(fake_redis, fake_bus, settings):
    """作业功能 3b：**图问** —— 图和问题一起送到 LLM。

    光「把文件存下来」不算数，关键是那张图进了请求体的
    ``image_url`` 块里（data URL）。
    """

    client = _client(fake_redis, fake_bus, settings)
    image = b"\x89PNG\r\n\x1a\n" + b"0" * 64
    client.post(
        "/api/chat",
        data={"question": "这张图里画的是什么", "session_id": "s1"},
        files=[("images", ("a.png", image, "image/png"))],
    )

    assert client.llm.calls, "应该调用过大模型"
    user_message = client.llm.calls[0][-1]
    assert user_message["role"] == "user"

    urls = [
        part["image_url"]["url"]
        for part in user_message["content"]
        if part.get("type") == "image_url"
    ]
    assert urls, "发给大模型的消息里应该带 image_url 块"
    assert urls[0].startswith("data:image/png;base64,"), urls[0][:40]


def test_图和问题在同一条消息里(fake_redis, fake_bus, settings):
    """图问不能拆成两轮 —— 得在**同一条** user 消息里。"""

    client = _client(fake_redis, fake_bus, settings)
    client.post(
        "/api/chat",
        data={"question": "这张图里画的是什么", "session_id": "s1"},
        files=[("images", ("a.png", b"\x89PNG\r\n\x1a\n", "image/png"))],
    )

    user_message = client.llm.calls[0][-1]
    text = " ".join(
        part.get("text", "") for part in user_message["content"]
        if part.get("type") == "text"
    )
    assert "这张图里画的是什么" in text


def test_清空会话(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    client.post("/api/chat", data={"question": "问题", "session_id": "s1"})
    assert client.delete("/api/sessions/s1").status_code == 200
    assert client.get("/api/sessions/s1/history").json()["messages"] == []


def test_检索只限于还活着的文档(fake_redis, fake_bus, settings):
    """文档 TTL 过期后 Redis 里没了，向量还在 —— 不能再被检索出来。"""

    app, _llm = _make_app(fake_redis, fake_bus, settings)
    client = TestClient(app)
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="alive", filename="活着的.pdf"))

    client.post("/api/chat", data={"question": "问题", "session_id": "s1"})

    retriever = app.state.qa.retriever
    assert retriever.calls, "应该调用过检索"
    assert retriever.calls[-1] == ["alive"]


def test_删文档会把图片目录也清掉(fake_redis, fake_bus, settings):
    client = _client(fake_redis, fake_bus, settings)
    store = StateStore(client=fake_redis, settings=settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))

    image_dir = settings.image_dir / "d1"
    image_dir.mkdir(parents=True, exist_ok=True)
    (image_dir / "page_1.png").write_bytes(b"png")

    assert client.delete("/api/documents/d1").status_code == 200
    assert not image_dir.exists(), "删文档后图片目录应该一起清掉"
