"""大模型客户端的测试（不发真实请求）。"""

from __future__ import annotations

import base64
from pathlib import Path

from mmrag.llm import LLMClient, LLMError, guess_mime, prepare_data_url, to_data_url


def test_没配key时不可用(settings):
    from dataclasses import replace

    client = LLMClient(replace(settings, llm_api_key=""))
    assert client.available() is False
    assert "MMRAG_API_KEY" in client.describe()


def test_配了key时可用(settings):
    client = LLMClient(settings)
    assert client.available() is True
    assert settings.llm_model in client.describe()


def test_没配key调用会报错(settings):
    from dataclasses import replace

    client = LLMClient(replace(settings, llm_api_key=""))
    try:
        client.complete([{"role": "user", "content": "hi"}])
    except LLMError as exc:
        assert "MMRAG_API_KEY" in str(exc)
    else:  # pragma: no cover - 不该走到这
        raise AssertionError("应该抛 LLMError")


def test_mime按后缀判断():
    assert guess_mime(Path("a.png")) == "image/png"
    assert guess_mime(Path("a.jpg")) == "image/jpeg"
    assert guess_mime(Path("a.jpeg")) == "image/jpeg"
    assert guess_mime(Path("a.webp")) == "image/webp"


def test_data_url格式正确(tmp_path: Path):
    image = tmp_path / "a.png"
    image.write_bytes(b"\x89PNG\r\n\x1a\n")
    url = to_data_url(image)
    assert url.startswith("data:image/png;base64,")
    payload = url.split(",", 1)[1]
    assert base64.b64decode(payload) == b"\x89PNG\r\n\x1a\n"


def test_准备data_url会缩到大图(tmp_path: Path):
    from PIL import Image

    big = tmp_path / "big.png"
    Image.new("RGB", (3000, 2000), (255, 255, 255)).save(big)

    url = prepare_data_url(big, max_side=800)
    assert url.startswith("data:image/jpeg;base64,")
    payload = base64.b64decode(url.split(",", 1)[1])
    # JPEG 头
    assert payload[:2] == b"\xff\xd8"


def test_图片读不出来退回原图(tmp_path: Path):
    broken = tmp_path / "broken.png"
    broken.write_bytes(b"not an image")
    url = prepare_data_url(broken)
    assert url.startswith("data:image/png;base64,")
