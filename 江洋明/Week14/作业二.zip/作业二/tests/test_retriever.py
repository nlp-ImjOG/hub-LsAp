"""检索层的测试。

重点是「带图检索」的选图策略 —— 提示词里能塞几张图、选哪几张，
直接决定模型能不能看到对应页面的内容。
"""

from __future__ import annotations

from typing import Any

import numpy as np

from mmrag.models import Chunk
from mmrag.retriever import Retriever
from mmrag.vector_store import VectorStore


class FakeEmbedder:
    """假嵌入模型：所有文本都映射到同一个向量。"""

    def encode_one(self, text: str) -> Any:
        return np.array([1.0, 0.0], dtype="float32")

    def encode(self, texts: list[str]) -> Any:
        return np.ones((len(texts), 2), dtype="float32")


def _chunk(doc_id: str, page: int, seq: int, images: list[str]) -> Chunk:
    return Chunk(
        chunk_id=f"{doc_id}-{page}-{seq}",
        doc_id=doc_id,
        page=page,
        text=f"第{page}页第{seq}块",
        images=list(images),
        seq=seq,
    )


def _store(settings, chunks: list[Chunk], doc_id: str) -> VectorStore:
    store = VectorStore(settings)
    store.add(doc_id, chunks, np.ones((len(chunks), 2), dtype="float32"))
    return store


def _retriever(settings, store: VectorStore) -> Retriever:
    return Retriever(embedder=FakeEmbedder(), store=store, settings=settings)


# ------------------------------------------------------------------ 文档过滤


def test_限定文档范围后只搜指定的文档(settings):
    store = VectorStore(settings)
    store.add("d1", [_chunk("d1", 1, 0, [])], np.array([[1.0, 0.0]], dtype="float32"))
    store.add("d2", [_chunk("d2", 1, 0, [])], np.array([[1.0, 0.0]], dtype="float32"))

    retriever = _retriever(settings, store)
    hits = retriever.retrieve("问题", top_k=5, doc_ids=["d2"])

    assert len(hits) == 1
    assert hits[0].chunk.doc_id == "d2"


def test_文档范围为空就是搜不到(settings):
    """空的 doc_ids 表示「一个文档都没有」，不是「不限制」。

    检索层拿 Redis 里的存活文档 id 来限定范围 ——
    文档 TTL 过期后 Redis 里没了，向量还在，这里必须挡住。
    """

    store = VectorStore(settings)
    store.add("d1", [_chunk("d1", 1, 0, [])], np.array([[1.0, 0.0]], dtype="float32"))

    retriever = _retriever(settings, store)
    assert retriever.retrieve("问题", top_k=5, doc_ids=[]) == []


# ------------------------------------------------------------------ 选图策略


def test_每个页面先各分一张图(settings):
    """第一轮按页去重 —— 保证提示词覆盖尽量多的页面。"""

    chunks = [
        _chunk("d1", 1, 0, ["page_1.png"]),
        _chunk("d1", 2, 1, ["page_2.png"]),
    ]
    store = _store(settings, chunks, "d1")
    retriever = _retriever(settings, store)

    _results, images = retriever.retrieve_with_images("问题", top_k=5, max_images=3)

    pages = [page for _name, page, _doc in images]
    assert pages == [1, 2]


def test_同一页的多张图不会挤掉别的页(settings):
    """第 2 页有 3 张图时，第 1 页也得能进来。

    反过来做（一路按顺序塞满）的话，模型就看不到第 1 页的流程图，
    回答里会直接说「文档里没有流程图」。
    """

    chunks = [
        _chunk("d1", 2, 0, ["page_2.png", "p2_img1.png", "p2_img2.png"]),
        _chunk("d1", 1, 1, ["page_1.png"]),
    ]
    store = _store(settings, chunks, "d1")
    retriever = _retriever(settings, store)

    _results, images = retriever.retrieve_with_images("问题", top_k=5, max_images=2)

    pages = sorted(page for _name, page, _doc in images)
    assert pages == [1, 2]


def test_位置有富余时会补同一页的其它图(settings):
    chunks = [
        _chunk("d1", 1, 0, ["page_1.png", "p1_img1.png"]),
    ]
    store = _store(settings, chunks, "d1")
    retriever = _retriever(settings, store)

    _results, images = retriever.retrieve_with_images("问题", top_k=5, max_images=3)

    names = [name for name, _page, _doc in images]
    assert names == ["page_1.png", "p1_img1.png"]


def test_图片不会重复(settings):
    chunks = [
        _chunk("d1", 1, 0, ["page_1.png"]),
        _chunk("d1", 1, 1, ["page_1.png"]),
    ]
    store = _store(settings, chunks, "d1")
    retriever = _retriever(settings, store)

    _results, images = retriever.retrieve_with_images("问题", top_k=5, max_images=5)

    assert len(images) == 1


def test_不限制图片数量时也能用(settings):
    chunks = [_chunk("d1", 1, 0, ["page_1.png"])]
    store = _store(settings, chunks, "d1")
    retriever = _retriever(settings, store)

    _results, images = retriever.retrieve_with_images("问题", top_k=5, max_images=0)
    assert len(images) == 1
