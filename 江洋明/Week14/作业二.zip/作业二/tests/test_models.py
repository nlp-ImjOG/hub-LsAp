"""数据契约的测试。"""

from __future__ import annotations

import json

from mmrag.models import (
    ChatMessage,
    Chunk,
    DocumentMeta,
    DocStatus,
    ImageAsset,
    ParseRequest,
    new_id,
    now_ms,
)


def test_三种状态的名字是中文():
    assert DocStatus.PENDING.value == "待解析"
    assert DocStatus.PARSING.value == "解析中"
    assert DocStatus.DONE.value == "解析完成"
    assert DocStatus.FAILED.value == "解析失败"


def test_状态的英文代号():
    assert DocStatus.PENDING.code == "pending"
    assert DocStatus.PARSING.code == "parsing"
    assert DocStatus.DONE.code == "done"
    assert DocStatus.FAILED.code == "failed"


def test_文档元信息往返():
    meta = DocumentMeta(doc_id="d1", filename="a.pdf", size=100)
    restored = DocumentMeta.from_dict(meta.to_dict())
    assert restored.doc_id == "d1"
    assert restored.filename == "a.pdf"
    assert restored.size == 100
    assert restored.status is DocStatus.PENDING


def test_文档元信息遇到不认识的状态会退回待解析():
    meta = DocumentMeta.from_dict({"doc_id": "d1", "status": "外星状态"})
    assert meta.status is DocStatus.PENDING


def test_图片地址是相对路径():
    asset = ImageAsset(doc_id="d1", filename="page_1.png", page=1)
    assert asset.url == "/api/documents/d1/images/page_1.png"


def test_块往返():
    chunk = Chunk(chunk_id="c1", doc_id="d1", page=3, text="正文", images=["a.png"], seq=0)
    restored = Chunk.from_dict(chunk.to_dict())
    assert restored.page == 3
    assert restored.images == ["a.png"]


def test_消息往返():
    message = ChatMessage(role="user", content="问题", images=["x.png"], sources=["d1"])
    restored = ChatMessage.from_json(message.to_json())
    assert restored.role == "user"
    assert restored.content == "问题"
    assert restored.images == ["x.png"]
    assert restored.sources == ["d1"]


def test_消息是合法json():
    message = ChatMessage(role="assistant", content="带\n换行和\"引号\"")
    assert json.loads(message.to_json())["content"] == message.content


def test_解析请求往返():
    request = ParseRequest(doc_id="d1", path="/tmp/a.pdf", filename="a.pdf", size=10)
    restored = ParseRequest.from_dict(request.to_dict())
    assert restored.doc_id == "d1"
    assert restored.filename == "a.pdf"


def test_新id带前缀且不重复():
    first = new_id("doc")
    second = new_id("doc")
    assert first.startswith("doc-")
    assert first != second


def test_时间戳是毫秒():
    assert now_ms() > 1_600_000_000_000
