"""启动器的端口处理。

守的是三件踩过坑的事：

- **默认端口必须躲开 8000** —— 本机上 ``ai-tutor`` 容器常年占着它，
  写死 8000 的结果就是「起不来」，而且报的是 ``winerror 10048``
  这种谁也看不懂的错；
- **``MMRAG_API_PORT`` 必须真的生效** —— ``.env.example`` 里写了它，
  以前启动器压根不看，白写；
- **端口被占要说人话** —— 至少告诉用户端口号和怎么换，
  而不是甩一句 ``[Errno 10048]``。
"""

from __future__ import annotations

import argparse
import socket
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
_SCRIPTS = PROJECT_ROOT / "scripts"
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

import launch  # noqa: E402  （要在 sys.path 调整之后 import）


@pytest.fixture
def occupied_port():
    """占住一个随机端口，测试期间不放。"""

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    # 不 listen，只占端口 —— 够让别人的 bind 失败。
    port = sock.getsockname()[1]
    try:
        yield port
    finally:
        sock.close()


def _free_port() -> int:
    """找一个当前没人用的端口。"""

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


# ------------------------------------------------------------------ 默认端口


def test_默认端口不是8000():
    """8000 是重灾区（别的容器常年占着），默认端口必须躲开。"""

    from mmrag.config import Settings

    assert Settings.api_port != 8000, "默认端口不能用 8000，本机容易被占"
    assert Settings.api_port == 8010


def test_启动器源码里没有写死8000():
    """启动器不能自己拿一个端口出来 —— 端口只有一个来源：配置。"""

    source = (PROJECT_ROOT / "scripts" / "launch.py").read_text(encoding="utf-8")
    for pattern in ("or 8000", "= 8000", ":8000"):
        assert pattern not in source, f"launch.py 里还写死了端口：{pattern}"


# ------------------------------------------------------------------ 端口解析


def test_命令行端口优先(monkeypatch):
    from_env = _free_port()
    from_flag = _free_port()
    monkeypatch.setenv("MMRAG_API_PORT", str(from_env))
    assert launch.resolve_port("127.0.0.1", from_flag) == from_flag


def test_配置里的端口真的生效(monkeypatch):
    """``.env`` 里写了 ``MMRAG_API_PORT`` 就得听它的 —— 以前是白写的。"""

    port = _free_port()
    monkeypatch.setenv("MMRAG_API_PORT", str(port))
    assert launch.resolve_port("127.0.0.1", 0) == port


def test_没配就用默认端口(monkeypatch):
    """配置里给了什么端口，空闲时就用什么端口。"""

    port = _free_port()
    monkeypatch.setenv("MMRAG_API_PORT", str(port))
    assert launch.resolve_port("127.0.0.1", 0) == port


# ------------------------------------------------------------------ 占用检测


def test_能查出端口被占用(occupied_port):
    assert launch.port_occupied("127.0.0.1", occupied_port) is True


def test_空闲端口没被占用():
    assert launch.port_occupied("127.0.0.1", _free_port()) is False


def test_显式指定的端口被占时报错(occupied_port, capsys):
    """用户明确指定了端口，就不能偷偷换成别的 —— 得报错让他自己决定。"""

    assert launch.resolve_port("127.0.0.1", occupied_port) is None
    out = capsys.readouterr().out
    assert str(occupied_port) in out, "提示里没说端口号"
    assert "MMRAG_API_PORT" in out, "提示里没说怎么换端口"


def test_默认端口被占时自动换一个(occupied_port, monkeypatch, capsys):
    """没显式指定端口时，自动挪到后面一个空闲端口，保证能起来。"""

    monkeypatch.setenv("MMRAG_API_PORT", str(occupied_port))
    port = launch.resolve_port("127.0.0.1", 0)
    assert port is not None
    assert port != occupied_port
    assert launch.port_occupied("127.0.0.1", port) is False
    assert "占用" in capsys.readouterr().out


def test_找空闲端口会跳过被占的():
    port = launch.find_free_port("127.0.0.1", 8100)
    assert launch.port_occupied("127.0.0.1", port) is False


# ------------------------------------------------------------------ 启动流程


def test_端口不对就不该先去装依赖(occupied_port, monkeypatch, capsys):
    """依赖探针要 import torch，等几十秒 —— 端口都不对就别让用户干等。"""

    called: list[int] = []
    monkeypatch.setattr(launch, "ensure_deps", lambda: bool(called.append(1)))
    code = launch.cmd_serve(
        argparse.Namespace(host="127.0.0.1", port=occupied_port)
    )
    assert code == 1
    assert called == [], "端口都不对，还去装依赖了"
    out = capsys.readouterr().out
    assert "占" in out, f"提示没说端口被占：{out}"
