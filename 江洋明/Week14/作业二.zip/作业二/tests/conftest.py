"""pytest 公共夹具。

提供一个内存版 Redis（``FakeRedis``），让「存储层」的测试
**不需要真的起 Redis 容器**。
真正连 Redis / Kafka 的用例放在 ``test_integration.py`` 里，
连不上会自动跳过。
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

# 让测试能 import 到 src/ 下的包
_SRC = Path(__file__).resolve().parent.parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


class FakePipeline:
    """``redis`` pipeline 的最小实现：把命令攒起来，execute 时按顺序执行。"""

    def __init__(self, client: "FakeRedis") -> None:
        self._client = client
        self._commands: list[tuple[str, tuple[Any, ...], dict[str, Any]]] = []

    def __getattr__(self, name: str) -> Any:
        def _record(*args: Any, **kwargs: Any) -> "FakePipeline":
            self._commands.append((name, args, kwargs))
            return self

        return _record

    def execute(self) -> list[Any]:
        results: list[Any] = []
        for name, args, kwargs in self._commands:
            results.append(getattr(self._client, name)(*args, **kwargs))
        self._commands.clear()
        return results

    def __enter__(self) -> "FakePipeline":
        return self

    def __exit__(self, *exc: Any) -> None:
        return None


class FakeRedis:
    """够用的内存 Redis。

    语义照抄 redis-py：``rpush`` 返回新长度、``lrange`` 越界返回空、
    ``ltrim`` 保留 ``[start, end]``。
    """

    def __init__(self) -> None:
        self.lists: dict[str, list[str]] = {}
        self.hashes: dict[str, dict[str, str]] = {}
        self.sets: dict[str, set[str]] = {}
        self.expiries: dict[str, int] = {}
        self.calls: list[tuple[str, tuple[Any, ...]]] = []

    # --- 连接 ---
    def ping(self) -> bool:
        return True

    def pipeline(self, transaction: bool = True) -> FakePipeline:
        return FakePipeline(self)

    # --- 通用 ---
    def exists(self, key: str) -> int:
        return int(self._has(key))

    def delete(self, *keys: str) -> int:
        removed = 0
        for key in keys:
            if self._has(key):
                removed += 1
            self.lists.pop(key, None)
            self.hashes.pop(key, None)
            self.sets.pop(key, None)
            self.expiries.pop(key, None)
        return removed

    def expire(self, key: str, seconds: int) -> bool:
        if not self._has(key):
            return False
        self.expiries[key] = seconds
        return True

    def _has(self, key: str) -> bool:
        return key in self.lists or key in self.hashes or key in self.sets

    # --- LIST ---
    def rpush(self, key: str, *values: str) -> int:
        bucket = self.lists.setdefault(key, [])
        bucket.extend(values)
        return len(bucket)

    def llen(self, key: str) -> int:
        return len(self.lists.get(key, []))

    def lrange(self, key: str, start: int, end: int) -> list[str]:
        bucket = list(self.lists.get(key, []))
        length = len(bucket)
        if length == 0:
            return []
        if start < 0:
            start = max(length + start, 0)
        if end < 0:
            end = length + end
        end = min(end, length - 1)
        if start > end:
            return []
        return bucket[start : end + 1]

    def ltrim(self, key: str, start: int, end: int) -> bool:
        bucket = self.lists.get(key)
        if bucket is None:
            return True
        self.lists[key] = self.lrange(key, start, end)
        return True

    # --- HASH ---
    def hset(self, key: str, mapping: dict[str, Any] | None = None, **_kwargs: Any) -> int:
        bucket = self.hashes.setdefault(key, {})
        added = 0
        for field, value in (mapping or {}).items():
            if field not in bucket:
                added += 1
            bucket[field] = str(value)
        return added

    def hgetall(self, key: str) -> dict[str, str]:
        return dict(self.hashes.get(key, {}))

    # --- SET ---
    def sadd(self, key: str, *members: str) -> int:
        bucket = self.sets.setdefault(key, set())
        before = len(bucket)
        bucket.update(members)
        return len(bucket) - before

    def smembers(self, key: str) -> set[str]:
        return set(self.sets.get(key, set()))

    def srem(self, key: str, *members: str) -> int:
        bucket = self.sets.get(key)
        if bucket is None:
            return 0
        before = len(bucket)
        bucket.difference_update(members)
        return before - len(bucket)


class FakeBus:
    """假的消息总线：把发出去的消息记下来，不真的碰 Kafka。"""

    def __init__(self, settings: Any | None = None) -> None:
        self.published: list[dict[str, Any]] = []
        self._settings = settings

    def _topic(self, name: str, fallback: str) -> str:
        if self._settings is None:
            return fallback
        return getattr(self._settings, name)

    def publish(self, topic: str, value: dict[str, Any], *, key: str | None = None) -> dict[str, Any]:
        self.published.append({"topic": topic, "value": value, "key": key})
        return {"topic": topic, "partition": 0, "offset": len(self.published), "key": key}

    def publish_parse_request(self, request: Any) -> dict[str, Any]:
        topic = self._topic("kafka_topic_parse", "wk14.pdf.parse")
        return self.publish(topic, request.to_dict(), key=request.doc_id)

    def publish_parsed_event(self, doc_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        topic = self._topic("kafka_topic_parsed", "wk14.pdf.parsed")
        return self.publish(topic, payload, key=doc_id)

    def ensure_topics(self) -> list[str]:
        return []

    def ping(self) -> bool:
        return True


@pytest.fixture
def fake_redis() -> FakeRedis:
    """一个干净的内存 Redis。"""

    return FakeRedis()


@pytest.fixture
def fake_bus(settings) -> FakeBus:
    """一个假的消息总线（topic 跟着测试配置走）。"""

    return FakeBus(settings)


@pytest.fixture
def settings(tmp_path: Path):
    """测试用的配置：数据目录指到临时目录，前缀固定。"""

    from mmrag.config import Settings

    data_dir = tmp_path / "data"
    return Settings(
        redis_url="redis://127.0.0.1:6379/15",
        redis_prefix="wk14-test",
        data_dir=data_dir,
        upload_dir=data_dir / "uploads",
        image_dir=data_dir / "images",
        chunk_dir=data_dir / "chunks",
        vector_dir=data_dir / "vectors",
        doc_ttl_seconds=60,
        chat_ttl_seconds=60,
        max_chat_messages=6,
        kafka_bootstrap_servers="127.0.0.1:9092",
        kafka_topic_parse="wk14.test.parse",
        kafka_topic_parsed="wk14.test.parsed",
        kafka_consumer_group="wk14-test-group",
        llm_api_key="sk-test-key",
        llm_base_url="https://example.invalid/v1",
        llm_model="deepseek-flash",
        top_k=3,
        max_images_in_prompt=2,
        chunk_size=120,
        chunk_overlap=20,
        max_upload_bytes=1024 * 1024,
        max_files_per_upload=3,
    )


@pytest.fixture
def sample_pdf(tmp_path: Path) -> Path:
    """造一份两页的样例 PDF。"""

    import sys as _sys

    scripts_dir = Path(__file__).resolve().parent.parent / "scripts"
    if str(scripts_dir) not in _sys.path:
        _sys.path.insert(0, str(scripts_dir))
    from sample_pdf import make_sample_pdf

    return make_sample_pdf(tmp_path / "示例.pdf")
