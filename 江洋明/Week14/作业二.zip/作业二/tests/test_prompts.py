"""提示词的测试。"""

from __future__ import annotations

from mmrag.models import Chunk
from mmrag.prompts import (
    SYSTEM_PROMPT,
    build_context,
    build_image_manifest,
    build_user_content,
)
from mmrag.retriever import Retrieved


def _retrieved(doc_id: str = "d1", page: int = 3, text: str = "正文", score: float = 0.8):
    chunk = Chunk(chunk_id="c1", doc_id=doc_id, page=page, text=text, images=[], seq=0)
    return Retrieved(chunk=chunk, score=score)


def test_系统提示词要求标页码():
    assert "页码" in SYSTEM_PROMPT
    assert "Markdown" in SYSTEM_PROMPT


def test_上下文带文档和页码():
    context = build_context([_retrieved(doc_id="doc-abc", page=5, text="内容在这里")])
    assert "doc-abc" in context
    assert "第 5 页" in context
    assert "内容在这里" in context


def test_没有检索结果时上下文有说明():
    assert "没有检索到" in build_context([])


def test_图片清单给出可引用的地址():
    manifest = build_image_manifest([("page_1.png", 1, "d1")])
    assert "/api/documents/d1/images/page_1.png" in manifest
    assert "第 1 页" in manifest


def test_图片清单为空时有说明():
    assert "没有可用图片" in build_image_manifest([])


def test_多模态消息体是数组():
    content = build_user_content(
        "问题是什么",
        "上下文",
        [("page_1.png", 1, "d1")],
        ["data:image/png;base64,AAAA"],
    )
    assert isinstance(content, list)
    assert content[0]["type"] == "text"
    assert "问题是什么" in content[0]["text"]


def test_多模态消息体里带上了图片():
    content = build_user_content(
        "问题",
        "上下文",
        [("page_1.png", 1, "d1")],
        ["data:image/png;base64,AAAA"],
    )
    images = [c for c in content if c["type"] == "image_url"]
    assert len(images) == 1
    assert images[0]["image_url"]["url"] == "data:image/png;base64,AAAA"


def test_图片比data_url多时不会错位():
    content = build_user_content(
        "问题",
        "上下文",
        [("a.png", 1, "d1"), ("b.png", 2, "d1")],
        ["data:image/png;base64,AAAA"],
    )
    images = [c for c in content if c["type"] == "image_url"]
    assert len(images) == 1


# ------------------------------------------------------------------ 用户上传的图


def test_用户上传的图会进消息体():
    content = build_user_content(
        "这张图里写了什么",
        "上下文",
        [],
        [],
        ["探针图片.png"],
        ["data:image/png;base64,BBBB"],
    )
    images = [c for c in content if c["type"] == "image_url"]
    assert len(images) == 1
    assert images[0]["image_url"]["url"] == "data:image/png;base64,BBBB"


def test_用户上传的图排在文档图片前面():
    """问题问的是用户传的那张图 —— 它得排在前面。"""

    content = build_user_content(
        "问题",
        "上下文",
        [("page_1.png", 1, "d1")],
        ["data:image/png;base64,AAAA"],
        ["探针图片.png"],
        ["data:image/png;base64,BBBB"],
    )
    images = [c["image_url"]["url"] for c in content if c["type"] == "image_url"]
    assert images == ["data:image/png;base64,BBBB", "data:image/png;base64,AAAA"]


def test_用户上传的图不会被当成文档某一页():
    """踩过的坑：用户图片被列成「第 0 页」，模型据此拒答。

    现在它单独成段，还明说是「问题的对象」，更不能出现页码。
    """

    content = build_user_content(
        "问题",
        "上下文",
        [],
        [],
        ["探针图片.png"],
        ["data:image/png;base64,BBBB"],
    )
    text = content[0]["text"]
    assert "用户随问题上传的图片" in text
    assert "探针图片.png" in text
    assert "第 0 页" not in text


def test_用户上传的图不进可引用的图片清单():
    """用户图片没有对外地址，不能让模型去 Markdown 引用它。"""

    content = build_user_content(
        "问题",
        "上下文",
        [("page_1.png", 1, "d1")],
        ["data:image/png;base64,AAAA"],
        ["探针图片.png"],
        ["data:image/png;base64,BBBB"],
    )
    text = content[0]["text"]
    manifest = text.split("【可引用的图片】")[1].split("【")[0]
    # 文档图片该有地址，可以被引用
    assert "/api/documents/d1/images/page_1.png" in manifest
    # 用户图片没有对外地址，不能进这个清单
    assert "探针图片.png" not in manifest


def test_系统提示词说了用户图片要直接看():
    """光改清单不够 —— 系统提示词也得说清楚用户图片怎么对待。"""

    assert "用户随问题上传的图片" in SYSTEM_PROMPT
    assert "直接看图作答" in SYSTEM_PROMPT
