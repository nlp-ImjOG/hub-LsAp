"""启动脚本 / 配置文件的自检。

这里守的是几个**踩过坑**的约定，坏了没人会立刻发现，所以写成测试：

- ``.bat`` 必须是纯 ASCII —— cmd.exe 用 GBK 读批处理，中文会变成乱码甚至语法错；
- ``.bat`` 必须是 CRLF 换行 —— 记事本和旧 cmd 认 LF；
- ``.bat`` 里不能出现括号 —— cmd 的 ``if`` 块里括号要转义，很容易写崩；
- ``.sh`` 必须是 LF 换行；
- ``.env`` 不能进仓库；
- ``requirements.txt`` 里不能有 MinerU —— 它必须装在独立的虚拟环境里。
"""

from __future__ import annotations

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

BAT_FILES = sorted(PROJECT_ROOT.glob("*.bat"))
SH_FILES = sorted(PROJECT_ROOT.glob("*.sh"))


def _raw(path: Path) -> bytes:
    return path.read_bytes()


# ------------------------------------------------------------------ 批处理


def test_有批处理脚本():
    assert BAT_FILES, "至少要有一个 .bat"


def test_批处理是纯ascii():
    for path in BAT_FILES:
        try:
            _raw(path).decode("ascii")
        except UnicodeDecodeError as exc:  # pragma: no cover - 出错才有意义
            raise AssertionError(f"{path.name} 里有非 ASCII 字符：{exc}") from exc


def test_批处理用crlf换行():
    for path in BAT_FILES:
        raw = _raw(path)
        assert b"\r\n" in raw, f"{path.name} 不是 CRLF 换行"
        # 不允许出现「裸 LF」：即每个 \n 前面都有 \r
        assert raw.replace(b"\r\n", b"") .count(b"\n") == 0, f"{path.name} 里有裸 LF"


def test_批处理里没有括号():
    for path in BAT_FILES:
        text = _raw(path).decode("ascii")
        assert "(" not in text and ")" not in text, f"{path.name} 里有括号"


def test_批处理都走同一个入口():
    for path in BAT_FILES:
        text = _raw(path).decode("ascii")
        # cmd 里路径用反斜杠，shell 里用正斜杠，这里都认
        assert "scripts" in text and "launch.py" in text, f"{path.name} 没调用 scripts/launch.py"


# ------------------------------------------------------------------ shell


def test_有shell脚本():
    assert SH_FILES, "至少要有一个 .sh"


def test_shell脚本用lf换行():
    for path in SH_FILES:
        raw = _raw(path)
        assert b"\r\n" not in raw, f"{path.name} 里出现了 CRLF"
        assert raw.endswith(b"\n"), f"{path.name} 结尾缺换行"


def test_shell脚本是纯ascii():
    for path in SH_FILES:
        _raw(path).decode("ascii")


def test_shell脚本都走同一个入口():
    for path in SH_FILES:
        text = _raw(path).decode("ascii")
        assert "scripts/launch.py" in text, f"{path.name} 没调用 scripts/launch.py"


# ------------------------------------------------------------------ 配置


def test_gitignore挡住了env():
    text = (PROJECT_ROOT / ".gitignore").read_text(encoding="utf-8")
    assert ".env" in text


def test_env文件本地存在但不入库():
    """本机要有 .env（跑起来要 key），但它必须在 .gitignore 里。"""

    ignored = (PROJECT_ROOT / ".gitignore").read_text(encoding="utf-8")
    assert ".env" in ignored
    if (PROJECT_ROOT / ".env").exists():
        content = (PROJECT_ROOT / ".env").read_text(encoding="utf-8")
        assert "MMRAG_API_KEY" in content


def test_env_example里没有真key():
    import re

    text = (PROJECT_ROOT / ".env.example").read_text(encoding="utf-8")
    assert "MMRAG_API_KEY=" in text
    # 只能有占位符，不能有像真 key 的那一串
    assert not re.search(r"sk-[A-Za-z0-9]{16,}", text)


def test_依赖里没有mineru():
    """MinerU 装在独立虚拟环境，不能混进主依赖。"""

    text = (PROJECT_ROOT / "requirements.txt").read_text(encoding="utf-8")
    for line in text.splitlines():
        if line.strip().startswith("#"):
            continue
        assert not line.lower().startswith("mineru"), f"requirements.txt 里不该有 {line}"


def test_docker_compose的端口和容器名():
    text = (PROJECT_ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    assert "wk14-redis" in text
    assert "wk14-kafka" in text
    assert "6380" in text
    assert "9095" in text


def test_前端是单文件():
    html = PROJECT_ROOT / "frontend" / "index.html"
    assert html.is_file()
    text = html.read_text(encoding="utf-8")
    assert "vue" in text.lower()
    assert "/api/documents" in text
    assert "/api/chat" in text


def test_前端有三种状态的中文():
    text = (PROJECT_ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    for word in ("待解析", "解析中", "解析完成"):
        assert word in text, f"前端里找不到「{word}」"
