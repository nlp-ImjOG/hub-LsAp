"""样例 PDF 生成器的自检。

守的是一个**渲染层**的坑：MuPDF 自带的 CJK 字体 ``china-s`` 里，
**拉丁字母是全角的** —— 一个字母占一个字宽。

不踩这个坑的话，画出来的流程图上是 ``F a s t A P I``、
``K a f k a``。MinerU 会照着像素 OCR，模型也只能照着念，
整个「多模态」的演示就露馅了。

所以这里断言：**拉丁字母必须用比例字体画，不能是全角**。
"""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from sample_pdf import _is_wide, _split_runs, _text_width  # noqa: E402


# ------------------------------------------------------------------ 字符分类


def test_汉字算全角():
    assert _is_wide("文") is True
    assert _is_wide("模") is True


def test_全角标点算全角():
    assert _is_wide("，") is True
    assert _is_wide("（") is True
    assert _is_wide("）") is True


def test_箭头算全角():
    assert _is_wide("→") is True


def test_拉丁字母和数字不算全角():
    assert _is_wide("K") is False
    assert _is_wide("a") is False
    assert _is_wide("7") is False
    assert _is_wide(" ") is False


# ------------------------------------------------------------------ 分段


def test_中英混排会切成两段():
    runs = _split_runs("用Kafka")
    assert runs == [(True, "用"), (False, "Kafka")]


def test_连续同类的字符会合成一段():
    runs = _split_runs("系统采用")
    assert runs == [(True, "系统采用")]


def test_英文和数字会合成一段():
    runs = _split_runs("deepseek-flash 4.1")
    assert runs == [(False, "deepseek-flash 4.1")]


# ------------------------------------------------------------------ 宽度


def test_全角文字的宽度等于字号乘字数():
    assert _text_width("浏览器", 10.0) == 30.0


def test_拉丁文字的宽度比全角窄():
    """比例字体下 7 个字母的宽度必须小于 7 个字宽。"""

    assert _text_width("FastAPI", 9.5) < 7 * 9.5


# ------------------------------------------------------------------ 生成的 PDF


def _spans_of(pdf_path: Path) -> list[tuple[str, str, float]]:
    """把 PDF 里所有 span 摊平成 ``[(文字, 字体名, 字号), ...]``。"""

    import pymupdf

    doc = pymupdf.open(pdf_path)
    try:
        page = doc[0]
        out: list[tuple[str, str, float]] = []
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    out.append((span["text"], span["font"], float(span["size"])))
        return out
    finally:
        doc.close()


def _width_of(pdf_path: Path, needle: str) -> float:
    """某个文字片段的包围盒宽度。"""

    import pymupdf

    doc = pymupdf.open(pdf_path)
    try:
        for block in doc[0].get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    if needle in span["text"]:
                        return float(span["bbox"][2] - span["bbox"][0])
    finally:
        doc.close()
    raise AssertionError(f"PDF 里找不到「{needle}」")


def test_文字层里是完整的英文单词(sample_pdf):
    """PDF 的文字层不能被拆成单字母。"""

    import pymupdf

    doc = pymupdf.open(sample_pdf)
    try:
        text = doc[0].get_text()
    finally:
        doc.close()

    assert "FastAPI" in text
    assert "Kafka" in text
    assert "F a s t" not in text


def test_拉丁字母不是用全角字体画的(sample_pdf):
    """``FastAPI`` 必须落在比例字体（Helvetica）上，不是 CJK 的 Heiti。"""

    spans = _spans_of(sample_pdf)
    latin = [span for span in spans if "FastAPI" in span[0]]
    assert latin, "PDF 里找不到 FastAPI 这个 span"
    for _text, font, _size in latin:
        assert font == "Helvetica", f"FastAPI 用的是 {font}，应该是 Helvetica"


def test_拉丁字母的宽度不是全角(sample_pdf):
    """全角的话宽度正好是「字数 × 字号」—— 现在必须严格小于。"""

    width = _width_of(sample_pdf, "FastAPI")
    assert width < 7 * 9.5, f"FastAPI 宽 {width}，还是全角"


def test_中文还是用CJK字体(sample_pdf):
    """汉字不能被换成比例字体 —— 那样会变成方块或问号。"""

    spans = _spans_of(sample_pdf)
    chinese = [span for span in spans if "浏览器" in span[0]]
    assert chinese, "PDF 里找不到「浏览器」这个 span"
    for _text, font, _size in chinese:
        assert font != "Helvetica", "中文不该用 Helvetica 画"


# ------------------------------------------------------------------ 导出流程图


def test_流程图能单独导出成PNG(sample_pdf, tmp_path):
    """「图问」演示要有一张能上传的图 —— 从样例 PDF 里裁出来。"""

    from sample_pdf import export_figure_png

    target = export_figure_png(sample_pdf, tmp_path / "流程图.png")
    assert target.is_file()
    assert target.stat().st_size > 0

    import pymupdf

    pix = pymupdf.Pixmap(str(target))
    assert pix.width > 100 and pix.height > 100

