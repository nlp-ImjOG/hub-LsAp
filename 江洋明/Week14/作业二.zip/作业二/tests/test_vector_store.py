"""向量库的测试。"""

from __future__ import annotations

import numpy as np

from mmrag.models import Chunk
from mmrag.vector_store import VectorStore


def _chunk(index: int, doc_id: str = "d1", page: int = 1) -> Chunk:
    return Chunk(
        chunk_id=f"{doc_id}-{index}",
        doc_id=doc_id,
        page=page,
        text=f"文本{index}",
        images=[],
        seq=index,
    )


def test_写进去能搜回来(settings):
    store = VectorStore(settings)
    chunks = [_chunk(0), _chunk(1)]
    vectors = np.array([[1.0, 0.0], [0.0, 1.0]], dtype="float32")
    store.add("d1", chunks, vectors)

    hits = store.search(np.array([1.0, 0.0], dtype="float32"), top_k=2)
    assert hits[0][0].chunk_id == "d1-0"
    assert hits[0][1] > hits[1][1]


def test_块数和向量数对不上会报错(settings):
    import pytest

    store = VectorStore(settings)
    with pytest.raises(ValueError):
        store.add("d1", [_chunk(0)], np.zeros((2, 2), dtype="float32"))


def test_按文档过滤(settings):
    store = VectorStore(settings)
    store.add("d1", [_chunk(0, "d1")], np.array([[1.0, 0.0]], dtype="float32"))
    store.add("d2", [_chunk(0, "d2")], np.array([[1.0, 0.0]], dtype="float32"))

    hits = store.search(np.array([1.0, 0.0], dtype="float32"), top_k=5, doc_ids=["d2"])
    assert len(hits) == 1
    assert hits[0][0].doc_id == "d2"


def test_删掉文档后搜不到(settings):
    store = VectorStore(settings)
    store.add("d1", [_chunk(0)], np.array([[1.0, 0.0]], dtype="float32"))
    assert store.remove("d1") is True
    assert store.search(np.array([1.0, 0.0], dtype="float32"), top_k=5) == []


def test_落盘后能重新载入(settings):
    store = VectorStore(settings)
    store.add("d1", [_chunk(0)], np.array([[1.0, 0.0]], dtype="float32"))

    fresh = VectorStore(settings)
    fresh.load()
    assert fresh.stats()["chunks"] == 1
    assert fresh.chunks_of("d1")[0].text == "文本0"


def test_空库搜索返回空(settings):
    assert VectorStore(settings).search(np.array([1.0], dtype="float32")) == []


# ------------------------------------------------------------------ 跨进程同步


def test_另一个进程写入的索引能看见(settings):
    """Worker 写完索引后，服务端要能看见 —— 不能是一次性快照。

    踩过的坑：服务一直开着，新文档解析完了，问答还是说「没找到相关内容」，
    因为向量库只在启动时读了一次磁盘。
    """

    server = VectorStore(settings)
    server.add("d1", [_chunk(0)], np.array([[1.0, 0.0]], dtype="float32"))
    assert server.stats()["documents"] == 1

    worker = VectorStore(settings)  # 另一个进程
    worker.add("d2", [_chunk(0, "d2")], np.array([[1.0, 0.0]], dtype="float32"))

    assert server.stats()["documents"] == 2
    assert server.stats()["chunks"] == 2


def test_磁盘上删掉的文档内存里也会消失(settings):
    server = VectorStore(settings)
    server.add("d1", [_chunk(0)], np.array([[1.0, 0.0]], dtype="float32"))

    VectorStore(settings).remove("d1")  # 另一个进程删了

    assert server.stats()["documents"] == 0


def test_索引更新后能搜到新内容(settings):
    server = VectorStore(settings)
    server.add("d1", [_chunk(0)], np.array([[1.0, 0.0]], dtype="float32"))

    worker = VectorStore(settings)
    worker.add("d1", [_chunk(0, "d1")], np.array([[0.0, 1.0]], dtype="float32"))

    hits = server.search(np.array([0.0, 1.0], dtype="float32"), top_k=1)
    assert len(hits) == 1
    assert hits[0][1] > 0.9
