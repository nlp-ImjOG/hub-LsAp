"""命令行的测试（不连 Redis / Kafka，全部替换成假的）。"""

from __future__ import annotations

from typing import Any

import pytest

import mmrag.cli as cli
from mmrag.models import DocStatus, DocumentMeta


class FakeStore:
    """只够 CLI 用的假存储。"""

    def __init__(self, settings: Any = None, client: Any = None) -> None:
        self._settings = settings
        self.docs: dict[str, DocumentMeta] = {}

    def save_doc(self, meta: DocumentMeta) -> None:
        self.docs[meta.doc_id] = meta

    def list_docs(self) -> list[DocumentMeta]:
        return list(self.docs.values())

    def get_doc(self, doc_id: str) -> DocumentMeta | None:
        return self.docs.get(doc_id)

    def pending_docs(self) -> list[DocumentMeta]:
        return [m for m in self.docs.values() if m.status is DocStatus.PENDING]

    def ping(self) -> bool:
        return True


class FakeBus:
    """只够 CLI 用的假总线。"""

    instances: list["FakeBus"] = []

    def __init__(self, settings: Any = None) -> None:
        self.published: list[dict[str, Any]] = []
        FakeBus.instances.append(self)

    def ensure_topics(self) -> list[str]:
        return []

    def publish_parse_request(self, request: Any) -> dict[str, Any]:
        self.published.append({"key": request.doc_id, "value": request.to_dict()})
        return {"topic": "t", "partition": 0, "offset": 0, "key": request.doc_id}

    def publish_parsed_event(self, doc_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        self.published.append({"key": doc_id, "value": payload})
        return {"topic": "t", "partition": 0, "offset": 0, "key": doc_id}

    def describe(self, topic: str) -> dict[str, Any]:
        return {"topic": topic, "partitions": []}

    def ping(self) -> bool:
        return True


@pytest.fixture(autouse=True)
def _patch(monkeypatch):
    """把 CLI 里的 Redis / Kafka 换成假的。"""

    FakeBus.instances.clear()
    monkeypatch.setattr(cli, "StateStore", FakeStore)
    monkeypatch.setattr(cli, "Bus", FakeBus)


# ------------------------------------------------------------------ 参数解析


def test_不带子命令时不报错():
    parser = cli.build_parser()
    args = parser.parse_args([])
    assert getattr(args, "command", None) is None


def test_status子命令():
    args = cli.build_parser().parse_args(["status"])
    assert args.func is cli.cmd_status


def test_upload能接多个文件():
    args = cli.build_parser().parse_args(["upload", "a.pdf", "b.pdf"])
    assert args.files == ["a.pdf", "b.pdf"]


def test_ask带会话和图片():
    args = cli.build_parser().parse_args(
        ["ask", "这篇讲了什么", "--session", "s1", "--image", "a.png"]
    )
    assert args.question == "这篇讲了什么"
    assert args.session == "s1"
    assert args.image == ["a.png"]


def test_worker有一次模式():
    args = cli.build_parser().parse_args(["worker", "--once"])
    assert args.once is True


# ------------------------------------------------------------------ 子命令


def test_docs没有文档时打印提示(capsys, settings):
    args = cli.build_parser().parse_args(["docs"])
    assert cli.cmd_docs(args, settings) == 0
    assert "还没有文档" in capsys.readouterr().out


def test_docs会列出状态(capsys, settings, monkeypatch):
    store = FakeStore(settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="论文.pdf", status=DocStatus.DONE))
    monkeypatch.setattr(cli, "StateStore", lambda settings=None, client=None: store)

    args = cli.build_parser().parse_args(["docs"])
    assert cli.cmd_docs(args, settings) == 0
    out = capsys.readouterr().out
    assert "论文.pdf" in out
    assert "解析完成" in out


def test_upload文件不存在时返回2(capsys, settings, tmp_path):
    args = cli.build_parser().parse_args(["upload", str(tmp_path / "没有.pdf")])
    assert cli.cmd_upload(args, settings) == 2
    assert "文件不存在" in capsys.readouterr().err


def test_upload会存文档并投Kafka(capsys, settings, tmp_path):
    pdf = tmp_path / "论文.pdf"
    pdf.write_bytes(b"%PDF-1.4 fake")

    args = cli.build_parser().parse_args(["upload", str(pdf)])
    assert cli.cmd_upload(args, settings) == 0

    out = capsys.readouterr().out
    assert "待解析" in out

    bus = FakeBus.instances[-1]
    assert len(bus.published) == 1
    doc_id = bus.published[0]["key"]
    # 文件按 <doc_id>__<原名> 的约定落在 data/uploads 下
    saved = settings.upload_dir / f"{doc_id}__论文.pdf"
    assert saved.is_file()


def test_upload能一次传多个(capsys, settings, tmp_path):
    first = tmp_path / "a.pdf"
    second = tmp_path / "b.pdf"
    first.write_bytes(b"%PDF-1.4 a")
    second.write_bytes(b"%PDF-1.4 b")

    args = cli.build_parser().parse_args(["upload", str(first), str(second)])
    assert cli.cmd_upload(args, settings) == 0
    assert len(FakeBus.instances[-1].published) == 2


# ------------------------------------------------------------------ 图问


def test_图片会被搬进会话目录(settings, tmp_path):
    """问答层只认「会话目录里的文件名」。

    命令行给的是**路径**，得先搬进 ``data/images/<session>/``。
    """

    source = tmp_path / "探针图片.png"
    source.write_bytes(b"\x89PNG fake")

    names = cli._stage_images([str(source)], settings, "s1")
    assert names == ["探针图片.png"]
    stored = settings.image_dir / "s1" / "探针图片.png"
    assert stored.is_file()
    assert stored.read_bytes() == b"\x89PNG fake"


def test_图片不存在就跳过(settings, tmp_path, capsys):
    names = cli._stage_images([str(tmp_path / "没有.png")], settings, "s1")
    assert names == []
    assert "图片不存在" in capsys.readouterr().err


def test_图片本来就在会话目录里也不会报错(settings, tmp_path):
    """自己拷自己会抛 ``SameFileError`` —— 得先判一下。"""

    session_dir = settings.image_dir / "s1"
    session_dir.mkdir(parents=True, exist_ok=True)
    source = session_dir / "a.png"
    source.write_bytes(b"x")

    names = cli._stage_images([str(source)], settings, "s1")
    assert names == ["a.png"]
    assert source.read_bytes() == b"x"
