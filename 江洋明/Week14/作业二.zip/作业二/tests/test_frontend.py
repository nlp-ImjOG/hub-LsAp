"""前端的测试。

前端是**单文件 HTML**，逻辑都在 ``frontend/index.html`` 里。
这里把里面的 Markdown 渲染器抠出来，放到真的 Chromium 里跑一遍 ——
渲染错的地方肉眼很难发现，但 ``![alt](url)`` 没变成 ``<img>`` 这种问题
一眼就能看出来（答案里会露出 Markdown 原文）。

没装 playwright 或没装浏览器就跳过，不让没这些环境的人跑红。
"""

from __future__ import annotations

from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
FRONTEND = PROJECT_ROOT / "frontend" / "index.html"


def _render_js() -> str:
    """从 index.html 里抠出渲染相关的 JS。"""

    text = FRONTEND.read_text(encoding="utf-8")
    start = text.index("/* ── 迷你 Markdown 渲染")
    end = text.index("/* ── 健康检查")
    return text[start:end]


def _css() -> str:
    """从 index.html 里抠出 ``<style>`` 里的 CSS。"""

    text = FRONTEND.read_text(encoding="utf-8")
    start = text.index("<style>") + len("<style>")
    end = text.index("</style>")
    return text[start:end]


def _chromium() -> str | None:
    import sys

    scripts = PROJECT_ROOT / "scripts"
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    from screenshot import _find_chromium

    return _find_chromium()


@pytest.fixture(scope="module")
def browser():
    """一个 Chromium 实例 —— 模块级复用，别每个用例都起一个。"""

    pytest.importorskip("playwright")
    from playwright.sync_api import sync_playwright

    executable = _chromium()

    with sync_playwright() as playwright:
        try:
            instance = playwright.chromium.launch(executable_path=executable)
        except Exception as exc:  # pragma: no cover - 环境问题
            pytest.skip(f"起不来浏览器：{exc}")
        try:
            yield instance
        finally:
            instance.close()


@pytest.fixture(scope="module")
def render(browser):
    """返回一个把 Markdown 变成 HTML 的函数。"""

    js = _render_js()
    page = browser.new_page()
    page.set_content("<div id='out'></div>")

    def _render(text: str) -> str:
        return page.evaluate(
            "([js, raw]) => {"
            "  const f = new Function('raw', js + '; return render(raw);');"
            "  return f(raw);"
            "}",
            [js, text],
        )

    yield _render
    page.close()


# ------------------------------------------------------------------ 图片


def test_图片语法会变成img(render):
    html = render("![第 1 页](/api/documents/d1/images/page_1.png)")
    assert "<img" in html
    assert 'src="/api/documents/d1/images/page_1.png"' in html


def test_括号里有空格也能认出来(render):
    """模型有时写成 ``![alt]( /path)`` —— 少一个正则就露馅了。"""

    html = render("![第 1 页]( /api/documents/d1/images/page_1.png)")
    assert "<img" in html


def test_外站图片会被丢掉(render):
    """白名单：只认本服务的图片地址和外链 http(s)。"""

    html = render("![x](javascript:alert(1))")
    assert "<img" not in html
    assert "javascript:" not in html


def test_外链图片可以留(render):
    html = render("![x](https://example.com/a.png)")
    assert "<img" in html


# ------------------------------------------------------------------ 表格


def test_表格会变成table(render):
    html = render("| 环节 | 做法 |\n|---|---|\n| 队列 | Kafka |")
    assert "<table" in html
    assert "<th>环节</th>" in html
    assert "<td>Kafka</td>" in html
    assert "|---|" not in html


# ------------------------------------------------------------------ 其它


def test_加粗会变成strong(render):
    assert "<strong>重点</strong>" in render("这是**重点**")


def test_行内代码会变成code(render):
    assert "<code>deepseek-flash</code>" in render("用 `deepseek-flash` 模型")


def test_脚本标签会被转义(render):
    html = render("<script>alert(1)</script>")
    assert "<script>" not in html
    assert "&lt;script&gt;" in html


def test_列表会变成ul(render):
    html = render("- 第一条\n- 第二条")
    assert "<ul>" in html
    assert html.count("<li>") == 2


# ------------------------------------------------------------------ 状态开关


def _frontend_parts() -> tuple[str, str]:
    """把前端拆成「页面」和「脚本」两段。

    页面 = ``<head>``（含 CSS）+ 模板（``<div id="app">`` 到 ``<script>``），
    脚本 = 最后那个内联 ``<script>`` 块。

    分开看是有必要的 —— 脚本的**注释里**会故意出现
    ``:disabled="streaming"`` 这种字符串（就是在解释这个坑），
    混在一起断言就会误伤。
    """

    text = FRONTEND.read_text(encoding="utf-8")
    end = text.index("<script>", text.index('<div id="app">'))
    return text[:end], text[end:]


def test_正在回答的开关和答案文本是分开的():
    """``streaming`` 是答案文本，``busy`` 才是「正在回答」的开关。

    混在一起踩过一个坑：``:disabled="streaming"`` ——
    Vue 对布尔属性，绑定值是**空字符串**时也当成「属性存在」
    （``includeBooleanAttr('')`` 为真），于是「清空对话」按钮
    **永远是禁用的**，点不动，截图脚本直接卡死。
    """

    template, script = _frontend_parts()
    assert "const busy = ref(false)" in script
    assert ':disabled="busy"' in template
    assert ':disabled="streaming"' not in template


def test_发送按钮用的是busy开关():
    template, script = _frontend_parts()
    assert ':disabled="busy || !question.trim()"' in template
    assert "if (!q || busy.value) return;" in script


def test_回答结束时busy会复位():
    """``busy`` 不复位的话，「清空对话」和「发送」会一直禁用。"""

    _template, script = _frontend_parts()
    assert "busy.value = false;" in script
    assert "busy.value = true;" in script


def test_实时预览用的是busy开关():
    """正在吐字的那块气泡也该跟着 ``busy`` 走，不能跟着答案文本走。"""

    template, _script = _frontend_parts()
    assert 'v-if="busy"' in template


def test_用户上传的图是缩略图():
    """``.msg .bubble img`` 那条规则（内联大图，420px 高）
    会把用户自己传的图也一起撑大 —— 缩略图得用更具体的选择器压住它。
    """

    template, _script = _frontend_parts()
    assert ".msg .bubble .thumbs img" in template


# ------------------------------------------------------------------ 布局


def test_上传框的边框是完整的一个框(browser):
    """``.drop`` 是个 ``<label>``，里面塞了三个 ``<div>``。

    ``label`` 默认 ``display: inline`` —— 行内框里出现块级元素，
    浏览器会把这个行内框**拆成片段**（inline box fragmentation），
    虚线边框于是画得七零八落：截图上左边一截、底边整条没了。

    所以 ``.drop`` 必须显式 ``display: block`` —— 拆完之后
    ``getClientRects()`` 就只剩一个矩形了。
    """

    page = browser.new_page()
    try:
        page.set_content(
            f"<style>{_css()}</style>"
            "<label class='drop'><div>PDF</div><div>把 PDF 拖进来</div>"
            "<div>一次最多 10 个</div></label>"
        )
        rects = page.evaluate(
            "() => document.querySelector('.drop').getClientRects().length"
        )
        assert rects == 1, f"上传框被拆成了 {rects} 个矩形，边框会画断"
        height = page.evaluate(
            "() => document.querySelector('.drop').getBoundingClientRect().height"
        )
        assert height > 60, f"上传框只有 {height}px 高，内容被压扁了"
    finally:
        page.close()


