"""Redis 存储层的测试（用内存版 Redis）。"""

from __future__ import annotations

from mmrag.models import ChatMessage, DocumentMeta, DocStatus
from mmrag.store import StateStore


def _store(fake_redis, settings) -> StateStore:
    return StateStore(client=fake_redis, settings=settings)


def test_存进去能读出来(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf", size=10))

    meta = store.get_doc("d1")
    assert meta is not None
    assert meta.filename == "a.pdf"
    assert meta.status is DocStatus.PENDING


def test_文档列表按创建时间倒序(fake_redis, settings):
    store = _store(fake_redis, settings)
    first = DocumentMeta(doc_id="d1", filename="a.pdf")
    second = DocumentMeta(doc_id="d2", filename="b.pdf")
    second.created_at = first.created_at + 1000
    store.save_doc(first)
    store.save_doc(second)

    assert [m.doc_id for m in store.list_docs()] == ["d2", "d1"]


def test_改状态会写回(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))

    meta = store.update_status(
        "d1", DocStatus.DONE, backend="pymupdf", pages=3, chunks=5, images=2
    )
    assert meta.status is DocStatus.DONE
    assert meta.backend == "pymupdf"
    assert meta.pages == 3
    assert meta.chunks == 5
    assert meta.images == 2


def test_改不存在的文档会报错(fake_redis, settings):
    import pytest

    store = _store(fake_redis, settings)
    with pytest.raises(KeyError):
        store.update_status("不存在", DocStatus.PARSING)


def test_待解析列表只含待解析(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    store.save_doc(DocumentMeta(doc_id="d2", filename="b.pdf"))
    store.update_status("d2", DocStatus.DONE)

    pending = store.pending_docs()
    assert [m.doc_id for m in pending] == ["d1"]


def test_删文档(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    assert store.delete_doc("d1") is True
    assert store.get_doc("d1") is None
    assert store.list_docs() == []


def test_会话历史按顺序(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.append_chat("s1", ChatMessage(role="user", content="一"))
    store.append_chat("s1", ChatMessage(role="assistant", content="二"))

    history = store.history("s1")
    assert [m.content for m in history] == ["一", "二"]


def test_会话历史超量会被裁掉(fake_redis, settings):
    store = _store(fake_redis, settings)
    for i in range(10):
        store.append_chat("s1", ChatMessage(role="user", content=str(i)))

    history = store.history("s1")
    assert len(history) == settings.max_chat_messages
    assert history[-1].content == "9"


def test_清会话(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.append_chat("s1", ChatMessage(role="user", content="一"))
    assert store.clear_chat("s1") is True
    assert store.history("s1") == []


def test_坏json不会让整个会话读不出来(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.append_chat("s1", ChatMessage(role="user", content="好的一条"))
    fake_redis.rpush(store.chat_key("s1"), "{坏掉的 json")

    history = store.history("s1")
    assert [m.content for m in history] == ["好的一条"]


def test_统计(fake_redis, settings):
    store = _store(fake_redis, settings)
    store.save_doc(DocumentMeta(doc_id="d1", filename="a.pdf"))
    store.update_status("d1", DocStatus.DONE)
    store.append_chat("s1", ChatMessage(role="user", content="一"))

    stats = store.stats()
    assert stats["documents"] == 1
    assert stats["by_status"]["解析完成"] == 1
    assert stats["sessions"] == 1


def test_键名带前缀(fake_redis, settings):
    store = _store(fake_redis, settings)
    assert store.docs_key().startswith(settings.redis_prefix)
    assert store.doc_key("d1").startswith(settings.redis_prefix)
