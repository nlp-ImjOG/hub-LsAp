"""真 Redis + 真 Kafka 的集成测试。

需要先起容器::

    docker compose up -d

连不上就自动跳过 —— 本机没装 Docker 的人跑 pytest 也不会红。
"""

from __future__ import annotations

import os
from dataclasses import replace
from pathlib import Path

import pytest

from mmrag.bus import Bus
from mmrag.models import DocStatus, DocumentMeta, ParseRequest, new_id
from mmrag.store import StateStore
from mmrag.worker import ParseWorker

#: 本次跑测试用的唯一后缀（避免和正在跑的作业互相干扰）。
_RUN_ID = f"{os.getpid()}"


@pytest.fixture
def live_settings(settings):
    """指向本地那套 wk14-redis / wk14-kafka 的配置。"""

    return replace(
        settings,
        redis_url="redis://127.0.0.1:6380/0",
        redis_prefix=f"wk14-int-{_RUN_ID}",
        kafka_bootstrap_servers="127.0.0.1:9095",
        kafka_topic_parse=f"wk14.int.parse.{_RUN_ID}",
        kafka_topic_parsed=f"wk14.int.parsed.{_RUN_ID}",
        kafka_consumer_group=f"wk14-int-group-{_RUN_ID}",
    )


def _require_redis(live_settings) -> StateStore:
    store = StateStore(settings=live_settings)
    if not store.ping():
        pytest.skip("连不上 Redis（先执行 docker compose up -d）")
    return store


def _require_kafka(live_settings) -> Bus:
    bus = Bus(live_settings)
    if not bus.ping():
        pytest.skip("连不上 Kafka（先执行 docker compose up -d）")
    return bus


# ------------------------------------------------------------------ Redis


def test_真实redis能读写文档状态(live_settings):
    store = _require_redis(live_settings)
    doc_id = new_id("doc")

    store.save_doc(DocumentMeta(doc_id=doc_id, filename="论文.pdf"))
    meta = store.get_doc(doc_id)
    assert meta is not None
    assert meta.status is DocStatus.PENDING

    store.update_status(doc_id, DocStatus.PARSING)
    assert store.get_doc(doc_id).status is DocStatus.PARSING

    store.update_status(doc_id, DocStatus.DONE, backend="pymupdf", pages=2, chunks=3)
    done = store.get_doc(doc_id)
    assert done.status is DocStatus.DONE
    assert done.backend == "pymupdf"
    assert done.pages == 2

    assert any(m.doc_id == doc_id for m in store.list_docs())
    store.delete_doc(doc_id)
    assert store.get_doc(doc_id) is None


def test_真实redis能存会话历史(live_settings):
    from mmrag.models import ChatMessage

    store = _require_redis(live_settings)
    session = f"sess-{_RUN_ID}"

    store.append_chat(session, ChatMessage(role="user", content="你好"))
    store.append_chat(session, ChatMessage(role="assistant", content="在的"))

    history = store.history(session)
    assert [m.role for m in history] == ["user", "assistant"]
    assert history[0].content == "你好"

    store.clear_chat(session)
    assert store.history(session) == []


# ------------------------------------------------------------------ Kafka


def test_真实kafka能收发消息(live_settings):
    bus = _require_kafka(live_settings)
    topic = f"wk14.int.echo.{_RUN_ID}"
    bus.ensure_topic(topic, partitions=1)

    key = new_id("k")
    bus.publish(topic, {"hello": "世界"}, key=key)

    messages = bus.poll_once(
        topic, group_id=f"wk14-int-echo-{_RUN_ID}", timeout_ms=15000, commit=False
    )
    assert messages, "没收到消息"
    assert messages[-1]["value"]["hello"] == "世界"
    assert messages[-1]["key"] == key


def test_真实kafka能自动建topic(live_settings):
    bus = _require_kafka(live_settings)
    created = bus.ensure_topics()
    assert isinstance(created, list)


# ------------------------------------------------------------------ 全链路


def test_上传到解析完成全链路(live_settings, sample_pdf: Path):
    """真 Redis + 真 Kafka + 真解析器 + 真嵌入模型，走完一整条链路。"""

    store = _require_redis(live_settings)
    bus = _require_kafka(live_settings)
    bus.ensure_topics()

    doc_id = new_id("doc")
    saved = live_settings.upload_path(doc_id, sample_pdf.name)
    live_settings.ensure_dirs()
    saved.write_bytes(sample_pdf.read_bytes())

    store.save_doc(DocumentMeta(doc_id=doc_id, filename=sample_pdf.name))
    bus.publish_parse_request(
        ParseRequest(
            doc_id=doc_id,
            path=str(saved),
            filename=sample_pdf.name,
            size=saved.stat().st_size,
        )
    )

    worker = ParseWorker(settings=live_settings, store=store, bus=bus)
    worker.run_once(timeout_ms=20000)

    meta = store.get_doc(doc_id)
    assert meta is not None
    assert meta.status is DocStatus.DONE, f"解析没成功：{meta.error}"
    assert meta.pages == 2
    assert meta.chunks >= 1
    assert meta.images >= 1  # 每页都渲染成了图
    assert worker._vectors.stats()["documents"] == 1  # noqa: SLF001

    store.delete_doc(doc_id)


def test_位点提交后不会重复处理(live_settings, sample_pdf: Path):
    """跑第二轮 ``run_once`` 不应该再拿到上一轮的消息。

    之前 ``poll_once`` 开了 ``enable_auto_commit=False`` 却没人提交位点，
    于是每跑一次就把同一批消息重新拉一遍、重新解析一遍。
    """

    store = _require_redis(live_settings)
    bus = _require_kafka(live_settings)
    bus.ensure_topics()

    doc_id = new_id("doc")
    saved = live_settings.upload_path(doc_id, sample_pdf.name)
    live_settings.ensure_dirs()
    saved.write_bytes(sample_pdf.read_bytes())

    store.save_doc(DocumentMeta(doc_id=doc_id, filename=sample_pdf.name))
    bus.publish_parse_request(
        ParseRequest(
            doc_id=doc_id,
            path=str(saved),
            filename=sample_pdf.name,
            size=saved.stat().st_size,
        )
    )

    worker = ParseWorker(settings=live_settings, store=store, bus=bus)
    first = worker.run_once(timeout_ms=20000)
    assert first >= 1

    second = worker.run_once(timeout_ms=3000)
    assert second == 0, f"位点没提交，第二轮又处理了 {second} 条"

    store.delete_doc(doc_id)
