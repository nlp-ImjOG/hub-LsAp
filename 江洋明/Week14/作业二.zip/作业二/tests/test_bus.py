"""Kafka 封装的测试。

**不发真消息** —— 测的是「Windows 上 kafka-python 那个 socket 竞态」
的兜底逻辑。这不是假设出来的坑：实机跑的时候确实会偶发
``ValueError: Invalid file descriptor: -1``，
没兜住的话整条「上传 → 解析」链路会随机挂一次。

真收发在 ``test_integration.py`` 里。
"""

from __future__ import annotations

from typing import Any

import pytest

from mmrag import bus as bus_module
from mmrag.bus import Bus, _retry_on_socket_race, is_socket_race


# ------------------------------------------------------------------ 识别


def test_认得出socket竞态():
    assert is_socket_race(ValueError("Invalid file descriptor: -1")) is True


def test_别的ValueError不算竞态():
    """认得太宽会把真正的 bug 当成网络抖动重试掉。"""

    assert is_socket_race(ValueError("invalid literal for int()")) is False


def test_别的异常类型不算竞态():
    assert is_socket_race(RuntimeError("Invalid file descriptor: -1")) is False


# ------------------------------------------------------------------ 重试


def test_竞态会重试(monkeypatch):
    monkeypatch.setattr(bus_module.time, "sleep", lambda _seconds: None)

    calls: list[int] = []

    def _action() -> str:
        calls.append(1)
        if len(calls) < 3:
            raise ValueError("Invalid file descriptor: -1")
        return "ok"

    assert _retry_on_socket_race(_action) == "ok"
    assert len(calls) == 3


def test_不是竞态就直接抛(monkeypatch):
    monkeypatch.setattr(bus_module.time, "sleep", lambda _seconds: None)

    def _action() -> str:
        raise ValueError("invalid literal for int()")

    with pytest.raises(ValueError, match="invalid literal"):
        _retry_on_socket_race(_action)


def test_一直竞态就放弃(monkeypatch):
    monkeypatch.setattr(bus_module.time, "sleep", lambda _seconds: None)

    calls: list[int] = []

    def _action() -> str:
        calls.append(1)
        raise ValueError("Invalid file descriptor: -1")

    with pytest.raises(ValueError):
        _retry_on_socket_race(_action, attempts=3)
    assert len(calls) == 3


# ------------------------------------------------------------------ 建 topic


class _FakeAdmin:
    """够用的假 admin 客户端。"""

    instances: list["_FakeAdmin"] = []
    #: 类级别的开关 —— 用来让**所有**实例在 close 时抛错。
    close_error: Exception | None = None

    def __init__(self, **kwargs: Any) -> None:
        self.kwargs = kwargs
        self.closed = False
        self.created: list[Any] = []
        _FakeAdmin.instances.append(self)

    def create_topics(self, topics: list[Any]) -> None:
        self.created.extend(topics)

    def close(self) -> None:
        self.closed = True
        if _FakeAdmin.close_error is not None:
            raise _FakeAdmin.close_error


def test_关连接报错不影响建topic的结果(monkeypatch, settings):
    """``admin.close()`` 撞上 socket 竞态时，不能把「建好了」的结果盖掉。

    ``finally`` 里如果直接 ``admin.close()``，
    close 抛的 ValueError 会盖掉 try 里的返回值 ——
    表现就是「明明 topic 建好了，函数却报错」。
    """

    _FakeAdmin.instances.clear()
    _FakeAdmin.close_error = None
    monkeypatch.setattr(bus_module, "KafkaAdminClient", _FakeAdmin)

    bus = Bus(settings)
    assert bus.ensure_topic("wk14.test.topic") is True

    # 让 close 开始抛错
    _FakeAdmin.close_error = ValueError("Invalid file descriptor: -1")
    try:
        assert bus.ensure_topic("wk14.test.topic") is True
        assert _FakeAdmin.instances[-1].closed is True
    finally:
        _FakeAdmin.close_error = None


def test_建topic本身撞上竞态会重试(monkeypatch, settings):
    """建连的时候也可能撞上 —— 得重试，而不是直接失败。"""

    _FakeAdmin.instances.clear()
    monkeypatch.setattr(bus_module.time, "sleep", lambda _seconds: None)

    state = {"calls": 0}

    class _FlakyAdmin(_FakeAdmin):
        def __init__(self, **kwargs: Any) -> None:
            super().__init__(**kwargs)
            state["calls"] += 1
            if state["calls"] < 2:
                raise ValueError("Invalid file descriptor: -1")

    monkeypatch.setattr(bus_module, "KafkaAdminClient", _FlakyAdmin)

    bus = Bus(settings)
    assert bus.ensure_topic("wk14.test.topic") is True
    assert state["calls"] == 2
