"""切块的测试。"""

from __future__ import annotations

from mmrag.chunker import chunk_document, chunk_stats
from mmrag.parsers.base import ParsedDoc, ParsedPage


def _doc(pages: list[tuple[int, str, list[str]]]) -> ParsedDoc:
    return ParsedDoc(
        doc_id="d1",
        filename="a.pdf",
        pages=[ParsedPage(page=p, text=t, images=list(i)) for p, t, i in pages],
    )


def test_空页不进块():
    chunks = chunk_document(_doc([(1, "", [])]), None)
    assert chunks == []


def test_页码被保留():
    chunks = chunk_document(_doc([(1, "第一页内容", []), (2, "第二页内容", [])]), None)
    assert [c.page for c in chunks] == [1, 2]


def test_图片跟着块走():
    chunks = chunk_document(_doc([(1, "内容", ["page_1.png"])]), None)
    assert chunks[0].images == ["page_1.png"]


def test_块id按顺序编号():
    chunks = chunk_document(_doc([(1, "甲" * 200, []), (2, "乙" * 200, [])]), None)
    assert [c.seq for c in chunks] == list(range(len(chunks)))
    assert chunks[0].chunk_id.startswith("d1-")


def test_长段落会被切开(settings):
    from dataclasses import replace

    small = replace(settings, chunk_size=100, chunk_overlap=20)
    chunks = chunk_document(_doc([(1, "一" * 500, [])]), small)
    assert len(chunks) > 1
    assert all(len(c.text) <= 100 for c in chunks)


def test_段落之间不会混在一起(settings):
    from dataclasses import replace

    small = replace(settings, chunk_size=400, chunk_overlap=0)
    text = "第一段内容。" * 5 + "\n\n" + "第二段内容。" * 5
    chunks = chunk_document(_doc([(1, text, [])]), small)
    joined = "\n".join(c.text for c in chunks)
    assert "第一段" in joined and "第二段" in joined


def test_统计():
    chunks = chunk_document(_doc([(1, "甲" * 100, []), (2, "乙" * 50, [])]), None)
    stats = chunk_stats(chunks)
    assert stats["chunks"] == 2
    assert stats["pages"] == 2
    assert stats["max_len"] == 100
