#!/usr/bin/env bash
# Week 14 homework 2 - start the Kafka parse worker only.
# Usage: ./start_worker.sh
# NOTE: keep this file pure ASCII. All Chinese messages live in scripts/launch.py.
set -e
cd "$(dirname "$0")"

if ! command -v python >/dev/null 2>&1; then
  echo "[ERROR] Python was not found in PATH."
  exit 1
fi

exec python -X utf8 scripts/launch.py worker
