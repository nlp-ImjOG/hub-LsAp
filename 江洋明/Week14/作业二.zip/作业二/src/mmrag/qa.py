"""问答编排。

一次问答的完整链路::

    问题 + 用户上传的图
        │
        ├─ 取会话历史（Redis）
        ├─ 向量检索 top_k（本地嵌入模型）
        ├─ 组装多模态消息体（文字 + data URL 图片）
        ├─ 流式调 DeepSeek
        ├─ 逐段吐给前端（SSE）
        └─ 写回会话历史（Redis）

**两种图片来源**：

| 来源 | 用途 | 怎么进提示词 |
| --- | --- | --- |
| 用户自己上传的图 | 「图问」—— 拿一张图提问 | 转 data URL，和问题一起发 |
| 检索命中的文档页 | 「文问」—— 让模型看原文页面 | 转 data URL，和上下文一起发 |

但两者在提示词里**不是平级的**：用户上传的图是**问题要问的对象**，
文档页只是背景资料。所以用户图片排在前面、单独成段、不标页码，
详见 :func:`mmrag.prompts.build_user_content`。
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import Settings, settings as default_settings
from .llm import LLMClient, prepare_data_url
from .models import ChatMessage
from .prompts import SYSTEM_PROMPT, build_context, build_user_content
from .retriever import Retriever, Retrieved
from .store import StateStore

log = logging.getLogger(__name__)


@dataclass
class QAEvent:
    """问答过程里往外抛的一个事件（SSE 的 data）。"""

    type: str
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "data": self.data}


class QAService:
    """多模态问答服务。"""

    def __init__(
        self,
        settings: Settings | None = None,
        store: StateStore | None = None,
        retriever: Retriever | None = None,
        llm: LLMClient | None = None,
    ) -> None:
        self._settings = settings or default_settings
        self._store = store or StateStore(settings=self._settings)
        self._retriever = retriever or Retriever(settings=self._settings)
        self._llm = llm or LLMClient(self._settings)

    # ------------------------------------------------------------------ 属性

    @property
    def llm(self) -> LLMClient:
        return self._llm

    @property
    def store(self) -> StateStore:
        return self._store

    @property
    def retriever(self) -> Retriever:
        return self._retriever

    # ------------------------------------------------------------------ 入口

    def answer(
        self,
        question: str,
        session_id: str,
        user_images: list[str] | None = None,
    ) -> Iterator[QAEvent]:
        """回答一个问题，逐段吐事件。"""

        question = (question or "").strip()
        user_images = list(user_images or [])
        if not question and not user_images:
            yield QAEvent("error", {"message": "问题不能为空"})
            return

        try:
            sources, doc_images = self._retrieve(question)
        except Exception as exc:
            log.exception("检索失败")
            yield QAEvent("error", {"message": f"检索失败：{exc}"})
            return

        yield QAEvent(
            "sources",
            {
                "items": [item.to_dict() for item in sources],
                "images": [
                    {"filename": name, "page": page, "doc_id": doc_id}
                    for name, page, doc_id in doc_images
                ],
            },
        )

        messages = self._build_messages(
            question, session_id, sources, doc_images, user_images
        )

        answer_text = ""
        try:
            for piece in self._llm.stream(messages):
                answer_text += piece
                yield QAEvent("delta", {"text": piece})
        except Exception as exc:
            log.exception("大模型调用失败")
            yield QAEvent("error", {"message": str(exc)})
            return

        self._remember(session_id, question, answer_text, user_images, sources)
        yield QAEvent(
            "done",
            {
                "message": ChatMessage(
                    role="assistant",
                    content=answer_text,
                    images=[name for name, _p, _d in doc_images],
                    sources=[item.chunk.doc_id for item in sources],
                ).to_dict()
            },
        )

    # ------------------------------------------------------------------ 内部

    def _retrieve(
        self, question: str
    ) -> tuple[list[Retrieved], list[tuple[str, int, str]]]:
        if not question:
            return [], []
        # 只在「还活着的文档」里检索。
        # 文档元信息有 TTL（默认 7 天），过期后 Redis 里的记录没了，
        # 但向量索引还在 —— 不限定的话，答案会引用用户根本看不到的文档，
        # 引用的图片地址也 404。
        live = self._store.doc_ids()
        return self._retriever.retrieve_with_images(question, doc_ids=live)

    def _build_messages(
        self,
        question: str,
        session_id: str,
        sources: list[Retrieved],
        doc_images: list[tuple[str, int, str]],
        user_images: list[str],
    ) -> list[dict[str, Any]]:
        history = self._history_messages(session_id)
        context = build_context(sources)

        # **两类图片要分开** ——
        # 文档页的图片有对外地址、模型可以在答案里引用；
        # 用户自己上传的图没有地址，只有「看」这一回事。
        # 早先两者混在一起，还给用户图片安了个「第 0 页」，
        # 模型据此判定它是无关的干扰材料，直接拒答（见 prompts.py 的说明）。
        doc_data_urls: list[str] = []
        usable: list[tuple[str, int, str]] = []
        for name, page, doc_id in doc_images:
            path = self._settings.image_dir / doc_id / name
            if not path.is_file():
                continue
            usable.append((name, page, doc_id))
            doc_data_urls.append(prepare_data_url(path))

        user_data_urls: list[str] = []
        usable_user: list[str] = []
        for name in user_images:
            path = self._settings.image_dir / session_id / name
            if path.is_file():
                usable_user.append(name)
                user_data_urls.append(prepare_data_url(path))

        content = build_user_content(
            question,
            context,
            usable,
            doc_data_urls,
            usable_user,
            user_data_urls,
        )
        return [{"role": "system", "content": SYSTEM_PROMPT}, *history, {"role": "user", "content": content}]

    def _history_messages(self, session_id: str) -> list[dict[str, Any]]:
        """取最近几轮历史。"""

        turns = self._settings.max_history_turns
        if turns <= 0:
            return []
        raw = self._store.history(session_id)
        # 只留最后 turns 轮（一条 user + 一条 assistant 算一轮）
        keep = raw[-(turns * 2) :]
        out: list[dict[str, Any]] = []
        for message in keep:
            if message.role not in {"user", "assistant"}:
                continue
            if not message.content.strip():
                continue
            out.append({"role": message.role, "content": message.content})
        return out

    def _remember(
        self,
        session_id: str,
        question: str,
        answer_text: str,
        user_images: list[str],
        sources: list[Retrieved],
    ) -> None:
        """把这一轮写回 Redis。"""

        doc_ids = sorted({item.chunk.doc_id for item in sources})
        self._store.append_chat(
            session_id,
            ChatMessage(role="user", content=question, images=list(user_images), sources=doc_ids),
        )
        self._store.append_chat(
            session_id,
            ChatMessage(role="assistant", content=answer_text, sources=doc_ids),
        )

    # ------------------------------------------------------------------ 自检

    def describe(self) -> list[str]:
        stats = self._retriever.store.stats()
        return [
            self._llm.describe(),
            f"向量索引（{stats['documents']} 个文档 / {stats['chunks']} 块）",
        ]


def resolve_upload_dir(settings: Settings) -> Path:
    """用户上传图片的存放目录（按会话分）。"""

    return settings.image_dir


def read_user_image(settings: Settings, session_id: str, name: str) -> Path:
    """用户上传图片的完整路径。"""

    return settings.image_dir / session_id / name
