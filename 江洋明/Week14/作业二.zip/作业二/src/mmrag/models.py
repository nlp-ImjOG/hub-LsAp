"""数据契约。

三个核心对象：

- :class:`DocStatus` —— 文档的解析状态（前端要显示的三态就在这里）。
- :class:`DocumentMeta` —— 一个已上传文档的元信息。
- :class:`Chunk` —— 解析后切出来的一段文本（带页码、关联图片）。
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


def now_ms() -> int:
    """当前毫秒时间戳。"""

    return int(time.time() * 1000)


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


class DocStatus(str, Enum):
    """文档解析状态。

    作业要求前端显示「待解析 / 解析中 / 解析完成」三态，
    这里多加一个 :attr:`FAILED` —— 解析失败必须让用户看见，
    不能让文档永远卡在「解析中」。
    """

    PENDING = "待解析"
    PARSING = "解析中"
    DONE = "解析完成"
    FAILED = "解析失败"

    @property
    def code(self) -> str:
        """给前端做样式映射用的英文代号。"""

        return {
            DocStatus.PENDING: "pending",
            DocStatus.PARSING: "parsing",
            DocStatus.DONE: "done",
            DocStatus.FAILED: "failed",
        }[self]


@dataclass
class DocumentMeta:
    """一个已上传文档的元信息 —— Redis HASH 里存的就是它。"""

    doc_id: str
    filename: str
    size: int = 0
    status: DocStatus = DocStatus.PENDING
    backend: str = ""
    pages: int = 0
    chunks: int = 0
    images: int = 0
    error: str = ""
    created_at: int = field(default_factory=now_ms)
    updated_at: int = field(default_factory=now_ms)

    def to_dict(self) -> dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "filename": self.filename,
            "size": self.size,
            "status": self.status.value,
            "backend": self.backend,
            "pages": self.pages,
            "chunks": self.chunks,
            "images": self.images,
            "error": self.error,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "DocumentMeta":
        status_value = str(raw.get("status") or DocStatus.PENDING.value)
        try:
            status = DocStatus(status_value)
        except ValueError:
            status = DocStatus.PENDING
        return cls(
            doc_id=str(raw.get("doc_id", "")),
            filename=str(raw.get("filename", "")),
            size=int(raw.get("size", 0)),
            status=status,
            backend=str(raw.get("backend", "")),
            pages=int(raw.get("pages", 0)),
            chunks=int(raw.get("chunks", 0)),
            images=int(raw.get("images", 0)),
            error=str(raw.get("error", "")),
            created_at=int(raw.get("created_at", 0)),
            updated_at=int(raw.get("updated_at", 0)),
        )


@dataclass
class Chunk:
    """解析后切出来的一段文本。"""

    chunk_id: str
    doc_id: str
    page: int
    text: str
    #: 这一段关联的图片文件名（存在 data/images/<doc_id>/ 下）。
    images: list[str] = field(default_factory=list)
    seq: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "chunk_id": self.chunk_id,
            "doc_id": self.doc_id,
            "page": self.page,
            "text": self.text,
            "images": list(self.images),
            "seq": self.seq,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Chunk":
        return cls(
            chunk_id=str(raw.get("chunk_id", "")),
            doc_id=str(raw.get("doc_id", "")),
            page=int(raw.get("page", 0)),
            text=str(raw.get("text", "")),
            images=[str(x) for x in raw.get("images", [])],
            seq=int(raw.get("seq", 0)),
        )


@dataclass
class ImageAsset:
    """解析出来的图片资源。"""

    doc_id: str
    filename: str
    page: int
    #: 原始文件名（MinerU 抽出来的图片会带原始语义）。
    origin: str = ""
    caption: str = ""

    @property
    def url(self) -> str:
        """前端能直接访问的 URL。"""

        return f"/api/documents/{self.doc_id}/images/{self.filename}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "filename": self.filename,
            "page": self.page,
            "origin": self.origin,
            "caption": self.caption,
            "url": self.url,
        }


@dataclass
class ChatMessage:
    """一轮对话里的一条消息。"""

    role: str
    content: str
    ts: int = field(default_factory=now_ms)
    #: 用户这一轮上传的图片（文件名列表）。
    images: list[str] = field(default_factory=list)
    #: 引用到的文档 id。
    sources: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "content": self.content,
            "ts": self.ts,
            "images": list(self.images),
            "sources": list(self.sources),
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "ChatMessage":
        return cls(
            role=str(raw.get("role", "user")),
            content=str(raw.get("content", "")),
            ts=int(raw.get("ts", 0)),
            images=[str(x) for x in raw.get("images", [])],
            sources=[str(x) for x in raw.get("sources", [])],
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_json(cls, text: str) -> "ChatMessage":
        return cls.from_dict(json.loads(text))


@dataclass
class ParseRequest:
    """发到 Kafka 上的「解析任务」消息体。"""

    doc_id: str
    path: str
    filename: str
    size: int = 0
    requested_at: int = field(default_factory=now_ms)

    def to_dict(self) -> dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "path": self.path,
            "filename": self.filename,
            "size": self.size,
            "requested_at": self.requested_at,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "ParseRequest":
        return cls(
            doc_id=str(raw.get("doc_id", "")),
            path=str(raw.get("path", "")),
            filename=str(raw.get("filename", "")),
            size=int(raw.get("size", 0)),
            requested_at=int(raw.get("requested_at", 0)),
        )
