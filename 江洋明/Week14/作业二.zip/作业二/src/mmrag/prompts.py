"""提示词。

两条主线：

1. **RAG 的提示词** —— 把检索到的上下文喂进去，要求「有据可依 + 标页码」。
2. **多模态的提示词** —— 要求模型在答案里用 Markdown 图片语法引用文档里的图。

**关于「图文混排」的一个关键事实**：DeepSeek 不会生成图片。
所以本作业的图文混排是 —— **模型选图 + 前端渲染**：

- 模型在答案里写 ``![第 3 页的架构图](/api/documents/xxx/images/page_3.png)``；
- 前端把这段 Markdown 渲染成真正的图片。

图片地址由后端在构造上下文时给全，模型照抄即可。

**两类图片必须分开说**：文档页的图（可引用、有页码）和
用户随问题上传的图（**就是问题要问的对象**、没有对外地址、不标页码）。

混为一谈会出大麻烦：早先把用户传的图也列进【可引用的图片】、
还标成「第 0 页」，模型就认为它是「来源不明、与文档无关的干扰内容」，
理直气壮地拒答「根据提供的文档无法确定房间号」——
图就在那儿，它就是没看。详见 :func:`build_user_content`。
"""

from __future__ import annotations

from typing import Any

from .retriever import Retrieved

#: 系统提示词。
SYSTEM_PROMPT = """你是一个严谨的文档问答助手，基于用户提供的文档内容回答问题。

要求：
1. 先看用户随问题上传的图片。**这类图片就是问题要问的对象**——
   要直接看图作答：图里有的就答出来，图里没有的不要编，
   这类图片**不要**标页码（它本来就不是文档的某一页）。
2. 除了用户上传的图片，只使用【参考资料】里的内容作答。
   资料里没有的信息，直接说「根据提供的文档无法确定」，不要编造。
3. 回答里引用了文档某处内容时，标注页码，格式形如「（见第 3 页）」。
4. 如果参考料里带有与问题相关的图，在回答的合适位置用 Markdown 图片语法引用它，格式形如：
   ![说明文字](图片地址)
   图片地址必须原样使用【可引用的图片】里给出的，不要改写、不要编造。
5. 用中文回答，条理清楚；可以用 Markdown 的标题、列表、表格。
6. 回答结尾不要重复问题，不要写「希望对你有帮助」这类客套话。
"""


def build_context(sources: list[Retrieved]) -> str:
    """把检索结果拼成上下文。

    每一段都带上「文档名 + 页码」，模型才知道该标第几页。
    """

    if not sources:
        return "（没有检索到任何相关内容）"
    blocks: list[str] = []
    for index, item in enumerate(sources, start=1):
        blocks.append(
            f"[片段 {index}] 来源：{item.chunk.doc_id} 第 {item.page} 页"
            f"（相关度 {item.score:.3f}）\n{item.text}"
        )
    return "\n\n".join(blocks)


def build_image_manifest(
    images: list[tuple[str, int, str]], base_url: str = ""
) -> str:
    """列出**可引用的**图片（文档页），让模型知道地址怎么写。"""

    if not images:
        return "（本次没有可用图片）"
    lines: list[str] = []
    for name, page, doc_id in images:
        url = f"{base_url}/api/documents/{doc_id}/images/{name}"
        lines.append(f"- 第 {page} 页：{url}")
    return "\n".join(lines)


def build_user_image_manifest(user_images: list[str]) -> str:
    """列出用户随问题上传的图片。

    和文档图片分开列 —— 这两张图在模型眼里是**两种东西**：

    - 文档图片：有对外地址，模型可以在答案里用 Markdown 引用它；
    - 用户图片：**没有对外地址**（它存在会话目录里，不属于任何文档），
      只能「看」，不能「引用」。

    早先这里是把两者混在一起列的，还给用户图片安了个「第 0 页」，
    模型一看「第 0 页」+「来源标注」，就认定这是份无关的干扰材料，
    于是拒绝读图。现在用户图片单独成段、并且明说是「问题的对象」。
    """

    if not user_images:
        return ""
    lines = [
        f"- {name}（用户随问题上传的图片 —— 这就是问题要问的对象，请直接看图回答）"
        for name in user_images
    ]
    return "\n".join(lines)


def build_user_content(
    question: str,
    context: str,
    doc_images: list[tuple[str, int, str]],
    doc_data_urls: list[str],
    user_images: list[str] | None = None,
    user_data_urls: list[str] | None = None,
    *,
    base_url: str = "",
) -> list[dict[str, Any]]:
    """构造多模态消息体。

    ``content`` 是一个数组：文字块 + 图片块。图片块用 ``image_url``，
    值是 ``data:image/png;base64,...``（OpenAI 兼容格式）。

    参数分两组，**不要合并**：

    - ``doc_images`` / ``doc_data_urls`` —— 检索命中的文档页图片，一一对应；
    - ``user_images`` / ``user_data_urls`` —— 用户随问题上传的图片，一一对应。

    消息体里**用户图片排在文档图片前面**：问题问的是它。

    ``data_url`` 由调用方（:mod:`mmrag.qa`）负责编码。
    """

    user_images = list(user_images or [])
    user_data_urls = list(user_data_urls or [])

    manifest = build_image_manifest(doc_images, base_url=base_url)
    parts = [
        f"【参考资料】\n{context}",
        f"【可引用的图片】\n{manifest}",
    ]
    user_manifest = build_user_image_manifest(user_images)
    if user_manifest:
        parts.append(f"【用户随问题上传的图片】\n{user_manifest}")
    parts.append(f"【问题】\n{question}")
    text = "\n\n".join(parts)

    content: list[dict[str, Any]] = [{"type": "text", "text": text}]

    # 用户上传的图片 —— 放前面，并且逐张点名。
    for index, name in enumerate(user_images):
        if index >= len(user_data_urls):
            break
        content.append(
            {"type": "text", "text": f"（用户上传的图片 {index + 1}：{name}）"}
        )
        content.append(
            {"type": "image_url", "image_url": {"url": user_data_urls[index]}}
        )

    # 文档页的图片 —— 放后面，配合【可引用的图片】里的地址。
    for index, (name, page, _doc_id) in enumerate(doc_images):
        if index >= len(doc_data_urls):
            break
        content.append(
            {"type": "text", "text": f"（文档第 {page} 页的图片：{name}）"}
        )
        content.append(
            {"type": "image_url", "image_url": {"url": doc_data_urls[index]}}
        )
    return content
