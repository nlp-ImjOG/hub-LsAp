"""切块。

切块的目标不是「切得均匀」，而是**切得能回答问题**：

- 先按段落切 —— 段落是语义边界，跨段拼一句会让检索命中得很别扭；
- 再按句号切 —— 单段太长时（有的表格整页就是一长段）不至于把两件事混在一块；
- 最后按长度硬切 —— 保证不出现超长块。

相邻块之间留一点重叠（``chunk_overlap``），避免答案正好卡在两块的接缝上。

每块都带着自己的**页码**和**图片**：页码用来在答案里标出处（「见第 3 页」），
图片用来做图文混排 —— 命中哪一块，就把那一页的图一起送进多模态大模型。
"""

from __future__ import annotations

import re
from typing import Any

from .config import Settings, settings as default_settings
from .models import Chunk
from .parsers.base import ParsedDoc

#: 句子边界（中英文标点都算）。
_SENTENCE_SPLIT = re.compile(r"(?<=[。！？!?；;])")

#: 段落边界。
_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")


def chunk_document(
    parsed: ParsedDoc, settings: Settings | None = None
) -> list[Chunk]:
    """把解析结果切成块。"""

    settings = settings or default_settings
    size = max(80, settings.chunk_size)
    overlap = max(0, min(settings.chunk_overlap, size // 2))

    chunks: list[Chunk] = []
    seq = 0
    for page in parsed.pages:
        text = page.text.strip()
        if not text:
            continue
        for piece in _split_page(text, size, overlap):
            piece = piece.strip()
            if not piece:
                continue
            chunks.append(
                Chunk(
                    chunk_id=f"{parsed.doc_id}-{seq:04d}",
                    doc_id=parsed.doc_id,
                    page=page.page,
                    text=piece,
                    images=list(page.images),
                    seq=seq,
                )
            )
            seq += 1
    return chunks


def _split_page(text: str, size: int, overlap: int) -> list[str]:
    """把一页文本切成若干块。"""

    pieces: list[str] = []
    for paragraph in _PARAGRAPH_SPLIT.split(text):
        paragraph = paragraph.strip()
        if not paragraph:
            continue
        if len(paragraph) <= size:
            pieces.append(paragraph)
            continue
        # 段落太长 → 按句子切
        buffer = ""
        for sentence in _SENTENCE_SPLIT.split(paragraph):
            sentence = sentence.strip()
            if not sentence:
                continue
            if len(sentence) > size:
                # 单句就超长 → 硬切
                if buffer:
                    pieces.append(buffer)
                    buffer = ""
                pieces.extend(_hard_split(sentence, size, overlap))
                continue
            if len(buffer) + len(sentence) <= size:
                buffer += sentence
                continue
            if buffer:
                pieces.append(buffer)
            buffer = sentence
        if buffer:
            pieces.append(buffer)
    return pieces


def _hard_split(text: str, size: int, overlap: int) -> list[str]:
    """按固定长度硬切，相邻块之间留 ``overlap`` 个字符的重叠。"""

    out: list[str] = []
    step = max(1, size - overlap)
    for start in range(0, len(text), step):
        piece = text[start : start + size]
        if piece.strip():
            out.append(piece)
        if start + size >= len(text):
            break
    return out


def chunk_stats(chunks: list[Chunk]) -> dict[str, Any]:
    """给 CLI 看的统计。"""

    lengths = [len(chunk.text) for chunk in chunks] or [0]
    return {
        "chunks": len(chunks),
        "pages": len({chunk.page for chunk in chunks}),
        "avg_len": round(sum(lengths) / len(lengths), 1),
        "max_len": max(lengths),
        "min_len": min(lengths),
    }
