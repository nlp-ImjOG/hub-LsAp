"""检索层：把「问题」变成「送进大模型的上下文」。

流程::

    问题 → 本地嵌入 → 向量检索 top_k → 拼上下文（带页码、带上图片）

**上下文里必须带页码**：大模型回答里要能标「见第 3 页」，
用户才点得回去原文核对。页码来自切块时保留的 ``Chunk.page``。

**上下文里必须带图片**：这是「多模态」的关键 ——
检索命中的块所在的那几页，渲染图会一起送给多模态大模型看。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from .config import Settings, settings as default_settings
from .embedder import Embedder
from .models import Chunk
from .vector_store import VectorStore

log = logging.getLogger(__name__)


@dataclass
class Retrieved:
    """一条检索结果。"""

    chunk: Chunk
    score: float

    @property
    def page(self) -> int:
        return self.chunk.page

    @property
    def text(self) -> str:
        return self.chunk.text

    @property
    def images(self) -> list[str]:
        return list(self.chunk.images)

    def to_dict(self) -> dict[str, Any]:
        return {
            "chunk_id": self.chunk.chunk_id,
            "doc_id": self.chunk.doc_id,
            "page": self.chunk.page,
            "score": round(self.score, 4),
            "text": self.chunk.text,
            "images": self.images,
        }


class Retriever:
    """向量检索。"""

    def __init__(
        self,
        embedder: Embedder | None = None,
        store: VectorStore | None = None,
        settings: Settings | None = None,
    ) -> None:
        self._settings = settings or default_settings
        self._embedder = embedder or Embedder(self._settings)
        self._store = store or VectorStore(self._settings)

    @property
    def store(self) -> VectorStore:
        return self._store

    def retrieve(
        self, question: str, top_k: int = 0, doc_ids: list[str] | None = None
    ) -> list[Retrieved]:
        """检索与问题最相关的若干块。

        ``doc_ids`` 限定检索范围 —— 只在这些文档里找。
        用来挡住「Redis 里已经没有、但向量索引还在」的僵尸文档。
        """

        question = (question or "").strip()
        if not question:
            return []
        k = top_k or self._settings.top_k
        vector = self._embedder.encode_one(question)
        pairs = self._store.search(vector, top_k=k, doc_ids=doc_ids)
        return [Retrieved(chunk=chunk, score=score) for chunk, score in pairs]

    def retrieve_with_images(
        self,
        question: str,
        top_k: int = 0,
        max_images: int = 0,
        doc_ids: list[str] | None = None,
    ) -> tuple[list[Retrieved], list[tuple[str, int, str]]]:
        """检索，并把命中块对应的图片整理出来。

        返回 ``(检索结果, [(文件名, 页码, doc_id), ...])``。

        选图的顺序是**先保证页面覆盖，再补细节**：

        1. 先给每个出现过的页面各挑一张图 —— 提示词里能看到的页数最多，
           模型才有机会把「第 1 页的流程图」和「第 2 页的文字」对上；
        2. 位置还有富余的话，再补同一页里的其它图（内嵌插图往往比整页渲染清晰）。

        反过来做（一路按顺序塞满）的话，某一页的三张图会把其它页挤掉 ——
        实测模型因此看不到第 1 页的流程图，回答里直接说「没有流程图」。
        """

        results = self.retrieve(question, top_k=top_k, doc_ids=doc_ids)
        limit = max_images or self._settings.max_images_in_prompt
        if limit <= 0:
            return results, []

        picked: list[tuple[str, int, str]] = []
        seen_image: set[tuple[str, str]] = set()
        seen_page: set[tuple[str, int]] = set()

        # 第一轮：每页先来一张
        for item in results:
            page_key = (item.chunk.doc_id, item.page)
            if page_key in seen_page:
                continue
            for name in item.images:
                image_key = (item.chunk.doc_id, name)
                if image_key in seen_image:
                    continue
                seen_image.add(image_key)
                picked.append((name, item.page, item.chunk.doc_id))
                seen_page.add(page_key)
                break
            if len(picked) >= limit:
                return results, picked

        # 第二轮：位置还有富余，补同一页里的其它图
        for item in results:
            for name in item.images:
                image_key = (item.chunk.doc_id, name)
                if image_key in seen_image:
                    continue
                seen_image.add(image_key)
                picked.append((name, item.page, item.chunk.doc_id))
                if len(picked) >= limit:
                    return results, picked
        return results, picked
