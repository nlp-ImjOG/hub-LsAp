"""命令行。

不启动 Web 服务也能把整条链路跑一遍，方便演示和排错::

    python -m mmrag status                 # 自检
    python -m mmrag upload 论文.pdf        # 模拟前端上传（投 Kafka）
    python -m mmrag worker --once          # 跑一轮 Worker
    python -m mmrag docs                   # 看文档状态
    python -m mmrag ask "这篇论文讲了什么"   # 问答
    python -m mmrag ask "这图里写了什么" --image 探针图片.png   # 图问
"""

from __future__ import annotations

import argparse
import io
import json
import logging
import sys
from pathlib import Path

from .config import Settings
from .models import DocStatus, DocumentMeta, ParseRequest, new_id
from .parsers import describe_parsers
from .store import StateStore
from .bus import Bus

log = logging.getLogger(__name__)


def _force_utf8() -> None:
    """Windows 控制台默认 GBK，中文会乱码。"""

    if hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace"
        )
    if hasattr(sys.stderr, "buffer"):
        sys.stderr = io.TextIOWrapper(
            sys.stderr.buffer, encoding="utf-8", errors="replace"
        )


def _setup_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
        stream=sys.stderr,
    )


# ---------------------------------------------------------------------- 子命令


def cmd_status(args: argparse.Namespace, settings: Settings) -> int:
    store = StateStore(settings=settings)
    bus = Bus(settings)
    from .embedder import Embedder
    from .llm import LLMClient
    from .vector_store import VectorStore

    vectors = VectorStore(settings)
    stats = vectors.stats()
    redis_ok = store.ping()
    kafka_ok = bus.ping()

    print("=== 环境自检 ===")
    print(f"Redis        : {'正常' if redis_ok else '连不上'}  ({settings.redis_url})")
    print(f"Kafka        : {'正常' if kafka_ok else '连不上'}  ({settings.kafka_bootstrap_servers})")
    for line in describe_parsers(settings):
        print(f"解析后端     : {line}")
    print(f"嵌入模型     : {Embedder(settings).describe()}")
    print(f"大模型       : {LLMClient(settings).describe()}")
    print()
    print("=== 存储统计 ===")
    print(f"文档         : {stats['documents']}")
    print(f"文本块       : {stats['chunks']}")
    by_status: dict[str, int] = {}
    for meta in store.list_docs():
        by_status[meta.status.value] = by_status.get(meta.status.value, 0) + 1
    for status in DocStatus:
        print(f"  {status.value:<6} : {by_status.get(status.value, 0)}")
    print()
    print("=== Kafka topic ===")
    for topic in (settings.kafka_topic_parse, settings.kafka_topic_parsed):
        try:
            print(f"{topic}: {json.dumps(bus.describe(topic), ensure_ascii=False)}")
        except Exception as exc:  # pragma: no cover - 自检不该挂
            print(f"{topic}: 读取失败 {exc}")
    return 0 if (redis_ok and kafka_ok) else 1


def cmd_upload(args: argparse.Namespace, settings: Settings) -> int:
    paths = [Path(p) for p in args.files]
    missing = [str(p) for p in paths if not p.is_file()]
    if missing:
        print(f"文件不存在：{', '.join(missing)}", file=sys.stderr)
        return 2

    store = StateStore(settings=settings)
    bus = Bus(settings)
    bus.ensure_topics()
    settings.ensure_dirs()
    for path in paths:
        doc_id = new_id("doc")
        saved = settings.upload_path(doc_id, path.name)
        saved.write_bytes(path.read_bytes())
        meta = DocumentMeta(
            doc_id=doc_id,
            filename=path.name,
            size=saved.stat().st_size,
            status=DocStatus.PENDING,
        )
        store.save_doc(meta)
        bus.publish_parse_request(
            ParseRequest(
                doc_id=doc_id,
                path=str(saved),
                filename=path.name,
                size=meta.size,
            )
        )
        print(f"已上传 {path.name}  doc_id={doc_id}  状态=待解析")
    return 0


def cmd_worker(args: argparse.Namespace, settings: Settings) -> int:
    from .worker import ParseWorker

    worker = ParseWorker(settings=settings)
    if args.once:
        count = worker.run_once(timeout_ms=args.timeout)
        print(f"这一轮处理了 {count} 条消息")
        return 0
    worker.run_forever()
    return 0


def cmd_docs(args: argparse.Namespace, settings: Settings) -> int:
    store = StateStore(settings=settings)
    docs = store.list_docs()
    if not docs:
        print("还没有文档")
        return 0
    print(f"{'文档':<28} {'状态':<8} {'页':>4} {'块':>5} {'图':>4}  后端")
    for meta in docs:
        print(
            f"{meta.filename[:26]:<28} {meta.status.value:<8} "
            f"{meta.pages:>4} {meta.chunks:>5} {meta.images:>4}  {meta.backend}"
        )
        if meta.error:
            print(f"    错误：{meta.error}")
    return 0


def _stage_images(
    paths: list[str], settings: Settings, session: str
) -> list[str]:
    """把命令行给的图片存进会话目录，返回存进去的文件名。

    问答层只认「``data/images/<session_id>/`` 里的文件名」——
    那是它唯一的图片入口（前端走的是同一个目录）。
    命令行给的是**路径**，得先搬过去。
    """

    import shutil

    session_dir = settings.image_dir / session
    names: list[str] = []
    for raw in paths:
        source = Path(raw)
        if not source.is_file():
            print(f"[跳过] 图片不存在：{source}", file=sys.stderr)
            continue
        session_dir.mkdir(parents=True, exist_ok=True)
        target = session_dir / source.name
        # 源文件本来就在会话目录里的话就别拷了（自己拷自己会报错）。
        if target.exists() and target.resolve() == source.resolve():
            names.append(target.name)
            continue
        shutil.copyfile(source, target)
        names.append(target.name)
    return names


def cmd_ask(args: argparse.Namespace, settings: Settings) -> int:
    from .qa import QAService

    # ``--image`` 收的是**文件路径**，先把图存进会话目录，再把文件名交给问答层。
    # （问答层只认「会话目录里的文件名」—— 搬文件是它不负责的事。）
    image_names = _stage_images(args.image or [], settings, args.session)

    qa = QAService(settings=settings)
    answer = ""
    for event in qa.answer(args.question, args.session, image_names):
        if event.type == "sources":
            items = event.data.get("items", [])
            print(f"[检索到 {len(items)} 个片段]")
            for item in items:
                print(
                    f"  · {item['doc_id']} 第 {item['page']} 页 "
                    f"（{item['score']:.3f}）"
                )
        elif event.type == "delta":
            answer += event.data.get("text", "")
            sys.stdout.write(event.data.get("text", ""))
            sys.stdout.flush()
        elif event.type == "error":
            print(f"\n[出错] {event.data.get('message')}", file=sys.stderr)
            return 1
    print()
    return 0


def cmd_serve(args: argparse.Namespace, settings: Settings) -> int:
    import uvicorn

    uvicorn.run(
        "mmrag.api.app:app",
        host=args.host or settings.api_host,
        port=args.port or settings.api_port,
        reload=args.reload,
    )
    return 0


# ---------------------------------------------------------------------- 入口


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mmrag", description="多模态 RAG 问答（Kafka + MinerU）"
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="日志级别：DEBUG / INFO / WARNING",
    )
    sub = parser.add_subparsers(dest="command")

    p_status = sub.add_parser("status", help="环境自检 + 存储统计")
    p_status.set_defaults(func=cmd_status)

    p_upload = sub.add_parser("upload", help="上传 PDF 到 Kafka（模拟前端上传）")
    p_upload.add_argument("files", nargs="+", help="PDF 路径")
    p_upload.set_defaults(func=cmd_upload)

    p_worker = sub.add_parser("worker", help="跑解析 Worker")
    p_worker.add_argument("--once", action="store_true", help="只跑一轮就退出")
    p_worker.add_argument("--timeout", type=int, default=5000, help="拉消息的超时（毫秒）")
    p_worker.set_defaults(func=cmd_worker)

    p_docs = sub.add_parser("docs", help="列出文档和状态")
    p_docs.set_defaults(func=cmd_docs)

    p_ask = sub.add_parser("ask", help="命令行问答")
    p_ask.add_argument("question", help="问题")
    p_ask.add_argument("--session", default="cli", help="会话 id")
    p_ask.add_argument("--image", action="append", help="附带图片路径（可多次）")
    p_ask.set_defaults(func=cmd_ask)

    p_serve = sub.add_parser("serve", help="启动 Web 服务")
    p_serve.add_argument("--host", default="")
    p_serve.add_argument("--port", type=int, default=0)
    p_serve.add_argument("--reload", action="store_true")
    p_serve.set_defaults(func=cmd_serve)

    return parser


def main(argv: list[str] | None = None) -> int:
    _force_utf8()
    parser = build_parser()
    args = parser.parse_args(argv)
    _setup_logging(getattr(args, "log_level", "INFO"))

    if not getattr(args, "command", None):
        parser.print_help()
        return 0

    settings = Settings.from_env()
    settings.ensure_dirs()
    try:
        return int(args.func(args, settings) or 0)
    except KeyboardInterrupt:  # pragma: no cover
        print("\n已中断", file=sys.stderr)
        return 130


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
