"""解析器的公共契约。

作业要求「后端通过 MinerU 解析 PDF」，但解析后端做成**可插拔**的：

- :class:`MinerUParser` —— 真正的 MinerU（调 ``.venv-mineru`` 里的 ``mineru-kit parse``）。
- :class:`PyMuPDFParser` —— 兜底后端，纯 Python 依赖，PDF 文本 / 内嵌图 / 整页渲染都能做。

两者产出同一个 :class:`ParsedDoc`，后面的切块、向量化、问答链路完全不变。
这样「装了 MinerU 就用 MinerU，没装也能跑通全流程」。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..models import ImageAsset


@dataclass
class ParsedPage:
    """解析出来的一页。"""

    #: 页码，从 1 开始（和 PDF 里看到的一致，前端也好显示）。
    page: int
    text: str = ""
    #: 这一页关联的图片文件名（存在 ``data/images/<doc_id>/`` 下）。
    images: list[str] = field(default_factory=list)


@dataclass
class ParsedDoc:
    """一个 PDF 解析完的结果。"""

    doc_id: str
    filename: str
    pages: list[ParsedPage] = field(default_factory=list)
    images: list[ImageAsset] = field(default_factory=list)
    #: 整篇的 Markdown（MinerU 有，PyMuPDF 兜底时按页拼）。
    markdown: str = ""
    #: 用了哪个后端。
    backend: str = ""
    #: 后端自己塞的额外信息（页数、耗时、警告……）。
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def page_count(self) -> int:
        return len(self.pages)

    @property
    def text(self) -> str:
        """整篇纯文本。"""

        return "\n\n".join(page.text for page in self.pages if page.text.strip())

    def image_names(self) -> list[str]:
        return [image.filename for image in self.images]

    def pages_with_images(self) -> list[ParsedPage]:
        return [page for page in self.pages if page.images]


class BaseParser(ABC):
    """解析器基类。"""

    #: 后端名，写进 Redis 的 ``backend`` 字段。
    name: str = "base"

    def available(self) -> bool:
        """这个后端当前能不能用（依赖装没装、模型在不在）。"""

        return True

    @abstractmethod
    def parse(self, path: Path, doc_id: str, filename: str) -> ParsedDoc:
        """解析一个 PDF。"""

    def describe(self) -> str:
        """一句话说明这个后端当前的状态，给 CLI / 自检用。"""

        return f"{self.name}（{'可用' if self.available() else '不可用'}）"
