"""MinerU 解析器 —— 作业要求的那一个。

**为什么是「壳子」而不是直接 import？**

MinerU 4.x 的依赖树很重（``docvortex`` / ``gradio`` / ``onnxruntime`` / ``tokenizers>=0.22``），
其中 ``tokenizers`` 和仓库里共用的 ``transformers 4.49`` 冲突（后者要 ``<0.22``）。
所以它被装在**独立的虚拟环境** ``.venv-mineru`` 里，本项目只通过命令行调它：

```
.venv-mineru/Scripts/mineru-kit.exe parse 论文.pdf -o <输出目录> -f zip --tier basic
```

``-f zip`` 的产物是一个压缩包，里面固定有三份文件（见 MinerU 源码
``mineru/parser/base.py:ParseResult.save``）::

    markdown.md             整篇 Markdown
    middle_json.json        带页码 / 坐标 / 类型的中间表示
    structured_content.json 结构化内容
    images/...              抽出来的插图

本模块把这些文件读回来，整理成和其他后端一致的 :class:`ParsedDoc`。

**读的时候故意写得「防御」** —— MinerU 的 middle_json 结构随版本变过好几轮，
所以每一步都做多形状兜底：能认出页码就按页分，认不出就整篇当一页，
绝不因为结构对不上就让整条链路挂掉。
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any

from ..config import Settings, settings as default_settings
from ..models import ImageAsset
from .base import BaseParser, ParsedDoc, ParsedPage
from .render import render_all_pages

log = logging.getLogger(__name__)

#: 压缩包里认得的图片后缀。
_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}

#: 图片路径可能藏在这些字段里 —— structured_content 用 ``image_source``，
#: middle_json 用 ``image_path``，别的版本还有 ``img_path`` / ``image``。
_IMAGE_KEYS = ("image_source", "image_path", "img_path", "image", "img")

#: MinerU 的版面模型会把连续的拉丁字母**拆成单字符框**再拼回去，
#: 拼的时候中间塞了空格 —— "Kafka" 变成 "K a f k a"、"RAG" 变成 "R A G"。
#: 这是 MinerU 侧的行为，不是 PDF 本身的问题（PDF 的文字层是干净的）。
#: 这个正则把「3 个及以上单字母用单空格连起来」的片段还原回一个词。
#: 只认 3 个及以上，免得把 "A B" 这种本来就分开的两个字母误伤。
_SPACED_LATIN = re.compile(r"(?<![A-Za-z0-9])([A-Za-z](?: [A-Za-z]){2,})(?![A-Za-z0-9])")


def _normalize_spaced_latin(text: str) -> str:
    """把 MinerU 拆散的拉丁单词还原（``K a f k a`` → ``Kafka``）。"""

    return _SPACED_LATIN.sub(lambda m: m.group(1).replace(" ", ""), text)


class MinerUParser(BaseParser):
    """调 MinerU CLI 解析 PDF。"""

    name = "mineru"

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings

    # ------------------------------------------------------------------ 环境

    def _python(self) -> Path | None:
        return self._settings.mineru_python()

    def _executable(self) -> Path | None:
        """优先用 ``mineru-kit`` 可执行文件，找不到就退回 ``python -m``。"""

        venv = self._settings.mineru_venv_dir
        for candidate in (
            venv / "Scripts" / "mineru-kit.exe",
            venv / "bin" / "mineru-kit",
        ):
            if candidate.is_file():
                return candidate
        return None

    def available(self) -> bool:
        """MinerU 装好且 ``mineru-kit`` 能跑，才算可用。"""

        if self._python() is None:
            return False
        executable = self._executable()
        if executable is not None:
            return True
        # 没有 console script，退而求其次：能不能 import mineru
        python = self._python()
        if python is None:
            return False
        try:
            result = subprocess.run(
                [str(python), "-c", "import mineru"],
                capture_output=True,
                timeout=60,
            )
        except Exception:
            return False
        return result.returncode == 0

    def describe(self) -> str:
        if self._python() is None:
            return (
                "mineru（不可用：没有 .venv-mineru 虚拟环境，"
                "请执行 python scripts/setup_mineru.py）"
            )
        if not self.available():
            return "mineru（不可用：.venv-mineru 里没装好 mineru）"
        return "mineru（可用）"

    # ------------------------------------------------------------------ 解析

    def parse(self, path: Path, doc_id: str, filename: str) -> ParsedDoc:
        executable = self._executable()
        python = self._python()
        if executable is None and python is None:  # pragma: no cover - available 已挡
            raise RuntimeError("MinerU 环境不存在")

        image_dir = self._settings.image_dir / doc_id
        image_dir.mkdir(parents=True, exist_ok=True)

        with tempfile.TemporaryDirectory(prefix="mmrag-mineru-") as tmp_name:
            work_dir = Path(tmp_name)
            out_dir = work_dir / "out"
            out_dir.mkdir(parents=True, exist_ok=True)

            command = self._build_command(executable, python, path, out_dir)
            log.info("调用 MinerU: %s", " ".join(command))
            self._run(command)

            archive = self._find_archive(out_dir)
            if archive is None:
                raise RuntimeError(
                    f"MinerU 没有产出结果文件（期望 {out_dir}/*.zip），"
                    "通常是模型没下载 —— 见 scripts/setup_mineru.py"
                )

            extract_dir = work_dir / "extract"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(archive) as zf:
                zf.extractall(extract_dir)

            markdown = _read_text(extract_dir / "markdown.md")
            structured = _read_json(extract_dir / "structured_content.json")
            middle = _read_json(extract_dir / "middle_json.json")
            # MinerU 的字母间距问题在 markdown 里也一样，统一还原。
            markdown = _normalize_spaced_latin(markdown)

            pages, images = self._collect_pages(
                extract_dir, doc_id, image_dir, structured, middle
            )

        if not pages:
            # 一页都没拆出来：把整篇 markdown 当第 1 页，别丢内容。
            text = markdown.strip()
            pages = [ParsedPage(page=1, text=text)] if text else []

        if not pages and not images:
            raise RuntimeError("MinerU 解析结果为空")

        # 整页渲染 —— MinerU 只抽结构，页面截图还得靠 PyMuPDF。
        if self._settings.render_page_images:
            rendered = render_all_pages(path, image_dir, self._settings.render_dpi)
            for number, saved in rendered.items():
                images.append(
                    ImageAsset(
                        doc_id=doc_id,
                        filename=saved,
                        page=number,
                        origin=f"第 {number} 页渲染图",
                    )
                )
                for page in pages:
                    if page.page == number and saved not in page.images:
                        page.images.append(saved)

        return ParsedDoc(
            doc_id=doc_id,
            filename=filename,
            pages=pages,
            images=images,
            markdown=markdown,
            backend=self.name,
            extra={"page_count": len(pages), "images": len(images)},
        )

    # ------------------------------------------------------------------ 细节

    def _build_command(
        self, executable: Path | None, python: Path | None, path: Path, out_dir: Path
    ) -> list[str]:
        if executable is not None:
            command = [str(executable), "parse", str(path)]
        else:
            assert python is not None
            command = [str(python), "-m", "mineru.kit.main", "parse", str(path)]
        command += ["-o", str(out_dir), "-f", "zip"]
        # **档位必须显式给** —— MinerU CLI 的默认值是 ``standard``，
        # 而 standard 档要加载 llama.cpp 的 VLM 模型。在 Windows 的 GBK 控制台上，
        # 那个原生扩展往控制台写一个非 ASCII 字符就会抛
        # ``UnicodeEncodeError: No mapping for the Unicode character exists in
        # the target multi-byte code page``，整个解析直接失败。
        # ``basic`` 档只用 ONNX 的版面分析 + OCR 模型，没有这个问题。
        command += ["--tier", self._settings.mineru_tier or "basic"]
        ocr_mode = self._settings.mineru_ocr_mode
        if ocr_mode:
            command += ["--ocr-mode", ocr_mode]
        return command

    def _run(self, command: list[str]) -> None:
        """跑 MinerU。"""

        env = dict(os.environ)
        env.setdefault("PYTHONIOENCODING", "utf-8")
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                timeout=self._settings.mineru_timeout_seconds,
                env=env,
            )
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(
                f"MinerU 解析超时（{self._settings.mineru_timeout_seconds:.0f} 秒）"
            ) from exc
        if result.returncode != 0:
            stderr = (result.stderr or b"").decode("utf-8", "replace")[-2000:]
            raise RuntimeError(f"MinerU 退出码 {result.returncode}\n{stderr}")

    def _find_archive(self, out_dir: Path) -> Path | None:
        archives = sorted(out_dir.glob("*.zip"))
        return archives[0] if archives else None

    def _collect_pages(
        self,
        extract_dir: Path,
        doc_id: str,
        image_dir: Path,
        structured: Any,
        middle: Any,
    ) -> tuple[list[ParsedPage], list[ImageAsset]]:
        """从 structured_content / middle_json 里整理出「每页文本 + 图片」。

        两份 JSON 的**页面结构是一样的**：``{"pages": [{"page_idx": 0, "blocks": [...]}]}``，
        差别只在块里面的字段名 —— structured 用 ``image_source``、内容是字符串，
        middle 用 ``image_path``、内容是 ``[{"type": "text", "content": "..."}]`` 列表。
        所以统一按「页面 → 块 → 内容项」三层摊平，谁先摊出东西就用谁。
        """

        page_text: dict[int, list[str]] = {}
        image_map: dict[int, list[str]] = {}

        for source in (structured, middle):
            page_text, image_map = self._pages_from_source(
                source, extract_dir, image_dir, doc_id
            )
            if page_text or image_map:
                break

        pages = [
            ParsedPage(
                page=number,
                text="\n\n".join(page_text.get(number, [])),
                images=list(image_map.get(number, [])),
            )
            for number in sorted(page_text)
        ]
        images = [
            ImageAsset(
                doc_id=doc_id,
                filename=name,
                page=number,
                origin="MinerU 抽取插图",
            )
            for number, names in sorted(image_map.items())
            for name in names
        ]
        return pages, images

    def _pages_from_source(
        self,
        source: Any,
        extract_dir: Path,
        image_dir: Path,
        doc_id: str,
    ) -> tuple[dict[int, list[str]], dict[int, list[str]]]:
        """从一份中间表示里摊出「每页文字」和「每页图片」。"""

        page_text: dict[int, list[str]] = {}
        image_map: dict[int, list[str]] = {}

        for number, blocks in _iter_page_blocks(source):
            for block in blocks:
                texts, raw_images = _walk_block(block)
                for text in texts:
                    if text:
                        page_text.setdefault(number, []).append(
                            _normalize_spaced_latin(text)
                        )
                for raw in raw_images:
                    saved = self._copy_asset(extract_dir, image_dir, doc_id, raw)
                    if saved and saved not in image_map.setdefault(number, []):
                        image_map[number].append(saved)

        return page_text, image_map

    def _copy_asset(
        self, extract_dir: Path, image_dir: Path, doc_id: str, raw_path: str
    ) -> str:
        """把压缩包里的图片拷到 ``data/images/<doc_id>/``，返回新文件名。"""

        cleaned = raw_path.replace("\\", "/").lstrip("./")
        if not cleaned:
            return ""
        source = (extract_dir / cleaned).resolve()
        try:
            source.relative_to(extract_dir.resolve())
        except ValueError:
            return ""
        if not source.is_file():
            return ""
        if source.suffix.lower() not in _IMAGE_SUFFIXES:
            return ""
        target_name = f"mineru_{source.name}"
        shutil.copyfile(source, image_dir / target_name)
        return target_name


# ---------------------------------------------------------------------- 工具


def _read_text(path: Path) -> str:
    if not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _read_json(path: Path) -> Any:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _iter_page_blocks(doc: Any) -> list[tuple[int, list[dict[str, Any]]]]:
    """把 MinerU 的中间表示摊平成 ``[(页码, [块, ...]), ...]``。

    实测 4.1.7 的 ``structured_content.json`` 和 ``middle_json.json`` 都是这个形状::

        {"pages": [{"page_idx": 0, "blocks": [ ... ]}, ...]}

    页码在 **page 对象**上，不在块上 —— 所以要先取页码再摊块。
    早期版本还可能直接是一个块列表，这里一并认掉。
    """

    if not isinstance(doc, dict):
        return []
    pages = doc.get("pages")
    if not isinstance(pages, list):
        return []
    out: list[tuple[int, list[dict[str, Any]]]] = []
    for index, page in enumerate(pages):
        if not isinstance(page, dict):
            continue
        number = _page_number(page, fallback=index + 1)
        blocks = _blocks_of(page)
        if blocks:
            out.append((number, blocks))
    return out


def _blocks_of(page: dict[str, Any]) -> list[dict[str, Any]]:
    """从一个 page 对象里取出它的块列表。"""

    for key in ("blocks", "content", "text_blocks", "image_blocks", "table_body"):
        value = page.get(key)
        if isinstance(value, list):
            items = [item for item in value if isinstance(item, dict)]
            if items:
                return items
    return []


def _walk_block(block: dict[str, Any]) -> tuple[list[str], list[str]]:
    """从一个块里抽出「文字」和「图片路径」。

    块的 ``content`` 字段有两种形状，都遇到过：

    - 字符串（structured_content.json）：
      ``{"type": "text", "content": "正文"}``
    - 列表（middle_json.json）：
      ``{"type": "image", "content": [{"type": "image_body", "image_path": "images/a.jpg"}]}``

    图片路径的字段名也不一样：structured 叫 ``image_source``，
    middle 叫 ``image_path``。认错了就等于把图片丢了 —— 而图片恰恰是
    「多模态」三个字里最值钱的那一半。
    """

    texts: list[str] = []
    images: list[str] = []

    for key in _IMAGE_KEYS:
        value = block.get(key)
        if isinstance(value, str) and value.strip():
            images.append(value.strip())
            break

    content = block.get("content")
    if isinstance(content, str):
        if content.strip():
            texts.append(content.strip())
    elif isinstance(content, list):
        for item in content:
            if not isinstance(item, dict):
                continue
            for key in _IMAGE_KEYS:
                value = item.get(key)
                if isinstance(value, str) and value.strip():
                    images.append(value.strip())
                    break
            inner = item.get("content")
            if isinstance(inner, str):
                if inner.strip():
                    texts.append(inner.strip())
            elif isinstance(inner, dict):
                sub_texts, sub_images = _walk_block(inner)
                texts.extend(sub_texts)
                images.extend(sub_images)

    return texts, images


def _page_number(item: dict[str, Any], fallback: int = 0) -> int:
    """从各种结构的页码字段里取出一个 **1 起** 的页码。

    MinerU 用的是 0 起的 ``page_idx``，别的结构用 1 起的 ``page`` / ``page_no``，
    这里统一转成 1 起 —— 前端要显示「第 N 页」，跟人看的页码一致。
    """

    if "page_idx" in item:
        value = _as_int(item.get("page_idx")) + 1
        return value if value > 0 else fallback
    value = _as_int(_first(item, "page", "page_no", "page_index"))
    if value > 0:
        return value
    return fallback


def _first(item: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in item and item[key] not in (None, ""):
            return item[key]
    return None


def _as_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


if sys.platform == "win32":  # pragma: no cover - 仅影响控制台编码
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
