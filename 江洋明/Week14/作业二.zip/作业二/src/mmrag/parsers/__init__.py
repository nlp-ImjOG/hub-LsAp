"""解析器工厂。

``parser_backend`` 三种取值：

| 值 | 行为 |
| --- | --- |
| ``auto``（默认） | 有 MinerU 就用 MinerU，没有就用 PyMuPDF；MinerU 跑挂了自动降级到 PyMuPDF |
| ``mineru`` | 强制 MinerU（跑不通就报错，不静默降级） |
| ``pymupdf`` | 强制 PyMuPDF |
"""

from __future__ import annotations

import logging

from ..config import Settings, settings as default_settings
from .base import BaseParser, ParsedDoc, ParsedPage
from .mineru_parser import MinerUParser
from .pymupdf_parser import PyMuPDFParser

log = logging.getLogger(__name__)

__all__ = [
    "BaseParser",
    "MinerUParser",
    "ParsedDoc",
    "ParsedPage",
    "PyMuPDFParser",
    "build_parser",
    "describe_parsers",
]


def build_parser(settings: Settings | None = None) -> BaseParser:
    """按配置挑一个解析后端。"""

    settings = settings or default_settings
    backend = (settings.parser_backend or "auto").strip().lower()

    if backend == "mineru":
        return MinerUParser(settings)
    if backend == "pymupdf":
        return PyMuPDFParser(settings)

    mineru = MinerUParser(settings)
    if mineru.available():
        return mineru
    log.info("没找到可用的 MinerU，退回 PyMuPDF 解析器")
    return PyMuPDFParser(settings)


def describe_parsers(settings: Settings | None = None) -> list[str]:
    """列出各后端当前状态，给 CLI 自检用。"""

    settings = settings or default_settings
    return [
        MinerUParser(settings).describe(),
        PyMuPDFParser(settings).describe(),
    ]
