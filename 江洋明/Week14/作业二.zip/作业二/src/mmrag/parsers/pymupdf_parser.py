"""PyMuPDF 兜底解析器。

MinerU 要单独装一套依赖 + 几 GB 模型（见 ``scripts/setup_mineru.py``），
装不上 / 没下完模型时，总不能让整条链路断掉。这个后端只依赖 ``pymupdf``，
能做出 MinerU 解析结果里本作业真正用到的那三样东西：

1. 每页文本；
2. PDF 里内嵌的图片（``page.get_images``）；
3. 每一页渲染成的 PNG（``page.get_pixmap``）—— **图文混排问答靠它**，
   大模型看不了 PDF，但看得懂一张页面截图。
"""

from __future__ import annotations

import logging
from pathlib import Path

from ..config import Settings, settings as default_settings
from ..models import ImageAsset
from .base import BaseParser, ParsedDoc, ParsedPage
from .render import render_page_png

log = logging.getLogger(__name__)

#: PDF 里能抽到的图片格式白名单（有些后缀其实不是图片，抽出来也没法用）。
_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".jpx"}


class PyMuPDFParser(BaseParser):
    """用 PyMuPDF 解析 PDF。"""

    name = "pymupdf"

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings

    # ------------------------------------------------------------------ 环境

    def available(self) -> bool:
        try:
            import pymupdf  # noqa: F401
        except ImportError:
            return False
        return True

    def describe(self) -> str:
        if not self.available():
            return "pymupdf（不可用：缺 pymupdf，请 pip install pymupdf）"
        return "pymupdf（可用）"

    def _ensure_module(self) -> object:
        try:
            import pymupdf
        except ImportError as exc:  # pragma: no cover - 环境问题
            raise RuntimeError(
                "缺少 pymupdf 依赖，请执行：pip install pymupdf"
            ) from exc
        return pymupdf

    # ------------------------------------------------------------------ 解析

    def parse(self, path: Path, doc_id: str, filename: str) -> ParsedDoc:
        pymupdf = self._ensure_module()
        image_dir = self._settings.image_dir / doc_id
        image_dir.mkdir(parents=True, exist_ok=True)

        pages: list[ParsedPage] = []
        images: list[ImageAsset] = []
        markdown_parts: list[str] = []

        with pymupdf.open(str(path)) as doc:
            for index in range(doc.page_count):
                page = doc.load_page(index)
                number = index + 1
                text = (page.get_text("text") or "").strip()
                page_images: list[str] = []

                for order, saved in enumerate(
                    self._extract_embedded_images(doc, page, image_dir, number), start=1
                ):
                    page_images.append(saved)
                    images.append(
                        ImageAsset(
                            doc_id=doc_id,
                            filename=saved,
                            page=number,
                            origin=f"内嵌图 {order}",
                        )
                    )

                if self._settings.render_page_images:
                    rendered = render_page_png(
                        page, image_dir, number, self._settings.render_dpi
                    )
                    if rendered:
                        page_images.append(rendered)
                        images.append(
                            ImageAsset(
                                doc_id=doc_id,
                                filename=rendered,
                                page=number,
                                origin=f"第 {number} 页渲染图",
                            )
                        )

                pages.append(ParsedPage(page=number, text=text, images=page_images))
                if text:
                    markdown_parts.append(f"## 第 {number} 页\n\n{text}")

        return ParsedDoc(
            doc_id=doc_id,
            filename=filename,
            pages=pages,
            images=images,
            markdown="\n\n".join(markdown_parts),
            backend=self.name,
            extra={"page_count": len(pages)},
        )

    # ------------------------------------------------------------------ 图片

    def _extract_embedded_images(
        self, document: object, page: object, image_dir: Path, number: int
    ) -> list[str]:
        """抽出这一页里内嵌的图片。"""

        out: list[str] = []
        try:
            raw_images = page.get_images(full=True)  # type: ignore[attr-defined]
        except Exception:  # pragma: no cover - 少数畸形 PDF
            return out

        seen: set[int] = set()
        for order, item in enumerate(raw_images, start=1):
            xref = item[0]
            if xref in seen:
                continue
            seen.add(xref)
            try:
                extracted = document.extract_image(xref)  # type: ignore[attr-defined]
            except Exception:
                continue
            payload = extracted.get("image")
            ext = str(extracted.get("ext") or "png")
            if not payload:
                continue
            suffix = f".{ext}".lower()
            if suffix not in _IMAGE_SUFFIXES:
                continue
            name = f"p{number}_img{order}{suffix}"
            (image_dir / name).write_bytes(payload)
            out.append(name)
        return out
