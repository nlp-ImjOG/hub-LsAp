"""整页渲染的公共工具。

大模型看不了 PDF，但看得懂一张页面截图 —— **图文混排问答**就靠这个：
把 PDF 的每一页渲染成 PNG，连同用户的问题一起送给多模态大模型。

MinerU 负责「抽」结构（标题 / 段落 / 表格 / 插图），PyMuPDF 负责「渲」页面，
两个后端共用这里的一套渲染逻辑。
"""

from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger(__name__)


def render_page_png(page: object, image_dir: Path, number: int, dpi: int) -> str:
    """把一页渲染成 PNG，返回文件名；失败返回空串。"""

    try:
        pixmap = page.get_pixmap(dpi=dpi)  # type: ignore[attr-defined]
        name = f"page_{number}.png"
        image_dir.mkdir(parents=True, exist_ok=True)
        (image_dir / name).write_bytes(pixmap.tobytes("png"))
        return name
    except Exception as exc:  # pragma: no cover - 渲染失败不该让整篇解析失败
        log.warning("第 %d 页渲染失败: %s", number, exc)
        return ""


def render_all_pages(
    pdf_path: Path, image_dir: Path, dpi: int
) -> dict[int, str]:
    """渲染整个 PDF，返回 ``{页码: 文件名}``。渲染不了就返回空 dict。"""

    try:
        import pymupdf
    except ImportError:
        log.warning("没装 pymupdf，跳过整页渲染")
        return {}

    out: dict[int, str] = {}
    try:
        with pymupdf.open(str(pdf_path)) as doc:
            for index in range(doc.page_count):
                number = index + 1
                name = render_page_png(doc.load_page(index), image_dir, number, dpi)
                if name:
                    out[number] = name
    except Exception as exc:  # pragma: no cover - 坏文件不该让解析失败
        log.warning("整页渲染失败 %s: %s", pdf_path.name, exc)
    return out
