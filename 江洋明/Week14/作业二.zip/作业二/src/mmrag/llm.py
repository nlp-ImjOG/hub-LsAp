"""多模态大模型客户端。

用 DeepSeek 的 OpenAI 兼容接口（``https://api.deepseek.com/v1``）。

**为什么是 ``deepseek-flash``？**

DeepSeek 的模型里只有 ``deepseek-flash`` 能读图，``deepseek-v4-pro`` 是纯文本模型 ——
给纯文本模型塞 ``image_url`` 只会报错。仓库里 Week12 的作业也是这个结论。

**DeepSeek 不会生成图片**，所以「图文混排」靠另一种方式实现：

- 模型生成文字答案，答案里可以用 Markdown 图片语法引用文档里的图；
- 那些图是**解析时抽出来的插图 / 页面渲染图**，前端把 Markdown 里的图片地址渲染成真正的图片。

这样输出是真的「图文混排」，而不是文字里写一句「（图略）」。

API Key 只从环境变量 / ``.env`` 读，代码里不出现任何密钥。
"""

from __future__ import annotations

import base64
import logging
import mimetypes
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from .config import Settings, settings as default_settings

log = logging.getLogger(__name__)

#: 后缀 → MIME。mimetypes 在部分 Windows 环境上认不出 .webp，这里补齐。
_MIME_OVERRIDES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".webp": "image/webp",
    ".tiff": "image/tiff",
}


class LLMError(RuntimeError):
    """大模型调用失败。"""


def guess_mime(path: Path) -> str:
    """猜一个图片的 MIME。"""

    suffix = path.suffix.lower()
    if suffix in _MIME_OVERRIDES:
        return _MIME_OVERRIDES[suffix]
    guessed, _ = mimetypes.guess_type(path.name)
    return guessed or "image/png"


def to_data_url(path: Path) -> str:
    """把本地图片转成 data URL（OpenAI 兼容接口认这个格式）。"""

    payload = path.read_bytes()
    encoded = base64.b64encode(payload).decode("ascii")
    return f"data:{guess_mime(path)};base64,{encoded}"


#: 送给大模型前的最大边长。整页渲染图在 110 DPI 下可能有几百 KB，
#: 缩到长边 1400 像素足够看清字，也省 token。
_MAX_SIDE = 1400


def prepare_data_url(path: Path, max_side: int = _MAX_SIDE) -> str:
    """读图 → 必要时等比缩小 → 转 data URL。"""

    try:
        from PIL import Image
    except ImportError:  # pragma: no cover - 没装 pillow 就原图发
        return to_data_url(path)

    try:
        with Image.open(path) as image:
            image = image.convert("RGB")
            width, height = image.size
            longest = max(width, height)
            if longest > max_side:
                ratio = max_side / longest
                image = image.resize(
                    (max(1, int(width * ratio)), max(1, int(height * ratio))),
                    Image.LANCZOS,
                )
            import io

            buffer = io.BytesIO()
            image.save(buffer, format="JPEG", quality=85)
        encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
        return f"data:image/jpeg;base64,{encoded}"
    except Exception as exc:  # pragma: no cover - 坏图不该让整个问答挂掉
        log.warning("图片处理失败 %s，退回原图: %s", path, exc)
        return to_data_url(path)


class LLMClient:
    """DeepSeek 多模态客户端。"""

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings
        self._client: Any | None = None

    # ------------------------------------------------------------------ 环境

    @property
    def api_key(self) -> str:
        return self._settings.llm_api_key

    def available(self) -> bool:
        return bool(self._settings.llm_api_key)

    def describe(self) -> str:
        if not self.available():
            return (
                "大模型（不可用：没配 API Key，"
                "请在 .env 里写 MMRAG_API_KEY=sk-...）"
            )
        return f"大模型（可用：{self._settings.llm_model}）"

    def _ensure_client(self) -> Any:
        if self._client is None:
            if not self.available():
                raise LLMError(
                    "没配 API Key：请在 .env 里写 MMRAG_API_KEY=sk-...，"
                    "或用环境变量 MMRAG_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY"
                )
            try:
                from openai import OpenAI
            except ImportError as exc:  # pragma: no cover - 环境问题
                raise LLMError(
                    "缺少 openai 依赖，请执行：pip install openai"
                ) from exc
            self._client = OpenAI(
                api_key=self._settings.llm_api_key,
                base_url=self._settings.llm_base_url,
                timeout=self._settings.request_timeout_seconds,
                max_retries=2,
            )
        return self._client

    # ------------------------------------------------------------------ 调用

    def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.2,
        max_tokens: int | None = None,
    ) -> str:
        """一次问答，返回完整文本。"""

        client = self._ensure_client()
        try:
            response = client.chat.completions.create(
                model=self._settings.llm_model,
                messages=messages,
                temperature=temperature,
                stream=False,
                **({"max_tokens": max_tokens} if max_tokens else {}),
            )
        except Exception as exc:
            raise LLMError(f"调用大模型失败：{exc}") from exc
        return _extract_text(response)

    def stream(
        self,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.2,
    ) -> Iterator[str]:
        """流式问答，逐段吐出文本。"""

        client = self._ensure_client()
        try:
            stream = client.chat.completions.create(
                model=self._settings.llm_model,
                messages=messages,
                temperature=temperature,
                stream=True,
            )
        except Exception as exc:
            raise LLMError(f"调用大模型失败：{exc}") from exc

        try:
            for chunk in stream:
                text = _extract_delta(chunk)
                if text:
                    yield text
        except Exception as exc:
            raise LLMError(f"读取大模型流式响应失败：{exc}") from exc


def _extract_text(response: Any) -> str:
    try:
        return response.choices[0].message.content or ""
    except (AttributeError, IndexError, KeyError):  # pragma: no cover - 异常响应
        return ""


def _extract_delta(chunk: Any) -> str:
    try:
        return chunk.choices[0].delta.content or ""
    except (AttributeError, IndexError, KeyError):  # pragma: no cover - 异常响应
        return ""
