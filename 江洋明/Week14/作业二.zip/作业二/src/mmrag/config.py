"""运行配置。

约定（与仓库既有做法一致）：

- **API Key 只从环境变量 / 同目录 .env 读取**，代码里不出现任何真实密钥。
- 解析顺序：环境变量 > ``<项目根>/.env`` > 默认值。
- 路径类配置都相对于项目根解析，换台机器也能跑。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

# src/mmrag/config.py -> parents[2] 即「作业二」目录
PROJECT_ROOT = Path(__file__).resolve().parents[2]

#: 跨周复用的本地嵌入模型在「AI大模型应用/asserts」下。
#: 从作业二往上数三级就是「AI大模型应用」。
_SHARED_ASSETS = PROJECT_ROOT.parents[2] / "asserts"

#: 本作业默认使用的本地嵌入模型（中文效果够用，512 维）。
DEFAULT_EMBED_MODEL = _SHARED_ASSETS / "bge-small-zh-v1.5"

_ENV_FILES = (
    PROJECT_ROOT / ".env",
)


def _parse_env_file(path: Path) -> dict[str, str]:
    """极简 .env 解析器：只认 KEY=VALUE，忽略注释和空行，不处理引号转义。"""

    values: dict[str, str] = {}
    if not path.is_file():
        return values
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return values
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _load_env_files() -> dict[str, str]:
    merged: dict[str, str] = {}
    for path in reversed(_ENV_FILES):
        merged.update(_parse_env_file(path))
    return merged


_FILE_ENV = _load_env_files()


def _env_str(name: str, default: str = "", *also: str) -> str:
    names = (name, *also)
    for key in names:
        value = os.getenv(key)
        if value:
            return value
    for key in names:
        if key in _FILE_ENV:
            return _FILE_ENV[key]
    return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(_env_str(name, str(default)))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(_env_str(name, str(default)))
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    raw = _env_str(name, "1" if default else "0").strip().lower()
    return raw in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    """一次运行所需的全部可调参数。"""

    # --- Redis ---
    redis_url: str = "redis://127.0.0.1:6380/0"
    redis_prefix: str = "wk14mmrag"
    #: 文档状态过期时间（秒）。默认 7 天。
    doc_ttl_seconds: int = 7 * 24 * 3600
    #: 会话历史过期时间（秒）。默认 1 天。
    chat_ttl_seconds: int = 24 * 3600
    #: 单个会话最多保留多少条消息。
    max_chat_messages: int = 40

    # --- Kafka ---
    kafka_bootstrap_servers: str = "127.0.0.1:9095"
    #: 上传事件 topic —— 前端上传后投递到这里，worker 消费。
    kafka_topic_parse: str = "wk14.pdf.parse"
    #: 解析完成事件 topic —— worker 解析完往这里发一条。
    kafka_topic_parsed: str = "wk14.pdf.parsed"
    kafka_topic_partitions: int = 3
    kafka_send_timeout_seconds: float = 10.0
    kafka_poll_max_records: int = 5
    kafka_poll_timeout_seconds: float = 1.0
    kafka_consumer_group: str = "wk14-mmrag-worker"
    kafka_auto_create_topics: bool = True

    # --- 存储路径 ---
    data_dir: Path = PROJECT_ROOT / "data"
    upload_dir: Path = PROJECT_ROOT / "data" / "uploads"
    image_dir: Path = PROJECT_ROOT / "data" / "images"
    chunk_dir: Path = PROJECT_ROOT / "data" / "chunks"
    vector_dir: Path = PROJECT_ROOT / "data" / "vectors"

    # --- 上传限制 ---
    max_upload_bytes: int = 50 * 1024 * 1024
    max_files_per_upload: int = 10

    # --- 解析后端 ---
    #: auto —— 有 MinerU 就用 MinerU，没有就用 PyMuPDF；mineru / pymupdf —— 强制指定。
    parser_backend: str = "auto"
    #: MinerU 所在的独立虚拟环境（Windows 下是 Scripts/python.exe）。
    mineru_venv_dir: Path = PROJECT_ROOT / ".venv-mineru"
    #: MinerU 解析超时（秒）。
    mineru_timeout_seconds: float = 900.0
    #: MinerU 档位。**必须显式指定** —— CLI 默认是 ``standard``，
    #: 而 standard 档要加载 llama.cpp 的 VLM 模型，在 Windows 的 GBK 控制台上
    #: 会炸 ``No mapping for the Unicode character exists in the target
    #: multi-byte code page``。``basic`` 档只用 ONNX 的版面 + OCR 模型，稳。
    mineru_tier: str = "basic"
    #: MinerU 的 OCR 模式：auto / txt / ocr。``auto`` 让它自己判断。
    mineru_ocr_mode: str = "auto"
    #: 是否把每页渲染成 PNG（图文混排要用）。
    render_page_images: bool = True
    #: 页面渲染 DPI，越大越清晰也越慢。
    render_dpi: int = 110

    # --- 切块 ---
    chunk_size: int = 600
    chunk_overlap: int = 80

    # --- 检索 ---
    top_k: int = 5
    #: 检索到的文本块里，最多带多少张图进提示词。
    max_images_in_prompt: int = 3

    # --- 模型 ---
    embed_model_path: Path = DEFAULT_EMBED_MODEL
    llm_api_key: str = ""
    llm_base_url: str = "https://api.deepseek.com/v1"
    llm_model: str = "deepseek-flash"
    request_timeout_seconds: float = 120.0
    max_history_turns: int = 4

    # --- 服务 ---
    api_host: str = "127.0.0.1"
    #: 默认端口**不用 8000** —— 那个端口在本机上常年被别的容器占着
    #: （写死 8000 的直接后果是 ``winerror 10048``，起都起不来）。
    #: 真要改就改 ``.env`` 里的 ``MMRAG_API_PORT``。
    api_port: int = 8010
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "Settings":
        data_dir = Path(_env_str("MMRAG_DATA_DIR", str(cls.data_dir)))
        if not data_dir.is_absolute():
            data_dir = PROJECT_ROOT / data_dir

        embed_path = Path(_env_str("MMRAG_EMBED_MODEL", str(cls.embed_model_path)))
        if not embed_path.is_absolute():
            embed_path = _SHARED_ASSETS / embed_path

        mineru_venv = Path(_env_str("MMRAG_MINERU_VENV", str(cls.mineru_venv_dir)))
        if not mineru_venv.is_absolute():
            mineru_venv = PROJECT_ROOT / mineru_venv

        api_key = _env_str(
            "MMRAG_API_KEY", "", "OPENAI_API_KEY", "DEEPSEEK_API_KEY", "LLM_API_KEY"
        )

        return cls(
            redis_url=_env_str("REDIS_URL", cls.redis_url),
            redis_prefix=_env_str("MMRAG_REDIS_PREFIX", cls.redis_prefix),
            doc_ttl_seconds=_env_int("MMRAG_DOC_TTL", cls.doc_ttl_seconds),
            chat_ttl_seconds=_env_int("MMRAG_CHAT_TTL", cls.chat_ttl_seconds),
            max_chat_messages=_env_int("MMRAG_MAX_CHAT_MESSAGES", cls.max_chat_messages),
            kafka_bootstrap_servers=_env_str(
                "KAFKA_BOOTSTRAP_SERVERS", cls.kafka_bootstrap_servers
            ),
            kafka_topic_parse=_env_str("KAFKA_TOPIC_PARSE", cls.kafka_topic_parse),
            kafka_topic_parsed=_env_str("KAFKA_TOPIC_PARSED", cls.kafka_topic_parsed),
            kafka_topic_partitions=_env_int(
                "KAFKA_TOPIC_PARTITIONS", cls.kafka_topic_partitions
            ),
            kafka_send_timeout_seconds=_env_float(
                "KAFKA_SEND_TIMEOUT", cls.kafka_send_timeout_seconds
            ),
            kafka_poll_max_records=_env_int(
                "KAFKA_POLL_MAX_RECORDS", cls.kafka_poll_max_records
            ),
            kafka_poll_timeout_seconds=_env_float(
                "KAFKA_POLL_TIMEOUT", cls.kafka_poll_timeout_seconds
            ),
            kafka_consumer_group=_env_str(
                "KAFKA_CONSUMER_GROUP", cls.kafka_consumer_group
            ),
            kafka_auto_create_topics=_env_bool(
                "KAFKA_AUTO_CREATE_TOPICS", cls.kafka_auto_create_topics
            ),
            data_dir=data_dir,
            upload_dir=data_dir / "uploads",
            image_dir=data_dir / "images",
            chunk_dir=data_dir / "chunks",
            vector_dir=data_dir / "vectors",
            max_upload_bytes=_env_int("MMRAG_MAX_UPLOAD_BYTES", cls.max_upload_bytes),
            max_files_per_upload=_env_int(
                "MMRAG_MAX_FILES", cls.max_files_per_upload
            ),
            parser_backend=_env_str("MMRAG_PARSER", cls.parser_backend).strip().lower(),
            mineru_venv_dir=mineru_venv,
            mineru_timeout_seconds=_env_float(
                "MMRAG_MINERU_TIMEOUT", cls.mineru_timeout_seconds
            ),
            mineru_tier=_env_str("MMRAG_MINERU_TIER", cls.mineru_tier).strip() or "basic",
            mineru_ocr_mode=(
                _env_str("MMRAG_MINERU_OCR_MODE", cls.mineru_ocr_mode).strip() or "auto"
            ),
            render_page_images=_env_bool("MMRAG_RENDER_PAGES", cls.render_page_images),
            render_dpi=_env_int("MMRAG_RENDER_DPI", cls.render_dpi),
            chunk_size=_env_int("MMRAG_CHUNK_SIZE", cls.chunk_size),
            chunk_overlap=_env_int("MMRAG_CHUNK_OVERLAP", cls.chunk_overlap),
            top_k=_env_int("MMRAG_TOP_K", cls.top_k),
            max_images_in_prompt=_env_int(
                "MMRAG_MAX_IMAGES", cls.max_images_in_prompt
            ),
            embed_model_path=embed_path,
            llm_api_key=api_key,
            llm_base_url=_env_str(
                "MMRAG_BASE_URL", cls.llm_base_url, "OPENAI_BASE_URL", "DEEPSEEK_BASE_URL"
            ).rstrip("/"),
            llm_model=_env_str("MMRAG_MODEL", cls.llm_model),
            request_timeout_seconds=_env_float(
                "MMRAG_REQUEST_TIMEOUT", cls.request_timeout_seconds
            ),
            max_history_turns=_env_int("MMRAG_MAX_HISTORY", cls.max_history_turns),
            api_host=_env_str("MMRAG_API_HOST", cls.api_host),
            api_port=_env_int("MMRAG_API_PORT", cls.api_port),
            log_level=_env_str("MMRAG_LOG_LEVEL", cls.log_level).upper(),
        )

    # ------------------------------------------------------------------ 路径

    def ensure_dirs(self) -> None:
        """把用到的目录都建出来。"""

        for path in (
            self.data_dir,
            self.upload_dir,
            self.image_dir,
            self.chunk_dir,
            self.vector_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)

    def upload_path(self, doc_id: str, filename: str) -> Path:
        """上传文件在磁盘上的路径。

        约定：``<doc_id>__<原文件名>``。带上 doc_id 是为了同名文件不互相覆盖
        （一次可以传多个 PDF）。
        """

        return self.upload_dir / f"{doc_id}__{filename}"

    def mineru_python(self) -> Path | None:
        """MinerU 虚拟环境里的 python 解释器路径。找不到返回 None。"""

        candidates = (
            self.mineru_venv_dir / "Scripts" / "python.exe",
            self.mineru_venv_dir / "bin" / "python",
        )
        for candidate in candidates:
            if candidate.is_file():
                return candidate
        return None


settings = Settings.from_env()
