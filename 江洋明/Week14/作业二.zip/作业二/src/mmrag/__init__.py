"""多模态 RAG 问答（作业二）。

模块分工::

    config.py      配置（环境变量 > .env > 默认值）
    models.py      数据契约（文档状态 / 块 / 图片 / 消息）
    store.py       Redis 状态存储
    bus.py         Kafka 事件总线
    parsers/       解析后端（MinerU / PyMuPDF）
    chunker.py     切块
    embedder.py    本地嵌入模型
    vector_store.py 向量库（numpy）
    retriever.py   检索
    llm.py         多模态大模型客户端
    prompts.py     提示词
    qa.py          问答编排
    worker.py      Kafka 消费者（解析 Worker）
    api/           FastAPI 应用
    cli.py         命令行
"""

from __future__ import annotations

__version__ = "1.0.0"

__all__ = ["__version__"]
