"""Redis 存储层：文档状态 + 会话历史。

Key 布局（``{prefix}`` 默认 ``wk14mmrag``）::

    {prefix}:docs                    SET    所有文档 id
    {prefix}:doc:{doc_id}:meta       HASH   文档元信息（含解析状态）
    {prefix}:chat:{session_id}       LIST   会话消息（JSON）
    {prefix}:sessions                SET    所有会话 id

分工和作业一一样：**Redis 存状态**（文档解析到哪一步了、聊到哪一句了），
**Kafka 传事件**（上传事件、解析完成事件）。
"""

from __future__ import annotations

import json
from typing import Any

from .config import Settings, settings as default_settings
from .models import ChatMessage, DocumentMeta, DocStatus, now_ms

try:
    import redis
except ImportError as exc:  # pragma: no cover - 环境问题
    raise ImportError(
        "缺少 redis 依赖，请先执行：pip install -r requirements.txt"
    ) from exc


class StateStore:
    """Redis 上的状态存储。"""

    def __init__(self, client: Any | None = None, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings
        self._prefix = self._settings.redis_prefix
        self._client = client if client is not None else self._connect()

    def _connect(self) -> Any:
        return redis.Redis.from_url(
            self._settings.redis_url,
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=5,
        )

    @property
    def client(self) -> Any:
        return self._client

    # ------------------------------------------------------------------ key

    def docs_key(self) -> str:
        return f"{self._prefix}:docs"

    def doc_key(self, doc_id: str) -> str:
        return f"{self._prefix}:doc:{doc_id}:meta"

    def chat_key(self, session_id: str) -> str:
        return f"{self._prefix}:chat:{session_id}"

    def sessions_key(self) -> str:
        return f"{self._prefix}:sessions"

    # ------------------------------------------------------------------ 文档

    def save_doc(self, meta: DocumentMeta) -> None:
        """写入（或覆盖）一个文档的元信息。"""

        meta.updated_at = now_ms()
        pipe = self._client.pipeline(transaction=True)
        pipe.hset(self.doc_key(meta.doc_id), mapping=meta.to_dict())
        pipe.sadd(self.docs_key(), meta.doc_id)
        pipe.expire(self.doc_key(meta.doc_id), self._settings.doc_ttl_seconds)
        pipe.execute()

    def update_status(
        self,
        doc_id: str,
        status: DocStatus,
        *,
        error: str = "",
        backend: str = "",
        pages: int | None = None,
        chunks: int | None = None,
        images: int | None = None,
    ) -> DocumentMeta:
        """改文档状态 —— worker 推进状态机时调用。"""

        if not self._client.exists(self.doc_key(doc_id)):
            # 不先查一下的话，hset 会凭空造出一个空文档。
            raise KeyError(f"文档不存在: {doc_id}")

        mapping: dict[str, Any] = {"status": status.value, "updated_at": now_ms()}
        if error:
            mapping["error"] = error
        if backend:
            mapping["backend"] = backend
        if pages is not None:
            mapping["pages"] = pages
        if chunks is not None:
            mapping["chunks"] = chunks
        if images is not None:
            mapping["images"] = images
        pipe = self._client.pipeline(transaction=True)
        pipe.hset(self.doc_key(doc_id), mapping=mapping)
        pipe.expire(self.doc_key(doc_id), self._settings.doc_ttl_seconds)
        pipe.execute()
        meta = self.get_doc(doc_id)
        if meta is None:
            raise KeyError(f"文档不存在: {doc_id}")
        return meta

    def get_doc(self, doc_id: str) -> DocumentMeta | None:
        raw = self._client.hgetall(self.doc_key(doc_id))
        if not raw:
            return None
        return DocumentMeta.from_dict(raw)

    def list_docs(self) -> list[DocumentMeta]:
        """列出所有文档，按创建时间倒序（新的在前）。"""

        doc_ids = sorted(self._client.smembers(self.docs_key()))
        metas = [self.get_doc(doc_id) for doc_id in doc_ids]
        found = [m for m in metas if m is not None]
        found.sort(key=lambda m: m.created_at, reverse=True)
        return found

    def doc_ids(self) -> list[str]:
        """所有还活着的文档 id。

        只读索引集合，不逐个读元信息 —— 检索时每问一次都要调，
        走 ``list_docs`` 会把每个文档的 HASH 都拉一遍，不划算。
        """

        return sorted(self._client.smembers(self.docs_key()))

    def delete_doc(self, doc_id: str) -> bool:
        existed = bool(self._client.exists(self.doc_key(doc_id)))
        pipe = self._client.pipeline(transaction=True)
        pipe.delete(self.doc_key(doc_id))
        pipe.srem(self.docs_key(), doc_id)
        pipe.execute()
        return existed

    def pending_docs(self) -> list[DocumentMeta]:
        """状态还是「待解析」的文档 —— 服务重启后用来补投 Kafka。"""

        return [m for m in self.list_docs() if m.status is DocStatus.PENDING]

    # ------------------------------------------------------------------ 会话

    def append_chat(self, session_id: str, message: ChatMessage) -> None:
        """追加一条会话消息。"""

        pipe = self._client.pipeline(transaction=True)
        pipe.rpush(self.chat_key(session_id), message.to_json())
        pipe.sadd(self.sessions_key(), session_id)
        pipe.expire(self.chat_key(session_id), self._settings.chat_ttl_seconds)
        pipe.execute()
        limit = self._settings.max_chat_messages
        if limit > 0:
            key = self.chat_key(session_id)
            length = int(self._client.llen(key))
            if length > limit:
                self._client.ltrim(key, length - limit, -1)

    def history(self, session_id: str, limit: int = 0) -> list[ChatMessage]:
        """读会话历史（时间正序）。"""

        key = self.chat_key(session_id)
        if limit and limit > 0:
            raw_items = self._client.lrange(key, -limit, -1)
        else:
            raw_items = self._client.lrange(key, 0, -1)
        out: list[ChatMessage] = []
        for item in raw_items:
            try:
                out.append(ChatMessage.from_json(item))
            except json.JSONDecodeError:
                continue
        return out

    def clear_chat(self, session_id: str) -> bool:
        existed = bool(self._client.exists(self.chat_key(session_id)))
        pipe = self._client.pipeline(transaction=True)
        pipe.delete(self.chat_key(session_id))
        pipe.srem(self.sessions_key(), session_id)
        pipe.execute()
        return existed

    # ------------------------------------------------------------------ 自检

    def ping(self) -> bool:
        try:
            return bool(self._client.ping())
        except Exception:
            return False

    def stats(self) -> dict[str, Any]:
        docs = self.list_docs()
        by_status: dict[str, int] = {}
        for doc in docs:
            by_status[doc.status.value] = by_status.get(doc.status.value, 0) + 1
        return {
            "documents": len(docs),
            "by_status": by_status,
            "sessions": len(self._client.smembers(self.sessions_key())),
            "redis_url": self._settings.redis_url,
        }
