"""Kafka 封装。

作业二用 Kafka 串起「上传 → 解析」这条异步链路：

```
浏览器 ──POST /api/documents──▶ FastAPI
                                   │ 写 Redis：状态 = 待解析
                                   │ produce → wk14.pdf.parse
                                   ▼
                            Worker（订阅 wk14.pdf.parse）
                                   │ 写 Redis：状态 = 解析中
                                   │ 调 MinerU / PyMuPDF 解析
                                   │ 写 Redis：状态 = 解析完成
                                   │ produce → wk14.pdf.parsed
```

**消息 key 用 `doc_id`** —— 同一个文档的多次解析请求会进同一个分区，
worker 消费时不会把同一个文档的两次任务交错执行。
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

from .config import Settings, settings as default_settings
from .models import ParseRequest

try:
    from kafka import KafkaConsumer, KafkaProducer
    from kafka.admin import KafkaAdminClient, NewTopic
    from kafka.errors import KafkaError, TopicAlreadyExistsError
except ImportError as exc:  # pragma: no cover - 环境问题
    raise ImportError(
        "缺少 kafka 依赖，请先执行：pip install -r requirements.txt"
    ) from exc

log = logging.getLogger(__name__)


class Bus:
    """Kafka 的薄封装。"""

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings
        self._producer: Any | None = None

    # ------------------------------------------------------------------ 生产者

    @property
    def producer(self) -> Any:
        if self._producer is None:
            self._producer = KafkaProducer(
                bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
                value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode("utf-8"),
                key_serializer=lambda k: k.encode("utf-8") if isinstance(k, str) else k,
                acks="all",
                retries=3,
                linger_ms=10,
                max_block_ms=int(self._settings.kafka_send_timeout_seconds * 1000),
            )
        return self._producer

    def publish(
        self, topic: str, value: dict[str, Any], *, key: str | None = None
    ) -> dict[str, Any]:
        """发一条消息。"""

        def attempt() -> dict[str, Any]:
            try:
                return self._publish_once(topic, value, key=key)
            except ValueError as exc:
                if _SOCKET_RACE_MARKER not in str(exc):
                    raise
                # 生产者的连接已经废了 —— 丢掉它，
                # 下一次重试会重新建一条（复用同一条只会接着报同一个错）。
                self.close()
                raise

        return _retry_on_socket_race(attempt)

    def _publish_once(
        self, topic: str, value: dict[str, Any], *, key: str | None = None
    ) -> dict[str, Any]:
        future = self.producer.send(topic, value=value, key=key)
        metadata = future.get(timeout=self._settings.kafka_send_timeout_seconds)
        self.producer.flush(timeout=self._settings.kafka_send_timeout_seconds)
        return {
            "topic": metadata.topic,
            "partition": metadata.partition,
            "offset": metadata.offset,
            "key": key,
        }

    def publish_parse_request(self, request: ParseRequest) -> dict[str, Any]:
        """投递一个解析任务。"""

        return self.publish(
            self._settings.kafka_topic_parse, request.to_dict(), key=request.doc_id
        )

    def publish_parsed_event(
        self, doc_id: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        """投递一条「解析完成」事件。"""

        return self.publish(
            self._settings.kafka_topic_parsed, payload, key=doc_id
        )

    def close(self) -> None:
        if self._producer is not None:
            try:
                self._producer.flush(timeout=5)
                self._producer.close(timeout=5)
            finally:
                self._producer = None

    # ------------------------------------------------------------------ 消费者

    @contextmanager
    def consume(
        self,
        topic: str,
        *,
        group_id: str | None = None,
        auto_offset_reset: str = "earliest",
        timeout_ms: int = 10_000,
    ) -> Iterator[Any]:
        """订阅 topic。"""

        consumer = KafkaConsumer(
            topic,
            bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
            group_id=group_id if group_id is not None else self._settings.kafka_consumer_group,
            auto_offset_reset=auto_offset_reset,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            key_deserializer=lambda k: k.decode("utf-8") if k is not None else None,
            consumer_timeout_ms=timeout_ms,
            enable_auto_commit=False,
            max_poll_records=self._settings.kafka_poll_max_records,
        )
        try:
            yield consumer
        finally:
            # Windows 上 kafka-python 关闭消费者时偶尔会抛
            # ``ValueError: Invalid file descriptor``（心跳线程没退干净）。
            # 消息这时候已经取到手了，不能因为关连接失败把整批丢掉。
            try:
                consumer.close()
            except Exception as exc:  # pragma: no cover - 平台相关
                log.warning("关闭消费者时出错（忽略）：%s", exc)

    def poll_once(
        self,
        topic: str,
        *,
        group_id: str | None = None,
        auto_offset_reset: str = "earliest",
        timeout_ms: int = 10_000,
        handler: Any | None = None,
        commit: bool = True,
    ) -> list[dict[str, Any]]:
        """拉一批消息就返回。

        给了 ``handler`` 就在**提交位点之前**把它调一遍 ——
        「处理成功才提交」的语义才成立。
        ``commit=False`` 则只看不提交（拿来窥探 topic 时用）。
        """

        return _retry_on_socket_race(
            lambda: self._poll_once(
                topic,
                group_id=group_id,
                auto_offset_reset=auto_offset_reset,
                timeout_ms=timeout_ms,
                handler=handler,
                commit=commit,
            )
        )

    def _poll_once(
        self,
        topic: str,
        *,
        group_id: str | None = None,
        auto_offset_reset: str = "earliest",
        timeout_ms: int = 10_000,
        handler: Any | None = None,
        commit: bool = True,
    ) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        with self.consume(
            topic,
            group_id=group_id,
            auto_offset_reset=auto_offset_reset,
            timeout_ms=timeout_ms,
        ) as consumer:
            records = consumer.poll(
                timeout_ms=timeout_ms, max_records=self._settings.kafka_poll_max_records
            )
            for _tp, batch in records.items():
                for record in batch:
                    item = {
                        "topic": record.topic,
                        "partition": record.partition,
                        "offset": record.offset,
                        "key": record.key,
                        "value": record.value,
                    }
                    if handler is not None:
                        handler(item)
                    out.append(item)
            if commit and out:
                # 处理完才提交位点（至少一次语义）。不提交的话，
                # 下次启动会把同一批消息再拉一遍。
                try:
                    consumer.commit()
                except Exception as exc:  # pragma: no cover - 提交失败不致命
                    log.warning("提交位点失败: %s", exc)
        out.sort(key=lambda item: (item["partition"], item["offset"]))
        return out

    # ------------------------------------------------------------------ 管理

    def ensure_topic(self, topic: str, partitions: int | None = None) -> bool:
        """确保 topic 存在。返回 True 表示这次新建了。"""

        count = partitions or self._settings.kafka_topic_partitions

        def attempt() -> bool:
            admin = KafkaAdminClient(
                bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
                request_timeout_ms=10_000,
            )
            try:
                admin.create_topics(
                    [NewTopic(name=topic, num_partitions=count, replication_factor=1)]
                )
                return True
            except TopicAlreadyExistsError:
                return False
            except KafkaError:
                return False
            finally:
                # 关连接也会撞上同一个 socket 竞态 ——
                # 别让它从 ``finally`` 里盖掉真正的结果。
                try:
                    admin.close()
                except Exception as exc:  # pragma: no cover - 平台相关
                    log.warning("关闭 admin 客户端时出错（忽略）：%s", exc)

        # 建 topic 也会踩到 socket 竞态（建连 + 心跳线程），
        # 所以跟收发消息一样走重试。
        return _retry_on_socket_race(attempt)

    def ensure_topics(self) -> list[str]:
        """把本作业要用的 topic 都建好，返回新建成功的那些。"""

        created: list[str] = []
        for topic in (self._settings.kafka_topic_parse, self._settings.kafka_topic_parsed):
            if self.ensure_topic(topic):
                created.append(topic)
        return created

    def describe(self, topic: str) -> dict[str, Any]:
        """看 topic 的分区与消息数。"""

        consumer = KafkaConsumer(
            bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
            group_id=None,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        )
        try:
            partitions = consumer.partitions_for_topic(topic) or set()
            if not partitions:
                return {"topic": topic, "partitions": []}
            from kafka import TopicPartition

            tps = [TopicPartition(topic, p) for p in sorted(partitions)]
            beginning = consumer.beginning_offsets(tps)
            end = consumer.end_offsets(tps)
            rows = [
                {
                    "partition": tp.partition,
                    "messages": max(0, end.get(tp, 0) - beginning.get(tp, 0)),
                }
                for tp in tps
            ]
            return {"topic": topic, "partitions": rows}
        finally:
            try:
                consumer.close()
            except Exception as exc:  # pragma: no cover - 平台相关
                log.warning("关闭消费者时出错（忽略）：%s", exc)

    def ping(self) -> bool:
        try:
            admin = KafkaAdminClient(
                bootstrap_servers=self._settings.kafka_bootstrap_servers.split(","),
                request_timeout_ms=5000,
            )
            admin.list_topics()
            admin.close()
            return True
        except Exception:
            return False


_SOCKET_RACE_MARKER = "Invalid file descriptor"


def is_socket_race(exc: BaseException) -> bool:
    """是不是 kafka-python-ng 在 Windows 上的 socket 竞态。

    现象：连接被并发关掉时，``poll()`` 会在 ``KafkaClient._poll`` 里
    ``self._selector.unregister(key.fileobj)`` 上炸 ——
    那个 socket 已经关了，``fileno()`` 返回 -1，
    于是报 ``ValueError: Invalid file descriptor: -1``。
    """

    return isinstance(exc, ValueError) and _SOCKET_RACE_MARKER in str(exc)


def _retry_on_socket_race(action: Any, attempts: int = 4) -> Any:
    """kafka-python-ng 的竞态兜底：连接被并发关掉时会报
    ``ValueError: Invalid file descriptor: -1``，重开一条连接重试即可。

    **重试之间要等一下** —— 不等的话三次重试会在同一个坏状态下连着失败
    （实测踩过：连续三次 ``重试第 N 次`` 之后还是抛同一个错）。
    等的时间按 0.3 / 0.6 / 1.2 秒递增，给底层 socket 一点恢复的时间。
    """

    last: Exception | None = None
    for attempt in range(attempts):
        try:
            return action()
        except ValueError as exc:
            if not is_socket_race(exc):
                raise
            last = exc
            log.warning("kafka 客户端 socket 竞态，重试第 %d 次", attempt + 1)
            time.sleep(0.3 * (2**attempt))
    assert last is not None
    raise last
