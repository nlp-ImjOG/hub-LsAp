"""本地嵌入模型。

用仓库里跨周复用的 ``asserts/bge-small-zh-v1.5``（512 维，中文效果够用）：

- **离线** —— 不调任何外部接口，作业环境断网也能跑；
- **快** —— CPU 上加载约 1 秒，编码一段文本几十毫秒；
- **和课程其它周一致** —— Week5/Week6 的检索实验用的就是它。

模型是**懒加载**的：只有真的开始向量化时才加载，
这样 FastAPI 起服务不用等模型，测试也不用背这个依赖。
"""

from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Any

from .config import Settings, settings as default_settings

log = logging.getLogger(__name__)


class Embedder:
    """句向量编码器。"""

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings
        self._model: Any | None = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ 加载

    @property
    def model_path(self) -> Path:
        return self._settings.embed_model_path

    def available(self) -> bool:
        return self.model_path.is_dir()

    def describe(self) -> str:
        if not self.available():
            return (
                f"嵌入模型（不可用：{self.model_path} 不存在，"
                "请检查 MMRAG_EMBED_MODEL 指向的本地模型目录）"
            )
        return f"嵌入模型（可用：{self.model_path.name}）"

    def _load(self) -> Any:
        if self._model is None:
            with self._lock:
                if self._model is None:
                    try:
                        from sentence_transformers import SentenceTransformer
                    except ImportError as exc:  # pragma: no cover - 环境问题
                        raise RuntimeError(
                            "缺少 sentence-transformers，请执行："
                            "pip install sentence-transformers"
                        ) from exc
                    if not self.available():
                        raise RuntimeError(
                            f"找不到本地嵌入模型：{self.model_path}。"
                            "可把 MMRAG_EMBED_MODEL 指向 asserts/bge-small-zh-v1.5"
                        )
                    log.info("加载嵌入模型：%s", self.model_path)
                    self._model = SentenceTransformer(
                        str(self.model_path), device="cpu"
                    )
        return self._model

    # ------------------------------------------------------------------ 编码

    def encode(self, texts: list[str]) -> Any:
        """编码成归一化向量（numpy 数组，形状 ``(n, 512)``）。"""

        import numpy as np

        if not texts:
            return np.zeros((0, 0), dtype="float32")
        model = self._load()
        vectors = model.encode(
            texts,
            normalize_embeddings=True,  # 归一化后余弦相似度 == 点积
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        return np.asarray(vectors, dtype="float32")

    def encode_one(self, text: str) -> Any:
        """编码一句话，返回一维向量。"""

        return self.encode([text])[0]

    @property
    def dim(self) -> int:
        """向量维度。"""

        return int(self.encode(["维度探测"])[0].shape[0])
