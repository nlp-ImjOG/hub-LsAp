"""FastAPI 应用。

路由一览：

| 方法 | 路径 | 干什么 |
| --- | --- | --- |
| GET | ``/`` | 前端页面 |
| GET | ``/api/health`` | 自检（Redis / Kafka / 解析器 / 模型 / 大模型） |
| POST | ``/api/documents`` | 上传多个 PDF → 存 Redis「待解析」→ 投 Kafka |
| GET | ``/api/documents`` | 列文档（含三态状态） |
| GET | ``/api/documents/{doc_id}`` | 单个文档 |
| DELETE | ``/api/documents/{doc_id}`` | 删文档（含向量、图片） |
| GET | ``/api/documents/{doc_id}/images/{name}`` | 取图片（前端渲染图文混排要用） |
| POST | ``/api/chat`` | 多模态问答（SSE 流式返回，可带图） |
| GET | ``/api/sessions/{sid}/history`` | 会话历史 |
| DELETE | ``/api/sessions/{sid}`` | 清会话历史 |

**为什么用 SSE 而不是 WebSocket？**

问答是「一次请求 → 一串增量 → 结束」的单向流，SSE 正好够用；
而且 SSE 在浏览器里用 ``fetch`` 就能读（``EventSource`` 不支持 POST），
不需要引额外的库。
"""

from __future__ import annotations

import json
import logging
import mimetypes
import re
import shutil
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse

from ..config import Settings, settings as default_settings
from ..embedder import Embedder
from ..models import DocumentMeta, DocStatus, ParseRequest, new_id
from ..parsers import describe_parsers
from ..qa import QAService
from ..store import StateStore
from ..vector_store import VectorStore
from ..bus import Bus
from .schemas import (
    ChatTurnIn,
    DocumentOut,
    HealthOut,
    HistoryMessageOut,
    HistoryOut,
    UploadOut,
)

log = logging.getLogger(__name__)

FRONTEND_FILE = Path(__file__).resolve().parents[3] / "frontend" / "index.html"

#: 允许上传的扩展名。
_ALLOWED_SUFFIXES = {".pdf"}

#: 存文件名时，把不安全的字符换掉。
_SAFE_NAME = re.compile(r"[^A-Za-z0-9._一-鿿-]")


def _safe_filename(name: str) -> str:
    """把上传的文件名收拾干净，同时保留中文。"""

    cleaned = _SAFE_NAME.sub("_", Path(name).name).strip("._")
    return cleaned or "upload.pdf"


def create_app(settings: Settings | None = None) -> FastAPI:
    """造一个 app。"""

    settings = settings or default_settings
    settings.ensure_dirs()

    app = FastAPI(title="多模态 RAG 问答（Kafka + MinerU）", version="1.0.0")
    app.state.settings = settings
    app.state.store = StateStore(settings=settings)
    app.state.bus = Bus(settings)
    app.state.qa = QAService(settings=settings)
    app.state.vectors = VectorStore(settings)
    app.state.embedder = Embedder(settings)

    # ------------------------------------------------------------------ 页面

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        if not FRONTEND_FILE.is_file():
            raise HTTPException(status_code=404, detail="前端文件不存在")
        return FileResponse(FRONTEND_FILE, media_type="text/html; charset=utf-8")

    # ------------------------------------------------------------------ 自检

    @app.get("/api/health", response_model=HealthOut)
    def health() -> HealthOut:
        store: StateStore = app.state.store
        bus: Bus = app.state.bus
        vectors: VectorStore = app.state.vectors
        redis_ok = store.ping()
        kafka_ok = bus.ping()
        stats = vectors.stats()
        parsers = describe_parsers(settings)
        embedder = app.state.embedder
        llm = app.state.qa.llm
        return HealthOut(
            ok=redis_ok and kafka_ok,
            redis=redis_ok,
            kafka=kafka_ok,
            parser=parsers[0],
            embedder=embedder.describe(),
            llm=llm.describe(),
            documents=stats["documents"],
            chunks=stats["chunks"],
            extra={
                "redis_url": settings.redis_url,
                "kafka_bootstrap": settings.kafka_bootstrap_servers,
                "parse_topic": settings.kafka_topic_parse,
                "parsed_topic": settings.kafka_topic_parsed,
                "parsers": parsers,
            },
        )

    # ------------------------------------------------------------------ 文档

    @app.post("/api/documents", response_model=UploadOut)
    async def upload_documents(
        files: list[UploadFile] = File(..., description="一个或多个 PDF"),
    ) -> UploadOut:
        store: StateStore = app.state.store
        bus: Bus = app.state.bus

        if not files:
            raise HTTPException(status_code=400, detail="没有收到文件")
        if len(files) > settings.max_files_per_upload:
            raise HTTPException(
                status_code=400,
                detail=f"一次最多上传 {settings.max_files_per_upload} 个文件",
            )

        accepted: list[DocumentOut] = []
        rejected: list[dict[str, str]] = []

        for upload in files:
            filename = _safe_filename(upload.filename or "upload.pdf")
            if Path(filename).suffix.lower() not in _ALLOWED_SUFFIXES:
                rejected.append({"filename": filename, "reason": "只接受 PDF"})
                continue

            payload = await upload.read()
            if not payload:
                rejected.append({"filename": filename, "reason": "文件是空的"})
                continue
            if len(payload) > settings.max_upload_bytes:
                rejected.append(
                    {
                        "filename": filename,
                        "reason": f"超过 {settings.max_upload_bytes // 1024 // 1024} MB",
                    }
                )
                continue

            doc_id = new_id("doc")
            saved_path = settings.upload_path(doc_id, filename)
            saved_path.write_bytes(payload)

            meta = DocumentMeta(
                doc_id=doc_id,
                filename=filename,
                size=len(payload),
                status=DocStatus.PENDING,
            )
            store.save_doc(meta)
            accepted.append(DocumentOut.from_meta(meta))

            # 投 Kafka —— 后面的解析交给 Worker
            bus.publish_parse_request(
                ParseRequest(
                    doc_id=doc_id,
                    path=str(saved_path),
                    filename=filename,
                    size=len(payload),
                )
            )
            log.info("已接收 %s（%d 字节），投递解析任务", filename, len(payload))

        return UploadOut(accepted=accepted, rejected=rejected)

    @app.get("/api/documents", response_model=list[DocumentOut])
    def list_documents() -> list[DocumentOut]:
        store: StateStore = app.state.store
        return [DocumentOut.from_meta(meta) for meta in store.list_docs()]

    @app.get("/api/documents/{doc_id}", response_model=DocumentOut)
    def get_document(doc_id: str) -> DocumentOut:
        store: StateStore = app.state.store
        meta = store.get_doc(doc_id)
        if meta is None:
            raise HTTPException(status_code=404, detail="文档不存在")
        return DocumentOut.from_meta(meta)

    @app.delete("/api/documents/{doc_id}")
    def delete_document(doc_id: str) -> dict[str, Any]:
        store: StateStore = app.state.store
        vectors: VectorStore = app.state.vectors
        meta = store.get_doc(doc_id)
        if meta is None:
            raise HTTPException(status_code=404, detail="文档不存在")
        vectors.remove(doc_id)
        store.delete_doc(doc_id)
        # 图片也要删 —— 只删向量的话，data/images/ 会一直涨。
        shutil.rmtree(settings.image_dir / doc_id, ignore_errors=True)
        return {"deleted": doc_id}

    @app.get("/api/documents/{doc_id}/images/{filename}")
    def get_image(doc_id: str, filename: str) -> FileResponse:
        if "/" in filename or "\\" in filename or ".." in filename:
            raise HTTPException(status_code=400, detail="文件名不合法")
        path = settings.image_dir / doc_id / filename
        if not path.is_file():
            raise HTTPException(status_code=404, detail="图片不存在")
        media_type = mimetypes.guess_type(path.name)[0] or "image/png"
        return FileResponse(path, media_type=media_type)

    # ------------------------------------------------------------------ 问答

    @app.post("/api/chat")
    async def chat(
        question: str = Form(""),
        session_id: str = Form("default"),
        images: list[UploadFile] = File(default=[]),
    ) -> StreamingResponse:
        qa: QAService = app.state.qa

        saved_images: list[str] = []
        image_dir = settings.image_dir / session_id
        for upload in images:
            filename = _safe_filename(upload.filename or "image.png")
            payload = await upload.read()
            if not payload:
                continue
            if len(payload) > settings.max_upload_bytes:
                continue
            image_dir.mkdir(parents=True, exist_ok=True)
            target = image_dir / f"{new_id('img')}__{filename}"
            target.write_bytes(payload)
            saved_images.append(target.name)

        def event_stream() -> Iterator[str]:
            yield _sse({"type": "start", "data": {"question": question}})
            for event in qa.answer(question, session_id, saved_images):
                yield _sse(event.to_dict())
            yield _sse({"type": "end", "data": {}})

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    @app.post("/api/chat/json")
    def chat_json(payload: ChatTurnIn) -> StreamingResponse:
        """不走 SSE 的普通 JSON 版本（调试 / 脚本用）。"""

        qa: QAService = app.state.qa
        answer = ""
        sources: list[dict[str, Any]] = []
        for event in qa.answer(payload.question, payload.session_id, payload.images):
            if event.type == "delta":
                answer += event.data.get("text", "")
            elif event.type == "sources":
                sources = event.data.get("items", [])
            elif event.type == "error":
                return JSONResponse(status_code=500, content={"error": event.data})
        return JSONResponse(
            {"answer": answer, "sources": sources, "session_id": payload.session_id}
        )

    # ------------------------------------------------------------------ 会话

    @app.get("/api/sessions/{session_id}/history", response_model=HistoryOut)
    def history(session_id: str) -> HistoryOut:
        store: StateStore = app.state.store
        messages = store.history(session_id)
        return HistoryOut(
            session_id=session_id,
            messages=[
                HistoryMessageOut(
                    role=m.role,
                    content=m.content,
                    ts=m.ts,
                    images=list(m.images),
                    sources=list(m.sources),
                )
                for m in messages
            ],
        )

    @app.delete("/api/sessions/{session_id}")
    def clear_history(session_id: str) -> dict[str, Any]:
        store: StateStore = app.state.store
        return {"cleared": store.clear_chat(session_id)}

    return app


def _sse(payload: dict[str, Any]) -> str:
    """拼一个 SSE 事件。"""

    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


app = create_app()
