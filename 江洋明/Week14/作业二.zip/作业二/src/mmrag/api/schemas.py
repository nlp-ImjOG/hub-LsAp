"""API 的出参结构。

前端要显示的三态（待解析 / 解析中 / 解析完成）直接体现在
:class:`DocumentOut` 里 —— ``status`` 是中文原文，``status_code`` 是
给前端做样式用的英文代号（pending / parsing / done / failed）。
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from ..models import DocumentMeta


class DocumentOut(BaseModel):
    """一个文档的状态。"""

    doc_id: str
    filename: str
    size: int = 0
    #: 中文状态：待解析 / 解析中 / 解析完成 / 解析失败。
    status: str
    #: 英文代号，给前端做样式用。
    status_code: str
    backend: str = ""
    pages: int = 0
    chunks: int = 0
    images: int = 0
    error: str = ""
    created_at: int = 0
    updated_at: int = 0

    @classmethod
    def from_meta(cls, meta: DocumentMeta) -> "DocumentOut":
        return cls(
            doc_id=meta.doc_id,
            filename=meta.filename,
            size=meta.size,
            status=meta.status.value,
            status_code=meta.status.code,
            backend=meta.backend,
            pages=meta.pages,
            chunks=meta.chunks,
            images=meta.images,
            error=meta.error,
            created_at=meta.created_at,
            updated_at=meta.updated_at,
        )


class UploadOut(BaseModel):
    """上传结果。"""

    accepted: list[DocumentOut] = Field(default_factory=list)
    rejected: list[dict[str, str]] = Field(default_factory=list)


class HealthOut(BaseModel):
    """自检结果。"""

    ok: bool
    redis: bool
    kafka: bool
    parser: str
    embedder: str
    llm: str
    documents: int = 0
    chunks: int = 0
    extra: dict[str, Any] = Field(default_factory=dict)


class ChatTurnIn(BaseModel):
    """一次问答请求（JSON 版本）。"""

    question: str = ""
    session_id: str = "default"
    images: list[str] = Field(default_factory=list)


class HistoryMessageOut(BaseModel):
    role: str
    content: str
    ts: int
    images: list[str] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)


class HistoryOut(BaseModel):
    session_id: str
    messages: list[HistoryMessageOut] = Field(default_factory=list)
