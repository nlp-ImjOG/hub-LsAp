"""向量存储。

没有 faiss / chromadb，就用 numpy 自己写一个 —— **对作业这个规模完全够用**：

- 块数在几百到几千的量级，暴力点积一次也就几毫秒；
- 归一化向量之间，余弦相似度 = 点积，不用再算模长；
- 落盘成 ``.npy`` + ``.json``，进程重启后索引能直接重建。

目录布局::

    data/vectors/<doc_id>.npy     (n, 512) float32
    data/chunks/<doc_id>.json     块内容（含页码、图片）

**为什么按文档分文件？**

一个文档解析失败要能单独重试、单独删除；按文档分文件，
删文档就是删两个文件，不用重写整个索引。
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from .config import Settings, settings as default_settings
from .models import Chunk

log = logging.getLogger(__name__)


class VectorStore:
    """numpy 向量库。"""

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or default_settings
        self._chunks: dict[str, list[Chunk]] = {}
        self._vectors: dict[str, Any] = {}  # np.ndarray
        #: doc_id -> (mtime, size)，用来判断磁盘上的索引变没变。
        self._stamps: dict[str, tuple[float, int]] = {}

    # ------------------------------------------------------------------ 路径

    def _vector_path(self, doc_id: str) -> Path:
        return self._settings.vector_dir / f"{doc_id}.npy"

    def _chunk_path(self, doc_id: str) -> Path:
        return self._settings.chunk_dir / f"{doc_id}.json"

    # ------------------------------------------------------------------ 载入

    def load(self) -> None:
        """把磁盘上的索引同步进内存。

        **这不是一次性的快照** —— Worker 是另一个进程，它解析完会往磁盘上写
        新的 ``.npy``；服务端必须看得见，否则新上传的文档永远搜不到
        （踩过这个坑：服务一直开着，新文档解析完了，问答还是说「没找到相关内容」）。

        所以每次都扫一遍目录，只把**新增的**和**变过的**读进来，
        已经加载过且没动过的直接跳过 —— 增量同步，又不会漏。
        """

        import numpy as np

        self._settings.ensure_dirs()
        seen: set[str] = set()
        changed = 0
        for vector_file in sorted(self._settings.vector_dir.glob("*.npy")):
            doc_id = vector_file.stem
            seen.add(doc_id)
            try:
                stat = vector_file.stat()
            except OSError:  # pragma: no cover - 刚好被删
                continue
            stamp = (stat.st_mtime, stat.st_size)
            if self._stamps.get(doc_id) == stamp:
                continue  # 没变，内存里那份就是最新的
            try:
                matrix = np.load(vector_file)
            except Exception as exc:  # pragma: no cover - 坏文件
                log.warning("向量文件读不了 %s: %s", vector_file.name, exc)
                continue
            chunk_file = self._chunk_path(doc_id)
            chunks: list[Chunk] = []
            if chunk_file.is_file():
                try:
                    raw = json.loads(chunk_file.read_text(encoding="utf-8"))
                    chunks = [Chunk.from_dict(item) for item in raw]
                except Exception as exc:  # pragma: no cover - 坏文件
                    log.warning("块文件读不了 %s: %s", chunk_file.name, exc)
            self._vectors[doc_id] = matrix
            self._chunks[doc_id] = chunks
            self._stamps[doc_id] = stamp
            changed += 1

        # 磁盘上已经没有的（被删了）—— 内存里也去掉
        for doc_id in list(self._vectors):
            if doc_id not in seen:
                self._vectors.pop(doc_id, None)
                self._chunks.pop(doc_id, None)
                self._stamps.pop(doc_id, None)

        if changed:
            log.info(
                "向量索引已同步：%d 个文档 / %d 块（本次更新 %d 个）",
                len(self._vectors),
                sum(len(v) for v in self._chunks.values()),
                changed,
            )

    # ------------------------------------------------------------------ 写入

    def add(self, doc_id: str, chunks: list[Chunk], vectors: Any) -> None:
        """写入（或覆盖）一个文档的块和向量。"""

        import numpy as np

        self.load()
        matrix = np.asarray(vectors, dtype="float32")
        if matrix.ndim == 1:
            matrix = matrix.reshape(1, -1)
        if len(chunks) != matrix.shape[0]:
            raise ValueError(
                f"块数({len(chunks)})和向量数({matrix.shape[0]})对不上"
            )

        self._settings.ensure_dirs()
        # **先写块文件，再写向量文件** —— 向量文件的 mtime 当作「写完了」的标记。
        # 读的时候先看向量文件变没变（见 load），所以块文件一定先于它就位。
        self._chunk_path(doc_id).write_text(
            json.dumps([chunk.to_dict() for chunk in chunks], ensure_ascii=False),
            encoding="utf-8",
        )
        np.save(self._vector_path(doc_id), matrix)
        self._chunks[doc_id] = list(chunks)
        self._vectors[doc_id] = matrix
        stat = self._vector_path(doc_id).stat()
        self._stamps[doc_id] = (stat.st_mtime, stat.st_size)

    def remove(self, doc_id: str) -> bool:
        """删掉一个文档的索引。"""

        self.load()
        existed = doc_id in self._vectors
        self._chunks.pop(doc_id, None)
        self._vectors.pop(doc_id, None)
        self._stamps.pop(doc_id, None)
        for path in (self._vector_path(doc_id), self._chunk_path(doc_id)):
            try:
                path.unlink(missing_ok=True)
            except OSError:  # pragma: no cover - Windows 上文件被占用
                log.warning("删不掉 %s", path)
        return existed

    # ------------------------------------------------------------------ 检索

    def search(
        self, query_vector: Any, top_k: int = 5, doc_ids: list[str] | None = None
    ) -> list[tuple[Chunk, float]]:
        """按向量检索，返回 ``[(块, 相似度), ...]``。"""

        import numpy as np

        self.load()
        if not self._vectors:
            return []

        # 注意是 ``is not None`` 而不是 ``if doc_ids`` ——
        # 空的 doc_ids 表示「一个文档都没有」，不能当成「不限制」。
        wanted = set(doc_ids) if doc_ids is not None else None
        scores: list[tuple[Chunk, float]] = []
        for doc_id, matrix in self._vectors.items():
            if wanted is not None and doc_id not in wanted:
                continue
            if matrix.size == 0:
                continue
            chunks = self._chunks.get(doc_id, [])
            sims = matrix @ np.asarray(query_vector, dtype="float32")
            for index, chunk in enumerate(chunks):
                if index >= len(sims):
                    break
                scores.append((chunk, float(sims[index])))

        scores.sort(key=lambda item: item[1], reverse=True)
        return scores[: max(1, top_k)]

    def chunks_of(self, doc_id: str) -> list[Chunk]:
        self.load()
        return list(self._chunks.get(doc_id, []))

    def stats(self) -> dict[str, Any]:
        self.load()
        return {
            "documents": len(self._vectors),
            "chunks": sum(len(v) for v in self._chunks.values()),
            "vector_dir": str(self._settings.vector_dir),
        }

    def doc_ids(self) -> list[str]:
        self.load()
        return sorted(self._vectors)
