"""解析 Worker —— Kafka 消费者。

状态机就写在这里：

```
待解析 ──消费到消息──▶ 解析中 ──解析成功──▶ 解析完成
                        │
                        └──解析异常──▶ 解析失败（带错误信息）
```

**为什么单独一个进程？**

解析 PDF 是慢操作（渲染、抽图、切片、向量化），
放在 FastAPI 的请求线程里会把 Web 服务卡住。拆成独立进程后：

- Web 进程只管「收文件 + 投 Kafka + 显示状态」，永远快；
- Worker 进程可以随便重启、随便加并发；
- Kafka 天然做成了任务队列 —— 传 10 个 PDF 就是 10 条消息，排队慢慢解析。

**为什么状态写 Redis 而不是内存？**

Web 进程和 Worker 进程是两个进程，要让前端能实时看到「解析中」，
状态必须有一个两边都能读的地方。Redis 就是那个地方。
"""

from __future__ import annotations

import logging
import shutil
import time
from pathlib import Path
from typing import Any

from .bus import Bus, is_socket_race
from .chunker import chunk_document
from .config import Settings, settings as default_settings
from .embedder import Embedder
from .models import DocStatus, ParseRequest
from .parsers import MinerUParser, PyMuPDFParser, build_parser
from .parsers.base import ParsedDoc
from .store import StateStore
from .vector_store import VectorStore

log = logging.getLogger(__name__)


class ParseWorker:
    """消费 ``wk14.pdf.parse``，把文档解析完并向量化。"""

    def __init__(
        self,
        settings: Settings | None = None,
        store: StateStore | None = None,
        bus: Bus | None = None,
    ) -> None:
        self._settings = settings or default_settings
        self._store = store or StateStore(settings=self._settings)
        self._bus = bus or Bus(self._settings)
        self._embedder = Embedder(self._settings)
        self._vectors = VectorStore(self._settings)

    # ------------------------------------------------------------------ 主循环

    def run_forever(self, poll_timeout_ms: int = 1000) -> None:
        """常驻消费。Ctrl+C 退出。

        **不能因为一次 socket 竞态就整个挂掉** ——
        kafka-python-ng 在 Windows 上有个已知的竞态：连接被并发关掉时，
        ``poll()`` 会抛 ``ValueError: Invalid file descriptor: -1``。
        之前这个异常没人接，Worker 直接崩了（作业跑着跑着就没 worker 了）。
        现在捕获它、重建消费者、接着跑 —— Kafka 的「至少一次」语义保证
        没处理完的消息会重投，不会丢。
        """

        self._settings.ensure_dirs()
        self._bus.ensure_topics()
        self.prune_orphans()
        self.recover_pending()

        topic = self._settings.kafka_topic_parse
        group_id = self._settings.kafka_consumer_group
        log.info("Worker 开始消费 %s（消费组 %s）", topic, group_id)

        while True:
            try:
                self._consume_loop(topic, group_id, poll_timeout_ms)
            except ValueError as exc:
                if not is_socket_race(exc):
                    raise
                log.warning("Kafka socket 竞态，重建消费者后继续消费")
                time.sleep(1.0)

    def _consume_loop(
        self, topic: str, group_id: str, poll_timeout_ms: int
    ) -> None:
        """拿着一个消费者一直 poll。连接坏掉就抛出去，由上层重建。"""

        with self._bus.consume(
            topic,
            group_id=group_id,
            auto_offset_reset="earliest",
            timeout_ms=10_000,
        ) as consumer:
            while True:
                batches = consumer.poll(
                    timeout_ms=poll_timeout_ms,
                    max_records=self._settings.kafka_poll_max_records,
                )
                for _tp, records in batches.items():
                    for record in records:
                        self._safe_handle(record.value)
                # 手动提交位点：处理完才提交，保证「至少一次」
                try:
                    consumer.commit()
                except Exception as exc:  # pragma: no cover - 提交失败不致命
                    log.warning("提交位点失败: %s", exc)

    def run_once(self, timeout_ms: int = 5000) -> int:
        """拉一批消息处理掉就返回（给测试和 CLI 用）。

        处理通过 ``handler`` 交给 ``poll_once``，位点在处理完之后才提交 ——
        否则每次跑都会把同一批消息重新拉一遍。
        """

        self.prune_orphans()
        messages = self._bus.poll_once(
            self._settings.kafka_topic_parse,
            group_id=self._settings.kafka_consumer_group,
            timeout_ms=timeout_ms,
            handler=lambda item: self._safe_handle(item.get("value") or {}),
        )
        return len(messages)

    def prune_orphans(self) -> int:
        """清理「Redis 里已经没有、但磁盘上还留着」的僵尸文档。

        文档元信息有 TTL（默认 7 天），过期后 Redis 里的记录没了，
        磁盘上的向量、块和图片却还在。不清的话磁盘一直涨，
        而且检索可能引用到用户根本看不到的文档。

        返回清掉的文档数。
        """

        live = set(self._store.doc_ids())
        removed = 0
        for doc_id in self._vectors.doc_ids():
            if doc_id in live:
                continue
            self._vectors.remove(doc_id)
            shutil.rmtree(self._settings.image_dir / doc_id, ignore_errors=True)
            removed += 1
            log.info("清理了僵尸文档 %s 的索引和图片", doc_id)
        return removed

    def recover_pending(self) -> int:
        """服务重启后，把卡在「待解析」的文档重新投一遍。"""

        pending = self._store.pending_docs()
        for meta in pending:
            path = self._settings.upload_path(meta.doc_id, meta.filename)
            if not path.is_file():
                log.warning("待解析文档 %s 的文件没了，标失败", meta.doc_id)
                self._store.update_status(
                    meta.doc_id, DocStatus.FAILED, error="上传文件不存在"
                )
                continue
            self._bus.publish_parse_request(
                ParseRequest(
                    doc_id=meta.doc_id,
                    path=str(path),
                    filename=meta.filename,
                    size=meta.size,
                )
            )
            log.info("重新投递待解析文档 %s", meta.doc_id)
        return len(pending)

    # ------------------------------------------------------------------ 处理

    def _safe_handle(self, payload: dict[str, Any]) -> None:
        try:
            request = ParseRequest.from_dict(payload)
        except Exception as exc:  # pragma: no cover - 坏消息
            log.warning("解析不了的消息 %r: %s", payload, exc)
            return
        try:
            self.handle(request)
        except Exception as exc:
            # handle 内部已经记过日志了，这里只留一行摘要，别刷一屏堆栈。
            log.warning("处理 %s 失败：%s", request.doc_id, exc)

    def handle(self, request: ParseRequest) -> dict[str, Any]:
        """处理一个解析任务。"""

        doc_id = request.doc_id
        if self._store.get_doc(doc_id) is None:
            # 文档在排队期间被删了 —— 直接跳过。报 ERROR 没意义，
            # 用户确实不要这个文档了。
            log.info("文档 %s 已被删除，跳过解析", doc_id)
            return {"doc_id": doc_id, "status": "已删除", "skipped": True}

        self._store.update_status(doc_id, DocStatus.PARSING)
        log.info("开始解析 %s（%s）", doc_id, request.filename)

        try:
            parsed, backend = self._parse(request)
            chunks = chunk_document(parsed, self._settings)
            if chunks:
                vectors = self._embedder.encode([chunk.text for chunk in chunks])
                self._vectors.add(doc_id, chunks, vectors)
            meta = self._store.update_status(
                doc_id,
                DocStatus.DONE,
                backend=backend,
                pages=parsed.page_count,
                chunks=len(chunks),
                images=len(parsed.images),
            )
        except Exception as exc:
            log.exception("解析 %s 失败", doc_id)
            try:
                self._store.update_status(doc_id, DocStatus.FAILED, error=str(exc)[:500])
            except KeyError:
                # 解析期间文档被删了 —— 状态没地方写了，但错误还是要报出来。
                log.warning("文档 %s 已被删除，状态写不回去了", doc_id)
            self._publish_event(
                doc_id, {"doc_id": doc_id, "status": DocStatus.FAILED.value, "error": str(exc)[:500]}
            )
            raise

        payload = {
            "doc_id": doc_id,
            "filename": request.filename,
            "status": meta.status.value,
            "backend": backend,
            "pages": meta.pages,
            "chunks": meta.chunks,
            "images": meta.images,
            "finished_at": meta.updated_at,
        }
        self._publish_event(doc_id, payload)
        log.info(
            "解析完成 %s：%d 页 / %d 块 / %d 图（%s）",
            doc_id,
            meta.pages,
            meta.chunks,
            meta.images,
            backend,
        )
        return payload

    # ------------------------------------------------------------------ 解析

    def _parse(self, request: ParseRequest) -> tuple[ParsedDoc, str]:
        """解析 PDF；auto 模式下 MinerU 挂了就退回 PyMuPDF。"""

        path = Path(request.path)
        if not path.is_file():
            raise FileNotFoundError(f"上传的文件不存在：{path}")

        parser = build_parser(self._settings)
        try:
            return parser.parse(path, request.doc_id, request.filename), parser.name
        except Exception as exc:
            if parser.name != MinerUParser.name:
                raise
            if (self._settings.parser_backend or "auto").strip().lower() != "auto":
                raise
            log.warning("MinerU 解析失败，退回 PyMuPDF：%s", exc)
            fallback = PyMuPDFParser(self._settings)
            return (
                fallback.parse(path, request.doc_id, request.filename),
                f"{fallback.name}(mineru失败降级)",
            )

    def _publish_event(self, doc_id: str, payload: dict[str, Any]) -> None:
        try:
            self._bus.publish_parsed_event(doc_id, payload)
        except Exception as exc:  # pragma: no cover - 事件发不出去不该影响解析结果
            log.warning("解析完成事件发送失败 %s: %s", doc_id, exc)


def wait_for_document(
    store: StateStore, doc_id: str, timeout: float = 120.0, interval: float = 0.5
) -> Any:
    """等一个文档解析完（给脚本 / 测试用）。"""

    deadline = time.time() + timeout
    while time.time() < deadline:
        meta = store.get_doc(doc_id)
        if meta is not None and meta.status in {DocStatus.DONE, DocStatus.FAILED}:
            return meta
        time.sleep(interval)
    return store.get_doc(doc_id)
