@echo off
REM Week 14 homework 2 - start the FastAPI web service only.
REM Usage: start_server.bat
REM NOTE: this file MUST stay pure ASCII.
REM All Chinese messages live in scripts\launch.py.
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 goto no_python

python -X utf8 scripts\launch.py serve
goto done

:no_python
echo [ERROR] Python was not found in PATH.
echo         Install Anaconda or Python 3.10+, add it to PATH, retry.
pause
exit /b 1

:done
pause
