#!/usr/bin/env python
"""把两个 Skill 安装到 Claude Code 的技能目录。

Claude Code 从 ``~/.claude/skills/<name>/SKILL.md`` 读取个人技能。
本脚本把 ``作业一/skills/`` 下的两个 Skill 复制过去，并做一次**结构自检**
（frontmatter 的 name / description 是否齐备、references 是否完整）。

用法::

    python install_skills.py --list          # 只看会装什么
    python install_skills.py --dry-run       # 模拟安装，不写盘
    python install_skills.py                 # 装到 ~/.claude/skills/
    python install_skills.py --target ./.claude/skills   # 装到项目里

    # 装作业二那一版（带确定性脚本层）
    python install_skills.py --source ../作业二/skills --target ~/.claude/skills-esg-script
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

SKILLS_DIR = Path(__file__).resolve().parent / "skills"

#: 作业二 SKILL.md 里注入的脚本臂章节标题。纯方法臂里不该出现它。
SCRIPT_SECTION_MARKER = "## 确定性脚本层（脚本臂）"

REQUIRED_REFERENCES = {
    "esg-monthly-report": [
        "references/client-profile.md",
        "references/source-map.md",
        "references/esg-taxonomy.md",
        "references/keyword-matrix.md",
        "references/data-sources.md",
        "references/tool-usage.md",
        "assets/report-template.md",
    ],
    "esg-tender-monitor": [
        "references/keyword-matrix.md",
        "references/data-sources.md",
        "references/amount-parsing.md",
        "references/tool-usage.md",
        "assets/report-template.md",
    ],
}

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.S)


def parse_frontmatter(text: str) -> dict[str, str]:
    """解析 YAML frontmatter（只取顶层 key，够用）。"""
    match = FRONTMATTER_RE.match(text)
    if not match:
        return {}
    fields: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if not line.strip() or line.startswith((" ", "\t", "#")):
            continue
        key, _, value = line.partition(":")
        if key:
            fields[key.strip()] = value.strip().strip("\"'")
    return fields


def check_skill(skill_dir: Path) -> list[str]:
    """返回问题列表；空列表表示通过。"""
    problems: list[str] = []

    skill_md = skill_dir / "SKILL.md"
    if not skill_md.is_file():
        return [f"{skill_dir.name}: 缺少 SKILL.md"]

    text = skill_md.read_text(encoding="utf-8")
    front = parse_frontmatter(text)
    if not front:
        problems.append(f"{skill_dir.name}: SKILL.md 缺少 YAML frontmatter")
    else:
        if front.get("name") != skill_dir.name:
            problems.append(
                f"{skill_dir.name}: frontmatter 的 name 是 {front.get('name')!r}，"
                f"与目录名不一致"
            )
        if not front.get("description"):
            problems.append(f"{skill_dir.name}: frontmatter 缺 description")
        elif len(front["description"]) > 1024:
            problems.append(f"{skill_dir.name}: description 超过 1024 字符")

    for relative in REQUIRED_REFERENCES.get(skill_dir.name, []):
        if not (skill_dir / relative).is_file():
            problems.append(f"{skill_dir.name}: 缺少 {relative}")

    # 脚本层是**可选**的：作业一是纯方法臂（没有 scripts/），
    # 作业二才有 scripts/esg_toolkit。带了就必须带全。
    scripts_dir = skill_dir / "scripts"
    if scripts_dir.is_dir() and not (scripts_dir / "esg_toolkit" / "__init__.py").is_file():
        problems.append(f"{skill_dir.name}: scripts/ 存在但缺 esg_toolkit（先跑 build_skills.py）")

    return problems


def check_method_arm(skill_dir: Path) -> list[str]:
    """纯方法臂（作业一）的额外检查。

    A/B 的唯一变量是"有没有确定性脚本"。作业一这一臂必须**干净**：
    既不能带 ``scripts/`` 目录，SKILL.md 里也不能混进脚本臂的章节 ——
    否则两臂就不是"同一个方法 + 有无脚本"，对比结论不成立。
    """
    problems: list[str] = []
    if (skill_dir / "scripts").is_dir():
        problems.append(f"{skill_dir.name}: 纯方法臂不该有 scripts/ 目录")
    skill_md = skill_dir / "SKILL.md"
    if skill_md.is_file():
        text = skill_md.read_text(encoding="utf-8")
        if SCRIPT_SECTION_MARKER in text:
            problems.append(f"{skill_dir.name}: SKILL.md 混进了脚本臂章节")
    return problems


def install(source: Path, target: Path, dry_run: bool) -> list[str]:
    """复制一个 Skill 目录，返回被复制的文件相对路径。"""
    copied: list[str] = []
    destination = target / source.name
    for item in sorted(source.rglob("*")):
        if "__pycache__" in item.parts or item.suffix == ".pyc":
            continue
        relative = item.relative_to(source)
        dest = destination / relative
        if item.is_dir():
            if not dry_run:
                dest.mkdir(parents=True, exist_ok=True)
            continue
        copied.append(relative.as_posix())
        if dry_run:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, dest)
    return copied


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="把两个 Skill 安装到 Claude Code")
    parser.add_argument(
        "--source",
        default="",
        help="技能目录；默认 作业一/skills（纯方法臂）。"
        "装作业二那一版传 --source ../作业二/skills",
    )
    parser.add_argument("--target", default="", help="目标目录；默认 ~/.claude/skills")
    parser.add_argument("--dry-run", action="store_true", help="只演示不写盘")
    parser.add_argument("--list", action="store_true", help="只列出自检结果")
    args = parser.parse_args(argv)

    source_dir = Path(args.source).resolve() if args.source else SKILLS_DIR
    #: 只有作业一那一臂是"纯方法臂"，需要额外检查没有脚本残留
    is_method_arm = source_dir == SKILLS_DIR.resolve()

    if not source_dir.is_dir():
        print(f"找不到技能目录：{source_dir}", file=sys.stderr)
        return 1

    skill_dirs = sorted(p for p in source_dir.iterdir() if p.is_dir())
    if not skill_dirs:
        print(f"{source_dir} 下没有技能", file=sys.stderr)
        return 1

    problems: list[str] = []
    for skill_dir in skill_dirs:
        found = check_skill(skill_dir)
        if is_method_arm:
            found.extend(check_method_arm(skill_dir))
        problems.extend(found)
        status = "OK" if not found else f"{len(found)} 个问题"
        arm = "（纯方法臂）" if is_method_arm else "（脚本臂）"
        print(f"[自检] {skill_dir.name}{arm}: {status}")
        for problem in found:
            print(f"    ! {problem}")

    if args.list:
        return 1 if problems else 0

    target = Path(args.target) if args.target else Path.home() / ".claude" / "skills"
    target.mkdir(parents=True, exist_ok=True)

    for skill_dir in skill_dirs:
        copied = install(skill_dir, target, args.dry_run)
        prefix = "[试运行] " if args.dry_run else ""
        print(f"{prefix}安装 {skill_dir.name} → {target / skill_dir.name}（{len(copied)} 个文件）")

    if problems:
        print(f"\n有 {len(problems)} 处问题，建议先修掉再安装。", file=sys.stderr)
        return 1

    print(f"\n完成。在 Claude Code 里输入 /{skill_dirs[0].name} 或直接提需求即可触发。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
