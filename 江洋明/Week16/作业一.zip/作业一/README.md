# 作业一 · 两个 ESG Agent Skill

按《作业.txt》案例一、案例二构建的两个 **Agent Skill**：

| Skill | 对应案例 | 产出 |
| --- | --- | --- |
| `esg-monthly-report` | 案例一 · ESG 月报 | 客户（中国神华）上一个自然月的 ESG 月报，三板块齐全 |
| `esg-tender-monitor` | 案例二 · ESG 招投标汇总与监控 | 近 2 年中标汇总（热点方向 + 金额分布）+ 每日增量推送 |

两个 Skill **不依赖任何脚本** —— 检索、筛选、抽取、归类、统计全部由模型用
WebSearch / WebFetch 亲手完成。这是作业二对比实验的**对照组**。

---

## 一、怎么用

### 1. 安装到 Claude Code

```bash
cd "16-江洋明-第十六周作业/作业一"

python install_skills.py --list       # 先自检
python install_skills.py              # 装到 ~/.claude/skills/
```

装完在 Claude Code 里直接提需求即可，例如：

- "请生成中国神华 2026 年 10 月的 ESG 月报。"
- "汇总近 2 年双碳相关的招标中标情况，分析热点方向与中标金额分布。"

也可以显式调用：`/esg-monthly-report`、`/esg-tender-monitor`。

装到项目里而不是全局：

```bash
python install_skills.py --target ./.claude/skills
```

### 2. 不想装，直接看

两个 Skill 的全部内容就是两个目录，直接读也行：

```
skills/esg-monthly-report/
├── SKILL.md                     方法层（手写，是唯一真相来源）
├── references/                  检索式、关键词矩阵、信源分级、议题分类法、客户档案
└── assets/report-template.md    报告骨架
```

---

## 二、目录结构

```
作业一/
├── README.md                    本文件
├── requirements.txt             零第三方依赖（刻意为之，见文件内说明）
├── .gitignore
├── install_skills.py            安装 + 结构自检
├── docs/
│   ├── 01-设计说明.md           整体设计（含 §6 对比实验设计）
│   ├── 02-功能设计文档.md
│   ├── 03-技术设计文档.md
│   └── screenshots/             交付证据：纯方法臂报告的整页图 + 分屏图
└── skills/
    ├── esg-monthly-report/
    └── esg-tender-monitor/
```

`skills/` 下的 `references/` 与 `assets/` 是**生成物** —— 由
`../作业二/scripts/build_skills.py` 从确定性脚本层同步过来，
保证 Skill 里写的口径和脚本实际行为不会各说各话。改口径要改脚本层，
然后重新跑生成脚本：

```bash
python ../作业二/scripts/build_skills.py
python ../作业二/scripts/build_skills.py --check    # 只检查是否同步
```

`SKILL.md` 是**手写**的，也是两臂方法的唯一真相来源：作业二那份 SKILL.md
就是在它末尾注入「确定性脚本层」一节生成的。

---

## 三、两个 Skill 各自做了什么

### `esg-monthly-report` · ESG 月报

- **时间窗**：上一个**自然月**（不是"最近 30 天"），口径固定才能跨月比；
- **三板块**：ESG 政策/评级/标准动态 → 行业动态与最佳实践 → 公司动态、
  对标企业行动与建议；
- **筛选的硬条件**：在时间窗内 + 与 ESG 真相关 + 对客户有信息量。
  第三条最容易忽略，也是月报质量的分水岭；
- **每条必须带来源链接**，写不出链接说明没核实过，删掉。

### `esg-tender-monitor` · ESG 招投标汇总与监控

- **汇总**：近 2 年 → 金额分档、月度走势、热点方向、地区与采购人分布；
- **监控**：每天找出**新出现**的 ESG 相关招标公告并推送；
- **第一规矩**：宁可漏，不要猜 —— 解析不出金额就写「—」，不拿预算当中标，
  不把"未披露"填成 0。

---

## 四、与作业二的关系

作业二把上面这些**可写成规则的活**沉淀成确定性脚本（公告字段抽取、金额单位
换算、日期补零、URL 去重、金额分档与热点统计），然后在**同一批真实任务**上
跑有脚本 / 无脚本两条臂做对比。

方法层（SKILL.md 正文、检索式、分类矩阵）在两臂里**逐字一致**，
搜索后端也**是同一个**（`claude -p` 自带的 WebSearch），
所以实验里唯一变化的变量是"抽取与聚合由谁完成"。

```bash
cd ../作业二
python bench/run_ab.py          # 12 次真实运行 + 盲评
```

实测结论一句话（详见 `../作业二/README.md` §六）：

> **脚本层买到的不是"抽得准"，是"算不错、跑得完、对得上"，
> 但它同时压低了"想得深"。**
> 中标金额准确率两臂**都 100%**；分档表自洽 **B 3/3 / A 0/2**；
> 盲评洞见分 **A 5.00 / B 4.20**；纯方法臂在招投标那条 prompt 上
> **六次尝试、烧掉 \$40.68 没跑出来**。
>
> 而且"对得上"还得**分两层看**：三次脚本臂跑批里，
> 报告照抄记录的偏差 **全是 0**（成稿没篡改数字），
> 但第二层对账查出 **5 条记录自相矛盾** ——
> 公告总额配上了单个合同包的中标单位，或者原始金额只留下一部分。
> **报告没改数字，但数字一开始就是错的。**
>
> **纯方法臂留了 180 行工作底稿，第二层查出 0 条不自洽** ——
> 它的记录反而是干净的，错的是"底稿跟成稿不是同一份数据"。
> 两臂各错一半，错的还不是同一半。
>
> 修法不是"再加功能"，而是**把不可协商的事实交给代码，
> 把需要判断的推演留给模型，中间再加一道两层的对账**。

对比数字见 `../作业二/bench/results/ab-report.md`（自动生成）。

---

## 五、交付证据（截图）

作业的交付物本体是**截图** —— 能跑不等于交作业。本目录的证据是
**纯方法臂**真实跑出来的报告（作业二 A/B 实验的对照组）：

| 文件 | 内容 |
|---|---|
| `docs/screenshots/armA-monthly-p1.jpg` | ESG 月报（纯方法臂）整页图（缩到 820px 宽的 JPEG —— 整页两万像素高，PNG 要 15MB） |
| `docs/screenshots/armA-monthly-p1-1.png` … `-6.png` | 同一份报告的分屏图（整页太长，缩到一张里看不清字） |
| `docs/screenshots/armA-tender-p3.jpg` | 招投标汇总（纯方法臂）整页图 |
| `docs/screenshots/armA-tender-p3-1.png` … `-10.png` | 同一份报告的分屏图（这条 prompt 跑了 185 条明细，比月报长得多） |
| `docs/screenshots/armA-tender-p1-第6次补跑.jpg` | **失败现场**：`tender-p1-A` 第 6 次补跑被 3600s 超时掐断时的报告 |
| `docs/screenshots/armA-tender-p1-第6次补跑-1.png` … `-7.png` | 同一份的分屏图；第 7 屏就是**掐断的位置** |

**配对的脚本臂截图**在 `../作业二/docs/screenshots/`，
用的是**同一条 prompt**（`p1` / `p3`），可以直接对照：

| 纯方法臂（A） | 脚本臂（B） | 同一条 prompt |
|---|---|---|
| `armA-monthly-p1.*` | `armB-monthly-p1.*` | `monthly-p1` |
| `armA-tender-p3.*` | `armB-tender-p3.*` | `tender-p3` |
| `armA-tender-p1-第6次补跑.*`（残篇） | `armB-tender-p1.*` | `tender-p1`（A 臂这条没跑出来） |

这些报告**不是手工编的**：它们是 `../作业二/bench/run_ab.py` 用 `claude -p`
真跑出来的原始产物（`../作业二/bench/runs/<run_id>/report.txt`），
经 `../作业二/scripts/md2html.py` 转成 HTML 后截图。

> **为什么招投标的截图是 `p3` 而不是 `p1`**：`tender-p1-A`（纯方法臂的第一条
> 招投标 prompt）**六次都没跑出来** —— 超时两次、API 报错两次、预算耗尽一次、
> 会话中断一次，合计烧掉 $40.68。`p3` 是同一臂、同一案例的另一次真实运行，
> 跑成了，所以拿它当交付证据。失败的尝试没有被抹掉，记在
> `../作业二/bench/_attempts/` 和 `../作业二/README.md` §6.3。
> 这本身就是一个发现：**纯方法臂在招投标这种"要翻很多页、要算"的活上，
> 不只是慢，是可能根本交不出来。**
>
> **第 6 次掐在哪，看第 7 屏截图就明白**：摘要、金额分档、月度走势、
> 热点方向、地区分布、采购人类型分布**全写完了**，
> 断在「三、中标明细 → 3.1 咨询/服务/技术类」的小节标题上，
> **136 行明细表一行没写**。更早一次超时恰好相反 —— 明细表写完了，
> 分析全是「（占位）」。两次都是同一个结论：**3600s 不够**。
>
> 第 6 次那次还留下了 **180 行工作底稿**（`.work/dataset*.md`），
> 拿它对账查出 3 条结论：底稿**条条自洽**（0/180 自相矛盾）、
> 报告的聚合表**从底稿复现不出来**（14 个月对不上）、
> 同一条分包公告**纯方法臂做对了、脚本臂做错了**。
> 见 `../作业二/README.md` §6.3 发现六。

转出来的页面**刻意跟脚本臂用同一套 CSS** —— 两臂截图放一起看，
读者比较的是**内容**，不是排版。

自己重跑一遍：

```bash
cd ../作业二
python bench/run_ab.py --arms A            # 只跑纯方法臂
python scripts/md2html.py \
    --input bench/runs/monthly-p1-A/report.txt \
    --out output/sample/armA-monthly-p1.html --title "ESG 月报（纯方法臂）"
python scripts/screenshot.py \
    --input output/sample/armA-monthly-p1.html \
    --out ../作业一/docs/screenshots --slices 6

# 招投标那份（p3，185 条明细，分屏切 10 屏）
python scripts/md2html.py \
    --input bench/runs/tender-p3-A/report.txt \
    --out output/sample/armA-tender-p3.html --title "ESG 招投标汇总（纯方法臂）"
python scripts/screenshot.py \
    --input output/sample/armA-tender-p3.html \
    --out ../作业一/docs/screenshots --slices 10
```

> 整页图默认压成 JPEG（`--full-page-max-width 820`）：原始 PNG 有 15MB，
> 压完 1.8MB —— 交付证据要进仓库，尺寸得对得起仓库。
> 分屏图保持 PNG（要能读）。

---

## 六、提交须知

- 本目录**不是 git 仓库**，提交走 GitHub 网页端 Pull Request；
- 提交记录里**必须写真实姓名**；
- 截止时间是每周**周四 24:00 前**；
- 不要把 `.env` 或真实 API key 放进仓库 —— 本目录本来也用不到 key
  （检索走 Claude Code 自带的 WebSearch）。
