# 信源地图与分级

> 本文件由 `作业二/scripts/build_skills.py` 从 `esg_toolkit/keywords.py` 自动生成，
> **不要手工编辑**。

## 一、分级口径

分级只影响**排序**，不影响**取舍** —— D 级信源里也可能有唯一的官方口径。

- **A**：监管与官方（政策原文、交易所指引、政府公告）
- **B**：主流财经媒体（证券时报、中国证券报、经济观察报等）
- **C**：行业媒体与商业资讯（东方财富、搜狐财经等）
- **D**：其他（个人博客、聚合站、转载页）

## 二、域名规则

| 域名包含 | 级别 |
| --- | --- |
| `gov.cn` | A |
| `ccgp.gov.cn` | A |
| `ggzy` | A |
| `mee.gov.cn` | A |
| `ndrc.gov.cn` | A |
| `csrc.gov.cn` | A |
| `sse.com.cn` | A |
| `szse.cn` | A |
| `sac.gov.cn` | A |
| `pbc.gov.cn` | A |
| `chinabond.com.cn` | A |
| `sasac.gov.cn` | A |
| `cninfo.com.cn` | A |
| `hkexnews.hk` | A |
| `shenhuachina.com.cn` | A |
| `chnenergy.com.cn` | A |
| `xinhuanet.com` | B |
| `people.com.cn` | B |
| `chinanews.com.cn` | B |
| `cnstock.com` | B |
| `stcn.com` | B |
| `cs.com.cn` | B |
| `21jingji.com` | B |
| `caixin.com` | B |
| `yicai.com` | B |
| `jiemian.com` | B |
| `thepaper.cn` | B |
| `cls.cn` | B |
| `sina.com.cn` | B |
| `163.com` | B |
| `qq.com` | B |
| `sohu.com` | C |
| `eastmoney.com` | C |
| `wind.com.cn` | C |
| `hexun.com` | C |
| `chinanews.com` | B |

## 三、常用站点

| 站点 | 用途 | 抓取注意 |
| --- | --- | --- |
| 中国政府采购网 `ccgp.gov.cn` | 全国政府采购公告 | 裸 UA 会 403，必须带 Referer 重试 |
| 各级公共资源交易中心 `ggzy.*.gov.cn` | 工程与服务招标中标公告 | 页面多为两列 key-value 表格 |
| 各省生态环境厅 `*.sthjt.*.gov.cn` | 政策文件、处罚公告 | 部分站点为 GBK 编码 |
| 生态环境部 `mee.gov.cn` | 全国性政策、碳市场 | 中央政策首选信源 |
| 国家发改委 `ndrc.gov.cn` | 碳达峰碳中和政策原文 | 中央政策首选信源 |
| 上交所/深交所 `sse.com.cn` `szse.cn` | 可持续发展报告指引、ESG 披露 | 需带浏览器 UA |
| 巨潮资讯 `cninfo.com.cn` | 上市公司公告原文 | 定期报告主入口 |
| 中国神华 `shenhuachina.com.cn` | 客户公司动态、ESG 报告 | 官网新闻栏目 |
