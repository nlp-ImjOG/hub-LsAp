#!/usr/bin/env python
"""成稿对账：把报告明细表里的数字，跟脚本层的结构化输出逐行核对。

**对账要分两层**（这是 A/B 实验跑出来的真实发现）。

第一层 · 报告 vs 记录：报告有没有**照抄**记录？
第二层 · 记录 vs 自身：记录**本身**对不对？

只做第一层会踩一个很深的坑 —— **报告没改数字，但数字一开始就是错的**。

实测（``tender-p3-B`` 的西安那条记录）::

    amount_yuan = 2,968,000         公告披露的总中标金额
    amount_raw  = "1,188,000.00元"   合同包 1 的金额
    winner      = 中节能咨询有限公司  合同包 1 的中标单位

原公告（中国政府采购网 2026-07-02）确实是三个合同包：

======================  ==========================  ================
合同包                   中标单位                      金额
======================  ==========================  ================
合同包 1                 中节能咨询有限公司             1,188,000.00 元
合同包 2                 中国启源工程设计研究院有限公司   1,200,000.00 元
合同包 3                 中国科学院地球环境研究所       580,000.00 元
**公告总中标金额**        ——                           **￥296.800000 万元**
======================  ==========================  ================

抽取时 ``amount_yuan`` 取了**公告总额**，``amount_raw`` 和 ``winner``
却只取到了**合同包 1**。报告如实照抄了它 —— 于是明细表里出现一行
「总中标金额 296.80 万元 / 中标单位 中节能咨询有限公司」，
读起来像这家单位独拿了全部 296.80 万。

**第一层是全绿的**（报告确实一字不差地照抄了记录），
**第二层才把它抓出来**。

而且同一条公告在另一次跑批（``tender-p2-B``）里是**对的** ——
同一套方法、同一批工具，换一次运行结果就不一样。
脚本层不保证自己对，它只是让"对"变成可能；真正兜住的是这道对账。

用法::

    python scripts/verify_report.py \\
        --report output/tender/esg-tender-20261127.md \\
        --data   output/tender/esg-tender-20261127.json

    # 只看结论（退出码：0 = 全部对得上，1 = 有出入）
    python scripts/verify_report.py --report r.md --data r.json --quiet

为什么放在 ``scripts/`` 而不是 ``scripts/esg_toolkit/``：
``scripts/esg_toolkit/`` 是**被测的**确定性工具层，它的内容哈希进
跑批指纹（``bench/run_ab.py:toolkit_fingerprint``）。
在跑批期间往里加文件，会让先后启动的两次运行用的不是同一版脚本层，
对比就不成立。所以对账工具放在外层，跑批结束后再决定要不要并进去。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from esg_toolkit.cli import force_utf8  # noqa: E402

#: 金额单位 → 换算成「元」的倍数。
_AMOUNT_SCALE = {"亿元": 1e8, "万元": 1e4, "千元": 1e3, "元": 1.0}

#: 数字 + **紧跟其后**的单位。
#:
#: 单位必须紧跟：「74.6万元」是金额，「包7」里的 7 是标段编号。
_AMOUNT_TOKEN_RE = re.compile(r"(?P<num>\d[\d,]*(?:\.\d+)?)\s*(?P<unit>亿元|万元|千元|元)?")

#: 表头里带单位的列（「中标金额（万元）」）—— 格子是纯数字时要靠它。
_UNIT_HEADER_RE = re.compile(r"(亿元|万元|千元)")

#: Markdown 链接的行内写法：``[标题](链接)``
_MD_LINK_RE = re.compile(r"\[(?P<title>[^\]]*)\]\((?P<url>[^)]*)\)")

#: 相对误差 0.5% 以内算相等 —— 公告里同一个金额有「116.6 万元」
#: 和「1,166,000.00 元」两种写法。
_REL_TOLERANCE = 0.005


def _norm(text: str) -> str:
    """归一化：去链接语法、去空白、去装饰符号。

    标题匹配必须稳 —— 报告里写的是「[某某项目](https://…)」，
    脚本 JSON 里写的是「某某项目」，直接比是比不上的。
    """
    text = _MD_LINK_RE.sub(lambda m: m.group("title"), str(text or ""))
    text = re.sub(r"[#*`\[\]()（）「」【】·—\-_|/\\]", "", text)
    return re.sub(r"\s+", "", text)


def _extract_url(text: str) -> str:
    """从单元格里取出链接（没有就返回空串）。"""
    match = _MD_LINK_RE.search(str(text or ""))
    return match.group("url").strip() if match else ""


def parse_markdown_tables(text: str) -> list[dict[str, Any]]:
    """把 Markdown 里的表格都解析出来。

    返回 ``[{"header": [...], "rows": [[...], ...]}, ...]``。
    只认「表头行 + 分隔行」才算一张表 —— 分隔行是 ``| --- | :--- |`` 这种。
    """
    tables: list[dict[str, Any]] = []
    lines = str(text or "").splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        if not (line.startswith("|") and line.endswith("|")):
            index += 1
            continue
        header = _split_row(line)
        # 表头下一行必须是分隔行，否则这不是一张表（是正文里的竖线）
        if index + 1 >= len(lines):
            break
        separator = lines[index + 1].strip()
        if not (separator.startswith("|") and separator.endswith("|")):
            index += 1
            continue
        if not all(re.fullmatch(r":?-{2,}:?", cell.strip()) for cell in _split_row(separator) if cell.strip()):
            index += 1
            continue
        rows: list[list[str]] = []
        cursor = index + 2
        while cursor < len(lines):
            candidate = lines[cursor].strip()
            if not (candidate.startswith("|") and candidate.endswith("|")):
                break
            rows.append(_split_row(candidate))
            cursor += 1
        tables.append({"header": header, "rows": rows})
        index = cursor
    return tables


def _split_row(line: str) -> list[str]:
    """把一行 ``|a|b|c|`` 拆成 ``['a','b','c']``。"""
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def _pick_detail_table(tables: list[dict[str, Any]]) -> dict[str, Any] | None:
    """挑出「中标明细」那张表。

    报告里往往有好几张表：金额分档、热点方向、地区分布、中标明细。
    认表的条件是**同时**有项目名列、金额列、日期列 ——
    只看「有金额列」会把「500–1000 万 / 条数 / 占比」那张分档表当成明细表
    （实测踩过：于是把「500–1000 万」当成了金额）。
    """
    best: dict[str, Any] | None = None
    best_rows = -1
    for table in tables:
        header = table["header"]
        if any("档" in cell or "区间" in cell or "典型" in cell for cell in header):
            continue
        has_title = any("项目" in cell or "名称" in cell for cell in header)
        has_amount = any("金额" in cell for cell in header)
        has_date = any("日期" in cell or "时间" in cell for cell in header)
        if not (has_title and has_amount and has_date):
            continue
        if len(table["rows"]) > best_rows:
            best, best_rows = table, len(table["rows"])
    return best


def parse_amount_cell(cell: str, header: str = "") -> list[float]:
    """把一格里的**所有**金额读出来（单位：自带 > 表头 > 元）。

    与 ``bench/run_ab.py`` 的口径保持一致 —— 同一个量，两处量出来
    不能不一样。
    """
    text = str(cell or "").strip()
    if not text or text in {"—", "-", "未披露", "/", "N/A"}:
        return []
    if re.search(r"\d+(?:\.\d+)?\s*%", text):
        return []
    with_unit: list[tuple[float, str]] = []
    bare: list[float] = []
    for match in _AMOUNT_TOKEN_RE.finditer(text):
        try:
            value = float(match.group("num").replace(",", ""))
        except ValueError:
            continue
        unit = match.group("unit") or ""
        if not unit:
            prefix = text[: match.start()].rstrip()
            if prefix and prefix[-1] in "￥¥":
                unit = "元"
        if unit:
            with_unit.append((value, unit))
        else:
            bare.append(value)
    if with_unit:
        return [value * _AMOUNT_SCALE[unit] for value, unit in with_unit]
    if not bare:
        return []
    unit_match = _UNIT_HEADER_RE.search(header or "")
    unit = unit_match.group(1) if unit_match else "元"
    return [value * _AMOUNT_SCALE[unit] for value in bare]


#: 标段编号的前缀。「包1 1188000」里的 1 是**标段号**，不是金额。
_PACKAGE_LABEL_RE = re.compile(r"(?:包|标段|分标|段|第)\s*$")

#: 自查用的金额 token —— 比 ``_AMOUNT_TOKEN_RE`` 多认「万」「亿」单字，
#: 也多认「32.800000 (万元)」这种**单位写在括号里**的写法。
#:
#: 「万」「亿」单字只在紧跟数字时才认（「8万」= 8 万元），
#: 否则「万家」之类会误伤。
_SELF_TOKEN_RE = re.compile(
    r"(?P<num>\d[\d,]*(?:\.\d+)?)\s*(?P<unit>亿元|万元|千元|元|亿|万|千)?"
)

#: 自查时允许的单位档位。``amount_raw`` 里如果**没写单位**
#: （「79」「170.98」），单位只能从表头来 —— 那就全都试一遍。
_SELF_SCALES = (1.0, 1e3, 1e4, 1e8)

#: 单位单字的换算。
_SELF_UNIT_SCALE = {"亿元": 1e8, "万元": 1e4, "千元": 1e3, "元": 1.0,
                    "亿": 1e8, "万": 1e4, "千": 1e3}


def _self_tokens(text: str) -> list[tuple[float, str | None]]:
    """把一段文字拆成 ``(数值, 单位或 None)`` 的列表。

    三件事要处理：

    - **标段编号不是金额**：「包1 1188000」里的 1 要剔掉，
      否则求和口径会多算 1+2+3。
    - **日期不是金额**：「2026年11月」里的 2026 要剔掉。
    - **单位可能写在括号里**：「32.800000 (万元)」——数字后面没有单位，
      这时单位只能从上下文找，找不到就当"单位未知"。
    """
    text = str(text or "")
    tokens: list[tuple[float, str | None]] = []
    for match in _SELF_TOKEN_RE.finditer(text):
        prefix = text[: match.start()].rstrip()
        if _PACKAGE_LABEL_RE.search(prefix):
            continue  # 标段编号
        try:
            value = float(match.group("num").replace(",", ""))
        except ValueError:
            continue
        unit = match.group("unit") or None
        if unit is None:
            tail = text[match.end():].lstrip()
            head = tail[:1]
            if head and head in "年月日号":
                continue  # 日期
            if head == "%":
                continue  # 百分比
            if prefix and prefix[-1] in "￥¥":
                unit = "元"
        tokens.append((value, unit))
    return tokens


#: 「单价 × 数量」型口径。碳汇、垃圾清运、用电量这类公告**不写总价**，
#: 写的是「151元/吨×582.68吨」—— 乘积才是金额。
#:
#: 少了这一条，碳汇那条记录会被误判成"自相矛盾"
#: （实测踩过：151 × 582.68 = 87,984.68，金额本来就是对的）。
_SELF_PRODUCT_RE = re.compile(
    r"(?P<a>\d[\d,]*(?:\.\d+)?)\s*(?P<au>亿元|万元|千元|元)?\s*"
    r"(?:/[^×x*\s]+)?\s*[×x*]\s*"
    r"(?P<b>\d[\d,]*(?:\.\d+)?)"
)


def _self_product_candidates(text: str) -> list[float]:
    """``amount_raw`` 里「单价 × 数量」能表示出的金额（都换算成元）。"""
    candidates: list[float] = []
    for match in _SELF_PRODUCT_RE.finditer(str(text or "")):
        try:
            left = float(match.group("a").replace(",", ""))
            right = float(match.group("b").replace(",", ""))
        except ValueError:
            continue
        unit = match.group("au")
        if unit:
            candidates.append(left * right * _SELF_UNIT_SCALE[unit])
        else:
            for scale in _SELF_SCALES:
                candidates.append(left * right * scale)
    return candidates


def _self_candidates(tokens: list[tuple[float, str | None]]) -> list[float]:
    """``amount_raw`` 能表示出的**所有合理金额**（都换算成元）。

    口径有几套，都要留着：

    - 带单位的：单位已定，单个数、以及它们**加起来**（分包总额）都算；
    - 没带单位的：单位未知，元 / 千元 / 万元 / 亿元**四种都试**，
      单个数、以及它们加起来都算。

    所以「包1 1188000＋包2 1200000＋包3 580000（元）＝296.80万元」能表示出
    2,968,000（总额口径）和 2,968,000（分包求和口径），
    「79」也能表示出 790,000（表头是万元）。
    """
    explicit = [value * _SELF_UNIT_SCALE[unit] for value, unit in tokens if unit]
    bare = [value for value, unit in tokens if not unit]
    candidates: list[float] = []
    if explicit:
        candidates.extend(explicit)
        candidates.append(sum(explicit))
    if bare:
        for scale in _SELF_SCALES:
            candidates.extend(value * scale for value in bare)
            candidates.append(sum(bare) * scale)
    return candidates


def _close(left: float, right: float | None) -> bool:
    """两个金额是否相等（相对误差 0.5%）。"""
    if right is None:
        return False
    return abs(left - right) < max(1.0, abs(right) * _REL_TOLERANCE)


def _same_text(left: str, right: str) -> bool:
    """两个文本是否指同一个东西（归一化后比较，忽略全角半角差异）。"""
    if not right:
        return True
    return _norm(left) == _norm(right)


def record_self_check(record: dict[str, Any]) -> list[str]:
    """**记录自己**有没有自相矛盾。

    这是实测踩出来的坑。``tender-p3-B`` 那条记录长这样：

    - ``amount_yuan`` = 2,968,000（公告披露的**总**中标金额）
    - ``amount_raw``  = "1,188,000.00元"（**合同包 1** 的金额）
    - ``winner``      = 中节能咨询有限公司（**合同包 1** 的中标单位）

    三个字段摆在一起就是矛盾的：总额配单包单位。
    报告如实照抄了这条记录，于是"对账"全绿 —— **报告没改数字，
    但数字一开始就是错的**。

    所以对账要分两层：
    **报告有没有照抄记录**（对账），和 **记录本身对不对**（自洽）。
    只做前一层，会把"抄得一模一样"当成"没问题"。

    判定方法：把 ``amount_raw`` 能表示的金额全列出来（见
    ``_self_candidates`` 与 ``_self_product_candidates``），
    ``amount_yuan`` 落不进去就是自相矛盾。

    「单价 × 数量」也是一种口径：碳汇、垃圾清运这类公告不写总价，
    写「151元/吨×582.68吨」，乘积才是金额 —— 少了这一条会把它误判成矛盾。
    """
    problems: list[str] = []
    expected = record.get("amount_yuan")
    if expected is None:
        return problems
    raw = str(record.get("amount_raw") or "").strip()
    if not raw:
        return problems
    tokens = _self_tokens(raw)
    candidates = _self_candidates(tokens)
    #: 「单价 × 数量」型口径（碳汇、垃圾清运这类不写总价的公告）
    candidates.extend(_self_product_candidates(raw))
    if not candidates:
        return problems
    expected = float(expected)
    if any(_close(value, expected) for value in candidates):
        return problems
    nearest = min(candidates, key=lambda value: abs(value - expected))
    problems.append(
        f"记录自相矛盾：amount_yuan {expected:,.0f} 元 "
        f"在 amount_raw「{raw}」里找不到对应口径"
        f"（最接近的是 {nearest:,.0f} 元）"
    )
    return problems


def verify(report_text: str, data: Any) -> dict[str, Any]:
    """对账：报告明细表 vs 脚本 JSON。

    返回 ``{"总行数", "对得上", "对不上", "对不上明细", "脚本有报告没写", ...}``，
    外加 ``记录自洽`` 一层 —— 见 :func:`record_self_check`。

    ``data`` 两种形态都收：脚本的产物（``{"records": [...]}``）
    和跑批落盘的纯记录数组（``[...]``）—— 后者方便直接拿
    ``bench/runs/<run_id>/**/records.json`` 对账，不用先转一道。
    """
    if isinstance(data, list):
        records = list(data)
    else:
        records = list((data or {}).get("records") or [])
    by_url: dict[str, dict] = {}
    by_title: dict[str, dict] = {}
    for record in records:
        url = str(record.get("url") or "").strip()
        if url:
            by_url[url] = record
        by_title[_norm(record.get("title", ""))] = record

    table = _pick_detail_table(parse_markdown_tables(report_text))
    result: dict[str, Any] = {
        "报告明细表行数": 0,
        "对得上": 0,
        "对不上": 0,
        "对账基准外": 0,
        "对不上明细": [],
        "对账基准外明细": [],
        "脚本有但报告没写": [],
        "备注": [],
    }
    if table is None:
        result["备注"].append("报告里没有找到「中标明细」表（项目名 + 金额 + 日期三列）")
        return result

    header = table["header"]
    title_key = next(
        (key for key, cell in enumerate(header) if "项目" in cell or "名称" in cell), None
    )
    amount_key = next((key for key, cell in enumerate(header) if "金额" in cell), None)
    date_key = next((key for key, cell in enumerate(header) if "日期" in cell or "时间" in cell), None)
    winner_key = next(
        (key for key, cell in enumerate(header) if "中标" in cell and "单位" in cell), None
    )
    if title_key is None or amount_key is None:
        result["备注"].append(f"明细表缺少项目名列或金额列：{header}")
        return result

    matched_records: set[str] = set()
    for row in table["rows"]:
        if len(row) <= max(title_key, amount_key):
            continue
        result["报告明细表行数"] += 1
        title_cell = row[title_key]
        url = _extract_url(title_cell)
        record = by_url.get(url) if url else None
        if record is None:
            record = by_title.get(_norm(title_cell))
        if record is None:
            # 不在对账基准里 —— 线上跑出来的报告会找到基准之外的公告，
            # 那是**多**不是错，不能算成对账失败。
            result["对账基准外"] += 1
            result["对账基准外明细"].append({"报告行": title_cell[:60]})
            continue

        key = str(record.get("url") or record.get("title"))
        matched_records.add(key)
        problems: list[str] = []
        reported = parse_amount_cell(row[amount_key], header[amount_key])
        expected = record.get("amount_yuan")
        if expected is None:
            # 脚本没抽到金额 —— 报告里也不该有金额
            if reported:
                problems.append(f"脚本未披露金额，报告却写了 {row[amount_key]}")
        elif not reported:
            problems.append("报告未写金额")
        elif not any(_close(value, float(expected)) for value in reported):
            problems.append(
                f"金额对不上：报告 {row[amount_key]}"
                f"（{', '.join(format(value, ',.0f') for value in reported)} 元）"
                f" vs 脚本 {float(expected):,.0f} 元"
            )
        if date_key is not None and len(row) > date_key:
            if not _same_text(row[date_key], str(record.get("published") or "")):
                problems.append(
                    f"发布日期对不上：报告 {row[date_key]} vs 脚本 {record.get('published')}"
                )
        if winner_key is not None and len(row) > winner_key:
            reported_winner = row[winner_key]
            if _norm(reported_winner) not in {"", "未检索到", "—", "-"} and not _same_text(
                reported_winner, str(record.get("winner") or "")
            ):
                # 报告可能把多个中标单位合并成一格 —— 只要包含脚本抽到的那个就算对
                if _norm(str(record.get("winner") or "")) not in _norm(reported_winner):
                    problems.append(
                        f"中标单位对不上：报告 {reported_winner} vs 脚本 {record.get('winner')}"
                    )

        if problems:
            result["对不上"] += 1
            result["对不上明细"].append(
                {
                    "报告行": title_cell[:60],
                    "问题": "；".join(problems),
                }
            )
        else:
            result["对得上"] += 1

    for record in records:
        key = str(record.get("url") or record.get("title"))
        if key not in matched_records:
            result["脚本有但报告没写"].append(
                {
                    "公告": record.get("title"),
                    "金额": record.get("amount_yuan"),
                    "url": record.get("url"),
                }
            )

    #: ---- 第二层：记录自己自不自洽 ----
    #:
    #: 报告照抄了一条自相矛盾的记录，对账是全绿的 —— 所以这一层必须单独查。
    self_bad: list[dict[str, Any]] = []
    for record in records:
        problems = record_self_check(record)
        if problems:
            self_bad.append(
                {
                    "公告": record.get("title"),
                    "url": record.get("url"),
                    "问题": "；".join(problems),
                }
            )
    result["记录条数"] = len(records)
    result["记录不自洽"] = len(self_bad)
    result["记录不自洽明细"] = self_bad
    return result


def render_markdown(result: dict[str, Any], report_path: str, data_path: str) -> str:
    """把对账结果渲染成 Markdown。"""
    lines = [
        "# 成稿对账报告",
        "",
        f"- 报告：`{report_path}`",
        f"- 脚本输出：`{data_path}`",
        f"- 报告明细表行数：**{result.get('报告明细表行数', 0)}**",
        f"- 对得上：**{result.get('对得上', 0)}**",
        f"- 对不上：**{result.get('对不上', 0)}**",
        f"- 对账基准外（报告找到、基准里没有）：**{result.get('对账基准外', 0)}**",
        f"- 脚本有、报告没写：**{len(result.get('脚本有但报告没写', []))}**",
        f"- 记录条数：**{result.get('记录条数', 0)}**",
        f"- **记录自相矛盾：{result.get('记录不自洽', 0)}**"
        "（第二层：记录本身自不自洽 —— 报告照抄一条矛盾的记录，对账同样是全绿的）",
        "",
    ]
    problems = result.get("对不上明细") or []
    if problems:
        lines.append("## 对不上的行")
        lines.append("")
        lines.append("| 报告行 | 问题 |")
        lines.append("| --- | --- |")
        for item in problems:
            lines.append(f"| {item['报告行']} | {item['问题']} |")
        lines.append("")
    missing = result.get("脚本有但报告没写") or []
    if missing:
        lines.append("## 脚本抽到、报告没写的公告")
        lines.append("")
        lines.append("| 公告 | 金额（元） |")
        lines.append("| --- | --- |")
        for item in missing:
            amount = item.get("金额")
            lines.append(
                f"| {item.get('公告')} | {amount:,.0f} |" if amount is not None
                else f"| {item.get('公告')} | 未披露 |"
            )
        lines.append("")
    self_bad = result.get("记录不自洽明细") or []
    if self_bad:
        lines.append("## 记录自相矛盾（报告照抄了它，对账看不出来）")
        lines.append("")
        lines.append("| 公告 | 问题 |")
        lines.append("| --- | --- |")
        for item in self_bad:
            lines.append(f"| {item.get('公告')} | {item.get('问题')} |")
        lines.append("")
    for note in result.get("备注") or []:
        lines.append(f"> {note}")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="成稿对账：报告明细表 vs 脚本 JSON 输出")
    parser.add_argument("--report", required=True, help="报告（.md / .txt）")
    parser.add_argument("--data", required=True, help="脚本层的 JSON 输出")
    parser.add_argument("--out", default="", help="对账报告输出路径（默认打印到 stdout）")
    parser.add_argument("--json", dest="json_out", default="", help="对账结果 JSON 输出路径")
    parser.add_argument("--quiet", action="store_true", help="只输出结论，不打印明细")
    args = parser.parse_args(argv)

    force_utf8()
    report_path = Path(args.report)
    data_path = Path(args.data)
    report_text = report_path.read_text(encoding="utf-8", errors="replace")
    data = json.loads(data_path.read_text(encoding="utf-8"))

    result = verify(report_text, data)
    markdown = render_markdown(result, str(report_path), str(data_path))

    if args.quiet:
        print(
            f"明细行 {result.get('报告明细表行数', 0)} 行 · "
            f"对得上 {result.get('对得上', 0)} · "
            f"对不上 {result.get('对不上', 0)} · "
            f"基准外 {result.get('对账基准外', 0)} · "
            f"脚本有报告没写 {len(result.get('脚本有但报告没写', []))} · "
            f"记录不自洽 {result.get('记录不自洽', 0)}"
        )
    else:
        print(markdown)

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(markdown, encoding="utf-8")
        print(f"对账报告已写入：{out_path}")
    if args.json_out:
        json_path = Path(args.json_out)
        json_path.parent.mkdir(parents=True, exist_ok=True)
        json_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"对账结果已写入：{json_path}")

    # 有出入就返回 1 —— 可以直接挂到流水线里当门禁。
    # **记录自相矛盾也算出入** —— 那条记录一旦进了报告，报告就是错的。
    return 1 if (result.get("对不上") or result.get("记录不自洽")) else 0


if __name__ == "__main__":
    raise SystemExit(main())
