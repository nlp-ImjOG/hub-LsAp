#!/usr/bin/env python
"""把脚本层的能力同步进两个 Skill —— 作业二的关键一步。

为什么需要这个脚本：Skill 里的检索式、关键词矩阵、金额归一规则如果各写一份，
很快就会和脚本层的实际行为对不上（脚本改了、Skill 没改，两边口径分裂）。
所以这里让**脚本层是唯一真源**，``build_skills.py`` 负责把下列内容生成到
Skill 目录里：

============================  ==========================================
生成物                        来源
============================  ==========================================
``references/keyword-matrix.md``   :mod:`esg_toolkit.keywords` 的方向词表与分类矩阵
``references/data-sources.md``     信源分级表 + 常见站点清单
``references/amount-parsing.md``   金额归一规则（单位、舍入、拿不准怎么办）
``references/tool-usage.md``       工具用法（作业一：无脚本版 / 作业二：脚本版）
``assets/report-template.md``      报告骨架
``scripts/esg_toolkit/``           脚本层本体（复制进去，Skill 可直接调用）
============================  ==========================================

``SKILL.md`` **不手写第二份**：作业一那份是唯一的真相来源，
作业二那份由它**注入「确定性脚本层」章节**后生成（见 :func:`_enhance_skill_md`），
``--check`` 会断言两版同步 —— 方法层悄悄漂移的话，A/B 结论就不成立了。

用法::

    python build_skills.py             # 生成到 作业一/skills/ 与 作业二/skills/
    python build_skills.py --check     # 只检查是否与脚本层一致，不写入

两个输出口径不一样，这是 A/B 对比成立的前提：

- **作业一/skills/** —— **纯方法层**。只有 SKILL.md、references/、assets/，
  **不含 scripts/**。这就是"没有确定性 script"的那一臂。
- **作业二/skills/** —— **方法 + 脚本层**。SKILL.md 在作业一那份基础上注入
  「确定性脚本层」章节，并附上 ``scripts/esg_toolkit/`` 与三个 CLI 入口。
  这就是"有确定性 script"的那一臂。
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from esg_toolkit.cli import force_utf8, make_logger  # noqa: E402
from esg_toolkit.config import HOME_DIR, WEEK16_DIR  # noqa: E402
from esg_toolkit.keywords import (  # noqa: E402
    DIRECTION_CATEGORY,
    ESG_CATEGORIES,
    ESG_DIRECTIONS,
    ESG_NEWS_KEYWORDS,
    ESG_STRONG_KEYWORDS,
    EXCLUDE_KEYWORDS,
    PROVINCES,
    SOURCE_TIER_RULES,
)
from esg_toolkit.pipeline import NEWS_BOARDS, TENDER_QUERIES  # noqa: E402

#: 作业一：纯方法层（**没有 scripts/**）—— A/B 的"无 script"臂
METHOD_SKILLS_DIR = WEEK16_DIR / "作业一" / "skills"
#: 作业二：方法 + 脚本层 —— A/B 的"有 script"臂
ENHANCED_SKILLS_DIR = WEEK16_DIR / "作业二" / "skills"
TOOLKIT_SRC = HOME_DIR / "scripts" / "esg_toolkit"

MONTHLY_SKILL = "esg-monthly-report"
TENDER_SKILL = "esg-tender-monitor"

#: 作业二 SKILL.md 里注入章节的锚点。``--check`` 靠它确认注入是幂等的。
SCRIPT_SECTION_MARKER = "## 确定性脚本层（脚本臂）"

#: 作业二 Skill 里要带的 CLI 入口（相对 ``作业二/scripts/``）
CLI_ENTRIES = ("monthly_report.py", "tender_report.py", "tender_daily.py")

TIER_LABEL = {
    "A": "A 级 · 监管与官方（政策原文、交易所指引、政府公告）",
    "B": "B 级 · 主流财经媒体（证券时报、中国证券报、经济观察报等）",
    "C": "C 级 · 行业媒体与商业资讯（东方财富、搜狐财经等）",
    "D": "D 级 · 其他（个人博客、聚合站、转载页）",
}


# ---------------------------------------------------------------- 模板


def _keyword_matrix_md() -> str:
    """ESG 关键词矩阵。"""
    lines = [
        "# ESG 关键词矩阵",
        "",
        "> 本文件由 `作业二/scripts/build_skills.py` 从 `esg_toolkit/keywords.py` 自动生成，",
        "> **不要手工编辑** —— 改了脚本层请重新运行 `python build_skills.py`。",
        "",
        "检索式与自动分类共用这一份口径。检索时用它构造查询，筛选时用它判定相关性。",
        "",
        "## 一、强相关词（命中即认为是 ESG 话题）",
        "",
        "```",
        "、".join(ESG_STRONG_KEYWORDS),
        "```",
        "",
        "## 一之二、月报口径的相关性词表（更宽）",
        "",
        "> 上面那份是**招投标**口径，宁严勿宽 —— 放进「绿色」「生态」这种宽词，",
        "> 会进来一堆绿化养护、办公用品采购。月报看的是政策与行业动态，",
        "> 「全国碳市场扩围」「碳排放管控」这类条目没有「双碳」字样，",
        "> 却恰恰是客户最该知道的，所以月报用下面这份更宽的表。",
        "",
        "```",
        "、".join(ESG_NEWS_KEYWORDS),
        "```",
        "",
        "## 二、排除词（命中即大概率与 ESG 无关）",
        "",
        "```",
        "、".join(EXCLUDE_KEYWORDS),
        "```",
        "",
        "## 三、细分方向与关键词",
        "",
    ]

    for category, words in ESG_CATEGORIES.items():
        lines.append(f"### {category}")
        lines.append("")
        for word in words:
            lines.append(f"- {word}")
        lines.append("")

    lines += [
        "## 四、规范方向词（用于热点统计）",
        "",
        "热点榜统计的是**方向**，不是任意关键词。同一段文本命中多个词时，",
        "**以最短的为准**（例如同时命中「温室气体排放」与「温室气体」，只记「温室气体」）——",
        "榜单要的是方向，不是限定语。",
        "",
        "| 方向词 | 所属分类 |",
        "| --- | --- |",
    ]
    for word in ESG_DIRECTIONS:
        lines.append(f"| {word} | {DIRECTION_CATEGORY.get(word, '其他方向')} |")

    lines += [
        "",
        "## 五、省份线索",
        "",
        "从 URL 域名或正文判断地域时使用。",
        "",
        "```",
        "、".join(PROVINCES),
        "```",
        "",
    ]
    return "\n".join(lines)


def _data_sources_md() -> str:
    """信源分级与站点清单。"""
    lines = [
        "# 信源地图与分级",
        "",
        "> 本文件由 `作业二/scripts/build_skills.py` 从 `esg_toolkit/keywords.py` 自动生成，",
        "> **不要手工编辑**。",
        "",
        "## 一、分级口径",
        "",
        "分级只影响**排序**，不影响**取舍** —— D 级信源里也可能有唯一的官方口径。",
        "",
    ]
    for tier, label in TIER_LABEL.items():
        lines.append(f"- **{tier}**：{label.split('·', 1)[1].strip()}")
    lines += [
        "",
        "## 二、域名规则",
        "",
        "| 域名包含 | 级别 |",
        "| --- | --- |",
    ]
    for pattern, tier in SOURCE_TIER_RULES:
        lines.append(f"| `{pattern}` | {tier} |")

    lines += [
        "",
        "## 三、常用站点",
        "",
        "| 站点 | 用途 | 抓取注意 |",
        "| --- | --- | --- |",
        "| 中国政府采购网 `ccgp.gov.cn` | 全国政府采购公告 | 裸 UA 会 403，必须带 Referer 重试 |",
        "| 各级公共资源交易中心 `ggzy.*.gov.cn` | 工程与服务招标中标公告 | 页面多为两列 key-value 表格 |",
        "| 各省生态环境厅 `*.sthjt.*.gov.cn` | 政策文件、处罚公告 | 部分站点为 GBK 编码 |",
        "| 生态环境部 `mee.gov.cn` | 全国性政策、碳市场 | 中央政策首选信源 |",
        "| 国家发改委 `ndrc.gov.cn` | 碳达峰碳中和政策原文 | 中央政策首选信源 |",
        "| 上交所/深交所 `sse.com.cn` `szse.cn` | 可持续发展报告指引、ESG 披露 | 需带浏览器 UA |",
        "| 巨潮资讯 `cninfo.com.cn` | 上市公司公告原文 | 定期报告主入口 |",
        "| 中国神华 `shenhuachina.com.cn` | 客户公司动态、ESG 报告 | 官网新闻栏目 |",
        "",
    ]
    return "\n".join(lines)


def _amount_parsing_md() -> str:
    """金额归一规则。"""
    lines = [
        "# 金额归一规则",
        "",
        "> 本文件由 `作业二/scripts/build_skills.py` 从 `esg_toolkit/parse_tender.py` 自动生成，",
        "> **不要手工编辑**。",
        "",
        "## 一、单位换算",
        "",
        "| 原文单位 | 换算为「元」 |",
        "| --- | --- |",
        "| 亿元 | × 100,000,000 |",
        "| 万元 | × 10,000 |",
        "| 千元 | × 1,000 |",
        "| 元 | × 1 |",
        "",
        "**识别顺序**：先匹配「亿元」，再「万元」，再「千元」，最后「元」。",
        "顺序反了会把「1.20 亿元」读成 1.2 元 —— 这是最常见也最致命的错误。",
        "",
        "## 二、常见写法",
        "",
        "| 原文 | 归一结果 |",
        "| --- | --- |",
        "| `10,080,000.00元` | 10,080,000 |",
        "| `1,008.0万元` | 10,080,000 |",
        "| `1008万元` | 10,080,000 |",
        "| `1.20亿元` | 120,000,000 |",
        "| `中标、成交金额` `(万元):` `37.5` | 375,000（单位在表头单独一格） |",
        "",
        "## 三、原则",
        "",
        "1. **保留原文**：`amount_raw` 存原始串，报告里逐字可引，人工可核对。",
        "2. **宁可漏，不要猜**：解析不出金额时 `amount_yuan` 为 `None`，",
        "   报告里显示「—」并单独计入「金额未披露」一档，**绝不用 0 顶替**。",
        "3. **区分预算与中标**：预算是上限，中标是结果，两者不是一回事，",
        "   统计金额分布时只用中标金额。",
        "4. **单位随表头走**：政务网站的表格常把单位放在标签格里",
        "   （`中标、成交金额` / `(万元):` / `37.5`），拆成三格。",
        "",
    ]
    return "\n".join(lines)


def _tool_usage_md(skill_name: str, kind: str, with_scripts: bool = True) -> str:
    """工具用法说明。

    ``with_scripts=False`` 产出**作业一（无 script）**那一版：讲怎么用
    WebSearch / WebFetch 自己做检索与解析。
    ``with_scripts=True`` 产出**作业二（有 script）**那一版：讲怎么调脚本层。
    """
    if kind == "monthly":
        commands = [
            "# 3. 生成月报（可选：先跑脚本拿到确定性事实，再由你写导语）",
            "python scripts/monthly_report.py --client 中国神华 --period 2026-10 --no-llm",
            "#   产物：output/monthly/esg-monthly-2026-10.{md,json,html}",
            "",
            "# 脚本层给出的确定性部分：",
            "#   - 按自然月过滤、去重、信源分级、相关性排序、议题归类",
            "#   - 影响方向判定（标题级启发式，见 references/ 里的说明）",
            "# 你负责的部分：导语、要点、对客户的建议",
        ]
        inputs = """## 一、输入

- **客户档案**：见 `references/client-profile.md`（默认客户：中国神华）。
- **统计区间**：上一个自然月（`2026-10-01` ~ `2026-10-31`）。口径固定，不使用"最近 30 天"。
- **检索式**：见 `references/source-map.md` 里的三组检索式。

## 二、检索

按 `references/source-map.md` 的检索式逐条搜索，每条取 8-10 条结果。
优先看 A 级信源；B 级用于补充行业动态；C/D 级只在 A、B 级没有覆盖时使用。
"""
    else:
        commands = [
            "# 3. 生成汇总报告（可选：先跑脚本拿到确定性统计，再由你写说明）",
            "python scripts/tender_report.py --years 2 --no-llm",
            "#   产物：output/tender/esg-tender-<日期>.{md,json,html}",
            "",
            "# 4. 生成每日增量推送",
            "python scripts/tender_daily.py --dry-run   # 先看会推出什么",
            "python scripts/tender_daily.py             # 推送并写状态",
            "",
            "# 脚本层给出的确定性部分：",
            "#   - 金额归一（单位换算）、日期归一、机构名清洗",
            "#   - 去重（URL 规范化 + 标题归一）、省份与议题归类",
            "#   - 金额分档、月度走势、热点方向、地区分布、采购人类型分布",
            "# 你负责的部分：汇总说明、要点、对招标策略的解读",
        ]
        query_lines = [
            "## 二、检索",
            "",
            "ESG 相关的招标公告分散在各级公共资源交易中心与政府采购网上，",
            "单个站点搜不全，要按方向分多组检索式，每条取 8-10 条结果后合并去重。",
            "",
            "### 推荐检索式",
            "",
        ]
        query_lines += [f"- `{query}`" for query in TENDER_QUERIES]
        query_lines += [
            "",
            "### 补充检索",
            "",
            "结果不足时按站点补检索：",
            "",
            "- `site:ccgp.gov.cn 双碳 中标`、`site:ggzy.gov.cn 碳达峰 中标`",
            "- `生态环境局 中标公告 温室气体`、`公共资源交易中心 节能改造 中标`",
            "- 按省份补：`省名 + 公共资源交易中心 + ESG/双碳/绿色 + 中标公告`",
            "",
        ]
        inputs = "\n".join(
            [
                "## 一、输入",
                "",
                "- **统计区间**：默认近 2 年。",
                "- **增量监控**：与 `output/state/seen.json` 比对，只推送没推过的公告。",
                "- **检索式**：见下方「推荐检索式」与 `references/keyword-matrix.md`。",
                "",
            ]
            + query_lines
        )

    if not with_scripts:
        # ---------------------------------------------------------- 无脚本版
        return "\n".join(
            [
                f"# 工具用法（{skill_name} · 纯方法版）",
                "",
                "> 本 Skill **不依赖任何脚本** —— 检索、筛选、抽取、统计全部由你",
                "> 用 WebSearch / WebFetch 亲手完成。",
                "> （作业二会把这些环节沉淀成确定性脚本，并给出有/无脚本的对比；",
                "> 那一版见 `../../作业二/skills/` 下的同名 Skill。）",
                "",
                inputs,
                "",
                "## 三、WebSearch 怎么用",
                "",
                "| 场景 | 做法 |",
                "| --- | --- |",
                "| 找公告 / 找动态 | 直接用检索式搜，每条取 8-10 条结果 |",
                "| 结果太杂 | 加站点限定：`site:ccgp.gov.cn`、`site:mee.gov.cn` |",
                "| 结果太少 | 换同义词与中英双语表述再搜，别急着下结论 |",
                "| 命中权威页面 | 用 WebFetch 读原文，不要只看摘要 |",
                "",
                "## 四、WebFetch 什么时候用、什么时候不用",
                "",
                "- **该用**：搜索结果指向政策原文、交易所指引、公告详情页时 —— 摘要常常",
                "  省略关键限定词（\"适用范围\"\"过渡期\"\"自 2027 年起\"），而这些恰恰是",
                "  报告里最有价值的信息。",
                "- **别用**：页面明显是列表页 / 搜索结果页（拿不到正文）；",
                "  或域名被安全校验拦住（部分 `.gov.cn` 站点会）—— 换个信源或改用摘要。",
                "- 抓不到就写「本期未检索到」，**不要编**。",
                "",
                "## 五、读公告时的三个坑",
                "",
                "1. **金额单位**：先认「亿元」再认「万元」。顺序反了，「1.20 亿元」会变成 1.2 元。",
                "2. **日期补零**：`2026-11-3` 是真实公告里的写法，要补成 `2026-11-03`。",
                "3. **预算 ≠ 中标**：统计金额分布时只用中标金额。",
                "",
                "详见 `references/amount-parsing.md`。",
                "",
                "## 六、统计口径",
                "",
                "| 口径 | 怎么算 |",
                "| --- | --- |",
                "| **中标金额分布** | 分 7 档（10 万以下 → 1 亿以上），未披露金额单独计一档 |",
                "| **月度走势** | 按公告发布日期归月，条数 + 金额合计 |",
                "| **热点方向** | 项目标题命中的方向词词频，**短形优先** |",
                "| **地区与采购人分布** | 省份从正文或域名推断；采购人按机构类型归类 |",
                "",
                "方向词只统计**项目标题**。\"热点招标情况\"问的是\"在买什么\"，标题才是答案；",
                "采购人属于\"谁买\"，单独呈现。",
                "",
                "加法与计数**自己动手算**：模型心算会错，宁可用两次。",
                "",
            ]
        )

    # -------------------------------------------------------------- 脚本版
    return "\n".join(
        [
            f"# 脚本层调用说明（{skill_name}）",
            "",
            "> 本文件由 `作业二/scripts/build_skills.py` 自动生成，**不要手工编辑**。",
            "",
            inputs,
            "",
            "## 三、脚本层（确定性部分）",
            "",
            "Skill 目录下的 `scripts/` 是作业二沉淀下来的确定性工具层，",
            "它负责**可写成规则的活**：抽取、归一、去重、统计。",
            "",
            "```bash",
            "cd <skill 目录>",
            *commands,
            "```",
            "",
            "### 什么时候用脚本，什么时候自己来",
            "",
            "| 任务 | 谁来做 | 理由 |",
            "| --- | --- | --- |",
            "| 抽取中标金额 | 脚本 | 单位换算规则明确，模型容易把「亿元」读成「元」 |",
            "| 日期归一 | 脚本 | 非零填充日期是真实坑位，模型会漏 |",
            "| 去重 | 脚本 | URL 规范化规则确定 |",
            "| 金额分档 / 热点统计 | 脚本 | 加法与计数不该交给模型 |",
            "| 判断这条动态对客户意味着什么 | **你** | 需要语义理解 |",
            "| 写导语、要点、建议 | **你** | 需要语言表达 |",
            "",
            "## 四、脚本层接口速查",
            "",
            "| 模块 | 关键函数 | 作用 |",
            "| --- | --- | --- |",
            "| `esg_toolkit.parse_tender` | `parse_tender_page(html, url)` | 从公告页面解析中标记录 |",
            "| `esg_toolkit.parse_tender` | `parse_tender_snippet(snippet, url)` | 从搜索摘要解析（页面抓不到时兜底） |",
            "| `esg_toolkit.parse_tender` | `normalize_amount(raw, unit)` | 金额归一为「元」 |",
            "| `esg_toolkit.parse_news` | `previous_month_window()` | 上一个自然月的时间窗 |",
            "| `esg_toolkit.parse_news` | `dedupe(items)` | URL + 标题两级去重 |",
            "| `esg_toolkit.aggregate` | `summarize(records)` | 一次性产出全部统计口径 |",
            "| `esg_toolkit.render` | `render_markdown/json/html` | 三件套渲染 |",
            "| `esg_toolkit.state` | `StateStore(path)` | 增量推送的已推送记录 |",
            "",
        ]
    )


def _script_section_md(kind: str) -> str:
    """注入到作业二 SKILL.md 末尾的「确定性脚本层」章节。"""
    if kind == "monthly":
        usage = """```bash
cd <skill 目录>

# 先跑脚本拿到确定性事实（时间窗、去重、归类、信源分级、影响方向初判）
python scripts/monthly_report.py --client 中国神华 --period 2026-10 --no-llm
#   产物：output/monthly/esg-monthly-2026-10.{md,json,html}
```

脚本只出**事实与初判**；导语、要点、建议仍然由你写。"""
    else:
        usage = """```bash
cd <skill 目录>

# 汇总报告（近 2 年）
python scripts/tender_report.py --years 2 --no-llm
#   产物：output/tender/esg-tender-<日期>.{md,json,html}

# 每日增量推送（先 dry-run 看会推出什么，确认后再真跑）
python scripts/tender_daily.py --dry-run
python scripts/tender_daily.py
```

脚本负责**抽取、归一、去重、统计**；你负责**解读** —— 这批采购说明了什么、
对手是谁、该不该跟进。"""

    return "\n".join(
        [
            SCRIPT_SECTION_MARKER,
            "",
            "本 Skill 与**纯方法版**（`作业一/skills/` 下同名 Skill）**方法完全一致**，",
            "区别只有一处：多了一层确定性脚本，把**可写成规则的活**交给代码。",
            "",
            "### 哪些活交给脚本",
            "",
            "| 环节 | 无脚本版 | 有脚本版 |",
            "| --- | --- | --- |",
            "| 时间窗计算 | 手工推算 | `parse_news.previous_month_window()` |",
            "| 公告字段抽取 | 逐页读、自己抄 | `parse_tender.parse_tender_page()` |",
            "| 金额归一 | 心算单位换算 | `parse_tender.normalize_amount()` |",
            "| 日期归一 | 手工补零 | `parse_tender.parse_date()` |",
            "| 去重 | 人工比对 | `parse_news.dedupe()` |",
            "| 金额分档 / 月度走势 / 热点统计 | 自己数 | `aggregate.summarize()` |",
            "| 判读影响、写导语与建议 | 模型 | **仍然是模型** |",
            "",
            "### 怎么用",
            "",
            usage,
            "",
            "> **能用脚本算的就别自己算。** 金额分档、热点词频这类统计模型心算会错；",
            "> 脚本算完你只负责解读与表达。",
            "",
        ]
    )


def _enhance_skill_md(md: str, kind: str) -> str:
    """把作业一的 SKILL.md 加工成作业二的增强版。

    幂等：已经注入过就把旧段落截掉重新注入，所以可以反复跑。
    """
    base = md.rstrip("\n")
    index = base.find(SCRIPT_SECTION_MARKER)
    if index != -1:
        base = base[:index].rstrip("\n")
    return base + "\n\n" + _script_section_md(kind).rstrip("\n") + "\n"


def _report_template_md(kind: str) -> str:
    """报告骨架。"""
    if kind == "monthly":
        return "\n".join(
            [
                "# {客户} ESG 月报（{年-月}）",
                "",
                "**统计区间**：{start} ~ {end}",
                "",
                "**生成时间**：{时间}",
                "",
                "## 摘要",
                "",
                "（3-5 句导语：本期最值得注意的三件事）",
                "",
                "## 关键要点",
                "",
                "- 要点一",
                "- 要点二",
                "- 要点三",
                "",
                "## 一、ESG 政策、评级与标准动态",
                "",
                "（每条：标题 + 日期 + 来源 + 一句话说明它意味着什么）",
                "",
                "## 二、行业动态与最佳实践",
                "",
                "（每条：标题 + 日期 + 来源 + 对客户的适用性）",
                "",
                "## 三、公司动态、对标企业行动与建议",
                "",
                "（每条：标题 + 日期 + 来源 + 影响方向；末尾给 3-5 条具体建议）",
                "",
                "## 数据说明与局限",
                "",
                "- 统计口径与时间窗",
                "- 未能核实的内容不作断言",
                "",
            ]
        )
    return "\n".join(
        [
            "# ESG / 可持续发展 / 双碳 招投标汇总报告（{start} ~ {end}）",
            "",
            "**生成时间**：{时间}",
            "",
            "## 摘要",
            "",
            "（3-5 句：本期汇总了多少条、金额什么量级、最热的方向是什么）",
            "",
            "## 关键要点",
            "",
            "- 要点一",
            "- 要点二",
            "- 要点三",
            "",
            "## 一、金额分布",
            "",
            "（分档表 + 月度走势图 + 集中趋势）",
            "",
            "## 二、热点招标方向",
            "",
            "（方向词频 + 地区分布 + 采购人类型分布）",
            "",
            "## 三、中标明细",
            "",
            "| 发布日期 | 项目名称 | 采购人 | 中标单位 | 中标金额 | 来源 |",
            "| --- | --- | --- | --- | --- | --- |",
            "",
            "## 数据说明与局限",
            "",
            "- 金额统一归一为「元」，原文保留在 amount_raw",
            "- 未能解析出金额的记录单独计入「金额未披露」",
            "",
        ]
    )


def _source_map_md() -> str:
    """月报检索式。"""
    lines = [
        "# 检索式地图（月报）",
        "",
        "> 本文件由 `作业二/scripts/build_skills.py` 从 `esg_toolkit/pipeline.py` 自动生成，",
        "> **不要手工编辑**。",
        "",
        "月报分三个板块，各板块用一组检索式。检索式是**起点**，不是终点 ——",
        "看到结果指向的权威页面（政策原文、交易所指引、公告原文）应当**直接去读**。",
        "",
    ]
    for board, queries in NEWS_BOARDS.items():
        lines.append(f"## {board}")
        lines.append("")
        for query in queries:
            lines.append(f"- `{query}`")
        lines.append("")
    lines += [
        "## 补充检索",
        "",
        "检索结果不足时，按下面的方向补检索（同样的结构，换关键词）：",
        "",
        "- 政策原文：`site:mee.gov.cn 碳市场 管理办法`、`发改委 双碳 通知`",
        "- 评级标准：`ESG 评级 方法论 争议`、`可持续披露准则 基本要求`",
        "- 客户公告：`中国神华 公告 2026`、`神华 绿色矿山 进展`",
        "- 对标企业：`中国中煤 ESG`、`国家能源集团 绿色低碳`",
        "",
    ]
    return "\n".join(lines)


def _esg_taxonomy_md() -> str:
    """ESG 议题分类法（E/S/G 映射）。"""
    return "\n".join(
        [
            "# ESG 议题分类法",
            "",
            "> 本文件由 `作业二/scripts/build_skills.py` 自动生成，**不要手工编辑**。",
            "",
            "给每条动态标注议题时用这套分类。**一个动态可以属于多个议题**，",
            "取最主要的一个作为 `topic`，其余在正文里说明。",
            "",
            "## 环境 E",
            "",
            "| 议题 | 关键词 |",
            "| --- | --- |",
        ]
        + [
            f"| {category} | {'、'.join(words)} |"
            for category, words in ESG_CATEGORIES.items()
        ]
        + [
            "",
            "## 影响方向",
            "",
            "- **利好**：明确的正向进展（获批、认证、入选、投产、示范…）",
            "- **风险**：明确的负面事件（处罚、约谈、整改、事故、召回…）",
            "- **中性**：只是信息发布，没有明确方向",
            "",
            "**拿不准就判中性。** 编一个方向比不判更糟。",
            "",
            "## 客户行业映射（中国神华）",
            "",
            "| 行业 | 主要议题 | 重点关注的政策 |",
            "| --- | --- | --- |",
            "| 煤炭开采与洗选 | 温室气体、能耗、CCUS、矿区生态修复 | 碳市场扩容、煤炭消费减量 |",
            "| 电力（煤电为主） | 机组能效、灵活性改造、绿电替代 | 煤电低碳化改造试点 |",
            "| 铁路运输 | 运输效率、电动化 | 多式联运政策 |",
            "| 煤化工 | 工艺能耗、废水废气 | 化工园区准入 |",
            "| 新能源（风电光伏） | 组件回收、绿电交易 | 绿证与碳市场衔接 |",
            "",
        ]
    )


# ---------------------------------------------------------------- 生成


def _write(path: Path, content: str, check: bool, log) -> bool:
    """写文件（``check`` 模式下只比对）。返回是否一致。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        # newline="" = 不做换行翻译，这样 CRLF 与 LF 的差异也会被看出来
        current = path.read_text(encoding="utf-8", newline="")
        if current == content:
            log(f"  = {path.name}（已是最新）")
            return True
        if check:
            log(f"  ! {path.name} 与脚本层不一致")
            return False
    if check:
        log(f"  ! {path.name} 缺失")
        return False
    # 显式指定 newline="\n"：Windows 上默认会把 \n 翻成 \r\n，
    # 那样同一份内容在两臂里字节不同，A/B 的"方法层逐字一致"就没法断言了。
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(content)
    log(f"  + {path.name}")
    return True


def _copy_toolkit(target: Path, check: bool, log) -> bool:
    """把 ``esg_toolkit`` 复制到 Skill 的 ``scripts/`` 目录。"""
    ok = True
    target_root = target / "scripts" / "esg_toolkit"
    for source in sorted(TOOLKIT_SRC.rglob("*.py")):
        if "__pycache__" in source.parts:
            continue
        relative = source.relative_to(TOOLKIT_SRC)
        destination = target_root / relative
        if check:
            if not destination.is_file() or destination.read_text(encoding="utf-8") != source.read_text(
                encoding="utf-8"
            ):
                log(f"  ! scripts/esg_toolkit/{relative.as_posix()} 与脚本层不一致")
                ok = False
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        log(f"  + scripts/esg_toolkit/{relative.as_posix()}")
    return ok


def _copy_cli_entries(target: Path, check: bool, log) -> bool:
    """把三个 CLI 入口复制到 Skill 的 ``scripts/`` 目录。"""
    ok = True
    scripts_root = HOME_DIR / "scripts"
    for name in CLI_ENTRIES:
        source = scripts_root / name
        destination = target / "scripts" / name
        if not source.is_file():
            log(f"  ! scripts/{name} 源文件不存在")
            ok = False
            continue
        if check:
            if not destination.is_file() or destination.read_text(
                encoding="utf-8"
            ) != source.read_text(encoding="utf-8"):
                log(f"  ! scripts/{name} 与脚本层不一致")
                ok = False
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        log(f"  + scripts/{name}")
    return ok


def _prune_method_scripts(skill_dir: Path, check: bool, log) -> bool:
    """作业一是**无脚本臂** —— 它下面不能留 ``scripts/``。

    这个目录以前被旧版 ``build_skills.py`` 生成过脚本层，留着会让 A/B
    的"唯一变量是有没有脚本"失效，所以这里主动清掉。

    只删**认得出来**是生成物的那一份（含 ``esg_toolkit/__init__.py``），
    手工放的脚本不动 —— 宁可留个警告，也不误删别人的东西。
    """
    scripts_dir = skill_dir / "scripts"
    if not scripts_dir.is_dir():
        return True
    if not (scripts_dir / "esg_toolkit" / "__init__.py").is_file():
        log("  ! scripts/ 目录不是生成物，手工确认后再清理")
        return False
    if check:
        log("  ! scripts/ 目录不该存在（作业一是无脚本臂）")
        return False
    shutil.rmtree(scripts_dir)
    log("  - scripts/（作业一无脚本臂，已清理）")
    return True


def _skill_files(skill_name: str, kind: str, with_scripts: bool) -> dict[str, str]:
    """某个 Skill 的全部派生文件（相对 Skill 目录）。"""
    if kind == "monthly":
        return {
            "references/keyword-matrix.md": _keyword_matrix_md(),
            "references/source-map.md": _source_map_md(),
            "references/esg-taxonomy.md": _esg_taxonomy_md(),
            "references/data-sources.md": _data_sources_md(),
            "references/tool-usage.md": _tool_usage_md(skill_name, kind, with_scripts),
            "assets/report-template.md": _report_template_md(kind),
        }
    return {
        "references/keyword-matrix.md": _keyword_matrix_md(),
        "references/data-sources.md": _data_sources_md(),
        "references/amount-parsing.md": _amount_parsing_md(),
        "references/tool-usage.md": _tool_usage_md(skill_name, kind, with_scripts),
        "assets/report-template.md": _report_template_md(kind),
    }


#: 手写的参考文件：从作业一复制到作业二（内容不变，只换地方）
HANDWRITTEN_REFERENCES: dict[str, tuple[str, ...]] = {
    MONTHLY_SKILL: ("references/client-profile.md",),
    TENDER_SKILL: (),
}


def build(check: bool = False, log=print) -> int:
    """生成两臂 Skill 的全部派生文件。返回不一致的项数。

    两臂的差别**只有一处**：作业一没有 ``scripts/``，作业二有。
    方法层（SKILL.md 正文与检索式、分类矩阵）在两臂里逐字一致。
    """
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    problems = 0

    for skill_name, kind in ((MONTHLY_SKILL, "monthly"), (TENDER_SKILL, "tender")):
        # ---------------------------------------------------- 作业一：纯方法层
        method_dir = METHOD_SKILLS_DIR / skill_name
        log(f"[作业一 · 无脚本臂] {method_dir}")
        method_dir.mkdir(parents=True, exist_ok=True)

        method_skill_md = method_dir / "SKILL.md"
        if not method_skill_md.is_file():
            log("  ! SKILL.md 缺失（手写内容，请补上）")
            problems += 1
            method_source = ""
        else:
            method_source = method_skill_md.read_text(encoding="utf-8")
            if SCRIPT_SECTION_MARKER in method_source:
                log("  ! SKILL.md 里混进了脚本臂章节，作业一必须保持纯方法")
                problems += 1

        for relative, content in _skill_files(skill_name, kind, with_scripts=False).items():
            if not _write(method_dir / relative, content, check, log):
                problems += 1

        if not _prune_method_scripts(method_dir, check, log):
            problems += 1

        # ---------------------------------------------------- 作业二：方法 + 脚本层
        enhanced_dir = ENHANCED_SKILLS_DIR / skill_name
        log(f"[作业二 · 脚本臂] {enhanced_dir}")
        enhanced_dir.mkdir(parents=True, exist_ok=True)

        if not method_source:
            log("  ! 作业一的 SKILL.md 缺失，作业二无从生成")
            problems += 1
        else:
            enhanced_md = _enhance_skill_md(method_source, kind)
            if not _write(enhanced_dir / "SKILL.md", enhanced_md, check, log):
                problems += 1

        for relative, content in _skill_files(skill_name, kind, with_scripts=True).items():
            if not _write(enhanced_dir / relative, content, check, log):
                problems += 1

        # 手写参考文件跟着复制过去
        for relative in HANDWRITTEN_REFERENCES.get(skill_name, ()):
            source = method_dir / relative
            destination = enhanced_dir / relative
            if not source.is_file():
                log(f"  ! {relative} 源文件不存在")
                problems += 1
                continue
            if check:
                if not destination.is_file() or destination.read_text(
                    encoding="utf-8"
                ) != source.read_text(encoding="utf-8"):
                    log(f"  ! {relative} 与作业一不一致")
                    problems += 1
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            log(f"  + {relative}")

        if not _copy_toolkit(enhanced_dir, check, log):
            problems += 1
        if not _copy_cli_entries(enhanced_dir, check, log):
            problems += 1

    # ------------------------------------------------------------- manifest
    for target_dir, arm in ((METHOD_SKILLS_DIR, "method"), (ENHANCED_SKILLS_DIR, "script")):
        manifest = {
            "generated_at": stamp,
            "source": "作业二/scripts/esg_toolkit",
            "arm": arm,
            "skills": [MONTHLY_SKILL, TENDER_SKILL],
        }
        manifest_path = target_dir / "manifest.json"
        if check:
            if not manifest_path.is_file():
                log(f"[manifest] {manifest_path} 缺失")
                problems += 1
        else:
            manifest_path.parent.mkdir(parents=True, exist_ok=True)
            with manifest_path.open("w", encoding="utf-8", newline="\n") as handle:
                handle.write(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
            log(f"[manifest] {manifest_path}")

    return problems


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    parser = argparse.ArgumentParser(description="把脚本层同步进两个 Skill")
    parser.add_argument("--check", action="store_true", help="只检查一致性，不写入")
    args = parser.parse_args(argv)

    log = make_logger(True)
    problems = build(check=args.check, log=log)

    if args.check:
        log(f"检查完成：{problems} 处不一致")
        return 1 if problems else 0

    log(f"生成完成：{problems} 处需要注意")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
