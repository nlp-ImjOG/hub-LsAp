#!/usr/bin/env python
"""把 Markdown 报告转成一个可截图的 HTML 页面。

**为什么需要它**：作业一的"纯方法臂"产出的就是一份 Markdown（``report.md``），
而交付要的是截图。截图工具只吃 HTML，所以中间要有这一层。

转出来的页面**刻意**跟脚本臂的 HTML 报告用同一套 CSS（``render.HTML_CSS``）——
两臂的截图放在一起看，读者比较的是**内容**，不是排版。

用法::

    python scripts/md2html.py --input bench/runs/monthly-p1-A/report.txt \\
        --out output/sample/esg-monthly-armA.html --title "ESG 月报（纯方法臂）"
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from esg_toolkit.cli import force_utf8  # noqa: E402
from esg_toolkit.render import HTML_CSS  # noqa: E402

#: 报告正文的排版 —— 在报告 CSS 之上补几条 Markdown 专属的规则
BODY_CSS = """
.report-body { max-width: 1080px; margin: 0 auto; }
.report-body h1 { font-size: 28px; margin: 0 0 14px; letter-spacing: .01em; }
.report-body h2 {
  font-size: 20px; margin: 30px 0 12px; padding-bottom: 8px;
  border-bottom: 1px solid var(--border);
}
.report-body h3 { font-size: 16.5px; margin: 22px 0 8px; }
.report-body p { margin: 10px 0; }
.report-body ul, .report-body ol { margin: 10px 0 10px 22px; padding: 0; }
.report-body li { margin: 4px 0; }
.report-body a { color: var(--series); text-decoration: none; }
.report-body a:hover { text-decoration: underline; }
.report-body table {
  width: 100%; border-collapse: collapse; margin: 14px 0; font-size: 13.5px;
}
.report-body th, .report-body td {
  border: 1px solid var(--border); padding: 7px 10px; text-align: left;
  vertical-align: top;
}
.report-body th { background: rgba(11,11,11,0.04); font-weight: 600; }
.report-body code {
  background: rgba(11,11,11,0.06); padding: 1px 5px; border-radius: 4px;
  font-family: ui-monospace, Consolas, monospace; font-size: 13px;
}
.report-body blockquote {
  margin: 12px 0; padding: 6px 14px; border-left: 3px solid var(--baseline);
  color: var(--text-secondary);
}
.report-body hr { border: 0; border-top: 1px solid var(--border); margin: 24px 0; }
"""


def markdown_to_html(text: str) -> str:
    """Markdown → HTML（带表格扩展）。

    ``markdown`` 是标准库外的依赖，所以这一层做了**降级**：装不上时退回
    ``mistune``，两个都没有就按纯文本转义 —— 截图工具照样能出图，
    只是少了表格和列表的排版。宁可排版差一点，也不要在交付环节卡住。
    """
    try:
        import markdown as markdown_lib

        return markdown_lib.markdown(text, extensions=["tables", "fenced_code", "sane_lists"])
    except ImportError:
        pass

    try:
        import mistune

        return mistune.html(text, escape=False)
    except ImportError:
        pass

    import html

    return f"<pre>{html.escape(text)}</pre>"


def build_page(title: str, body_html: str) -> str:
    """套上报告 CSS，产出独立可打开的 HTML。"""
    return (
        "<!DOCTYPE html>\n<html lang='zh-CN'>\n<head>\n<meta charset='utf-8'>\n"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>\n"
        f"<title>{title}</title>\n<style>{HTML_CSS}</style>\n<style>{BODY_CSS}</style>\n"
        "</head>\n<body>\n<div class='viz-root'><div class='wrap'>\n"
        f"<header class='report'><h1>{title}</h1></header>\n"
        f"<div class='card report-body'>\n{body_html}\n</div>\n"
        "</div></div>\n</body>\n</html>\n"
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Markdown 报告 → 可截图的 HTML")
    parser.add_argument("--input", required=True, help="Markdown 文件")
    parser.add_argument("--out", required=True, help="输出 HTML 路径")
    parser.add_argument("--title", default="", help="页面标题；默认取 Markdown 的一级标题")
    return parser


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    args = build_parser().parse_args(argv)

    source = Path(args.input)
    if not source.is_file():
        print(f"找不到输入文件：{source}")
        return 1

    text = source.read_text(encoding="utf-8", errors="replace")
    body = markdown_to_html(text)

    title = args.title
    if not title:
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("# "):
                title = stripped[2:].strip()
                break
    title = title or source.stem

    destination = Path(args.out)
    destination.parent.mkdir(parents=True, exist_ok=True)
    # 显式 newline="\n"：Windows 默认会把 \n 翻译成 \r\n，
    # 生成的 HTML 与仓库里其他文件对不上，diff 会莫名其妙地满屏变化。
    destination.write_text(build_page(title, body), encoding="utf-8", newline="\n")
    print(f"  + {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
