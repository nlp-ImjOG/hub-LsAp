#!/usr/bin/env python
"""把 HTML 报告截图成 PNG —— 交付取证用。

作业的交付物本体是**截图**，能跑不等于交作业。本脚本用 Playwright
（Chromium 内核）把报告页整页截图，输出到 ``docs/`` 目录下。

用法::

    python screenshot.py --input output/tender/esg-tender-20261126.html
    python screenshot.py --dir output --out docs
    python screenshot.py --dir output --width 1280 --scale 2
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from esg_toolkit.cli import echo_result, force_utf8, make_logger  # noqa: E402
from esg_toolkit.config import HOME_DIR  # noqa: E402


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="把 HTML 报告截图成 PNG")
    parser.add_argument("--input", default="", help="单个 HTML 文件")
    parser.add_argument("--dir", default="", help="目录（会递归找所有 .html）")
    parser.add_argument("--out", default="", help="输出目录；默认 作业二/docs/screenshots")
    parser.add_argument("--width", type=int, default=1280, help="视口宽度")
    parser.add_argument("--height", type=int, default=900, help="视口高度")
    parser.add_argument("--scale", type=float, default=1.0, help="设备像素比（2 更清晰）")
    parser.add_argument(
        "--full-page", action="store_true", default=True, help="整页截图（默认开）"
    )
    parser.add_argument(
        "--full-page-max-width",
        type=int,
        default=820,
        help=(
            "整页图缩到这个宽度并存成 JPEG（0 = 保持原样 PNG）。"
            "整页动辄一两万像素，PNG 要十几 MB —— 交付证据进仓库缩不动，"
            "压成 JPEG 后一份 1~2MB"
        ),
    )
    parser.add_argument(
        "--slices",
        type=int,
        default=0,
        help="额外按视口高度切成 N 屏分别截图（整页太长时用），0 表示不切",
    )
    parser.add_argument("--theme", default="", help="light / dark；不传则跟随系统")
    return parser


def collect_targets(args) -> list[Path]:
    if args.input:
        path = Path(args.input)
        return [path] if path.is_file() else []

    if args.dir:
        root = Path(args.dir)
        if root.is_file():
            return [root]
        return sorted(root.rglob("*.html"))

    return []


def shrink_fullpage(path: Path, max_width: int) -> Path | None:
    """把整页 PNG 缩到指定宽度并存成同名的 JPEG。

    返回 JPEG 路径；缩不了（没装 Pillow / 图片有毛病）就返回 ``None``，
    由调用方保留原 PNG —— 宁可大一点也不丢证据。
    """
    try:
        from PIL import Image
    except ImportError:
        return None

    Image.MAX_IMAGE_PIXELS = None
    try:
        with Image.open(path) as image:
            image = image.convert("RGB")
            if image.width <= max_width:
                ratio = 1.0
            else:
                ratio = max_width / image.width
            resized = image.resize(
                (max(1, int(image.width * ratio)), max(1, int(image.height * ratio))),
                Image.LANCZOS,
            )
            destination = path.with_suffix(".jpg")
            resized.save(destination, "JPEG", quality=68, optimize=True, progressive=True)
    except Exception:
        return None
    return destination


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    args = build_parser().parse_args(argv)
    log = make_logger(True)

    targets = collect_targets(args)
    if not targets:
        log("没有找到要截图的 HTML 文件")
        return 1

    out_dir = Path(args.out) if args.out else HOME_DIR / "docs" / "screenshots"
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        log("缺少 playwright：pip install playwright && playwright install chromium")
        return 2

    shots: list[str] = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()
        context = browser.new_context(
            viewport={"width": args.width, "height": args.height},
            device_scale_factor=args.scale,
            color_scheme=args.theme or "light",
        )
        page = context.new_page()

        for target in targets:
            url = target.resolve().as_uri()
            try:
                page.goto(url, wait_until="networkidle")
            except Exception as exc:
                log(f"  ! 打开失败 {target.name}：{exc}")
                continue

            destination = out_dir / f"{target.stem}.png"
            try:
                page.screenshot(path=str(destination), full_page=args.full_page)
            except Exception as exc:
                log(f"  ! 截图失败 {target.name}：{exc}")
                continue

            # 整页图缩成 JPEG —— 一张两万像素高的 PNG 要十几 MB，
            # 交进仓库缩不动；压过之后一份 1~2MB，肉眼还是整份的样子。
            if args.full_page_max_width > 0:
                shrunk = shrink_fullpage(destination, args.full_page_max_width)
                if shrunk is not None:
                    destination.unlink(missing_ok=True)
                    destination = shrunk

            log(f"  + {destination}")
            shots.append(str(destination))

            # 整页报告动辄一两万像素，缩到一张图里字都看不清 ——
            # 交付截图要能读，所以再按视口高度切几屏出来。
            if args.slices > 0:
                total = page.evaluate("() => document.body.scrollHeight")
                step = max(1, args.height)
                for index in range(args.slices):
                    offset = min(index * step, max(0, total - args.height))
                    page.evaluate("(y) => window.scrollTo(0, y)", offset)
                    page.wait_for_timeout(120)
                    piece = out_dir / f"{target.stem}-{index + 1}.png"
                    try:
                        page.screenshot(path=str(piece), full_page=False)
                    except Exception as exc:
                        log(f"  ! 分屏截图失败 {target.name}：{exc}")
                        continue
                    log(f"  + {piece}")
                    shots.append(str(piece))
                page.evaluate("() => window.scrollTo(0, 0)")

        context.close()
        browser.close()

    echo_result({"screenshots": shots, "count": len(shots)})
    return 0 if shots else 1


if __name__ == "__main__":
    raise SystemExit(main())
