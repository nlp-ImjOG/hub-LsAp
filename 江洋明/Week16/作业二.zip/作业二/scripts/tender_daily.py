#!/usr/bin/env python
"""ESG 招标每日推送（案例二下半部分）—— 脚本臂。

对应《作业.txt》案例二第 2 条：监控新的跟 ESG 相关的招标情况，每天推送新的招标信息。

关键不在"搜"，而在**记住上次推过什么**。本脚本：

1. 用与 :mod:`tender_report` 相同的检索式与解析逻辑拿到候选公告；
2. 与状态文件 ``output/state/seen.json`` 做差集，挑出**没推过**的那些；
3. 产出三种推送形态：Markdown 周报、JSON（给下游程序）、纯文本（贴进微信/钉钉）；
4. **推送成功之后**才写状态 —— 推送失败下次还能重推。

用法::

    python tender_daily.py                    # 增量推送
    python tender_daily.py --dry-run          # 只看会推出什么，不写状态
    python tender_daily.py --since 2026-11-01 # 指定回溯起点
"""

from __future__ import annotations

import argparse
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from esg_toolkit.cli import echo_result, force_utf8, make_logger, resolve_outdir  # noqa: E402
from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.pipeline import (  # noqa: E402
    TENDER_QUERIES,
    collect_tenders,
    now_stamp,
    write_artifacts,
)
from esg_toolkit.providers import build_provider  # noqa: E402
from esg_toolkit.providers.base import SearchUnavailable  # noqa: E402
from esg_toolkit.render import (  # noqa: E402
    default_meta,
    fmt_amount,
    render_html,
    render_json,
    render_markdown,
)
from esg_toolkit.state import StateStore  # noqa: E402


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="ESG 招标每日推送（案例二·脚本臂）")
    parser.add_argument(
        "--since",
        default="",
        help="回溯起点 YYYY-MM-DD；默认从上次运行日的次日开始",
    )
    parser.add_argument("--days", type=int, default=30, help="回溯天数（配合 --since 缺省使用）")
    parser.add_argument("--out", default="", help="输出目录；默认 作业二/output/daily")
    parser.add_argument("--name", default="", help="产物文件名（不含扩展名）")
    parser.add_argument("--provider", default="", help="搜索后端：claude-cli / bocha")
    parser.add_argument("--count", type=int, default=8, help="每条检索式取回的结果数")
    parser.add_argument("--no-fetch", action="store_true", help="不抓公告页面，只用搜索摘要")
    parser.add_argument("--no-llm", action="store_true", help="不调用 LLM 写说明")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只展示会推出什么，不写状态文件（也不推送）",
    )
    return parser


def render_digest(records: list[dict]) -> str:
    """纯文本推送稿 —— 直接贴进微信群 / 钉钉群。"""
    if not records:
        return "今日未发现新的 ESG 相关招标公告。"

    lines = [f"ESG 相关招标新增 {len(records)} 条（{now_stamp()}）：", ""]
    for index, record in enumerate(records, start=1):
        amount = fmt_amount(record.get("amount_yuan"))
        date_text = record.get("published") or "日期未标注"
        lines.append(f"{index}. {record.get('title') or '（无标题）'}")
        lines.append(f"   日期：{date_text}　金额：{amount}")
        buyer = record.get("buyer") or "—"
        lines.append(f"   采购人：{buyer}")
        if record.get("url"):
            lines.append(f"   链接：{record['url']}")
        lines.append("")
    return "\n".join(lines)


def push_webhook(url: str, records: list[dict]) -> str:
    """把新增公告推到 webhook。

    返回一段描述结果的状态串；失败不抛异常 —— 推送是附加能力，
    不该让整次跑批失败（此时状态不写，下次会重推）。
    """
    if not url:
        return "未配置 webhook，仅落地文件"

    import requests

    body = {
        "msgtype": "markdown",
        "markdown": {"content": render_digest(records)},
    }
    try:
        resp = requests.post(url, json=body, timeout=20)
    except Exception as exc:  # 网络异常一律降级为"推送失败"
        return f"推送失败：{type(exc).__name__}: {exc}"

    if resp.status_code >= 400:
        return f"推送失败：HTTP {resp.status_code} {resp.text[:200]}"
    return f"推送成功：HTTP {resp.status_code}"


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    args = build_parser().parse_args(argv)
    log = make_logger(True)

    config = Config.load()
    if args.provider:
        config.search_provider = args.provider
    config.ensure_dirs()

    store = StateStore(config.state_path)
    log(f"状态文件：{config.state_path}（已记录 {len(store.seen_ids())} 条）")

    # 回溯窗口
    if args.since:
        since = args.since
    else:
        since = (date.today() - timedelta(days=args.days)).isoformat()
    until = date.today().isoformat()
    log(f"回溯窗口：{since} ~ {until}")

    try:
        provider = build_provider(config)
    except SearchUnavailable as exc:
        log(f"搜索后端不可用：{exc}")
        return 2

    log(f"搜索后端：{provider.name}")
    fetcher = Fetcher(config)

    records = collect_tenders(
        config,
        provider,
        fetcher=fetcher,
        queries=TENDER_QUERIES,
        count=args.count,
        since=since,
        until=until,
        fetch_pages=not args.no_fetch,
        log=log,
    )

    new_records = store.filter_new(records)
    log(f"候选 {len(records)} 条，其中新增 {len(new_records)} 条")

    new_dicts = [record.to_dict() for record in new_records]

    undated = sum(1 for record in new_records if not record.published)

    daily_notes = [
        "本清单只包含此前未推送过的公告，判定依据是公告 URL 的规范化结果。",
        "未能从公告中解析出金额的记录，金额列显示为「—」，不做估算。",
    ]
    if undated:
        daily_notes.append(
            f"有 {undated} 条记录解析不出发布日期，无法核实是否落在监控窗口内，"
            "已在明细里标为「日期未标注」。"
        )

    meta = default_meta(
        title="ESG 相关招标新增公告（每日推送）",
        client="中国神华",
        period_start=since,
        period_end=until,
        data_source="公开网络检索（WebSearch）+ 各级公共资源交易中心公告",
        notes=daily_notes,
    )

    payload = {
        "meta": meta,
        "summary": (
            f"本次监控窗口 {since} ~ {until}，共发现 {len(new_records)} 条"
            f"此前未推送过的 ESG 相关招标公告。"
        ),
        "highlights": [],
        "sections": [
            {
                "heading": "新增公告",
                "intro": "按发布日期倒序排列。",
                "items": [
                    {
                        "title": record.get("title", ""),
                        "url": record.get("url", ""),
                        "published": record.get("published"),
                        "source": record.get("site", ""),
                        "topic": record.get("category", ""),
                        "summary": "采购人：{buyer}　中标金额：{amount}".format(
                            buyer=record.get("buyer") or "—",
                            amount=fmt_amount(record.get("amount_yuan")),
                        ),
                    }
                    for record in new_dicts
                ],
            }
        ],
        "records": new_dicts,
        "stats": {"total": len(new_dicts)},
    }

    if not args.no_llm and new_dicts:
        from esg_toolkit.llm import summarize_tenders

        log("调用模型撰写说明…")
        narrative = summarize_tenders(
            config.claude_cli,
            f"{since} ~ {until}",
            {"total": len(new_dicts), "items": new_dicts[:20]},
        )
        if narrative:
            payload["summary"] = narrative["summary"]
            payload["highlights"] = narrative["highlights"]

    out_dir = Path(args.out) if args.out else resolve_outdir(config, "daily")
    name = args.name or f"esg-tender-daily-{date.today().strftime('%Y%m%d')}"

    paths = write_artifacts(
        out_dir, name, payload, render_markdown, render_json, render_html
    )
    digest_path = out_dir / f"{name}.txt"
    digest_path.write_text(render_digest(new_dicts), encoding="utf-8")
    log("产物已生成：")
    for kind, path in paths.items():
        log(f"  {kind}: {path}")
    log(f"  digest: {digest_path}")

    if args.dry_run:
        log("--dry-run：不写状态、不推送")
        echo_result(
            {
                "dry_run": True,
                "new_count": len(new_dicts),
                "new_titles": [r.get("title", "") for r in new_dicts],
            }
        )
        return 0

    # 先推送，成功了再记状态 —— 顺序反了会丢公告
    status = push_webhook(config.webhook_url, new_dicts)
    log(f"推送：{status}")

    store.record(new_records)
    store.save()
    pruned = store.prune(keep_days=180)
    if pruned:
        log(f"清理了 {pruned} 条过期状态")

    echo_result(
        {
            "window": f"{since} ~ {until}",
            "candidate": len(records),
            "new_count": len(new_dicts),
            "push": status,
            "state": str(config.state_path),
            "artifacts": {kind: str(path) for kind, path in paths.items()},
            "digest": str(digest_path),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
