#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""离线评测：用人工标注基准给确定性脚本层打分。

作业二的结论不能靠"看起来更准"。这个脚本把 **32 份真实公告** 跑一遍
确定性解析器，逐字段和 ``ground_truth.json`` 里人工标注的值比，
给出可复现的准确率数字。

同时做一件更重要的事：**审计基准本身**。每个非空标注值都必须能在原始
HTML 里字面找到 —— 否则说明基准和原文脱节了，后面所有分数都是废的。

用法::

    python bench/run_offline.py                 # 打印报告
    python bench/run_offline.py --json out.json # 同时落 JSON

退出码：审计不通过返回 2（基准烂了），解析有字段错返回 1。
"""

from __future__ import annotations

import argparse
import io
import json
import re
import sys
from pathlib import Path

BENCH_DIR = Path(__file__).resolve().parent
ROOT = BENCH_DIR.parent
sys.path.insert(0, str(ROOT / "scripts"))

from esg_toolkit.parse_tender import parse_tender_page  # noqa: E402

FIXTURE_DIR = BENCH_DIR / "fixtures"
GROUND_TRUTH = BENCH_DIR / "ground_truth.json"

#: 参与打分的字段。顺序就是报告里的列顺序。
SCORED_FIELDS: tuple[str, ...] = (
    "title",
    "buyer",
    "winner",
    "amount_yuan",
    "published",
    "province",
    "category",
)

#: 必填字段：这些字段全对才算"这条样本解析正确"
REQUIRED_FIELDS: tuple[str, ...] = ("title", "buyer", "winner", "amount_yuan", "published")


def _normalize(text: str) -> str:
    """比对用的归一化：去掉所有空白，保留其余字符。

    只去空白不去标点 —— 标点是标注的一部分（"（二次）" 不能丢）。
    """
    return re.sub(r"\s+", "", str(text or ""))


def audit_ground_truth(entries: list[dict], manifest: dict[str, dict]) -> list[str]:
    """审计基准：标注值必须能在原始 HTML 里找到。

    返回问题列表，空列表表示基准自洽。
    """
    problems: list[str] = []

    gt_files = {entry["file"] for entry in entries}
    missing = set(manifest) - gt_files
    extra = gt_files - set(manifest)
    if missing:
        problems.append(f"有 {len(missing)} 份 fixture 没有标注：{sorted(missing)[:3]}")
    if extra:
        problems.append(f"标注里有 {len(extra)} 份 fixture 不在 manifest 里：{sorted(extra)[:3]}")

    for entry in entries:
        name = entry["file"]
        path = FIXTURE_DIR / name
        if not path.is_file():
            problems.append(f"{name}: fixture 文件不存在")
            continue
        html = path.read_text(encoding="utf-8", errors="replace")
        flat = _normalize(html)

        # 标题 / 采购人 / 中标人：字面出现
        for field in ("title", "buyer", "winner"):
            value = _normalize(entry.get(field, ""))
            if not value:
                problems.append(f"{name}: {field} 标注为空")
                continue
            if value not in flat:
                # 标题可能带编号后缀，宽松到前 12 个字
                if value[:12] not in flat:
                    problems.append(f"{name}: {field} 在原文里找不到 —— {entry[field][:40]}")

        # 日期：允许几种常见写法
        published = entry.get("published")
        if published:
            year, month, day = (int(part) for part in published.split("-"))
            variants = (
                f"{year}-{month:02d}-{day:02d}",
                f"{year}-{month}-{day}",
                f"{year}年{month}月{day}日",
                f"{year}/{month:02d}/{day:02d}",
            )
            if not any(variant in html for variant in variants):
                problems.append(f"{name}: 日期 {published} 在原文里找不到")

        # 金额：原文串里的数字必须出现在 HTML 里
        raw = entry.get("amount_raw", "")
        if raw:
            digits = re.sub(r"[^\d.]", "", raw.split("元")[0].split("万元")[0])
            if digits and digits not in re.sub(r"[,\s￥]", "", html):
                problems.append(f"{name}: 金额原文 {raw} 在 HTML 里找不到")

    return problems


def _amount_candidates(entry: dict) -> list[float]:
    """这条公告的**合法金额**取值集合。

    分包公告下「中标金额」有多个口径 —— 报任一合同包、报公告总额，
    都是原文披露过的真实数字。只认其中一个，就是在拿基准自己的
    口径挑人（实测踩过：脚本臂报的是公告总额，被判成错）。
    """
    values: list[float] = []
    for key in ("amount_yuan", "amount_yuan_total"):
        raw = entry.get(key)
        if raw is not None:
            values.append(float(raw))
    for raw in entry.get("packages") or []:
        if raw is not None:
            values.append(float(raw))
    return values


def _matches(field: str, expected: object, actual: object, entry: dict | None = None) -> bool:
    """单个字段是否匹配。

    金额按数值比（0 与 0.0 是同一个数），其余按归一化字符串比。
    传了 ``entry`` 时按上面的多口径集合判金额。
    """
    if field == "amount_yuan":
        if entry is not None:
            candidates = _amount_candidates(entry)
            if actual is None:
                return not candidates
            return any(abs(float(actual) - value) < 0.01 for value in candidates)
        if expected is None and actual is None:
            return True
        if expected is None or actual is None:
            return False
        return abs(float(expected) - float(actual)) < 0.01
    return _normalize(expected) == _normalize(actual)


def score(entries: list[dict], manifest: dict[str, dict]) -> dict:
    """跑一遍解析器并逐字段打分。"""
    per_field_total = {field: 0 for field in SCORED_FIELDS}
    per_field_hit = {field: 0 for field in SCORED_FIELDS}
    exact_samples = 0
    required_hit = 0
    details: list[dict] = []

    for entry in entries:
        meta = manifest.get(entry["file"], {})
        html = (FIXTURE_DIR / entry["file"]).read_text(encoding="utf-8", errors="replace")
        record = parse_tender_page(
            html, url=entry["url"], fallback_title=meta.get("title", "")
        )

        if record is None:
            details.append({"file": entry["file"], "parsed": None, "misses": list(SCORED_FIELDS)})
            for field in SCORED_FIELDS:
                per_field_total[field] += 1
            continue

        actual = {
            "title": record.title,
            "buyer": record.buyer,
            "winner": record.winner,
            "amount_yuan": record.amount_yuan,
            "published": record.published,
            "province": record.province,
            "category": record.category,
        }

        misses: list[str] = []
        for field in SCORED_FIELDS:
            per_field_total[field] += 1
            if _matches(field, entry.get(field), actual[field], entry):
                per_field_hit[field] += 1
            else:
                misses.append(field)

        if all(_matches(field, entry.get(field), actual[field], entry) for field in REQUIRED_FIELDS):
            required_hit += 1
        if not misses:
            exact_samples += 1

        details.append(
            {
                "file": entry["file"],
                "title": entry["title"],
                "misses": misses,
                "expected": {field: entry.get(field) for field in SCORED_FIELDS},
                "actual": actual,
            }
        )

    total = len(entries)
    return {
        "样本数": total,
        "字段准确率": {
            field: round(per_field_hit[field] / per_field_total[field], 4)
            for field in SCORED_FIELDS
        },
        "必填字段全对率": round(required_hit / total, 4) if total else 0.0,
        "全字段全对率": round(exact_samples / total, 4) if total else 0.0,
        "逐字段命中数": {field: per_field_hit[field] for field in SCORED_FIELDS},
        "明细": details,
    }


def render_markdown(result: dict, problems: list[str]) -> str:
    """把结果渲染成人能读的 Markdown。"""
    lines: list[str] = []
    lines.append("# 离线评测报告 · 确定性脚本层")
    lines.append("")
    lines.append(
        f"样本 **{result['样本数']}** 份真实中标公告，逐字段与 `bench/ground_truth.json` "
        "的人工标注比对。"
    )
    lines.append("")

    if problems:
        lines.append("## ⚠ 基准审计未通过")
        lines.append("")
        for problem in problems:
            lines.append(f"- {problem}")
        lines.append("")
    else:
        lines.append("## 基准审计")
        lines.append("")
        lines.append("每个非空标注值都能在原始 HTML 里字面找到 —— 基准与原文自洽。")
        lines.append("")

    lines.append("## 字段准确率")
    lines.append("")
    lines.append("| 字段 | 命中 / 总数 | 准确率 |")
    lines.append("| --- | --- | --- |")
    for field, accuracy in result["字段准确率"].items():
        hit = result["逐字段命中数"][field]
        lines.append(f"| `{field}` | {hit} / {result['样本数']} | {accuracy:.1%} |")
    lines.append("")
    lines.append(
        f"- **必填字段全对率**（title/buyer/winner/amount/published 同时正确）："
        f"**{result['必填字段全对率']:.1%}**"
    )
    lines.append(f"- **全字段全对率**（七个字段全对）：**{result['全字段全对率']:.1%}**")
    lines.append("")

    misses = [d for d in result["明细"] if d["misses"]]
    if misses:
        lines.append("## 未命中的样本")
        lines.append("")
        lines.append("| 文件 | 未命中字段 |")
        lines.append("| --- | --- |")
        for detail in misses:
            lines.append(f"| `{detail['file'][:44]}` | {', '.join(detail['misses'])} |")
        lines.append("")

    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="确定性脚本层的离线评测")
    parser.add_argument("--json", help="把完整结果写成 JSON")
    parser.add_argument("--out-md", help="把 Markdown 报告写到指定文件")
    args = parser.parse_args()

    manifest = {
        item["file"]: item
        for item in json.loads(
            (FIXTURE_DIR / "manifest.json").read_text(encoding="utf-8")
        )
    }
    ground_truth = json.loads(GROUND_TRUTH.read_text(encoding="utf-8"))
    entries = ground_truth["fixtures"]

    problems = audit_ground_truth(entries, manifest)
    result = score(entries, manifest)

    report = render_markdown(result, problems)
    sys.stdout.write(report)

    if args.out_md:
        out = Path(args.out_md)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(report, encoding="utf-8")

    if args.json:
        out = Path(args.json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(
            json.dumps(
                {"基准审计问题": problems, "评测": result},
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )

    if problems:
        return 2
    return 0 if result["全字段全对率"] >= 1.0 else 1


if __name__ == "__main__":
    if hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.exit(main())
