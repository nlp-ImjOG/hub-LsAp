import io, sys, shutil
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 阶段一（build2.py）：抓取 + 解析 + 初筛的审计
shutil.copy('output/audit.txt', 'output/audit_stage1.txt')
print('阶段一审计已备份 -> output/audit_stage1.txt')
