import io, sys, json, re
from pathlib import Path
from collections import Counter
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

recs = json.loads(Path('output/records.json').read_text(encoding='utf-8'))
out = []
out.append('records %d' % len(recs))
out.append('无日期 %d' % sum(1 for r in recs if not r.get('published')))
out.append('无金额 %d' % sum(1 for r in recs if r.get('amount_yuan') is None))
out.append('无采购人 %d' % sum(1 for r in recs if not (r.get('buyer') or '').strip()))
out.append('无中标单位 %d' % sum(1 for r in recs if not (r.get('winner') or '').strip()))
out.append('无省份 %d' % sum(1 for r in recs if not (r.get('province') or '').strip()))
out.append('无方向 %d' % sum(1 for r in recs if not (r.get('category') or '').strip()))
w = Counter((r.get('winner') or '').strip() for r in recs if (r.get('winner') or '').strip())
out.append('有中标单位 %d 条 / 不同单位 %d 家 / 最多 %d 单' % (sum(w.values()), len(w), max(w.values())))
out.append('复购单位: %s' % ', '.join('%s(%d)' % (k, v) for k, v in w.most_common() if v >= 2))

for f in ['output/audit_stage1.txt', 'output/audit.txt']:
    p = Path(f)
    out.append('==== %s (%d 行) ====' % (f, len(p.read_text(encoding='utf-8').splitlines())))
    txt = p.read_text(encoding='utf-8')
    # 统计各类前缀
    c = Counter()
    for line in txt.splitlines():
        m = re.match(r'^\[([^\]]+)\]', line.strip())
        if m:
            c[m.group(1)] += 1
    for k, v in c.most_common():
        out.append('   %-24s %d' % (k, v))
    out.append('   --- 前 6 行 ---')
    for line in txt.splitlines()[:6]:
        out.append('   ' + line[:150])
    out.append('   --- 末 8 行 ---')
    for line in txt.splitlines()[-8:]:
        out.append('   ' + line[:150])

Path('output/check_claims.txt').write_text('\n'.join(out), encoding='utf-8')
print('ok')
