#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把确定性统计结果渲染成 report.md 里的表格块。

只渲染"能写成规则的活"（金额分档、月度走势、热点方向、地区/采购人分布、明细表）。
导语、要点、结论由人写，放在 report.md 里，本脚本不碰。

report.md 里用**具名占位符**指明每张表放在哪一节::

    <!-- T:amounts -->   金额分档
    <!-- T:trend -->      按月走势
    <!-- T:hotspots -->   热点方向词频
    <!-- T:categories --> 方向分布
    <!-- T:regions -->    地区分布
    <!-- T:buyers -->     采购人类型分布
    <!-- T:detail -->     中标明细

每一张统计表都带一列"代表项目"，点进去就是那条公告的原文链接 ——
汇总表里的每一个数字都能顺着链接核回原文。

口径约定：全报告的**条数占比**一律以 106 条全部公告为分母，
**金额占比**以 4.7640 亿元为分母；未披露金额的 25 条单列一档，不进金额分母。

用法::

    python make_report.py          # 生成 output/tables.md 并注入 report.md
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
sys.path.insert(0, str(ROOT))

from refine_buyers import classify_buyer  # noqa: E402

OUT = ROOT / "output"
STATS = json.loads((OUT / "stats.json").read_text(encoding="utf-8"))
RECORDS = json.loads((OUT / "records.json").read_text(encoding="utf-8"))

#: 金额档位的上下界（与 aggregate.summarize 的分档口径一致）
BUCKET_BOUNDS: dict[str, tuple[float | None, float | None]] = {
    "10 万以下": (None, 100_000),
    "10–50 万": (100_000, 500_000),
    "50–100 万": (500_000, 1_000_000),
    "100–500 万": (1_000_000, 5_000_000),
    "500–1000 万": (5_000_000, 10_000_000),
    "1000 万–1 亿": (10_000_000, 100_000_000),
    "1 亿以上": (100_000_000, None),
}

#: 未披露金额这一档没有上下界，必须单独判定 —— 否则区间检查会把"有金额"的记录也算进去
UNDISCLOSED = "金额未披露"

#: 省级行政区推断不出来时的占位写法
UNKNOWN_REGION = "未识别"


def esc(text: str) -> str:
    return (text or "").replace("|", "／").replace("\n", " ").strip()


def esc_link(text: str) -> str:
    """链接文字里的方括号要转义，否则 "[公示结束] xxx" 会把 Markdown 链接拆断。"""
    return esc(text).replace("[", "\\[").replace("]", "\\]")


def amount_cell(record: dict) -> str:
    """中标金额列：能归一就写归一后的值；写不出就写「—」，不估算。"""
    value = record.get("amount_yuan")
    if value is None:
        discount = (record.get("extra") or {}).get("discount")
        if discount:
            return f"折扣 {discount}（无固定金额）"
        rate = (record.get("extra") or {}).get("rate")
        if rate:
            return f"费率 {rate}（无固定金额）"
        return "—"
    if value >= 1e8:
        return f"{value / 1e8:.2f} 亿元"
    if value >= 1e4:
        return f"{value / 1e4:.2f} 万元"
    return f"{value:,.0f} 元"


def amount_total(value: float) -> str:
    """表格里的合计金额。"""
    if not value:
        return "—"
    if value >= 1e8:
        return f"{value / 1e8:.4f} 亿元"
    if value >= 1e4:
        return f"{value / 1e4:.2f} 万元"
    return f"{value:,.0f} 元"


def link_of(record: dict) -> str:
    """代表项目：项目名 + 原文链接。"""
    title = esc_link(record.get("title")) or "（无标题）"
    url = record.get("url", "")
    return f"[{title}]({url})" if url else title


def pick(predicate) -> dict | None:
    """挑一条满足条件的记录当代表（取发布日期最新的那条）。"""
    for record in RECORDS:
        if predicate(record):
            return record
    return None


def table_amounts() -> str:
    """金额分档。条数占比以 106 条为分母；金额未披露档不进金额分母。"""
    total_count = STATS["total"] or 1
    lines = [
        "| 中标金额档位 | 条数 | 条数占比（占 106 条） | 金额合计 | 金额占比 | 代表项目（原文） |",
        "| --- | ---: | ---: | ---: | ---: | --- |",
    ]
    for bucket in STATS["buckets"]:
        count = bucket["count"]
        name = bucket["bucket"]
        low, high = BUCKET_BOUNDS.get(name, (None, None))

        def in_bucket(record: dict, low=low, high=high, name=name) -> bool:
            value = record.get("amount_yuan")
            if name == UNDISCLOSED:
                return value is None
            if value is None:
                return False
            if low is not None and value < low:
                return False
            if high is not None and value >= high:
                return False
            return True

        sample = pick(in_bucket)
        if name == UNDISCLOSED:
            amount_sum = "—（不计入）"
            amount_share = "—（不计入）"
        elif not count:
            amount_sum = "—"
            amount_share = "—"
        else:
            amount_sum = amount_total(bucket["total_yuan"])
            amount_share = f"{bucket['amount_ratio'] * 100:.1f}%"
        lines.append(
            f"| {name} | {count} | {count / total_count * 100:.1f}% | "
            f"{amount_sum} | {amount_share} | "
            f"{link_of(sample) if sample else '—（本档 0 条，无可链接项目）'} |"
        )
    amount = STATS["amount"]
    lines.append(
        f"| **合计** | **{STATS['total']}** | 100% | "
        f"**{amount_total(amount['total_yuan'])}** | 100% | — |"
    )
    return "\n".join(lines)


def table_trend() -> str:
    lines = [
        "| 发布月份 | 公告条数 | 其中披露金额 | 中标金额合计 | 代表项目（原文） |",
        "| --- | ---: | ---: | ---: | --- |",
    ]
    for row in STATS["trend"]:
        month = row["month"]
        in_month = [r for r in RECORDS if (r.get("published") or "")[:7] == month]
        with_amount = sum(1 for r in in_month if r.get("amount_yuan") is not None)
        sample = in_month[0] if in_month else None
        lines.append(
            f"| {month} | {row['count']} | {with_amount} | {amount_total(row['total_yuan'])} | "
            f"{link_of(sample) if sample else '—'} |"
        )
    return "\n".join(lines)


def table_hotspots() -> str:
    lines = [
        "| 招标方向词（只统计项目标题） | 命中条数 | 占比 | 所属方向 | 代表项目（原文） |",
        "| --- | ---: | ---: | --- | --- |",
    ]
    for row in STATS["hotspots"]:
        term = row["term"]
        sample = pick(lambda r, t=term: t in (r.get("title") or ""))
        lines.append(
            f"| {term} | {row['count']} | {row['share'] * 100:.1f}% | {row['category']} | "
            f"{link_of(sample) if sample else '—'} |"
        )
    return "\n".join(lines)


def table_categories() -> str:
    lines = [
        "| ESG 细分方向 | 公告条数 | 条数占比 | 中标金额合计 | 代表项目（原文） |",
        "| --- | ---: | ---: | ---: | --- |",
    ]
    for row in STATS["categories"]:
        category = row["category"]
        sample = pick(lambda r, c=category: r.get("category") == c)
        lines.append(
            f"| {category} | {row['count']} | {row['ratio'] * 100:.1f}% | "
            f"{amount_total(row['total_yuan'])} | {link_of(sample) if sample else '—'} |"
        )
    return "\n".join(lines)


def table_regions() -> str:
    lines = [
        "| 地区（采购人所在省级行政区） | 公告条数 | 中标金额合计 | 代表项目（原文） |",
        "| --- | ---: | ---: | --- |",
    ]
    for row in STATS["regions"]:
        region = row["region"]
        # 省份推断不出来的记录在 records.json 里是空值，统计里叫「未识别」——
        # 代表项目要按同样的口径回查，否则这一行会找不到链接。
        sample = pick(lambda r, g=region: (r.get("province") or UNKNOWN_REGION) == g)
        lines.append(
            f"| {region} | {row['count']} | {amount_total(row['total_yuan'])} | "
            f"{link_of(sample) if sample else '—'} |"
        )
    return "\n".join(lines)


def table_buyers() -> str:
    lines = [
        "| 采购人类型（按机构性质） | 公告条数 | 占比 | 代表采购人（原文） |",
        "| --- | ---: | ---: | --- |",
    ]
    total = STATS["total"] or 1
    for label, count in STATS["buyers"].items():
        sample = pick(lambda r, l=label: classify_buyer(r.get("buyer") or "") == l)
        lines.append(
            f"| {label} | {count} | {count / total * 100:.1f}% | "
            f"{link_of(sample) if sample else '—'} |"
        )
    return "\n".join(lines)


def table_detail() -> str:
    lines = [
        "| 发布日期 | 项目名称（点击看原文） | 采购人 | 中标单位 | 中标金额 | 方向 | 地区 |",
        "| --- | --- | --- | --- | ---: | --- | --- |",
    ]
    for record in RECORDS:
        lines.append(
            f"| {record.get('published') or '日期未标注'} | {link_of(record)} | "
            f"{esc(record.get('buyer')) or '未检索到'} | {esc(record.get('winner')) or '未检索到'} | "
            f"{amount_cell(record)} | {esc(record.get('category')) or '未分类'} | "
            f"{esc(record.get('province')) or '未识别'} |"
        )
    return "\n".join(lines)


TABLES = {
    "amounts": table_amounts,
    "trend": table_trend,
    "hotspots": table_hotspots,
    "categories": table_categories,
    "regions": table_regions,
    "buyers": table_buyers,
    "detail": table_detail,
}


def main() -> int:
    rendered = {name: func() for name, func in TABLES.items()}

    blocks = ["\n\n".join(f"### {name}\n\n{text}" for name, text in rendered.items())]
    (OUT / "tables.md").write_text("\n\n".join(blocks), encoding="utf-8")

    report_path = ROOT / "report.md"
    if not report_path.is_file():
        print("report.md 不存在 —— 先写正文骨架（含占位符），再跑本脚本注入表格")
        return 0

    body = report_path.read_text(encoding="utf-8")
    missing = []
    for name, text in rendered.items():
        marker = f"<!-- T:{name} -->"
        if marker in body:
            body = body.replace(marker, text)
        else:
            missing.append(name)
    report_path.write_text(body, encoding="utf-8")

    print(f"已注入 report.md：明细 {len(RECORDS)} 条")
    if missing:
        print(f"未找到占位符的表：{', '.join(missing)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
