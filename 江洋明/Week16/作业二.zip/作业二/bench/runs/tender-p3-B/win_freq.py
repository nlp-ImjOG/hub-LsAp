import io, sys, json
from collections import Counter
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

recs = json.loads(open('output/records.json', encoding='utf-8').read())
c = Counter()
for r in recs:
    w = (r.get('winner') or '').strip()
    if w:
        c[w] += 1
lines = []
for name, n in c.most_common(20):
    total = sum(r['amount_yuan'] for r in recs if (r.get('winner') or '').strip() == name and r.get('amount_yuan'))
    lines.append('%d 条 | 合计 %.2f 元 | %s' % (n, total, name))
lines.append('---')
lines.append('有中标单位的记录 %d 条；不同中标单位 %d 家' % (sum(1 for r in recs if (r.get('winner') or '').strip()), len(c)))
open('output/winners.txt', 'w', encoding='utf-8').write('\n'.join(lines))
print('ok')
