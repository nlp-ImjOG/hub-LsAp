import io, sys, re, hashlib, pathlib
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
CACHE = pathlib.Path('output/cache')
urls = {
    '应对气候变化-ggzy': 'https://www.ggzy.gov.cn/information/deal/html/b/500000/0202/20260519/005021c958d038354cfc9dabe8661bafe982.html',
    '义乌绿色低碳产业园': 'https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202610/t20261005_27701245.htm',
    '数字化绿色智能工厂': 'https://ggzyjy.weihai.cn/jyxx/003001/003001005/20250320/64383BF6-4A69-4CA1-A812-8963781B52EC.html',
}
out = []
for name, url in urls.items():
    f = CACHE / (hashlib.sha1(url.encode('utf-8')).hexdigest() + '.html')
    out.append('##### %s' % name)
    if not f.is_file():
        out.append('  (no cache) %s' % url)
        continue
    html = f.read_text(encoding='utf-8', errors='replace')
    txt = re.sub(r'<script.*?</script>', ' ', html, flags=re.S | re.I)
    txt = re.sub(r'<style.*?</style>', ' ', txt, flags=re.S | re.I)
    txt = re.sub(r'<[^>]+>', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt)
    out.append('  URL=%s' % url)
    out.append('  施工=%d 建设=%d EPC=%d 总承包=%d 标段=%d' % (
        txt.count('施工'), txt.count('建设'), txt.count('EPC'), txt.count('总承包'), txt.count('标段')))
    for kw in ['746000', '746,000', '1166000', '1,166,000']:
        for m in re.finditer(re.escape(kw), txt):
            out.append('  [%s] ...%s...' % (kw, txt[max(0, m.start() - 110):m.start() + 60]))
    out.append('  HEAD: %s' % txt[:600])
    out.append('')
open('output/dbg_rows4.txt', 'w', encoding='utf-8').write('\n'.join(out))
print('ok')
