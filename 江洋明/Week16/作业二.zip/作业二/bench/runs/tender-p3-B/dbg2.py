import io, sys, re, hashlib, pathlib
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '.claude/skills/esg-tender-monitor/scripts')
from esg_toolkit.parse_tender import extract_rows
CACHE = pathlib.Path('output/cache')
targets = {
    'xian-减污降碳': 'https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202607/t20260702_26861655.htm',
    'gansu-核查': 'https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202604/t20260408_26372690.htm',
    'datong-节水': 'https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251126_25856578.htm',
    'qingdao-碳足迹': 'https://ggzy.qingdao.gov.cn/TradeDetals-ZtbShow/163470-5070-1-2-0/a93138c1-fb2b-451a-b56a-812c2a1dc83f',
    'shandong-碳足迹': 'https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202606/t20260624_26826995.htm',
}
out = []
for name, url in targets.items():
    f = CACHE / (hashlib.sha1(url.encode('utf-8')).hexdigest() + '.html')
    if not f.is_file():
        out.append('##### %s  (no cache) %s' % (name, url))
        continue
    html = f.read_text(encoding='utf-8', errors='replace')
    out.append('##### %s  %s' % (name, url))
    for i, cells in enumerate(extract_rows(html)):
        j = ' | '.join(cells)
        if re.search(r'金额|价|元|万|序号|供应商|单位|合计|总计|包', j):
            out.append('  r%-3d %s' % (i, j[:260]))
    out.append('')
open('output/dbg_rows2.txt', 'w', encoding='utf-8').write('\n'.join(out))
print('ok')
