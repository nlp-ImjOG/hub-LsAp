import io, sys, json
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
S = json.loads(Path('output/stats.json').read_text(encoding='utf-8'))
out = []
out.append('total=%s  amount=%s' % (S['total'], json.dumps(S['amount'], ensure_ascii=False)))
out.append('---- buckets ----')
for b in S['buckets']:
    out.append('%-10s count=%-4s ratio=%.4f total=%.2f amount_ratio=%.4f' % (
        b['bucket'], b['count'], b['ratio'], b['total_yuan'], b['amount_ratio']))
out.append('---- categories ----')
for c in S['categories']:
    out.append('%-22s count=%-4s ratio=%.4f total=%.2f' % (c['category'], c['count'], c['ratio'], c['total_yuan']))
out.append('---- regions (count desc) ----')
for r in sorted(S['regions'], key=lambda x: -x['count']):
    out.append('%-8s count=%-4s total=%.2f' % (r['region'], r['count'], r['total_yuan']))
out.append('---- trend (by total desc, top6) ----')
for t in sorted(S['trend'], key=lambda x: -x['total_yuan'])[:6]:
    out.append('%s count=%-4s total=%.2f' % (t['month'], t['count'], t['total_yuan']))
out.append('---- trend months ----')
out.append(', '.join(t['month'] for t in S['trend']))
out.append('---- buyers ----')
for k, v in S['buyers'].items():
    out.append('%-24s %s' % (k, v))
out.append('---- hotspots ----')
for h in S['hotspots']:
    out.append('%-14s %-4s %.4f %s' % (h['term'], h['count'], h['share'], h['category']))
Path('output/check_numbers.txt').write_text('\n'.join(out), encoding='utf-8')
print('ok')
