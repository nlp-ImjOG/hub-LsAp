#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""修正层 —— 汇总报告与每日监控共用的数据修正规则。

放在 Skill 脚本层**之外**，因为这些是本次抽取实际踩到的坑的修补，
而不是 Skill 本身的规则。Skill 的脚本层保持原样，方便做两臂对照。

修的七件事：

1. **单位二次换算**。Skill 的 ``_join_amounts`` 把多包金额（已经是元）加总后
   返回**不带单位**的数字，而 ``amount_unit`` 仍留着标签行里的「万元」，
   ``normalize_amount`` 于是又乘了一次 10000 —— 9,271,740 元被读成
   92,717,400,000 元。这一层改成自己推导，单位优先级：
   **金额串自带 > 结果表列头 > 标签格里写的单位**，三者都没有就不采信。
2. **多包求和**。Skill 的正文正则只取**第一个**"中标金额"，多包项目会少算
   （应对气候变化统计核算分析：包7 74.6 万 + 包8 42 万 = 116.6 万）。
3. **总额与分项交叉校验**。表头「总中标金额」和结果表分项金额互为校验；
   对不上时采用**带明确单位的总额**，并把分歧记进审计。
4. **标题兜底**。页面 ``<title>`` 抓到页脚样板句（"十五、对本次公告内容提出
   询问、质疑、投诉……"）时退回检索得到的标题；404 / JS 模板占位符页直接丢弃。
5. **去重**。URL 之外再按「项目名 + 日期」去重（同一项目在不同分网的转载），
   合并时优先保留带金额、金额来源更可靠的那条。
6. **相关性闸门**。Skill 的 ``ESG_STRONG_KEYWORDS`` 比它自己的方向矩阵窄 ——
   生态修复、污染防治、节水这些方向的公告会被整体漏掉。本层按**方向矩阵**
   口径判定，再叠加排除词表。
7. **土建类剔除**。园区、厂房建设类合同（EPC、施工）金额动辄上亿，混进来会
   把"ESG 咨询服务"这个市场的金额分布彻底带偏，按 Skill 排除词表的思路剔除。

规矩仍然是 Skill 的那条：**宁可漏，不要猜**。任何一处单位对不上，宁可写「—」。
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.keywords import (  # noqa: E402
    ESG_CATEGORIES,
    ESG_STRONG_KEYWORDS,
    is_excluded,
)
from esg_toolkit.parse_tender import (  # noqa: E402
    UNIT_FACTORS,
    detect_unit,
    extract_rows,
    parse_date,
)

# ---------------------------------------------------------------- 金额推导

#: 结果表的金额**列头**
_COL_AMT_RE = re.compile(
    r"中标[（(]成交[）)]金额|中标金额|成交金额|中标[（(]成交[）)]价|中标价|成交价"
)

#: 键值行/正文里当标签用的金额字段名
_AMT_LABEL_RE = re.compile(r"(?:金额|价格|报价|总价)")

#: 看着像金额、其实不是中标金额的行（代理费、保证金、收费标准）
_NOT_AWARD_RE = re.compile(r"代理服务收费|收费标准|收费|保证金|履约保证|代理费")

#: 「总」字头的标签 —— 这是公告自己给出的汇总金额，最可信
_TOTAL_LABEL_RE = re.compile(r"总中标金额|总成交金额|总金额|合计|总额|总计")

#: 金额串（必须自带单位）
_AMOUNT_WITH_UNIT_RE = re.compile(
    r"([\d,，]+(?:\.\d+)?)\s*[（(]?\s*(亿元|万元|千元|元)\s*[）)]?"
)

#: 金额串（不带单位，只取数字）
_BARE_NUMBER_RE = re.compile(r"[\d,，]+(?:\.\d+)?")

#: 结果表数据行的"下一张表头"识别：首列是这些词就不是数据行
_ROW_HEADER_WORDS = ("序号", "标项", "包号", "标包", "标段名称", "项目名称", "供应商名称")

#: 金额格不可能很长；超过这个长度说明抓到的是正文块，不是金额
_MAX_AMOUNT_CELL = 60


def amount_with_unit(text: str | None) -> tuple[float | None, bool]:
    """只按金额串**自带**的单位归一。

    返回 ``(金额_元, 单位是否明确)``。没有单位的数字返回 ``(数字, False)`` ——
    交给上层靠列头/总额交叉校验，绝不自己猜单位。
    """
    if text is None:
        return None, False
    s = str(text).strip()
    if not s or "折扣" in s or "%" in s or "费率" in s:
        return None, False
    match = _AMOUNT_WITH_UNIT_RE.search(s)
    if not match:
        bare = _BARE_NUMBER_RE.search(s)
        if bare:
            try:
                return float(bare.group(0).replace(",", "").replace("，", "")), False
            except ValueError:
                return None, False
        return None, False
    try:
        value = float(match.group(1).replace(",", "").replace("，", ""))
    except ValueError:
        return None, False
    return round(value * UNIT_FACTORS[match.group(2)], 2), True


def _apply_unit(value: float | None, known: bool, unit: str) -> tuple[float | None, bool]:
    """金额串没带单位时，用外部单位（列头 / 标签）补上。"""
    if value is None or known or not unit:
        return value, known
    return round(value * UNIT_FACTORS[unit], 2), True


def has_explicit_unit(raw: str) -> bool:
    """金额原文里有没有写单位（没写单位的数字不可信）。"""
    if not raw:
        return False
    return bool(re.search(r"(亿元|万元|千元|元)", str(raw)))


def _scan_tables(rows: list[list[str]]) -> tuple[list, list]:
    """扫表格，分成「结果表分项」与「键值金额」两类。

    分项项：``(金额数字, 单位是否明确, 原文)``
    键值项：``(标签, 金额数字, 单位是否明确, 原文)``
    """
    col_items: list[tuple[float, bool, str]] = []
    kv_items: list[tuple[str, float, bool, str]] = []

    # ---- 结果表：>=3 列且有金额列头 ----
    index = 0
    total = len(rows)
    while index < total:
        cells = rows[index]
        if len(cells) >= 3:
            column = None
            for position, cell in enumerate(cells):
                if _COL_AMT_RE.search(cell):
                    column = position
                    break
            if column is not None:
                # 单位随列头走："中标（成交）金额(元)" -> 元
                header_unit = detect_unit(cells[column])
                cursor = index + 1
                while cursor < total:
                    row = rows[cursor]
                    if not any(re.search(r"\d", cell) for cell in row):
                        break
                    if row[0].strip() in _ROW_HEADER_WORDS:
                        break
                    if column < len(row):
                        cell = row[column]
                    else:
                        # 有些行缺格（地址列为空），金额落到最后一格
                        cell = row[-1]
                    if len(cell) > _MAX_AMOUNT_CELL:
                        # 抓到的是正文块，不是金额格
                        cursor += 1
                        continue
                    value, known = amount_with_unit(cell)
                    value, known = _apply_unit(value, known, header_unit)
                    if value is not None:
                        col_items.append((value, known, cell))
                    cursor += 1
                index = cursor
                continue
        index += 1

    # ---- 键值：标签格 + 相邻的值格 ----
    for cells in rows:
        for position, label in enumerate(cells):
            if position + 1 >= len(cells):
                break
            if len(label) > 40 or not _AMT_LABEL_RE.search(label):
                continue
            if _NOT_AWARD_RE.search(label):
                continue
            value_cell = cells[position + 1]
            if len(value_cell) > _MAX_AMOUNT_CELL:
                continue
            value, known = amount_with_unit(value_cell)
            # 单位随标签格走："投标报价（人民币万元）" -> 万元
            value, known = _apply_unit(value, known, detect_unit(label))
            if value is None:
                continue
            kv_items.append((label.strip(), value, known, value_cell))

    return col_items, kv_items


#: 正文里的分项金额："中标（成交）金额：746,000.00元"、"中标金额（元/优惠率）：13219522"
_BODY_AMOUNT_RE = re.compile(
    r"(?:中标|成交)\s*[（(]?\s*成交?\s*[）)]?\s*金额"
    r"(?:\s*[（(][^）)）]{0,12}[）)])?\s*[：:]\s*"
    r"([\d,，]+(?:\.\d+)?)\s*(亿元|万元|千元|元)?"
)


def body_amounts(html: str) -> list[tuple[float, bool]]:
    """正文里的分项金额（多包项目要全部加起来）。"""
    if not html:
        return []
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&nbsp;", " ", text)
    results: list[tuple[float, bool]] = []
    for match in _BODY_AMOUNT_RE.finditer(text):
        raw = match.group(1)
        try:
            value = float(raw.replace(",", "").replace("，", ""))
        except ValueError:
            continue
        unit = match.group(2)
        if unit:
            results.append((round(value * UNIT_FACTORS[unit], 2), True))
        else:
            results.append((value, False))
    return results


def rederive_amount(html: str) -> tuple[float | None, str, list[str]]:
    """从公告 HTML 重新推导中标金额（元）。

    返回 ``(金额_元, 依据, 说明)``。金额为 ``None`` 表示"看到了金额但
    定不下来"；依据为「未找到金额」表示"这张表里没有金额线索"，
    两者要区别对待。
    """
    if not html:
        return None, "未找到金额", []

    rows = extract_rows(html)
    if not rows:
        return None, "未找到金额", []

    col_items, kv_items = _scan_tables(rows)
    notes: list[str] = []

    def close(left: float, right: float) -> bool:
        return abs(left - right) <= max(1.0, abs(right) * 0.001)

    col_total = None
    if col_items and all(item[1] for item in col_items):
        col_total = round(sum(item[0] for item in col_items), 2)

    totals = [item for item in kv_items if _TOTAL_LABEL_RE.search(item[0]) and item[2]]
    singles = [item for item in kv_items if not _TOTAL_LABEL_RE.search(item[0]) and item[2]]
    body = body_amounts(html)
    body_known = [value for value, known in body if known]

    # 1) 公告自己给的汇总金额 —— 最可信
    if totals:
        label, value = totals[0][0], totals[0][1]
        if value > 0:
            if col_total is not None and not close(value, col_total):
                notes.append(
                    f"「{label}」={value:,.2f} 元 与 结果表分项合计 "
                    f"{col_total:,.2f} 元 不一致，采用总额"
                )
            return value, f"「{label}」", notes
        notes.append(f"「{label}」为 0，按未披露处理")
        return None, "总额为 0", notes

    # 2) 结果表分项合计
    if col_total is not None and col_total > 0:
        return col_total, "结果表分项合计", notes

    # 3) 正文分项金额合计（多包项目）
    if body_known:
        total = round(sum(body_known), 2)
        if total > 0:
            if len(body_known) > 1:
                return total, f"正文分项合计（{len(body_known)} 个包）", notes
            return total, "正文金额", notes

    # 4) 单项金额（中标金额：X）
    if singles:
        label, value = singles[0][0], singles[0][1]
        if value > 0:
            return value, f"「{label}」", notes

    if singles or body:
        notes.append("金额缺单位或为 0，未采信")
        return None, "金额无单位", notes

    return None, "未找到金额", notes


# ---------------------------------------------------------------- 标题修补

#: 页面里抓到的样板句 —— 不是公告标题
_BOILERPLATE_TITLE_RE = re.compile(
    r"对本次公告内容提出询问|^\s*[一二三四五六七八九十]+\s*、|^\s*\d+\s*、|"
    r"^\s*附件\s*[:：]|返回网站首页|中标人名称|中标价（结算率）|"
    r"^\s*项目名称\s*\|\s*|供应商名称.*中标金额"
)

#: 页面本身就没内容 —— 404、JS 模板占位符、错误页
_ERROR_TITLE_RE = re.compile(
    r"404|Not Found|页面不存在|错误页面|访问出错|Forbidden|"
    r"\{\{|\}\}|undefined|NaN"
)


def is_error_title(title: str) -> bool:
    """标题是不是「页面没抓到」留下的痕迹。"""
    return bool(_ERROR_TITLE_RE.search(title or ""))


def is_boilerplate_title(title: str) -> bool:
    """标题是不是页脚/分节样板句、或者表头被拍成了标题。"""
    return bool(_BOILERPLATE_TITLE_RE.search(title or ""))


# ---------------------------------------------------------------- 日期兜底

#: Skill 的日期正则没覆盖的常见标签
_EXTRA_DATE_RE = re.compile(
    r"(?:公示时间|发表时间|公告发布时间|发布于|时间)\s*[：:]\s*"
    r"(20\d{2}\s*[-/年.]\s*\d{1,2}\s*[-/月.]\s*\d{1,2}\s*日?)"
)

#: URL 路径里自带发布日期的平台（江苏公共资源交易平台：/jyxx/.../20260908/xxx.html）
_URL_DATE_RULES: list[tuple[str, re.Pattern]] = [
    (
        "jszwfw.gov.cn",
        re.compile(r"/(20\d{2})(\d{2})(\d{2})/[0-9a-f\-]{8,}\.html"),
    ),
]


def repair_date(html: str, url: str) -> tuple[str | None, str]:
    """补日期：先看正文标签，再看平台 URL 约定。返回 (ISO 日期, 依据)。"""
    if not html:
        return None, ""
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&nbsp;", " ", text)
    match = _EXTRA_DATE_RE.search(text)
    if match:
        iso = parse_date(match.group(1))
        if iso:
            return iso, "正文标签"
    for domain, pattern in _URL_DATE_RULES:
        if domain in (url or ""):
            found = pattern.search(url)
            if found:
                year, month, day = found.groups()
                return f"{year}-{month}-{day}", "平台 URL 路径日期"
    return None, ""


# ---------------------------------------------------------------- 土建类剔除

#: 标题里出现这些词，说明标的物是"工程"而不是"咨询服务"
_WORKS_TITLE_RE = re.compile(
    r"施工|总承包|土建|基础设施建设|基础设施建|厂房建设|厂房建|标准化厂房|"
    r"建筑安装|装修工程|基建工程"
)

#: 标题里出现这些词，说明买的是服务/技术，不是工程量
_SERVICE_WORDS = (
    "咨询", "服务", "评价", "核查", "核算", "评估", "规划", "监测", "检测",
    "运维", "培训", "审计", "鉴证", "调查", "治理", "管护", "托管", "研究",
    "编制", "技术", "管理", "平台", "系统", "评估", "诊断", "运维",
)

#: 正文里的"工程量"信号
_WORKS_BODY_RE = re.compile(r"建设规模|建筑面积|工期（日历天）|工期\(日历天\)")


def is_works_contract(title: str, html: str) -> bool:
    """这条公告是不是"盖楼修路"类的工程合同。

    工程合同单笔动辄上亿，混进 ESG 咨询服务的金额分布会把结论带偏；
    但"绿色建筑咨询、检测服务"这类标题里带"工程"字样的要保留，
    所以判断条件是：**没有服务类词** 且（标题像工程 或 正文有工程量字段）。
    """
    text = title or ""
    if any(word in text for word in _SERVICE_WORDS):
        return False
    if _WORKS_TITLE_RE.search(text):
        return True
    if html and _WORKS_BODY_RE.search(html):
        return True
    return False


# ---------------------------------------------------------------- 相关性闸门

#: 方向矩阵里没单列、但确实是 ESG 采购方向的词
_EXTRA_ESG_WORDS = [
    "碳资产",
    "碳管理",
    "气候变化",
    "减污降碳",
    "低碳",
    "气候投融资",
    "碳交易",
    "碳汇",
    "绿色",
    "环保",
    "治污",
    "排污",
    "土壤",
    "流域",
    "水利",
    "污水",
]


def esg_scope(text: str) -> tuple[bool, str]:
    """判断一段文本是否在报告口径内。

    返回 ``(是否纳入, 依据)``。口径 = 方向矩阵任一方向的关键词命中
    （Skill 的强信号词是其子集），再排除土建、绿化养护、办公用品这类
    非 ESG 采购。
    """
    if not text:
        return False, "空文本"
    if is_excluded(text):
        return False, "命中排除词"
    if any(word in text for word in ESG_STRONG_KEYWORDS):
        return True, "强信号词"
    for category, words in ESG_CATEGORIES.items():
        if any(word in text for word in words):
            return True, f"方向矩阵：{category}"
    if any(word in text for word in _EXTRA_ESG_WORDS):
        return True, "补充词"
    return False, "未命中"


# ---------------------------------------------------------------- 去重

_TITLE_NOISE_RE = re.compile(
    r"[\s()（）【】\[\]、，,。\.：:；;\-—_－\"“”'‘’!！?？/｜|]+"
)
_TITLE_SUFFIX_RE = re.compile(
    r"(中标[（(]成交[）)]结果公告|中标[（(]成交[）)]结果|中标结果公告|成交结果公告|"
    r"中标结果公布|中标候选人公示|成交结果公告|中标公告|成交公告|结果公告|"
    r"中标结果|成交结果|结果|公告|公示)$"
)
_TITLE_PACKAGE_RE = re.compile(
    r"(采购包|标段|分标段|标包|包号)?[0-9一二三四五六七八九十]+$"
)


def core_title(title: str) -> str:
    """去掉标点、公告类型后缀与标段编号后的"项目名"，用于跨站去重。"""
    text = _TITLE_NOISE_RE.sub("", title or "")
    previous = None
    while previous != text:
        previous = text
        text = _TITLE_SUFFIX_RE.sub("", text)
        text = _TITLE_PACKAGE_RE.sub("", text)
    return text
