import io, sys, re, json
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

root = Path('.')
text = (root / 'report.md').read_text(encoding='utf-8')
lines = text.splitlines()
out = []
out.append('总行数 %d，总字符 %d' % (len(lines), len(text)))
out.append('剩余占位符: %s' % re.findall(r'<!-- T:[a-z]+ -->', text))
out.append('---- 标题结构 ----')
for i, l in enumerate(lines, 1):
    if l.startswith('#'):
        out.append('%5d  %s' % (i, l))
out.append('---- 链接统计 ----')
links = re.findall(r'\[[^\]]*\]\(([^)]+)\)', text)
out.append('markdown 链接总数 %d，唯一 URL %d' % (len(links), len(set(links))))
recs = json.loads((root / 'output' / 'records.json').read_text(encoding='utf-8'))
urls = {r['url'] for r in recs if r.get('url')}
hit = [u for u in urls if u in text]
miss = [u for u in urls if u not in text]
out.append('records.json 中的 URL 出现在 report.md 的: %d / %d' % (len(hit), len(urls)))
for u in miss:
    out.append('  缺失: %s' % u)
out.append('---- 关键数字核对 ----')
for kw in ['106', '4.7640', '95.0', '588.1', '74.3%', '4.9%', '25 条', '80 条']:
    out.append('  %-10s 出现 %d 次' % (kw, text.count(kw)))
out.append('---- 表格行数 ----')
for name in ['金额档位', '发布月份', '招标方向词', 'ESG 细分方向', '地区（采购人', '采购人类型', '发布日期']:
    n = sum(1 for l in lines if l.startswith('|') and name in l)
    out.append('  %-14s 表行 %d' % (name, n))
out.append('---- 每行是否都有链接（明细表）----')
det = [l for l in lines if re.match(r'^\| \d{4}-\d{2}-\d{2} \|', l)]
nolink = [l for l in det if not re.search(r'\]\(http', l)]
out.append('明细行 %d，其中无链接 %d' % (len(det), len(nolink)))
for l in nolink[:5]:
    out.append('  %s' % l[:120])
out.append('---- 未检索到 / — 的使用 ----')
out.append('「未检索到」出现 %d 次；「—」出现 %d 次' % (text.count('未检索到'), text.count('—')))
Path('output/verify.txt').write_text('\n'.join(out), encoding='utf-8')
print('ok')
