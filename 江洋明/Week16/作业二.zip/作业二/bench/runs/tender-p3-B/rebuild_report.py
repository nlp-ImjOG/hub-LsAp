"""在 report.md 里就地替换已注入的表格（不重写正文）。

report.md 里的表格是 make_report.py 注入的；改正生成逻辑后不必重写整篇正文，
按表头定位表格块、整块替换即可。
"""

from __future__ import annotations

import io
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))

import make_report  # noqa: E402

#: 表名 -> 表头首行特征串
ANCHORS = {
    "amounts": "| 中标金额档位 |",
    "trend": "| 发布月份 |",
    "hotspots": "| 招标方向词",
    "categories": "| ESG 细分方向 |",
    "regions": "| 地区（采购人",
    "buyers": "| 采购人类型",
    "detail": "| 发布日期 |",
}


def replace_block(lines: list[str], anchor: str, new_text: str) -> list[str]:
    start = next((i for i, l in enumerate(lines) if l.startswith(anchor)), None)
    if start is None:
        raise SystemExit(f"找不到表格块：{anchor}")
    end = start
    while end < len(lines) and lines[end].startswith("|"):
        end += 1
    return lines[:start] + new_text.splitlines() + lines[end:]


def main() -> int:
    path = Path("report.md")
    lines = path.read_text(encoding="utf-8").splitlines()
    for name, anchor in ANCHORS.items():
        lines = replace_block(lines, anchor, make_report.TABLES[name]())
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"已替换 {len(ANCHORS)} 张表")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
