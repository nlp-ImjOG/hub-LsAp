import io, sys, json, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

old = open('output/review_106.txt', encoding='utf-8').read()
# 旧明细行： "  2026-11-26 | 方向 | 金额 | 标题"
old_rows = []
for line in old.splitlines():
    m = re.match(r'^  (\d{4}-\d{2}-\d{2}) \| .*? \| .*? \| (.*)$', line)
    if m:
        old_rows.append((m.group(1), m.group(2).strip()))
old_set = set(old_rows)
print('旧明细 %d 行' % len(old_rows))

recs = json.loads(open('output/records.json', encoding='utf-8').read())
new_rows = [(r.get('published') or '', r.get('title','').strip()) for r in recs]
new_set = set(new_rows)
print('新记录 %d 条' % len(new_rows))

lines = []
lines.append('=== 旧有新无 ===')
for r in old_rows:
    if r not in new_set:
        lines.append('  %s | %s' % r)
lines.append('=== 新有旧无 ===')
for r in new_rows:
    if r not in old_set:
        lines.append('  %s | %s' % r)

# 字段差异
oldmap = {t: d for d, t in old_rows}
lines.append('=== 字段变化（标题相同） ===')
for r in recs:
    t = r.get('title','').strip()
    key = (r.get('published') or '', t)
    if key in old_set:
        continue
open('output/dbg8.txt', 'w', encoding='utf-8').write('\n'.join(lines))
print('\n'.join(lines))
