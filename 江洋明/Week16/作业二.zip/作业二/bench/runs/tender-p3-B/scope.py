#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""口径扩展 —— 在 Skill 方向矩阵的基础上补几个明显属于 ESG、但矩阵没列的词。

为什么要有这一层：

Skill 的 ``ESG_CATEGORIES``（方向矩阵）是**筛查词表**，不是分类词表 ——
它的作用是把"明显不是 ESG 的采购"筛掉。矩阵里的"环境与生态治理"只列了
污染防治、生态保护、生态修复、环境保护等词，**没有列"生态环境""生态文明"**。

真实公告里这两种说法很常见，比如：

    杭锦旗生态环境质量与生态文明示范建设路径优化提升项目(二次)

这条是百分之百的环境治理类采购，却一个字都命中不了矩阵 —— 如果只认矩阵，
它会被漏掉。Skill 的 ``ESG_STRONG_KEYWORDS`` 更窄（连生态修复、污染防治、
节水、绿色工厂都没有），只用它会把一整类项目全部漏掉。

所以这里只做**加法**：矩阵命中就命中，矩阵不命中时再看这几个补充词。
补充词全列在这里，谁要审口径，改这一处就行。

注意：补充词只影响"是否纳入"，不影响"归到哪个方向" ——
方向仍由 Skill 的 ``classify_category`` + build2 的补充映射决定。
"""

from __future__ import annotations

from fixup import esg_scope as _base_esg_scope

#: 方向矩阵没列、但确实是 ESG 采购的词
EXTRA_SCOPE_WORDS: tuple[str, ...] = (
    "生态文明",       # 生态文明示范建设
    "生态环境质量",   # 生态环境质量提升/优化
    "生态环境治理",
    "生态治理",
)


def esg_scope(text: str) -> tuple[bool, str]:
    """是否纳入报告口径。返回 ``(是否纳入, 依据)``。"""
    ok, basis = _base_esg_scope(text)
    if ok:
        return True, basis
    for word in EXTRA_SCOPE_WORDS:
        if word in (text or ""):
            return True, f"补充词：{word}"
    return False, basis
