import io, sys, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '.')
sys.path.insert(0, '.claude/skills/esg-tender-monitor/scripts')

from build2 import cache_html, merge, same_announcement
from esg_toolkit.models import TenderRecord
from postprocess import correct_one, is_candidate_notice

raw_records = json.loads(open('output/records.json', encoding='utf-8').read())
lines = []
corrected = []
for raw in raw_records:
    url = raw['url']
    st = raw.get('extra', {}).get('search_title', '')
    html = cache_html(url) or ''
    rec = TenderRecord(
        title=raw.get('title', ''), url=url, buyer=raw.get('buyer', ''),
        winner=raw.get('winner', ''), amount_yuan=raw.get('amount_yuan'),
        amount_raw=raw.get('amount_raw', ''), published=raw.get('published'),
        package=raw.get('package', ''), province=raw.get('province', ''),
        category=raw.get('category', ''), extra=raw.get('extra', {}))
    fixed, notes = correct_one(html, url, st, rec)
    if fixed is None:
        lines.append('[丢弃] %s | %s | %s' % (raw.get('published'), raw.get('title','')[:40], notes))
        continue
    if is_candidate_notice(fixed.title, st):
        lines.append('[候选人] %s' % fixed.title[:40])
        continue
    corrected.append(fixed)

lines.append('修正后 %d 条，开始去重' % len(corrected))
unique = []
for r in corrected:
    for i, k in enumerate(unique):
        if same_announcement(k, r):
            lines.append('[合并] 保留: %s | %s' % (k.title[:44], k.url[:70]))
            lines.append('        并入: %s | %s' % (r.title[:44], r.url[:70]))
            unique[i] = merge(k, r)
            break
    else:
        unique.append(r)
lines.append('去重后 %d 条' % len(unique))
open('output/dbg9.txt', 'w', encoding='utf-8').write('\n'.join(lines))
print('\n'.join(lines[-40:]))
