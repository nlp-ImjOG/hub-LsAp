#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""字段清洗：把表格标题行、碎片从字段值里剔出去。

公告页的结果表是二维表，拍平成一行一行的文本之后，表头会混进字段值里 ——
比如「中标单位」抽出来是 ``标段名称``、``成交额(人民币)``、``联系方式``。
这些值**不是数据**，直接进报告就是错的数据。

两条规则，都只做减法，不做推断：

* :func:`clean_winner` —— 中标单位：去掉角色前缀（"牵头供应商："）、
  去掉"投标联合体"后面的成员清单、识别表头碎片。
* :func:`buyer_from_title` —— 采购人：页面上没抽到时，从标题开头的机构名兜底。
  这是**有规则的抽取**，不是猜：只认以机构后缀结尾的片段。
"""

from __future__ import annotations

import re

#: 结果表表头/碎片标记 —— 命中就说明这个字段值其实是表头，不是数据
_JUNK_MARKERS = (
    "标段名称",
    "标包号",
    "标包",
    "序号",
    "中标供应商地址",
    "供应商地址",
    "成交额",
    "中标金额",
    "投标报价",
    "报价金额",
    "联系方式",
    "项目名称",
    "供应商名称",
    "中标单位名称",
    "金额（元）",
    "金额(元)",
)

#: 角色前缀："牵头供应商：XXX"、"中标单位：XXX"
_ROLE_PREFIX_RE = re.compile(
    r"^(?:牵头供应商|牵头单位|中标供应商|成交供应商|供应商|中标单位|中标人|"
    r"成交人|联合体牵头单位)\s*[：:]\s*"
)

#: 机构名（尽量长的后缀排前面，贪婪匹配优先取完整机构名）
_ORG_SUFFIX = (
    "有限责任公司|股份有限公司|有限公司|管理委员会|委员会|管委会|"
    "研究院|研究所|事务所|发展中心|服务中心|管理中心|监测中心|"
    "科学院|学会|集团|银行|信用社|大学|学院|医院|政府|"
    "管理局|办公室|局|厅|部|署|中心|公司|股份|院|所"
)

#: 扁平化的表格行里，末尾往往才是真正的机构名
_ORG_TOKEN_RE = re.compile(
    r"[一-鿿A-Za-z（）()·]{2,40}?(?:" + _ORG_SUFFIX + r")"
)

#: 标题开头的机构名（采购人兜底）
_BUYER_LEAD_RE = re.compile(
    r"^([一-鿿A-Za-z（）()·]{2,45}(?:" + _ORG_SUFFIX + r"))"
)

#: 标题里"XX关于YY"形态 —— 关于之后的机构才是采购人，前面的是代理机构
_ABOUT = "关于"


def clean_winner(winner: str) -> str:
    """清洗中标单位：表头碎片不算数据。"""
    text = (winner or "").strip()
    if not text:
        return ""

    # 去掉角色前缀
    text = _ROLE_PREFIX_RE.sub("", text).strip()

    # "中标供应商：XXX投标联合体：YYY、ZZZ" —— 牵头方是 XXX
    if "投标联合体" in text:
        head = re.split(r"投标联合体|联合体成员", text)[0].strip(" ：:，,、")
        if head:
            text = head

    # 去掉"（联合体成员：XXX）"这类括号补充
    text = re.sub(r"[（(]联合体[^）)]*[）)]", "", text).strip(" 、,，;；")

    # 表头碎片：整段作废，尝试捞出末尾的机构名
    if any(marker in text for marker in _JUNK_MARKERS):
        found = _ORG_TOKEN_RE.findall(text)
        return found[-1] if found else ""

    return text.strip(" 、,，;；")


def buyer_from_title(title: str) -> str:
    """从标题开头兜底出采购人。只认以机构后缀结尾的片段，认不出就留空。"""
    text = (title or "").strip()
    if not text:
        return ""

    if _ABOUT in text:
        # "XX代理公司关于YY项目" —— 前面是代理机构，用"关于"后面的
        head = text.split(_ABOUT, 1)[1].strip()
        found = _BUYER_LEAD_RE.match(head)
        return found.group(1) if found else ""

    found = _BUYER_LEAD_RE.match(text)
    return found.group(1) if found else ""
