import io, sys, json, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
recs = json.loads(open('output/records.json', encoding='utf-8').read())
stats = json.loads(open('output/stats.json', encoding='utf-8').read())
out = []
out.append('===== 审计 =====')
out.append(open('output/audit.txt', encoding='utf-8').read())
out.append('')
out.append('===== 金额最大的 12 条 =====')
withamt = [r for r in recs if r['amount_yuan'] is not None]
for r in sorted(withamt, key=lambda x: -x['amount_yuan'])[:12]:
    out.append('  %14.2f 元 | %s | %s | src=%s | raw=%s' % (
        r['amount_yuan'], r['published'], r['title'][:44],
        r['extra'].get('amount_source', ''), (r.get('amount_raw') or '')[:36]))
out.append('')
out.append('===== 金额最小的 8 条 =====')
for r in sorted(withamt, key=lambda x: x['amount_yuan'])[:8]:
    out.append('  %14.2f 元 | %s | %s | src=%s' % (
        r['amount_yuan'], r['published'], r['title'][:44], r['extra'].get('amount_source', '')))
out.append('')
out.append('===== 分桶 =====')
for b in stats['buckets']:
    out.append('  %-12s %3d 条  合计 %s' % (b['bucket'], b['count'], b['total_yuan']))
out.append('  总条数 %d，其中披露金额 %d 条' % (len(recs), len(withamt)))
out.append('  金额合计 %.2f 元 = %.2f 万元 = %.4f 亿元' % (
    sum(r['amount_yuan'] for r in withamt),
    sum(r['amount_yuan'] for r in withamt) / 1e4,
    sum(r['amount_yuan'] for r in withamt) / 1e8))
out.append('')
out.append('===== 方向分布（全部记录）=====')
from collections import Counter
c = Counter(r['category'] or '未分类' for r in recs)
for k, v in c.most_common():
    out.append('  %-16s %3d' % (k, v))
out.append('')
out.append('===== 缺字段统计 =====')
out.append('  无日期 %d 条' % sum(1 for r in recs if not r['published']))
out.append('  无金额 %d 条' % sum(1 for r in recs if r['amount_yuan'] is None))
out.append('  无采购人 %d 条' % sum(1 for r in recs if not r['buyer']))
out.append('  无中标单位 %d 条' % sum(1 for r in recs if not r['winner']))
out.append('  无省份 %d 条' % sum(1 for r in recs if not r['province']))
out.append('  未分类 %d 条' % sum(1 for r in recs if not r['category']))
out.append('')
out.append('===== 全部明细（日期|方向|金额|标题）=====')
for r in recs:
    out.append('  %s | %-14s | %14s | %s' % (
        r['published'] or '未标注', (r['category'] or '未分类')[:14],
        ('%.2f' % r['amount_yuan']) if r['amount_yuan'] is not None else '—',
        r['title'][:60]))
open('output/review.txt', 'w', encoding='utf-8').write('\n'.join(out))
print('ok', len(recs))
