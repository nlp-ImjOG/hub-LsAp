import io, sys, json, re
from pathlib import Path
from collections import Counter
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
out = []

# --- audit.txt 精确分类 ---
txt = Path('output/audit.txt').read_text(encoding='utf-8')
clean_rows = [l for l in txt.splitlines() if '中标单位清洗' in l]
void_rows = [l for l in clean_rows if '表头碎片，作废' in l]
repl_rows = [l for l in clean_rows if '表头碎片，作废' not in l]
out.append('audit.txt 总行 %d' % len(txt.splitlines()))
out.append('中标单位清洗 %d 条（作废 %d / 纠正为正常机构名 %d）' % (len(clean_rows), len(void_rows), len(repl_rows)))
out.append('作废明细:')
for l in void_rows:
    out.append('   ' + l[:130])
other = [l for l in txt.splitlines() if l.startswith('[') and '中标单位清洗' not in l and '剔除-候选人公示' not in l]
out.append('其余 %d 条:' % len(other))
for l in other:
    out.append('   ' + l[:150])

# --- 谁中了 中国环境科学研究院 ---
recs = json.loads(Path('output/records.json').read_text(encoding='utf-8'))
out.append('---- 中国环境科学研究院 中标的记录 ----')
for r in recs:
    if '中国环境科学研究院' in (r.get('winner') or ''):
        out.append('  %s | %s | %s' % (r.get('published'), r.get('title')[:46], r.get('url')))
out.append('---- 复购单位（2 单）各自的记录 ----')
w = Counter((r.get('winner') or '').strip() for r in recs if (r.get('winner') or '').strip())
for name, n in w.most_common():
    if n >= 2:
        for r in recs:
            if (r.get('winner') or '').strip() == name:
                out.append('  %s | %s | %s | %s' % (name, r.get('published'), r.get('title')[:40], r.get('url')))

# --- 检索分组 ---
hg = Path('output/hit_groups.txt').read_text(encoding='utf-8')
out.append('---- hit_groups 尾部 ----')
for l in hg.splitlines()[-3:]:
    out.append('   ' + l)
out.append('---- 筛选链核对 ----')
a1 = Path('output/audit_stage1.txt').read_text(encoding='utf-8')
out.append('stage1 行数 %d' % len(a1.splitlines()))

Path('output/check_claims2.txt').write_text('\n'.join(out), encoding='utf-8')
print('ok')
