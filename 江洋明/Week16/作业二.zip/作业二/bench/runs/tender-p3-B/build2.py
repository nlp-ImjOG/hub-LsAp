#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ESG 招投标汇总 —— 脚本臂 + 修正层（build.py 的修正版）。

与 ``build.py`` 的关系：抓取、解析、统计都还是 Skill 脚本层在跑，
本文件只多跑一遍 ``fixup.py`` 的修正规则，并且**把每一处改动都记下来**
（``output/audit.txt``），便于逐条复核。

不重新联网：``build.py`` 已经把 133 条候选的页面缓存在 ``output/cache/``，
本脚本只读缓存重跑解析 —— 同样的页面、同样的解析器，结果可复现。

用法::

    python build2.py
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
sys.path.insert(0, str(ROOT))

from esg_toolkit.aggregate import summarize  # noqa: E402
from esg_toolkit.keywords import classify_category, infer_province  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

from fixup import (  # noqa: E402
    core_title,
    esg_scope,
    has_explicit_unit,
    is_boilerplate_title,
    is_error_title,
    is_works_contract,
    rederive_amount,
    repair_date,
)

OUT = ROOT / "output"
CACHE = OUT / "cache"

SINCE = "2024-11-01"
UNTIL = "2026-11-27"

#: 方向矩阵的补充映射 —— Skill 的 classify_category 判不出来时用。
#: 只补充「Skill 方向矩阵里已有的方向」，不新增方向类别，
#: 免得报告里的「方向」列出现词表之外的分类。
_DIRECTION_FALLBACK: list[tuple[str, str]] = [
    ("气候变化", "碳足迹与核算"),
    ("碳资产", "双碳与碳中和"),
    ("碳管理", "双碳与碳中和"),
    ("碳交易", "双碳与碳中和"),
    ("碳汇", "生态产品价值GEP"),
    ("低碳", "绿色低碳与节能"),
    ("生态修复", "环境与生态治理"),
    ("生态保护", "环境与生态治理"),
    ("污染防治", "环境与生态治理"),
    ("污染", "环境与生态治理"),
    ("环境治理", "环境与生态治理"),
    ("生态文明", "环境与生态治理"),
    ("土壤", "环境与生态治理"),
    ("流域治理", "水与资源"),
    ("污水", "水与资源"),
    ("节水", "水与资源"),
    ("水资源", "水与资源"),
    ("水务", "水与资源"),
    ("绿色工厂", "绿色低碳与节能"),
    ("绿色园区", "绿色低碳与节能"),
    ("绿色工业园区", "绿色低碳与节能"),
    ("绿色建筑", "绿色低碳与节能"),
    ("节能", "绿色低碳与节能"),
    ("能源管理", "绿色低碳与节能"),
    ("气候投融资", "绿色金融"),
    ("绿色金融", "绿色金融"),
    ("绿色供应链", "供应链与责任"),
    ("可持续发展报告", "ESG披露与鉴证"),
]


def direction_of(text: str) -> str:
    """项目的 ESG 细分方向。先用 Skill 的分类器，再用补充映射兜底。"""
    category = classify_category(text)
    if category:
        return category
    for word, category in _DIRECTION_FALLBACK:
        if word in text:
            return category
    return ""


def load_hits() -> list[dict]:
    hits = json.loads((ROOT / "hits.json").read_text(encoding="utf-8"))["hits"]
    extra = ROOT / "hits2.json"
    if extra.is_file():
        hits += json.loads(extra.read_text(encoding="utf-8"))["hits"]
    return hits


def cache_html(url: str) -> str | None:
    path = CACHE / f"{hashlib.sha1(url.encode('utf-8')).hexdigest()}.html"
    if not path.is_file():
        return None
    return path.read_text(encoding="utf-8", errors="replace")


def plain_text(html: str) -> str:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&nbsp;", " ", text)
    return re.sub(r"[ \t\r\f\v]+", " ", text)


#: 金额来源的可信度排序 —— 合并同一份公告时留可信度高的那条
_SOURCE_RANK = [
    ("总中标金额", 0),
    ("总成交金额", 0),
    ("总金额", 0),
    ("结果表分项合计", 1),
    ("正文分项合计", 2),
    ("正文金额", 3),
    ("中标金额", 4),
    ("成交金额", 4),
]


def source_rank(record: TenderRecord) -> int:
    source = record.extra.get("amount_source", "")
    for keyword, rank in _SOURCE_RANK:
        if keyword in source:
            return rank
    return 9


def completeness(record: TenderRecord) -> tuple:
    """字段完整度 —— 合并时同分的情况下用。"""
    return (
        record.amount_yuan is not None,
        bool(record.published),
        bool(record.buyer),
        bool(record.winner),
        len(record.title),
    )


def merge(primary: TenderRecord, other: TenderRecord) -> TenderRecord:
    """两条是同一份公告：留可信度高的金额，其余字段补齐。"""
    keep, drop = (primary, other)
    if (source_rank(other), completeness(other)) < (source_rank(primary), completeness(primary)):
        keep, drop = other, primary
    keep.extra = dict(keep.extra)
    keep.extra["duplicate_url"] = drop.url
    for field in ("buyer", "winner", "published", "province", "category", "package"):
        if not getattr(keep, field) and getattr(drop, field):
            setattr(keep, field, getattr(drop, field))
    if keep.amount_yuan is None and drop.amount_yuan is not None:
        keep.amount_yuan = drop.amount_yuan
        keep.extra["amount_source"] = drop.extra.get("amount_source", "")
    return keep


def same_announcement(left: TenderRecord, right: TenderRecord) -> bool:
    """两条记录是不是同一份公告（跨站转载）。"""
    url_left = canonical_url(left.url)
    url_right = canonical_url(right.url)
    if url_left and url_left == url_right:
        return True
    if (left.published or "") != (right.published or ""):
        return False
    core_left = core_title(left.title)
    core_right = core_title(right.title)
    if not core_left or not core_right:
        return False
    if core_left == core_right:
        return True
    # 转载时常带采购人前缀或公告类型后缀，一方是另一方的子串即是同一条
    return len(core_left) >= 8 and len(core_right) >= 8 and (
        core_left in core_right or core_right in core_left
    )


def main() -> int:
    hits = load_hits()
    audit: list[str] = []
    records: list[TenderRecord] = []

    counts = {
        "candidates": len(hits),
        "fetch_failed": 0,
        "parse_failed": 0,
        "dropped_empty": 0,
        "dropped_scope": 0,
        "dropped_works": 0,
        "dropped_window": 0,
        "kept": 0,
    }

    for hit in hits:
        url = hit["url"]
        search_title = (hit.get("title") or "").strip()
        html = cache_html(url)
        if html is None:
            counts["fetch_failed"] += 1
            audit.append(f"[抓取失败] {url}｜检索标题：{search_title}")
            continue

        record = parse_tender_page(html, url=url, fallback_title=search_title)
        if record is None:
            counts["parse_failed"] += 1
            audit.append(f"[解析失败] {url}｜检索标题：{search_title}")
            continue

        title = (record.title or "").strip()

        # ---- 标题：样板句 / 错误页 ----
        if is_error_title(title):
            counts["dropped_empty"] += 1
            audit.append(f"[丢弃-页面无内容] {url}｜解析标题：{title}")
            continue
        if is_boilerplate_title(title):
            if search_title and not is_error_title(search_title):
                audit.append(f"[标题修正] {url}｜{title[:36]} → {search_title[:36]}")
                title = search_title
            else:
                counts["dropped_empty"] += 1
                audit.append(f"[丢弃-标题为样板句] {url}｜{title[:36]}")
                continue

        # ---- 日期 ----
        published = record.published
        date_source = "公告解析"
        if not published:
            published, basis = repair_date(html, url)
            if published:
                date_source = basis
                audit.append(f"[日期补齐] {published}｜{basis}｜{title[:36]}")

        # ---- 金额：重新推导（单位安全）----
        amount, basis, notes = rederive_amount(html)
        if basis == "未找到金额":
            # 脚本层没抓到金额：只有原文**自带单位**时它的值才可信
            if record.amount_yuan is not None and has_explicit_unit(record.amount_raw):
                amount = record.amount_yuan
                amount_source = "公告解析（原文带单位）"
            else:
                amount = None
                amount_source = ""
        else:
            amount_source = basis
            if amount is None:
                if record.amount_yuan is not None:
                    audit.append(
                        f"[金额未采信] 原解析 {record.amount_yuan:,.2f} 元 → 未披露"
                        f"｜依据：{basis}｜{title[:36]}"
                    )
                amount = None
            elif (
                record.amount_yuan is not None
                and abs(record.amount_yuan - amount) > max(1.0, abs(amount) * 0.001)
            ):
                audit.append(
                    f"[金额修正] {record.amount_yuan:,.2f} → {amount:,.2f} 元"
                    f"｜依据：{basis}｜{title[:36]}"
                )
        for note in notes:
            audit.append(f"[金额存疑] {note}｜{title[:36]}｜{url}")

        # 金额为 0 —— 中标结果公告里出现 0 金额基本都是模板占位符
        # （「￥0.000000 万元」），按「不把未披露填成 0」处理。
        if amount == 0:
            audit.append(f"[金额置为未披露] 解析出 0 元，视为未披露｜{title[:36]}")
            amount = None
            amount_source = ""

        # ---- 采购人 / 中标单位 / 省份 / 方向 ----
        buyer = record.buyer
        winner = record.winner
        text = plain_text(html)
        if not buyer:
            found = re.search(
                r"(?:采购人名称|采购人|招标人|采购单位)\s*[：:]\s*"
                r"([^\s，,。；;（(【\[]{4,40})",
                text,
            )
            if found:
                buyer = found.group(1).strip()
        if not winner:
            found = re.search(
                r"(?:中标[、,]?成交供应商名称|中标供应商名称|成交供应商名称|"
                r"中标供应商|成交供应商|中标单位|中标人)\s*[：:]\s*"
                r"([^\s，,。；;（(【\[]{2,40})",
                text,
            )
            if found:
                winner = found.group(1).strip()

        haystack = f"{title} {search_title} {buyer} {winner}"
        province = record.province or infer_province(text[:4000], url)
        category = direction_of(haystack)

        # ---- 相关性闸门 ----
        in_scope, basis = esg_scope(haystack)
        if not in_scope:
            counts["dropped_scope"] += 1
            audit.append(f"[不在口径内-{basis}] {title[:44]}")
            continue

        # ---- 土建类剔除 ----
        if is_works_contract(title, html):
            counts["dropped_works"] += 1
            audit.append(f"[剔除-土建类] {title[:44]}")
            continue

        # ---- 时间窗 ----
        if published and not (SINCE <= published <= UNTIL):
            counts["dropped_window"] += 1
            audit.append(f"[超出时间窗] {published}｜{title[:44]}")
            continue

        if not (published or amount is not None or buyer or winner):
            counts["dropped_empty"] += 1
            audit.append(f"[丢弃-字段全空] {url}｜{title[:40]}")
            continue

        counts["kept"] += 1
        records.append(
            TenderRecord(
                title=title,
                url=url,
                buyer=buyer,
                winner=winner,
                amount_yuan=amount,
                amount_raw=record.amount_raw,
                published=published,
                package=record.package,
                province=province,
                category=category,
                extra={
                    **record.extra,
                    "amount_source": amount_source,
                    "date_source": date_source,
                    "scope_basis": basis,
                    "search_title": search_title,
                },
            )
        )

    # ---- 去重：同一份公告的跨站转载 ----
    unique: list[TenderRecord] = []
    for record in records:
        matched = False
        for index, kept in enumerate(unique):
            if same_announcement(kept, record):
                unique[index] = merge(kept, record)
                audit.append(
                    f"[去重] {record.published}｜{record.title[:34]}｜{record.url}"
                )
                matched = True
                break
        if not matched:
            unique.append(record)

    unique.sort(key=lambda r: (r.published or "", r.title), reverse=True)

    stats = summarize(unique)
    stats["window"] = {"since": SINCE, "until": UNTIL}
    stats["filter"] = {
        **counts,
        "after_dedupe": len(unique),
        "scope_note": "方向矩阵口径 + Skill 排除词表 + 土建类剔除",
    }

    (OUT / "records.json").write_text(
        json.dumps([r.to_dict() for r in unique], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (OUT / "audit.txt").write_text("\n".join(audit), encoding="utf-8")

    print(json.dumps(stats["filter"], ensure_ascii=False, indent=2))
    print(f"记录 {len(unique)} 条；审计 {len(audit)} 行 -> output/audit.txt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
