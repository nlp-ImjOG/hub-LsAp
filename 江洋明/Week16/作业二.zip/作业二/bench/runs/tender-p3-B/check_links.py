import io, sys, re, json
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

text = Path('report.md').read_text(encoding='utf-8')
lines = text.splitlines()
out = []

# 1. Markdown 链接语法完整性：链接文字里不得有裸的 [ 或 ]
bad = []
for i, l in enumerate(lines, 1):
    for m in re.finditer(r'(?<!\\)\[', l):
        idx = m.start()
        rest = l[idx + 1:]
        if re.match(r'((?:\\.|[^\]\\])*)\]\(', rest) is None:
            bad.append((i, l[:140]))
            break
out.append('方括号未闭合/未转义的行数: %d' % len(bad))
for i, l in bad[:10]:
    out.append('  %d: %s' % (i, l))

# 2. 明细行：每行必须有 http 链接
det = [l for l in lines if re.match(r'^\| \d{4}-\d{2}-\d{2} \|', l)]
out.append('明细行 %d，无链接 %d' % (len(det), sum(1 for l in det if 'http' not in l)))

# 3. 汇总表每行都要有链接
def block(anchor):
    s = next(i for i, l in enumerate(lines) if l.startswith(anchor))
    e = s
    while e < len(lines) and lines[e].startswith('|'):
        e += 1
    return lines[s:e]

for anchor in ['| 中标金额档位 |', '| 发布月份 |', '| 招标方向词', '| ESG 细分方向 |',
               '| 地区（采购人', '| 采购人类型']:
    rows = block(anchor)
    data = [r for r in rows[2:] if '合计' not in r]
    missing = [r for r in data if 'http' not in r]
    out.append('%-20s 数据行 %d，无链接 %d' % (anchor.strip('| ')[:18], len(data), len(missing)))
    for r in missing:
        out.append('    ' + r[:140])

urls = sorted(set(re.findall(r'\]\((https?://[^)]+)\)', text)))
out.append('唯一链接 URL 数: %d' % len(urls))

# 4. 正文关键数字 vs stats
S = json.loads(Path('output/stats.json').read_text(encoding='utf-8'))
recs = json.loads(Path('output/records.json').read_text(encoding='utf-8'))
checks = {
    '总条数 106': S['total'] == 106,
    '合计 4.7640 亿': abs(S['amount']['total_yuan'] - 476399390.62) < 0.01,
    '中位数 95.0 万': S['amount']['median_yuan'] == 950000.0,
    '均值 588.1 万': abs(S['amount']['mean_yuan'] - 5881473.96) < 0.01,
    '未披露 25 条': S['amount']['missing'] == 25,
    '最大 1.3036 亿': abs(S['amount']['max_yuan'] - 130355665.0) < 0.01,
    '最小 15.9 万': S['amount']['min_yuan'] == 159000.0,
    'records=stats': len(recs) == S['total'],
}
for k, v in checks.items():
    out.append('  %-16s %s' % (k, 'OK' if v else 'MISMATCH'))

# 5. 金额分档表 vs stats
def num(cell):
    return float(cell.strip().replace('**', '').replace('%', ''))

tbl = {}
for r in block('| 中标金额档位 |')[2:]:
    cells = [c.strip().replace('**', '') for c in r.strip('|').split('|')]
    tbl[cells[0]] = int(cells[1])
for b in S['buckets']:
    got = tbl.get(b['bucket'])
    out.append('  档位 %-10s 表=%-4s stats=%-4s %s' % (
        b['bucket'], got, b['count'], 'OK' if got == b['count'] else 'MISMATCH'))

# 6. 各表条数占比之和
for anchor, name in [('| 中标金额档位 |', '金额分档'), ('| 采购人类型', '采购人类型')]:
    rows = block(anchor)
    tot = sum(num(r.strip('|').split('|')[2]) for r in rows[2:-1])
    out.append('%-8s 条数占比之和 = %.1f%%' % (name, tot))
rows = block('| ESG 细分方向 |')
tot = sum(num(r.strip('|').split('|')[2]) for r in rows[2:])
out.append('%-8s 条数占比之和 = %.1f%%' % ('方向分布', tot))

Path('output/check_links.txt').write_text('\n'.join(out), encoding='utf-8')
print('ok')
