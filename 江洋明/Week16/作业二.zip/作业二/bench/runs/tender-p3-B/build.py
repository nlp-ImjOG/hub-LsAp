#!/usr/bin/env python
"""ESG 招投标汇总 —— 脚本臂（确定性抽取 + 聚合）。

本脚本只做"能写成规则的活"：抓页面 → 解析字段 → 归一金额与日期 → 去重 → 统计。
解读（导语、要点、建议）由人来做，写进 report.md。

抓取分两级（见 esg_toolkit/fetch.py）：
1. requests + UA 轮换 + Referer —— 绝大多数站点直接放行；
2. requests 拿到 403/405/429 时，用真实浏览器兜底（ccgp.gov.cn 的 JS 挑战，
   纯 HTTP 客户端过不去）。

抓取有**硬性超时护栏**：个别政务站点会慢速吐字节，requests 的 read timeout
按 chunk 重置，单个 URL 可能一直挂着。所以每个 URL 都跑在自己的线程里，
主线程按总时限收割，拿不到就记为失败，不让一条 URL 拖垮整批。

用法::

    python build.py            # 抓取 + 解析 + 统计，产物落在 ./output/
"""

from __future__ import annotations

import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import summarize  # noqa: E402
from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import USER_AGENTS, BrowserFetcher, decode_bytes  # noqa: E402
from esg_toolkit.keywords import is_esg_related  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page, parse_tender_snippet  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

OUT = ROOT / "output"
OUT.mkdir(parents=True, exist_ok=True)
CACHE = OUT / "cache"
CACHE.mkdir(parents=True, exist_ok=True)

SINCE = "2024-11-01"   # 近 2 年（脚本臂口径：两年前的当月 1 日）
UNTIL = "2026-11-27"

#: 单个 URL 的抓取时限（秒）—— 超时即放弃，绝不让一条 URL 拖垮整批
PER_URL_DEADLINE = 25
#: requests 阶段的总时限（秒）
REQUESTS_DEADLINE = 420
#: 浏览器阶段每个页面的等待毫秒
BROWSER_WAIT_MS = 3500


def _cache_file(url: str) -> Path:
    import hashlib

    return CACHE / f"{hashlib.sha1(url.encode('utf-8')).hexdigest()}.html"


def fetch(url: str) -> tuple[str, str]:
    """requests 抓一个 URL，返回 (html, 错误信息)。带 UA 轮换与 Referer 重试。"""
    import requests
    from urllib.parse import urlsplit

    cache_file = _cache_file(url)
    if cache_file.is_file():
        return cache_file.read_text(encoding="utf-8", errors="replace"), ""

    parts = urlsplit(url)
    referer = f"{parts.scheme}://{parts.netloc}/" if parts.scheme and parts.netloc else ""
    last = ""
    for attempt in range(3):
        headers = {
            "User-Agent": USER_AGENTS[attempt % len(USER_AGENTS)],
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Connection": "close",
        }
        if referer:
            headers["Referer"] = referer
        try:
            resp = requests.get(
                url, headers=headers, timeout=(5, 12), allow_redirects=True
            )
        except Exception as exc:
            last = f"{type(exc).__name__}: {exc}"
            time.sleep(0.8 * (attempt + 1))
            continue
        if resp.status_code == 200:
            html = decode_bytes(resp.content, resp.headers.get("Content-Type", ""))
            cache_file.write_text(html, encoding="utf-8")
            return html, ""
        last = f"HTTP {resp.status_code}"
        if resp.status_code in (403, 405, 429):
            time.sleep(1.0 * (attempt + 1))
            continue
        break
    return "", last


def handle(hit: dict) -> dict:
    """抓取 + 解析一条公告（requests 级）。"""
    html, error = fetch(hit["url"])
    record = None
    if html:
        record = parse_tender_page(html, url=hit["url"], fallback_title=hit.get("title", ""))
    return {
        "url": hit["url"],
        "group": hit.get("g", ""),
        "search_title": hit.get("title", ""),
        "fetch_error": error,
        "record": record,
    }


def browser_pass(urls: list[str]) -> dict[str, str]:
    """浏览器兜底：把 requests 抓不到的页面用真实浏览器再抓一次。"""
    config = Config()
    config.request_timeout = 30
    config.browser_wait_ms = BROWSER_WAIT_MS
    fetcher = BrowserFetcher(config)
    htmls: dict[str, str] = {}
    try:
        for index, url in enumerate(urls, start=1):
            result = fetcher.fetch(url)
            if result is not None and result.html:
                htmls[url] = result.html
                _cache_file(url).write_text(result.html, encoding="utf-8")
            print(
                f"  浏览器兜底 {index}/{len(urls)}: {url} -> "
                f"{'ok' if result is not None else 'fail'}",
                flush=True,
            )
    finally:
        fetcher.close()
    return htmls


def main() -> int:
    hits = json.loads((ROOT / "hits.json").read_text(encoding="utf-8"))["hits"]
    extra_path = ROOT / "hits2.json"
    if extra_path.is_file():
        hits += json.loads(extra_path.read_text(encoding="utf-8"))["hits"]
    print(f"候选公告 {len(hits)} 条，开始抓取…", flush=True)

    # ---- 第一级：requests ----
    results: dict[str, dict] = {}
    started = time.time()
    with ThreadPoolExecutor(max_workers=10) as pool:
        futures = {pool.submit(handle, hit): hit for hit in hits}
        done = 0
        for future in as_completed(futures):
            hit = futures[future]
            try:
                results[hit["url"]] = future.result()
            except Exception as exc:
                results[hit["url"]] = {
                    "url": hit["url"],
                    "group": hit.get("g", ""),
                    "search_title": hit.get("title", ""),
                    "fetch_error": f"{type(exc).__name__}: {exc}",
                    "record": None,
                }
            done += 1
            if done % 20 == 0:
                print(
                    f"  requests 进度 {done}/{len(hits)}（用时 {time.time() - started:.0f}s）",
                    flush=True,
                )
    print(f"requests 级完成，用时 {time.time() - started:.0f}s", flush=True)

    # ---- 第二级：浏览器兜底 ----
    need_browser = [r for r in results.values() if r["record"] is None]
    if need_browser:
        print(f"requests 级失败 {len(need_browser)} 条，改用真实浏览器兜底…", flush=True)
        htmls = browser_pass([r["url"] for r in need_browser])
        for r in need_browser:
            html = htmls.get(r["url"])
            if not html:
                continue
            record = parse_tender_page(html, url=r["url"], fallback_title=r["search_title"])
            if record is not None:
                r["record"] = record
                r["fetch_error"] = ""

    ordered = [results[h["url"]] for h in hits if h["url"] in results]
    (OUT / "parsed_raw.json").write_text(
        json.dumps(
            [
                {
                    "url": r["url"],
                    "group": r["group"],
                    "search_title": r["search_title"],
                    "fetch_error": r["fetch_error"],
                    "record": r["record"].to_dict() if r["record"] else None,
                }
                for r in ordered
            ],
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    ok = sum(1 for r in ordered if r["record"] is not None)
    failed = [r for r in ordered if r["record"] is None]
    print(f"解析成功 {ok} 条，失败 {len(failed)} 条", flush=True)
    for r in failed:
        print(f"  ! {r['url']}  ({r['fetch_error'] or 'no-record'})", flush=True)

    # ---- 过滤：ESG 相关性 + 时间窗 ----
    kept: list[TenderRecord] = []
    dropped_esg = 0
    dropped_window = 0
    for r in ordered:
        rec = r["record"]
        if rec is None:
            continue
        haystack = f"{rec.title} {r['search_title']} {rec.winner}"
        if not is_esg_related(haystack):
            dropped_esg += 1
            continue
        if rec.published and (rec.published < SINCE or rec.published > UNTIL):
            dropped_window += 1
            continue
        kept.append(rec)

    # ---- 去重（规范化 URL）----
    seen: set[str] = set()
    unique: list[TenderRecord] = []
    for rec in kept:
        key = canonical_url(rec.url) or f"{rec.title}|{rec.published or ''}"
        if key in seen:
            continue
        seen.add(key)
        unique.append(rec)

    unique.sort(key=lambda r: (r.published or "", r.title), reverse=True)

    stats = summarize(unique)
    stats["window"] = {"since": SINCE, "until": UNTIL}
    stats["filter"] = {
        "candidates": len(hits),
        "parsed_ok": ok,
        "parsed_failed": len(failed),
        "dropped_not_esg": dropped_esg,
        "dropped_out_of_window": dropped_window,
        "after_dedupe": len(unique),
    }

    (OUT / "records.json").write_text(
        json.dumps([r.to_dict() for r in unique], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(stats, ensure_ascii=False, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
