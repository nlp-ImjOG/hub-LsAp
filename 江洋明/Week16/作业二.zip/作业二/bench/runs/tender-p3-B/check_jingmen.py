import io, sys, json
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
recs = json.loads(Path('output/records.json').read_text(encoding='utf-8'))
out = []
out.append('---- 含「荆门」的记录 ----')
for i, r in enumerate(recs):
    if '荆门' in (r.get('title') or ''):
        out.append('idx=%d | amount=%s | published=%s | %s | %s' % (
            i, r.get('amount_yuan'), r.get('published'), r.get('title')[:50], r.get('url')))
out.append('---- 前 5 条 amount 为 None 的记录 ----')
n = 0
for i, r in enumerate(recs):
    if r.get('amount_yuan') is None:
        out.append('idx=%d | %s | %s | %s' % (i, r.get('published'), r.get('title')[:50], r.get('url')))
        n += 1
        if n >= 5:
            break
out.append('---- 500-1000万 档里的前 3 条 ----')
c = 0
for r in recs:
    v = r.get('amount_yuan')
    if v is not None and 5_000_000 <= v < 10_000_000:
        out.append('%s | %s | %s' % (r.get('published'), r.get('title')[:50], r.get('url')))
        c += 1
        if c >= 3:
            break
Path('output/check_jingmen.txt').write_text('\n'.join(out), encoding='utf-8')
print('ok')
