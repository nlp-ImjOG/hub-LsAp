#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""修正与收口阶段 —— 汇总报告与每日监控共用的**唯一一份**修正规则。

流程是这样串起来的：

    build2.py       抓取 + 解析 + 初筛   -> output/records.json
    postprocess.py  修正 + 去重 + 统计   -> output/records.json + output/stats.json

``correct_one()`` 是单条公告的修正入口，汇总报告和每日监控都调它，
所以两边的口径永远一致 —— 不会出现"报告里金额是 9,271,740 元、
每天推送里却是 92,717,400,000 元"这种事。

本阶段在 build2.py 的基础上再收五件事：

1. **标题清理**：公告页经常把"发布时间：2026-09-21""（招标编号：xxx）"
   拼进标题里，清掉，标题才是项目名。
2. **剔除中标候选人公示**：候选人公示里的金额是**投标报价**，
   不是最终中标金额 —— 混进中标统计等于把报价当中标。
3. **补日期**：正文标签补不到时，从平台 URL 路径里取日期
   （``ccgp.gov.cn`` 的 ``t20261124_xxxx.htm`` 就是发布日）。
4. **字段清洗**：中标单位列里混进来的表头碎片（``标段名称``、``成交额(人民币)``）
   要剔掉 —— 它们是表头，不是数据。
5. **去重 + 统计**：同一份公告跨站转载按 URL 与"项目名+日期"两级去重，
   合并时留金额来源更可信的那条。

用法::

    python build2.py && python postprocess.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
sys.path.insert(0, str(ROOT))

from esg_toolkit.aggregate import summarize  # noqa: E402
from esg_toolkit.keywords import infer_province  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402

from build2 import (  # noqa: E402
    cache_html,
    merge,
    plain_text,
    same_announcement,
)
from cleanup import buyer_from_title, clean_winner  # noqa: E402
from fixup import (  # noqa: E402
    has_explicit_unit,
    is_boilerplate_title,
    is_error_title,
    is_works_contract,
    rederive_amount,
    repair_date,
)
from scope import esg_scope  # noqa: E402

OUT = ROOT / "output"

#: 标题尾巴清理：公告页经常把发布时间、招标编号拼进标题
_TITLE_TAIL_RE = re.compile(
    r"\s*(?:发布时间|公告发布时间|时间)\s*[：:]\s*\d{4}[-/年.]\d{1,2}[-/月.]\d{1,2}.*$"
    r"|\s*[（(]\s*(?:招标编号|采购项目编号|项目编号)\s*[：:].*$"
)

#: 中标候选人公示 —— 阶段不对，金额是投标报价
_CANDIDATE_RE = re.compile(r"候选人")

#: 平台 URL 里带日期的几种写法（正文标签补不到时用）
_URL_DATE_RULES = [
    (re.compile(r"/t(\d{4})(\d{2})(\d{2})_"), "平台 URL 路径日期"),  # ccgp: t20261124_xxxx.htm
    (re.compile(r"/(\d{4})(\d{2})(\d{2})/"), "平台 URL 路径日期"),
    (re.compile(r"/(\d{4})-(\d{2})-(\d{2})/"), "平台 URL 路径日期"),
    (re.compile(r"/(\d{4})(\d{2})(\d{2})\d{6,}"), "平台 URL 路径日期"),
]

WINDOW = {"since": "2024-11-01", "until": "2026-11-27"}


def clean_title(title: str) -> str:
    """去掉标题里拼进来的发布时间、招标编号这类尾巴。"""
    cleaned = _TITLE_TAIL_RE.sub("", title or "").strip()
    return cleaned or (title or "").strip()


def is_candidate_notice(title: str, search_title: str = "") -> bool:
    """是不是"中标候选人公示"（阶段不对，金额是投标报价而非中标金额）。"""
    return bool(_CANDIDATE_RE.search(f"{title} {search_title}"))


def date_from_url(url: str) -> tuple[str | None, str]:
    """从平台 URL 路径里取发布日期。取不到就返回 (None, "")。"""
    for pattern, basis in _URL_DATE_RULES:
        found = pattern.search(url or "")
        if found:
            year, month, day = found.groups()
            if "01" <= month <= "12" and "01" <= day <= "31":
                return f"{year}-{month}-{day}", basis
    return None, ""


def direction_of(text: str) -> str:
    """项目的 ESG 细分方向（Skill 分类器 + build2 的补充映射）。"""
    from build2 import direction_of as _direction_of

    return _direction_of(text)


def correct_one(
    html: str,
    url: str,
    search_title: str,
    record: TenderRecord,
) -> tuple[TenderRecord | None, list[str]]:
    """把一条公告修正成可以直接进报告的记录。

    返回 ``(记录, 说明列表)``；记录为 ``None`` 表示这条应当丢弃
    （页面没内容、标题是样板句、超出口径、土建类等）。
    """
    notes: list[str] = []
    title = (record.title or "").strip()

    if is_error_title(title):
        return None, [f"丢弃-页面无内容：{title[:36]}"]
    if is_boilerplate_title(title):
        if search_title and not is_error_title(search_title):
            notes.append(f"标题修正：{title[:36]} → {search_title[:36]}")
            title = search_title
        else:
            return None, [f"丢弃-标题为样板句：{title[:36]}"]
    title = clean_title(title)

    # ---- 日期 ----
    published = record.published
    date_source = "公告解析"
    if not published:
        published, basis = repair_date(html, url)
        if not published:
            published, basis = date_from_url(url)
        if published:
            date_source = basis
            notes.append(f"日期补齐：{published}（{basis}）")

    # ---- 金额 ----
    amount, basis, amount_notes = rederive_amount(html)
    notes.extend(amount_notes)
    if basis == "未找到金额":
        # 脚本层没抓到金额：只有原文**自带单位**时它的值才可信
        if record.amount_yuan is not None and has_explicit_unit(record.amount_raw):
            amount = record.amount_yuan
            amount_source = "公告解析（原文带单位）"
        else:
            amount = None
            amount_source = ""
    else:
        amount_source = basis
        if amount is None:
            if record.amount_yuan is not None:
                notes.append(
                    f"金额未采信：原解析 {record.amount_yuan:,.2f} 元 → 未披露（{basis}）"
                )
            amount = None
        elif (
            record.amount_yuan is not None
            and abs(record.amount_yuan - amount) > max(1.0, abs(amount) * 0.001)
        ):
            notes.append(
                f"金额修正：{record.amount_yuan:,.2f} → {amount:,.2f} 元（{basis}）"
            )
    if amount == 0:
        notes.append("金额置为未披露：解析出 0 元，按未披露处理")
        amount = None
        amount_source = ""

    # ---- 采购人 / 中标单位 / 省份 / 方向 ----
    buyer = (record.buyer or "").strip()
    winner = (record.winner or "").strip()
    text = plain_text(html)
    if not buyer:
        found = re.search(
            r"(?:采购人名称|采购人|招标人|采购单位)\s*[：:]\s*"
            r"([^\s，,。；;（(【\[]{4,40})",
            text,
        )
        if found:
            buyer = found.group(1).strip()
    if not buyer:
        # 页面上没抽到 —— 从标题开头的机构名兜底（有规则的抽取，不是猜）
        buyer = buyer_from_title(title)
    if winner:
        cleaned = clean_winner(winner)
        if cleaned != winner:
            notes.append(f"中标单位清洗：{winner[:28]} → {cleaned or '（表头碎片，作废）'}")
        winner = cleaned

    haystack = f"{title} {search_title} {buyer} {winner}"
    province = record.province or infer_province(text[:4000], url)
    category = direction_of(haystack)

    in_scope, scope_basis = esg_scope(haystack)
    if not in_scope:
        return None, [f"不在口径内（{scope_basis}）：{title[:40]}"]
    if is_works_contract(title, html):
        return None, [f"剔除-土建类：{title[:40]}"]

    # 关键字段全空 —— 拿不到任何可核对的字段就跳过，不要用上下文猜
    if not (published or amount is not None or buyer or winner):
        return None, [f"丢弃-关键字段全空：{title[:40]}"]

    fixed = TenderRecord(
        title=title,
        url=url,
        buyer=buyer,
        winner=winner,
        amount_yuan=amount,
        amount_raw=record.amount_raw,
        published=published,
        package=record.package,
        province=province,
        category=category,
        extra={
            **record.extra,
            "amount_source": amount_source,
            "date_source": date_source,
            "scope_basis": scope_basis,
            "search_title": search_title,
        },
    )
    return fixed, notes


def dedupe(records: list[TenderRecord]) -> list[TenderRecord]:
    """两级去重：URL 一级，"项目名 + 日期"二级。"""
    unique: list[TenderRecord] = []
    for record in records:
        matched = False
        for index, kept in enumerate(unique):
            if same_announcement(kept, record):
                unique[index] = merge(kept, record)
                matched = True
                break
        if not matched:
            unique.append(record)
    unique.sort(key=lambda r: (r.published or "", r.title), reverse=True)
    return unique


def write_outputs(
    records: list[TenderRecord], filter_stats: dict | None = None
) -> dict:
    """写 records.json / stats.json，返回统计结果。"""
    stats = summarize(records)
    stats["window"] = WINDOW
    if filter_stats:
        stats["filter"] = filter_stats
    (OUT / "records.json").write_text(
        json.dumps([r.to_dict() for r in records], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (OUT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return stats


def main() -> int:
    """把 build2.py 的产物重新过一遍修正层，并重新统计。"""
    records_path = OUT / "records.json"
    stats_path = OUT / "stats.json"
    raw_records = json.loads(records_path.read_text(encoding="utf-8"))
    prev_stats = (
        json.loads(stats_path.read_text(encoding="utf-8")) if stats_path.is_file() else {}
    )
    filter_stats: dict = dict(prev_stats.get("filter") or {})
    audit: list[str] = []

    corrected: list[TenderRecord] = []
    dropped_candidate = 0
    for raw in raw_records:
        url = raw["url"]
        search_title = raw.get("extra", {}).get("search_title", "")
        html = cache_html(url) or ""
        record = TenderRecord(
            title=raw.get("title", ""),
            url=url,
            buyer=raw.get("buyer", ""),
            winner=raw.get("winner", ""),
            amount_yuan=raw.get("amount_yuan"),
            amount_raw=raw.get("amount_raw", ""),
            published=raw.get("published"),
            package=raw.get("package", ""),
            province=raw.get("province", ""),
            category=raw.get("category", ""),
            extra=raw.get("extra", {}),
        )
        fixed, notes = correct_one(html, url, search_title, record)
        for note in notes:
            audit.append(f"[{raw.get('published') or '日期未标注'}] {note}｜{url}")
        if fixed is None:
            continue
        if is_candidate_notice(fixed.title, search_title):
            dropped_candidate += 1
            audit.append(f"[剔除-候选人公示] {fixed.title[:40]}｜{url}")
            continue
        corrected.append(fixed)

    unique = dedupe(corrected)
    filter_stats["dropped_candidate_notice"] = dropped_candidate
    filter_stats["after_dedupe"] = len(unique)
    stats = write_outputs(unique, filter_stats)
    (OUT / "audit.txt").write_text("\n".join(audit), encoding="utf-8")

    print(json.dumps(stats.get("filter", {}), ensure_ascii=False, indent=2))
    print(f"记录 {len(unique)} 条；审计 {len(audit)} 行 -> output/audit.txt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
