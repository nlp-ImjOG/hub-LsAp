#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ESG 招标每日增量监控 —— 脚本臂（与汇总报告共用同一套底座）。

与汇总报告的差别只有一处：多了一步「与状态文件求差集」，只推送没推过的公告。

**必须先推送、成功之后再写状态。** 顺序反了会丢公告 —— 推送失败、状态已写，
第二天就再也推不出来了。

这条链路和汇总报告是同一条：

    检索(hits) → 抓取 → 解析 → 修正(postprocess.correct_one) → 过滤 → 去重
              → 与 output/state/seen.json 求差集 → 推送 → 写状态

关键点：**修正层是共用的**（postprocess.correct_one）。所以推送里的金额
和汇总报告里的金额一定一致 —— 不会出现报告写 9,271,740 元、
推送写 92,717,400,000 元这种事。

用法::

    python daily.py --since 2026-11-20 --dry-run   # 只看会推出什么，不写状态
    python daily.py --since 2026-11-20             # 推送并写状态
    python daily.py --offline                      # 用 output/cache/ 里的缓存，不联网
    python daily.py --days 3                       # 最近 3 天（默认 30 天）
"""

from __future__ import annotations

import json
import os
import sys
import time
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
sys.path.insert(0, str(ROOT))

from esg_toolkit.fetch import USER_AGENTS, decode_bytes  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page, parse_tender_snippet  # noqa: E402
from esg_toolkit.state import StateStore  # noqa: E402

from build2 import cache_html, load_hits, plain_text  # noqa: E402
from fixup import esg_scope, is_works_contract  # noqa: E402
from postprocess import (  # noqa: E402
    clean_title,
    correct_one,
    dedupe,
    is_candidate_notice,
)

OUT = ROOT / "output"
DAILY = OUT / "daily"
DAILY.mkdir(parents=True, exist_ok=True)
STATE = OUT / "state" / "seen.json"


def fetch(url: str, offline: bool = False) -> str:
    """抓一个公告页。offline=True 时只读缓存，不联网。"""
    if offline:
        return cache_html(url) or ""
    parts = url.split("/")
    referer = f"{parts[0]}//{parts[2]}/" if len(parts) > 2 and parts[2] else ""
    last = ""
    for attempt in range(3):
        headers = {
            "User-Agent": USER_AGENTS[attempt % len(USER_AGENTS)],
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Connection": "close",
        }
        if referer:
            headers["Referer"] = referer
        try:
            import requests

            resp = requests.get(
                url, headers=headers, timeout=(5, 12), allow_redirects=True
            )
        except Exception as exc:
            last = f"{type(exc).__name__}: {exc}"
            time.sleep(0.8 * (attempt + 1))
            continue
        if resp.status_code == 200:
            return decode_bytes(resp.content, resp.headers.get("Content-Type", ""))
        last = f"HTTP {resp.status_code}"
        if resp.status_code in (403, 405, 429):
            time.sleep(1.0 * (attempt + 1))
            continue
        break
    # 网络失败时退回缓存 —— 宁可推旧内容，也不要漏掉公告
    return cache_html(url) or ""


def collect(since: str, until: str, offline: bool = False) -> list[TenderRecord]:
    """检索 → 抓取 → 解析 → 修正 → 过滤 → 去重（与汇总报告同一条链路）。"""
    records: list[TenderRecord] = []
    for hit in load_hits():
        url = hit["url"]
        search_title = (hit.get("title") or "").strip()
        html = fetch(url, offline=offline)

        record = None
        if html:
            record = parse_tender_page(html, url=url, fallback_title=search_title)
        if record is None:
            record = parse_tender_snippet("", url, search_title)
        if record is None:
            continue

        # ---- 修正层：与汇总报告共用 ----
        fixed, notes = correct_one(html, url, search_title, record)
        if fixed is None:
            continue
        if is_candidate_notice(fixed.title, search_title):
            continue  # 候选人公示：金额是投标报价，不是中标金额
        if fixed.published and not (since <= fixed.published <= until):
            continue
        records.append(fixed)
    return dedupe(records)


def fmt_amount(value) -> str:
    if value is None:
        return "—"
    return f"{value / 1e4:,.2f} 万元"


def render_digest(records: list) -> str:
    """纯文本推送稿 —— 直接贴进微信群 / 钉钉群。"""
    if not records:
        return "今日未发现新的 ESG 相关招标公告。"
    lines = [f"ESG 相关招标新增 {len(records)} 条：", ""]
    for index, record in enumerate(records, start=1):
        lines.append(f"{index}. {record.title}")
        lines.append(
            f"   日期：{record.published or '日期未标注'}　金额：{fmt_amount(record.amount_yuan)}"
        )
        lines.append(f"   采购人：{record.buyer or '—'}")
        lines.append(f"   链接：{record.url}")
        lines.append("")
    return "\n".join(lines)


def push_webhook(records: list) -> str:
    """推送到 webhook（可选）。没配 webhook 就只落地文件。

    返回一段描述结果的状态串；失败**不抛异常** —— 但调用方据此决定
    写不写状态（见 main）。
    """
    url = os.environ.get("ESG_WEBHOOK_URL", "").strip()
    if not url:
        return "未配置 webhook，仅落地文件"
    if not records:
        return "无新增，未推送"

    import requests

    body = {"msgtype": "markdown", "markdown": {"content": render_digest(records)}}
    try:
        resp = requests.post(url, json=body, timeout=20)
    except Exception as exc:
        return f"推送失败：{type(exc).__name__}: {exc}"
    if resp.status_code >= 400:
        return f"推送失败：HTTP {resp.status_code} {resp.text[:200]}"
    return f"推送成功：HTTP {resp.status_code}"


def main() -> int:
    args = sys.argv[1:]
    dry_run = "--dry-run" in args
    offline = "--offline" in args
    since = ""
    if "--since" in args:
        since = args[args.index("--since") + 1]
    days = 30
    if "--days" in args:
        days = int(args[args.index("--days") + 1])
    if not since:
        since = (date.today() - timedelta(days=days)).isoformat()
    until = date.today().isoformat()

    store = StateStore(STATE)
    print(f"状态文件：{STATE}（已记录 {len(store.seen_ids())} 条）")
    print(f"监控窗口：{since} ~ {until}{'（离线模式，只读缓存）' if offline else ''}")

    records = collect(since, until, offline=offline)
    new_records = store.filter_new(records)
    print(f"候选 {len(records)} 条，其中新增 {len(new_records)} 条")

    payload = {
        "window": {"since": since, "until": until},
        "candidate": len(records),
        "new_count": len(new_records),
        "items": [r.to_dict() for r in new_records],
    }
    (DAILY / "daily.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (DAILY / "daily.md").write_text(
        "# ESG 相关招标新增公告（每日推送）\n\n"
        f"监控窗口 {since} ~ {until}；新增 {len(new_records)} 条。\n\n"
        + "\n".join(
            f"- **{r.published or '日期未标注'}**｜{r.title}｜采购人：{r.buyer or '—'}"
            f"｜金额：{fmt_amount(r.amount_yuan)}｜[原文]({r.url})"
            for r in new_records
        )
        + "\n",
        encoding="utf-8",
    )
    (DAILY / "daily.txt").write_text(render_digest(new_records), encoding="utf-8")

    if dry_run:
        print("--dry-run：不写状态、不推送")
        for record in new_records:
            print(f"  + {record.published or '日期未标注'} {record.title}")
        return 0

    # 先推送，成功了再记状态 —— 顺序反了会丢公告。
    #
    # 注意：Skill 自带的 tender_daily.py 里 push_webhook 失败只返回一段状态串、
    # 不抛异常，而 main() 后面**无条件** store.record + save —— 也就是"推送失败"
    # 的公告仍然被标成已推送，第二天就再也推不出来了（与它自己代码注释里
    # "推送失败下次还能重推"的说法不一致）。这里显式按推送结果决定要不要写状态。
    push_status = push_webhook(new_records)
    print(f"推送：{push_status}")
    if push_status.startswith("推送失败"):
        print("推送失败 —— 不写状态，下次运行会重推这批公告")
        return 1

    store.record(new_records)
    store.save()
    pruned = store.prune(keep_days=180)
    print(f"状态已写入：{STATE}（清理 {pruned} 条过期记录）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
