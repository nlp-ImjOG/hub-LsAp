import io, sys, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
recs = json.loads(open('output/records.json', encoding='utf-8').read())
lines = []
for r in recs:
    lines.append('%s\t%s\t%s' % (r.get('buyer') or '（无采购人）', r.get('winner') or '（无中标单位）', r.get('title','')[:40]))
open('output/buyers.txt','w',encoding='utf-8').write('\n'.join(lines))
print('ok %d' % len(lines))
