import io, sys, json, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '.')
sys.path.insert(0, '.claude/skills/esg-tender-monitor/scripts')

from build2 import cache_html, load_hits
from esg_toolkit.parse_tender import parse_tender_page, parse_tender_snippet
from postprocess import correct_one

hits = load_hits()
recs = json.loads(open('output/records.json', encoding='utf-8').read())
known = {r['url'] for r in recs}

out = []
out.append('汇总数据集 %d 条；hits %d 条' % (len(known), len(hits)))
for hit in hits:
    url = hit['url']
    if url in known:
        continue
    st = (hit.get('title') or '').strip()
    html = cache_html(url)
    if html is None:
        out.append('[无缓存] %s | %s' % (st[:50], url))
        continue
    r = parse_tender_page(html, url=url, fallback_title=st)
    if r is None:
        r = parse_tender_snippet('', url, st)
    if r is None:
        out.append('[解析失败] %s | %s' % (st[:50], url))
        continue
    fixed, notes = correct_one(html, url, st, r)
    if fixed is None:
        out.append('[被修正层剔除] %s | %s | %s' % (st[:40], url[:70], notes))
        continue
    out.append('[保留] title=%r published=%r amount=%r buyer=%r' % (
        fixed.title, fixed.published, fixed.amount_yuan, fixed.buyer))
    out.append('       hit=%r' % st)
    out.append('       url=%s' % url)
    for n in notes:
        out.append('       note: %s' % n)

open('output/dbg6.txt','w',encoding='utf-8').write('\n'.join(out))
print('ok lines=%d' % len(out))
