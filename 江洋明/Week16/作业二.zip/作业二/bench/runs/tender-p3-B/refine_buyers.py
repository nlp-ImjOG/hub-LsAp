#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""采购人类型归类 —— 把 72 条"其他"拆开。

Skill 自带的 ``aggregate.summarize()`` 里的采购人分类只分了 5 类，
把 106 条里的 72 条都归进了"其他"，没法回答"谁在买"这个问题。

这里按**机构性质**重分，规则全部写死在下面，谁要审口径改这一处即可。
匹配顺序 = 规则顺序（先命中先算），所以顺序是有意义的：

1. 金融机构 —— 银行 / 信用社 / 保险 / 信托 / 基金
2. 生态环境与自然资源部门 —— 生态环境 / 自然资源 / 水利 / 水务 / 土地…
3. 发展改革与工信部门 —— 发改 / 工信 / 住建 / 城管 / 经济信息…
4. 其他政府部门 —— 人民政府 / 办事处 / 管理局 / 应急管理 / 机关…
5. 园区 / 开发区管委会
6. 事业单位 / 高校 / 医院
7. 国有企业 / 集团 / 能源企业
8. 其他企业（市场化主体）
9. 未识别

7 和 8 的分界是**名称里的机构标记**（集团 / 国资 / 能源 / 电力 / 港口…），
不是股权性质 —— 名称看不出来的就归"其他企业"，不猜。

用法::

    python refine_buyers.py    # 结果写回 output/stats.json 的 buyers 字段
"""

from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"

#: (类型, 匹配正则) —— 顺序即优先级
BUYER_RULES: list[tuple[str, str]] = [
    ("金融机构", r"银行|信用社|保险|信托|基金"),
    ("生态环境与自然资源部门", r"生态环境|自然资源|林草|林业|水利|水务|河湖|水资源|节约用水|土地"),
    ("发展改革与工信部门", r"发展和改革|发展改革|发改|工业和信息化|经济和信息化|住房和城乡|城市建设|城市管理|城管|经济信息|投资评审|投资项目"),
    ("其他政府部门", r"人民政府|政府办公室|办事处|管理局|应急管理|机关|海关|国资|农业农村|乡村振兴|经贸发展|财政|市场监管|直辖机关"),
    ("园区 / 开发区管委会", r"管委会|开发区|高新区|工业园区|产业园区|保税区|自由贸易|园区"),
    ("事业单位 / 高校 / 医院", r"事业单位|大学|学院|学校|医院|研究院|研究所|科学院|监测中心|事务中心|服务中心|事务局"),
    ("国有企业 / 集团 / 能源企业", r"集团|国资|能源|电力|港口|钢铁|航运|航空|城投|交投|盐业|建设投资|实业|投资"),
    ("其他企业（市场化主体）", r"有限公司|股份|公司|厂|中心"),
]

_COMPILED = [(label, re.compile(pattern)) for label, pattern in BUYER_RULES]


def classify_buyer(buyer: str) -> str:
    """按机构性质归类。认不出来就返回"未识别" —— 不硬塞。"""
    text = (buyer or "").strip()
    if not text:
        return "未识别"
    for label, pattern in _COMPILED:
        if pattern.search(text):
            return label
    return "未识别"


def main() -> int:
    records = json.loads((OUT / "records.json").read_text(encoding="utf-8"))
    stats = json.loads((OUT / "stats.json").read_text(encoding="utf-8"))

    counter: Counter = Counter()
    detail: list[str] = []
    for record in records:
        buyer = (record.get("buyer") or "").strip()
        label = classify_buyer(buyer)
        counter[label] += 1
        detail.append(f"{label}\t{buyer or '（无采购人）'}\t{record.get('title', '')[:44]}")

    # 按预设顺序输出，没命中的类别不出现
    ordered = {label: counter.get(label, 0) for label, _ in BUYER_RULES}
    if counter.get("未识别"):
        ordered["未识别"] = counter["未识别"]

    stats["buyers"] = ordered
    stats["buyer_rule_note"] = "refine_buyers.py 的机构性质规则，顺序即优先级"
    (OUT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (OUT / "buyer_types.txt").write_text("\n".join(detail), encoding="utf-8")

    print(json.dumps(ordered, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
