import io, sys, re, hashlib, pathlib, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '.claude/skills/esg-tender-monitor/scripts')
from esg_toolkit.parse_tender import extract_rows
CACHE = pathlib.Path('output/cache')
recs = json.loads(open('output/records.json', encoding='utf-8').read())
keys = ['鞍山经济开发区省级零碳园区', '合同能源管理节能改造', '伊犁州伊宁市',
        '应对气候变化统计核算分析', '中新天津生态城', '滨海新区北塘A1',
        '数字化绿色智能工厂', '中标价（结算率）', '西安节水', '拜城县']
out = []
for rec in recs:
    title = rec['title']
    if not any(k in title for k in keys):
        continue
    url = rec['url']
    f = CACHE / (hashlib.sha1(url.encode('utf-8')).hexdigest() + '.html')
    out.append('##### %s | %s | %s' % (title[:56], rec['amount_yuan'], rec['published']))
    out.append('  URL=%s' % url)
    if not f.is_file():
        out.append('  (no cache)')
        continue
    html = f.read_text(encoding='utf-8', errors='replace')
    for i, cells in enumerate(extract_rows(html)):
        j = ' | '.join(cells)
        if re.search(r'金额|价|元|万|序号|供应商|单位|合计|总计|包|结算', j):
            out.append('  r%-3d %s' % (i, j[:230]))
    out.append('')
open('output/dbg_rows3.txt', 'w', encoding='utf-8').write('\n'.join(out))
print('ok')
