import io, sys, json
from collections import Counter
from urllib.parse import urlsplit
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '.')

from build2 import load_hits

hits = load_hits()
g = Counter(h.get('g', '?') for h in hits)
d = Counter(urlsplit(h['url']).netloc for h in hits)
lines = ['===== 检索分组 =====']
for k, v in g.most_common():
    lines.append('%3d  %s' % (v, k))
lines.append('===== 来源站点 =====')
for k, v in d.most_common():
    lines.append('%3d  %s' % (v, k))
lines.append('===== 总计 %d 条候选 =====' % len(hits))
open('output/hit_groups.txt', 'w', encoding='utf-8').write('\n'.join(lines))
print('ok')
