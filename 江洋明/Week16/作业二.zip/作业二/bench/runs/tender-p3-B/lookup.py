import io, sys, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
recs = json.loads(open('output/records.json', encoding='utf-8').read())
keys = ['海南广场', '财信金控', '盐田港', '应对气候变化统计核算分析', '浙江省碳交易',
        '零碳园区(连云港', '重点排放单位温室气体排放报告核查复查', '上海市碳达峰碳中和数智管理']
for k in keys:
    for r in recs:
        if k in r['title']:
            print('%s | %s | %s | %s' % (r['published'], r['amount_yuan'], r['title'][:40], r['url']))
            break
