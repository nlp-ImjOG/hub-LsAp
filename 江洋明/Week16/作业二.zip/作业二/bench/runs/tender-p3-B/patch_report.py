"""对 report.md 做一次精确的文本替换（Edit 工具不可用时的定点修补）。

替换要求"原文必须唯一命中"，命中不到就报错退出 —— 宁可失败也不要改错地方。
"""

from __future__ import annotations

import io
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

OLD = """6. **本次修正记录**（全部逐条留痕，可复核）：
   金额改判 **11 处**、金额口径存疑 **5 处**、金额由 0 改判未披露 **3 处**、
   标题修正 **2 处**、日期补齐 **5 处**、中标单位清洗 **11 处**（3 处是表头碎片作废、8 处纠正为正常机构名）、
   候选人公示剔除 **7 条**、跨站去重合并 **6 条**、土建类剔除 **5 条**。
   日志在 `output/audit_stage1.txt`（抓取/解析阶段）与 `output/audit.txt`（修正阶段）。"""

NEW = """6. **本次修正记录**（全部逐条留痕，可复核）：
   金额数值改判 **11 处**；金额口径存疑 **5 处** —— 其中 3 处是「总额为 0 → 按未披露处理」，
   2 处是「总额与结果表分项合计不一致 → 采用总额」；另有原解析 0.00 元不采信 **2 处**。
   标题修正 **2 处**、日期补齐 **5 处**、中标单位清洗 **11 处**（3 处是表头碎片作废、8 处纠正为正常机构名）、
   候选人公示剔除 **7 条**、跨站去重合并 **6 条**、土建类剔除 **5 条**。
   日志在 `output/audit_stage1.txt`（抓取/解析阶段）与 `output/audit.txt`（修正阶段）。"""


def main() -> int:
    path = Path("report.md")
    text = path.read_text(encoding="utf-8")
    count = text.count(OLD)
    if count != 1:
        print(f"原文命中 {count} 次（应为 1 次），未做替换")
        return 1
    path.write_text(text.replace(OLD, NEW), encoding="utf-8")
    print("已替换「数据说明与局限」第 6 条")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
