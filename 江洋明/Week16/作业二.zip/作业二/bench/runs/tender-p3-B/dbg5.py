import io, sys, json, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
recs = json.loads(open('output/records.json', encoding='utf-8').read())
out = []
out.append('=== 标题含"候选人"的记录 ===')
n = 0
for r in recs:
    t = r['title'] + ' ' + r['extra'].get('search_title', '')
    if '候选人' in t:
        n += 1
        out.append('  %s | %s | %s | %s' % (r['published'], r['amount_yuan'],
                                            r['title'][:56], r['url'][:88]))
out.append('  共 %d 条' % n)
out.append('')
out.append('=== 盐田港记录 ===')
for r in recs:
    if '盐田港' in r['title']:
        out.append(json.dumps({k: r[k] for k in
                    ('title', 'url', 'amount_yuan', 'published', 'winner', 'buyer')},
                   ensure_ascii=False, indent=1))
        out.append('  search_title=%s' % r['extra'].get('search_title'))
out.append('')
out.append('=== 标题里带尾巴的记录 ===')
for r in recs:
    t = r['title']
    if re.search(r'发布时间|招标编号|采购包\d|（招标编号', t) or '  ' in t:
        out.append('  %s' % t[:120])
open('output/dbg5.txt', 'w', encoding='utf-8').write('\n'.join(out))
print('ok')
