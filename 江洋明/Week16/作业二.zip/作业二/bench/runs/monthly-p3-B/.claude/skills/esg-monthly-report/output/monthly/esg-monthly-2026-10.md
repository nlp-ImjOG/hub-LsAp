# 中国神华 ESG 月报

**客户**：中国神华

**统计区间**：2026-10-01 ~ 2026-10-31

**生成时间**：2026-11-27 10:50:23

**数据来源**：公开网络检索（WebSearch）+ 中国政府采购网等公开渠道

## 摘要

本期共整理 32 条 ESG 相关动态，覆盖政策与标准、行业实践、客户与对标企业三方面。

## 统计概览

| 指标 | 数值 |
| --- | --- |
| 动态条目总数 | 32 |
| 有明确发布日期 | 1（3.1%）
| 覆盖议题数 | 8 |
| 覆盖信源数 | 29 |
| 其中 A 级信源条目 | 4 |

## 一、ESG 政策、评级与标准动态

本期检索到的政策、评级方法与披露标准相关动态。

### [潮涌南沙!2026上市公司可持续发展大会即将启幕](https://www.stcn.com/article/detail/4353012.html)

*日期未标注 · stcn.com*

议题：可持续与社会责任

证券时报报道2026上市公司可持续发展大会将于11月30日在广州南沙举办，主题为"向新向优共促高质量发展"，聚焦上市公司可持续披露与ESG实践的最新趋势。

### [聚焦“十五五”规划建议 瞄准“双碳”目标，全国碳市场建设稳步推进](https://big5.www.gov.cn/gate/big5/www.gov.cn/zhengce/202511/content_7049413.htm)

*日期未标注 · big5.www.gov.cn*

议题：双碳与碳中和

围绕“十五五”规划建议提出的碳达峰碳中和目标，阐述全国碳市场建设的推进思路：完善总量控制下的配额分配机制、深化钢铁水泥铝冶炼等行业履约管理、推进碳排放双控与碳市场协同、加强温室气体自愿减排市场建设。

### [刚刚!沪深北三大交易所,最新发布!涉及三大ESG实操"指南"](https://www.jingjiribao.cn/static/detail.jsp?id=607769)

*日期未标注 · jingjiribao.cn*

议题：可持续与社会责任

经济日报报道沪深北三大交易所同步发布ESG实操指南，配套《上市公司可持续发展报告指引》落地，覆盖气候、污染物排放、能源与水资源利用等具体议题的编制要求。

### [关于政协十四届全国委员会第三次会议第01055号(财税金融类072号)提案答复的函](https://www.csrc.gov.cn/csrc/c101983/c7617079/content.shtml)

*日期未标注 · csrc.gov.cn*

议题：可持续与社会责任

证监会就政协提案答复，阐述上市公司可持续信息披露制度安排与规则体系，包括交易所《指引》与《指南》双层设计、强制与自愿披露安排、以及与境外准则的衔接安排。

### [上市公司绿色治理指数持续抬升 机制披露短板亟待补齐](https://lib.cet.com.cn/paper/szb_con/545597.html)

*日期未标注 · lib.cet.com.cn*

议题：碳足迹与核算

中国经济周刊报道绿色治理指数上升但披露质量分化：仅约37.8%的上市公司主动披露温室气体排放等定量绩效，第三方鉴证与应急预案披露比例偏低，机制类披露仍是短板。

### [可持续信息披露制度新发展:法理､创新与展望](https://www.cnstock.com/commonDetail/173363)

*日期未标注 · cnstock.com*

议题：可持续与社会责任

上海证券研究文章，从法理与制度视角分析可持续信息披露制度的新发展，梳理三大交易所指引与配套指南的创新点、强制披露边界及对上市公司治理与投资决策的影响。

### [ESG Ratings Regulation – new legal framework for ESG ratings applies from 2 July 2026](https://www.fma.gv.at/en/esg-ratings-regulation-new-legal-framework-for-esg-ratings-applies-from-2-july-2026/)

*日期未标注 · fma.gv.at*

议题：可持续与社会责任

奥地利金融市场管理局（FMA）说明欧盟 ESG评级法规（Regulation (EU) 2024/3005）自 2026 年 7 月 2 日起全面适用：欧盟境内专业发布 ESG 评级须取得 ESMA 授权，既有评级机构须于 2026 年 8 月 2 日前通知 ESMA、11 月 2 日前提交授权/认可申请。

### [Communication to market participants on the application of the ESG Ratings Regulation and the new disclosure requirements under the SFDR](https://www.cssf.lu/en/2026/07/communication-to-market-participants-on-the-application-of-the-esg-ratings-regulation-and-the-new-disclosure-requirements-under-the-sfdr/)

*日期未标注 · cssf.lu*

议题：可持续与社会责任

卢森堡 CSSF 2026 年 7 月通知：ESG 评级法规第 49 条修订 SFDR 第 13 条，金融机构在营销材料中披露第三方 ESG 评级时，须在官网披露 Annex III 第 1 点信息并附链接。

### [ESG Ratings](https://www.fma.gv.at/en/cross-sectoral-topics/sustainable-finance/esg-ratings)

*日期未标注 · fma.gv.at*

议题：可持续与社会责任

FMA 关于 ESG 评级的监管专栏页面，汇总欧盟 ESG 评级注册/授权框架、ESMA 相关技术标准清单以及欧盟市场参与者的适用要求指引。

### [Environmental, Social and Governance (ESG) Rating](https://lsfi.lu/regulations/environmental-social-and-governance-esg-rating-regulation/)

*日期未标注 · lsfi.lu*

议题：可持续与社会责任

卢森堡金融行业监管规范页面，逐条说明 ESG 评级法规下的授权与认可流程、过渡期安排，以及评级机构需满足的业务隔离、方法论披露与利益冲突管理义务。

### [EU ESG Ratings Regulation: What Changes for Rating Providers in 2026](https://reporting.academy/en/pages/eu-esg-ratings-regulation-what-changes-for-rating-providers-in-2026/)

*日期未标注 · reporting.academy*

议题：ESG披露与鉴证

解读 2026 年欧盟 ESG 评级法规对评级机构的实际影响：配套 RTS（方法论披露、业务隔离、收费与处罚程序、授权认可程序）对方法论透明度、E/S/G 权重披露、是否采用双重重要性等的影响。

### [ISSB Update November 2025](https://www.ifrs.org/news-and-events/updates/issb/2025/issb-update-november-2025/)

*日期未标注 · ifrs.org*

议题：可持续与社会责任

国际可持续发展准则理事会 2025 年 11 月更新：决定基于 TNFD 框架开展自然相关风险与机遇披露项目，并转入标准制定阶段；持续跟踪 ISSB 准则的采用进展与生效安排。

## 二、行业动态与最佳实践

本期检索到的客户所属行业动态与可借鉴的最佳实践。

### [2025年全国绿色矿山建设十件大事](http://dzj.gd.gov.cn/4dd/dzkp/content/post_4854046.html)

*日期未标注 · dzj.gd.gov.cn*

议题：绿色低碳与节能

梳理2025年绿色矿山建设十件大事：GB/T 44823—2024《绿色矿山评价通则》2月1日实施；《绿色矿山建设规范》《固体矿产绿色勘查规范》系列国标发布，填补不同矿种绿色矿山国标空白；绿色矿山名录推行移出动态管理，告别“一评终身”；发改委《生态保护修复领域中央预算内投资专项管理办法》与《推进生态综合补偿实施方案》相继出台。

### [完善清洁高效利用标杆水平和基准水平 加快煤炭绿色低碳转型](https://www.zhonghongwang.com/show-254-447907-1.html)

*日期未标注 · zhonghongwang.com*

议题：双碳与碳中和

解读《煤炭清洁高效利用重点领域标杆水平和基准水平（2025年版）》三大调整：拓展重点领域（新增燃煤发电供热、煤制油、煤制天然气）、全面调升能效标杆值与基准值、污染物排放标杆对标最严格排放要求；低于基准的存量项目限期改造（一般不超过3年），不能按期完成的予以淘汰。

### [建设零碳工厂既要“算得准”，又要“管得精”](https://www.cecaweb.org.cn/home/content.php?portal_id=1&column_id=21&column_type=0&content_id=5295)

*日期未标注 · cecaweb.org.cn*

议题：绿色低碳与节能

中国节能协会文章，阐述零碳工厂智能控碳体系：通过物联网与大数据实现碳排放实时监测、动态优化，运用 AI 预测模型进行异常预警与节能降碳空间挖掘，推动从“事后核算”向“过程管控”和“前瞻预测”升级。

### [煤炭企业如何做好ESG这道必答题?——细读2025年煤炭行业社会责任报告](https://www.coalchina.org.cn/index.php?m=content&c=index&a=show&catid=10&id=162545)

*日期未标注 · coalchina.org.cn*

议题：可持续与社会责任

中国煤炭工业协会解读《中国煤炭行业社会责任报告（蓝皮书）》：说明“十五五”碳排放双控由软约束转为硬考核，煤炭企业需完善分层治理架构、配备复合型管理团队；并给出强化环境板块定量数据披露、加大行业专属重大实质性议题披露、优化报告平衡性三个改进方向。

### [三年行动,推进能源领域节能降碳](https://www.zglsfz.com.cn/newsinfo/11255843.html)

*日期未标注 · zglsfz.com.cn*

议题：绿色低碳与节能

解读国家能源局《能源领域节能降碳行动计划（2026—2028年）》：电力领域关停老旧低效煤电机组、发展新型储能与绿电直连；煤炭领域推进智能化开采、矿区就地开发光伏风电地热、运输工具电动或氢能替代、煤矸石与瓦斯资源化利用；目标到2028年非化石能源消费比重年均提升约1个百分点，达到能效标杆水平的煤电产能比例力争提高15个百分点，建成一批零碳低碳煤炭矿区。

### [气候信息披露：让企业低碳转型看得见](https://www.cnenergynews.cn/article/4U0jIPU4Ojl)

*日期未标注 · cnenergynews.cn*

议题：双碳与碳中和

中国能源网报道企业气候信息披露《气候准则》及配套指南推进情况，涵盖披露主体、统计口径与量化数据类型界定，碳市场数据须经第三方核查，并推动范围三排放披露（当前披露率仅约 23%）。

### [企业“气候账本”怎么算？配套指南有望给出“操作说明书”](http://adimg.ce.cn/xwzx/gnsz/gdxw/202610/t20261012_3254110.shtml)

*2026-10-12 · adimg.ce.cn*

议题：双碳与碳中和

中国经济网报道：企业气候信息披露制度框架与配套指南进展，聚焦“气候账本”核算口径与操作规范，支持在“十五五”碳达峰行动方案下推进企业信息披露，并推动范围三披露。

### [《投资蓝皮书：中国ESG投资发展报告(2026)》指出：国内能源电力企业需打造本土化ESG治理体系助力转型](https://www.cet.com.cn/cms/show-10677166.html)

*日期未标注 · cet.com.cn*

议题：可持续与社会责任

蓝皮书建议能源电力企业：统一双重实质性ESG评审并严控新增高碳资产；调整长期投资结构（特高压、智能配网、抽蓄、新型储能、CCUS、氢能）；构建内外兼容、量化透明的披露体系，对内遵循国内规范、海外对接 GRI/TCFD/ISSB/CSRD/EEI，完整公示 Scope 1/2/3；搭建集团一体化 ESG 数字管控中台。

### [ESG深度融入能源主业:从披露到实效的新阶段](https://idongdian.com/cms/dianlijianguan/13692)

*日期未标注 · idongdian.com*

议题：ESG披露与鉴证

分析ESG从形式化披露走向业务实效的路径：建立动态碳排放台账与数字化ESG管理平台，将指标拆解至业务部门并纳入绩效考核，推动气候风险量化披露与压力测试，引入第三方鉴证，避免“报喜不报忧”，以应对ESG强制披露与ISSB国际准则要求。

### [（中国环境报）矿山生态修复：守“两山”初心，增“绿色财富”](https://chinamining.org.cn/index.php/news/75/12219)

*日期未标注 · chinamining.org.cn*

议题：绿色金融

中国环境报指出当前矿山生态修复短板：后续资金投入大、回报周期长、修复模式单一，“重生态治理、轻价值挖掘和产业导入”“重施工、轻运维”，植被退化、边坡复损、水土流失反弹等风险仍在。建议设立矿山修复专项基金、推广EOD模式、开发定向绿色金融产品，从末端治理转向全过程“采复耦合”修复。

### [新华视点：超300万亩“大地伤疤”如何被修复](https://k.sina.cn/article_1699432410_654b47da02001y924.html)

*日期未标注 · k.sina.cn*

议题：环境与生态治理

新华社关注我国历史遗留矿山生态修复：2021年核查查明待修复废弃矿山超630万亩，“十四五”已完成335万亩修复治理。河北邢台胜合华建材采用“基金预存+利润反哺”模式，每年将盈利40%专项用于修复，建成3A级矿山公园，年旅游收入超6000万元；天津春山里项目采用EOD模式引入文旅、地产业态。

## 三、公司动态、对标企业行动与建议

本期检索到的客户公司动态、对标企业 ESG 关键行动，及其对客户 ESG 的影响与建议。

### [国家能源集团多项履责案例入选2026央企社会责任系列蓝皮书](https://www.chnenergy.com.cn/gjnyjtww/newCE0301/202611/47f354fde26944e598e5c8a12093bef5.shtml)

*日期未标注 · chnenergy.com.cn*

议题：可持续与社会责任 · 影响：利好

[利好·入选] 国家能源集团五项履责成果入选《中央企业社会责任蓝皮书(2026)》《海外ESG蓝皮书》《上市公司ESG蓝皮书》等系列蓝皮书。

### [中国神华2026年半年度业绩说明会直播结束](https://m.cnstock.com/commonDetail/785321)

*日期未标注 · m.cnstock.com*

议题：双碳与碳中和 · 影响：中性

中国证券网2026年半年度业绩说明会直播记录,涉及2026年上半年双碳目标推进、碳市场履约与绿色矿山建设等议题的最新管理层口径。

### [中国神华2025年半年度业绩说明会直播结束](https://www.cnstock.com/topicDetail/515207)

*日期未标注 · cnstock.com*

议题：双碳与碳中和 · 影响：中性

中国证券网2025年半年度业绩说明会直播记录,总经理张长岩明确双碳目标:二氧化碳排放量于2030年前达峰,努力争取2060年前实现碳中和;并披露ESG治理工作领导小组成立、《气候变化风险与机遇管理办法》编制等治理机制建设情况。

### [中国神华官网 - 新闻中心/要闻动态](http://www.shenhuachina.cc/zgshww/mta/ywtxListContent.shtml)

*日期未标注 · shenhuachina.cc*

议题：可持续与社会责任 · 影响：中性

中国神华官方网站新闻动态列表页,是公司公告、ESG与可持续发展动态、碳减排与绿色矿山相关官方发布的权威原始来源,可用于逐条核验发布时间与原文表述。

### [中国神华:投资者关系活动记录表(2026年半年度业绩说明会)](https://www.cnfin.com/announ/detail/index.html?dannoun=lcdetail&id=843320205380)

*日期未标注 · cnfin.com*

议题：双碳与碳中和 · 影响：中性

公司回应投资者关于煤电定位、容量电价、煤炭与新能源融合、绿电绿证及碳资产管理等问题，介绍2026年上半年绿色低碳转型与新能源装机进展。

### [中国中煤举办社会责任和ESG工作专题培训暨可持续发展反向路演](https://www.cctd.com.cn/show-22-257255-1.html)

*日期未标注 · cctd.com.cn*

议题：可持续与社会责任 · 影响：中性

中国中煤在平朔集团开展ESG专题培训与可持续发展反向路演，部署社会责任和ESG工作“提质扩面”三年行动，健全二级企业责任治理体系并强化重要议题与关键指标管理。

### [CHN Energy Builds Nine Zero-Carbon Benchmark Parks, Cutting 170,000 Tons of Carbon Annually](https://www.ceic.com/gjnyjtwwEn/xwzx/202511/4d10bbd4b5cf460993c7087942bfe00b.shtml)

*日期未标注 · ceic.com*

议题：绿色低碳与节能 · 影响：中性

国家能源集团建成九个零碳及近零碳园区，年可减少碳排放约17万吨，属于零碳园区建设的可复制做法。

### [CHN Energy advances green transformation across vast landscapes](https://www.ceic.com/gjnyjtwwEn/xwzx/202603/afde763e8fe74258a0fb759ceecbbc21.shtml)

*日期未标注 · ceic.com*

议题：绿色低碳与节能 · 影响：中性

国家能源集团介绍其跨区域绿色转型实践，涉及新能源基地建设、零碳园区与运输装备电动化等具体举措。

### [物资公司绿色供应链案例入选ESG实践报告](http://hk.csec.com/zgshww/xwtt/202609/5e41c836fed94766a6b66a74127651c7.shtml)

*日期未标注 · hk.csec.com*

议题：供应链与责任 · 影响：利好

[利好·入选] 中国神华物资公司绿色供应链案例入选ESG实践报告，依托“国能绿链”绿色供应链碳管理平台，自研12款算碳模型，绿色产品销售额约3.47亿元，直接减碳806.15吨。

## 数据说明与局限

- 报告按自然月统计（上月 1 日至月末），口径固定，可跨月对比。
- 所有结论均以标注来源为准；未能核实的内容不作断言。
- 检索后端：claude-cli；抽取、去重与排序由确定性脚本完成，导语与建议由模型基于已核实事实撰写。
