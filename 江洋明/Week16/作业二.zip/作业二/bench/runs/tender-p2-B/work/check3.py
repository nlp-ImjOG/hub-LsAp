"""抽查最大金额记录 + 抓取江西 GEP 与池州采购人（补两条证据）。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGET = "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251127_25778105.htm"

PROBE = [
    ("江西GEP", "https://drc.jiangxi.gov.cn/jxsfzhggwyh/col/col14590/content/content_2063876380782551040.html"),
    ("池州采购人", "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb"),
]


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def main() -> int:
    print("== 海南广场 记录原文 ==")
    for name in ("records.json", "records2.json"):
        for row in json.loads((ROOT / name).read_text(encoding="utf-8")):
            if row["url"] == TARGET:
                print(json.dumps(row, ensure_ascii=False, indent=2))

    print("\n== fixup.json 命中 ==")
    fixup = json.loads((ROOT / "fixup.json").read_text(encoding="utf-8"))
    key = next((k for k in fixup if TARGET in k), None)
    print(key, json.dumps(fixup.get(key), ensure_ascii=False) if key else "(无)")

    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)
    for label, url in PROBE:
        print("\n" + "=" * 90)
        print("###", label, url)
        res = browser.fetch(url)
        html = res.html if res and res.html else ""
        if not html:
            print("!! 抓取失败")
            continue
        for line in plain(html):
            if len(line) > 220:
                continue
            if re.search(r"中标|成交|采购人|采购单位|招标人|金额|万元|元|日期|发布|时间|供应商|机构", line):
                print("  >", line[:200])
    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
