"""核对报告里引用的 Top 名单与地区金额排序。"""

from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))
stats = json.loads((ROOT / "stats.json").read_text(encoding="utf-8"))

counter: Counter[str] = Counter()
for row in rows:
    if row["winner"]:
        counter[row["winner"]] += 1

print("== 中标单位 Top 15 ==")
for name, count in counter.most_common(15):
    print(f"  {count}  {name}")

print("\n== 地区按金额排序 Top 12 ==")
for r in sorted(stats["regions"], key=lambda x: -x["total_yuan"])[:12]:
    print(f"  {r['region']:<8s} {r['count']:>3d} 条  {r['total_yuan']/1e4:12,.2f} 万")

print("\n== 地区按条数 Top 8 ==")
for r in stats["regions"][:8]:
    print(f"  {r['region']:<8s} {r['count']:>3d} 条  {r['total_yuan']/1e4:12,.2f} 万")

print("\n== 采购人类型 ==")
for k, v in stats["buyers_by_title"].items():
    print(f"  {k:<20s} {v:>3d}")

print("\n== 检索摘要级记录 ==")
for r in rows:
    if r["evidence"].startswith("检索摘要"):
        print(f'  {r["date"]} | {r["title"][:46]} | {r["evidence"]}')

print("\n== 采购人为空的条数 ==",
      sum(1 for r in rows if not r["buyer"]))
print("== 无金额条数 ==", sum(1 for r in rows if r["amount_yuan"] is None))
