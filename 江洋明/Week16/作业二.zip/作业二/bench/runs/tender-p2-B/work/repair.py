"""修复/补全：把金额标签所在的原文行原样打出来，人工核对后写入 corrections.json。

为什么需要这一步：确定性解析器在两种情形下会失手——
  1. 表格结构特殊（多包结果表、候选人公示表），字段名不在 FIELD_PATTERNS 里；
  2. 单位在相邻单元格（``954700.0`` + 表头 ``万元``），归一时选错因子。

这里**不重新推断**，只把页面原文逐行打出来（带 URL 与上下文），
让人对着原文确认，再把确认后的值写进 corrections.json。
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_news import extract_body  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

#: 命中这些词的行，才值得打出来看
LABELS = (
    "中标", "成交", "金额", "报价", "单价", "总价", "预算", "控制价",
    "最高限价", "价格", "候选", "供应商", "中标人", "成交供应商",
)

AMOUNT_LINE_RE = re.compile(
    r"(?:\d[\d,，]*(?:\.\d+)?)\s*(?:亿元|万元|元|%|％|折)"
)


def load_records() -> list[dict]:
    records: list[dict] = []
    for name in ("records.json", "records2.json"):
        path = ROOT / name
        if path.is_file():
            records.extend(json.loads(path.read_text(encoding="utf-8")))
    return records


def main() -> int:
    records = load_records()
    only = set(sys.argv[1:])
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for rec in records:
        if only and not any(k in rec["title"] for k in only) and rec["url"] not in only:
            continue
        amount = rec["amount_yuan"]
        suspicious = amount is None or (
            rec["amount_raw"]
            and not re.search(r"[亿万千百%％]", rec["amount_raw"])
            and amount is not None
            and amount < 1000
        )
        if not suspicious:
            continue

        print("=" * 110)
        print(f"标题: {rec['title']}")
        print(f"URL : {rec['url']}")
        print(f"当前解析: amount_yuan={amount} raw={rec['amount_raw']!r} winner={rec['winner']!r}")

        result = fetcher.fetch(rec["url"])
        if not (result.ok and result.html):
            print("   !! requests 抓取失败:", result.error, result.status)
            browser = fetcher._browser  # noqa: SLF001
            if browser is None:
                from esg_toolkit.fetch import BrowserFetcher

                browser = BrowserFetcher(config)
                fetcher._browser = browser  # noqa: SLF001
            br = browser.fetch(rec["url"])
            if br is None or not br.html:
                print("   !! 浏览器抓取也失败")
                continue
            html = br.html
        else:
            html = result.html

        body = extract_body(html)
        for raw_line in body.splitlines():
            line = re.sub(r"\s+", " ", raw_line).strip()
            if not line or len(line) > 200:
                continue
            if not AMOUNT_LINE_RE.search(line):
                continue
            if not any(label in line for label in LABELS):
                continue
            print("   >", line[:190])

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
