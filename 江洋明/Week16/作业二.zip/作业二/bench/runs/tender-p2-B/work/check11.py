"""核对哈尔滨华能碳排放管控服务项目（样本最早的一条）的金额与中标人。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

URL = "https://hrbggzy.harbin.gov.cn/zbgs/20241120/4f53964a-897f-42d8-863d-21147d659cd0.html"

for name in ("records.json", "records2.json"):
    for row in json.loads((ROOT / name).read_text(encoding="utf-8")):
        if row["url"] == URL:
            print(json.dumps(row, ensure_ascii=False, indent=2))


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)
    res = browser.fetch(URL)
    html = res.html if res and res.html else ""
    if not html:
        print("!! 抓取失败")
        return 1
    for line in plain(html):
        if len(line) > 240:
            continue
        if re.search(r"中标|候选|金额|万元|元|公示|采购人|招标人|供应商|报价", line):
            print("  >", line[:220])
    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
