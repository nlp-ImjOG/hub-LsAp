"""最终构建（v4）：修正采购人分类的正则匹配，并让热点词的所属方向与「方向」列一致。"""

from __future__ import annotations

import json
import re
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
sys.path.insert(0, str(ROOT))

from build3 import (  # noqa: E402
    CORRECTIONS,
    DIRECTION_ALIASES,
    OUT_OF_WINDOW,
    RECORD_FIELDS,
    direction_of,
    evidence_of,
    load_records,
    title_key,
)
from esg_toolkit.aggregate import BUYER_RULES, extract_directions, summarize  # noqa: E402
from esg_toolkit.keywords import DIRECTION_CATEGORY  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TODAY = date(2026, 11, 27)
SINCE = date(TODAY.year - 2, TODAY.month, 1).isoformat()
UNTIL = TODAY.isoformat()


def term_category(term: str) -> str:
    """热点词的所属方向：矩阵归类优先，「其他方向」按别名表归并。"""
    base = DIRECTION_CATEGORY.get(term, "其他方向")
    if base != "其他方向":
        return base
    for alias, category in DIRECTION_ALIASES:
        if alias in term:
            return category
    return base


def buyer_classification(records: list[TenderRecord]) -> dict[str, int]:
    """按 Skill 的采购人规则表分类，匹配文本为「采购人字段 + 公告标题」。

    规则表里的模式是正则（多选分支），必须用 ``re.search`` —— 子串判断会把
    「生态环境局|环保局|…」当成一个整体词表，永远匹配不上。
    """
    counter: dict[str, int] = {}
    for record in records:
        text = f"{record.buyer} {record.title} {record.extra.get('buyer_raw', '')}"
        matched = "其他"
        for label, pattern in BUYER_RULES:
            if pattern and re.search(pattern, text):
                matched = label
                break
        counter[matched] = counter.get(matched, 0) + 1
    return dict(sorted(counter.items(), key=lambda kv: -kv[1]))


def main() -> int:
    raw_records = load_records()
    applied: set[str] = set()
    kept: list[TenderRecord] = []

    for item in raw_records:
        url = item["url"]
        if url in OUT_OF_WINDOW:
            continue
        fix = CORRECTIONS.get(url, {})
        data = dict(item)
        extra = dict(data.get("extra") or {})
        for key, value in fix.items():
            if key in ("evidence", "note"):
                extra[key] = value
            else:
                data[key] = value
        data["extra"] = extra
        record = TenderRecord(**{k: data.get(k) for k in RECORD_FIELDS})
        record.category = direction_of(record.title, record.category)
        kept.append(record)
        if fix:
            applied.add(url)

    unmatched = set(CORRECTIONS) - applied
    if unmatched:
        print("!! 以下修正没有匹配到任何记录:")
        for url in sorted(unmatched):
            print("   ", url)

    seen_urls: set[str] = set()
    seen_keys: set[str] = set()
    deduped: list[TenderRecord] = []
    dup_count = 0
    for record in kept:
        url_key = canonical_url(record.url)
        key = f"{title_key(record.title)}|{record.published or ''}"
        if (url_key and url_key in seen_urls) or (key in seen_keys):
            dup_count += 1
            continue
        if url_key:
            seen_urls.add(url_key)
        seen_keys.add(key)
        deduped.append(record)

    in_window = [r for r in deduped if not r.published or SINCE <= r.published <= UNTIL]
    outside = [r for r in deduped if r.published and not (SINCE <= r.published <= UNTIL)]

    stats = summarize(in_window)
    stats["buyers_by_title"] = buyer_classification(in_window)
    for hot in stats["hotspots"]:
        hot["category"] = term_category(hot["term"])

    rows = []
    for record in in_window:
        rows.append({
            "date": record.published or "",
            "title": record.title,
            "url": record.url,
            "buyer": record.buyer or "",
            "winner": record.winner or "",
            "amount_yuan": record.amount_yuan,
            "amount_raw": record.amount_raw or "",
            "direction": record.category or "未分类",
            "province": record.province or "未识别",
            "evidence": evidence_of(record),
            "note": record.extra.get("note", ""),
        })
    rows.sort(key=lambda r: (r["date"] or "9999", r["title"]), reverse=True)

    (ROOT / "records_final.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    (ROOT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"原始 {len(raw_records)} 条；应用修正 {len(applied)} 条；去重 {dup_count} 条；"
          f"入表 {len(in_window)} 条")
    print(f"统计区间：{SINCE} ~ {UNTIL}")
    print(f"有金额 {stats['with_amount']} 条；金额未披露 {stats['amount']['missing']} 条；"
          f"无日期 {stats['undated']} 条")
    for rec in outside:
        print("   [区间外]", rec.published, rec.title)
    amt = stats["amount"]
    print(f"金额合计 {amt['total_yuan']/1e4:.2f} 万元；中位数 {amt['median_yuan']/1e4:.2f} 万元；"
          f"均值 {amt['mean_yuan']/1e4:.2f} 万元；最大 {amt['max_yuan']/1e4:.2f} 万元；"
          f"最小 {amt['min_yuan']/1e4:.2f} 万元")
    print("\n-- 金额分布 --")
    for b in stats["buckets"]:
        print(f"  {b['bucket']:>12s}  {b['count']:>3d} 条  占比 {b['ratio']*100:5.1f}%  "
              f"金额 {b['total_yuan']/1e4:12.2f} 万  金额占比 {b['amount_ratio']*100:5.1f}%")
    print("\n-- 热点方向（标题词频） --")
    for h in stats["hotspots"]:
        print(f"  {h['term']:<14s} {h['count']:>3d} 条  {h['share']*100:5.1f}%  [{h['category']}]")
    print("\n-- 方向分布 --")
    for c in stats["categories"]:
        print(f"  {c['category']:<14s} {c['count']:>3d} 条  {c['total_yuan']/1e4:12.2f} 万")
    print("\n-- 未分类 / 其他方向 明细 --")
    for r in rows:
        if r["direction"] in ("未分类", "其他方向"):
            print(f'  [{r["direction"]}] {r["date"]} {r["title"][:52]} | {extract_directions(r["title"])}')
    print("\n-- 地区 --")
    for r in stats["regions"]:
        print(f"  {r['region']:<8s} {r['count']:>3d} 条  {r['total_yuan']/1e4:12.2f} 万")
    print("\n-- 采购人类型（采购人字段+标题，re.search） --")
    for k, v in stats["buyers_by_title"].items():
        print(f"  {k:<20s} {v:>3d} 条")
    print("\n-- 采购人类型（仅采购人字段，Skill 原口径） --")
    for k, v in stats["buyers"].items():
        print(f"  {k:<20s} {v:>3d} 条")
    print("\n-- 月度走势 --")
    for t in stats["trend"]:
        print(f"  {t['month']}  {t['count']:>3d} 条  {t['total_yuan']/1e4:12.2f} 万")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
