"""打印候选清单里的检索摘要（hint），用于核对「页面拿不到金额」的记录。

Tier C 兜底：页面抓不到时，搜索摘要本身就是证据来源。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

KEYS = [
    "ahsz.gov.cn", "ccgp-xizang", "t20250911_25643675", "t20250910_25327535",
    "t20250108_24036512", "t20260108_25863718", "chizhou.gov.cn", "zaozhuangbank",
    "cfet.com.cn", "bidding.csg.cn", "ahtba.org.cn", "fzggw.ah.gov.cn",
    "cntcitc", "zfcg.henan.gov.cn", "cnbiding.com.cn", "jsggzy.jszwfw.gov.cn",
    "ggzyjy.yantai.gov.cn", "gdebidding", "szxc.gov.cn", "e.ytport",
    "ggzy.zj.gov.cn", "shaanxi",
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    for name in ("candidates.json", "candidates2.json"):
        path = ROOT / name
        if not path.is_file():
            continue
        for item in json.loads(path.read_text(encoding="utf-8")):
            url = item.get("url", "")
            if any(k in url for k in KEYS):
                print("-" * 110)
                print("URL  :", url)
                print("GROUP:", item.get("group", ""))
                print("TITLE:", item.get("title_hint", ""))
                print("HINT :", item.get("hint", "")[:900])


if __name__ == "__main__":
    raise SystemExit(main())
