"""枣庄银行页面用 requests 直连试一次；并扫描全部记录里的模板占位符。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    fetcher = Fetcher(config)
    url = "https://www.zaozhuangbank.com/zzbank/2025-09/12/article_2025091208165779389.html"
    res = fetcher.fetch(url)
    html = res.html if res and res.html else ""
    print("枣庄银行 fetch:", "OK" if html else "失败", len(html))
    for line in plain(html)[:60]:
        print("  >", line[:180])
    fetcher.close()

    print("\n== 模板占位符 / 疑似脏字段 ==")
    rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))
    for r in rows:
        for field in ("title", "buyer", "winner"):
            value = r.get(field) or ""
            if "{{" in value or "null" == value.lower() or "undefined" in value:
                print(f'  {field}={value!r} | {r["date"]} | {r["title"][:40]} | {r["url"]}')
    print("\n== 采购人为空 ==")
    for r in rows:
        if not r["buyer"]:
            print(f'  {r["date"]} | {r["title"][:56]} | {r["url"]}')
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
