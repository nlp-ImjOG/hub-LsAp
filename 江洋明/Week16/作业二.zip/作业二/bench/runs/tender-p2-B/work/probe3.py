"""第四轮定点取证：把页面正文按行打出来（去掉导航），人工读出中标人与金额的对应关系。

用法: python probe3.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

NOISE = {
    "首页", "大", "中", "小", "公司要闻", "当前位置", "详细信息", "字体", "【",
    "】", "浏览次数", "发布日期", "信息来源", "字体：【", "信息时间", "阅读次数",
    "【信息时间", "【阅读次数", "【信息来源", "当前位置：", "返回", "更多",
    "打印", "关闭", "分享", "网站地图", "联系我们", "无障碍浏览", "旧版",
    "简体", "繁體", "English", "登录", "注册", "搜索", "意见反馈",
}

TARGETS = [
    ("上海双碳试点", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202512/t20251203_25836326.htm"),
    ("国家能源", "https://www.chnenergybidding.com.cn/bidweb/001/001005/001005003/20250612/8887b51e-c2dc-42ea-b6f3-306d272e583b.html"),
    ("青岛卷烟厂", "https://sdgy.tobacco.com.cn/p1/jggs/20261023/61389.html"),
    ("会泽", "https://www.ynzy-tobacco.com/c/2025-06-06/607216.shtml"),
    ("大理", "https://www.ynzy-tobacco.com/c/2025-07-01/608219.shtml"),
    ("苏州浦江源", "https://www.wujiang.gov.cn/zgwj/xezbxx/202511/41e7257102bc4d1fa46d06fa623738e5.shtml"),
    ("蚌埠", "https://ggzy.bengbu.gov.cn/jyxxgk/002002/002002009/002002009001/20251029/a5a9f814-f5d8-46d5-a82e-34ad25e1ca13.html"),
    ("宿州", "https://ggzyjy.ahsz.gov.cn/jyxx/001002/001002004/001002004001/20261110/0504a4c0-2338-4413-aed9-9bf326cf4507.html"),
]


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&").replace("&gt;", ">")
    lines = [re.sub(r"[ \t　]+", " ", ln).strip() for ln in text.split("\n")]
    return [ln for ln in lines if ln and ln not in NOISE and len(ln) > 1]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for label, url in TARGETS:
        print("=" * 116)
        print(f"### {label}\n### {url}")
        html = ""
        res = fetcher.fetch(url)
        if res.ok and res.html:
            html = res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html
        if not html:
            print("!! 抓取失败\n")
            continue
        for line in plain(html)[:150]:
            print(" ", line[:260])
        print("", flush=True)

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
