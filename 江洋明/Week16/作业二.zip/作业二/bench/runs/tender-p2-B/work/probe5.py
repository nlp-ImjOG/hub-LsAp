"""第六轮：把关键表格的**原始 HTML** 整段打出来（bs4 合并单元格后丢了供应商名）。

用法: python probe5.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    ("广东工业双碳", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202507/t20250724_25034196.htm",
     "中标（成交）金额"),
    ("西安减污降碳", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202607/t20260702_26861655.htm",
     "中标（成交）金额"),
    ("西安双控", "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202607/t20260731_27051407.htm",
     "中标（成交）金额"),
    ("宜兴GEP", "https://www.yixing.gov.cn/doc/2025/11/20/1366608.shtml",
     "中标金额"),
    ("盛京银行", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251114_25699821.htm",
     "中标"),
]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for label, url, needle in TARGETS:
        print("=" * 114)
        print(f"### {label}\n### {url}")
        html = ""
        res = fetcher.fetch(url)
        if res.ok and res.html:
            html = res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html
        if not html:
            print("!! 抓取失败\n")
            continue

        # 找包含关键词的 <table>，把其中所有 <tr> 逐行打出来（保留单元格边界）
        for table in re.findall(r"<table.*?</table>", html, flags=re.S | re.I):
            if needle not in table:
                continue
            for tr in re.findall(r"<tr.*?</tr>", table, flags=re.S | re.I):
                cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", tr, flags=re.S | re.I)
                vals = []
                for cell in cells:
                    txt = re.sub(r"<[^>]+>", " ", cell)
                    txt = re.sub(r"\s+", " ", txt).strip()
                    vals.append(txt)
                if not any(vals):
                    continue
                print("  TR:", " | ".join(vals)[:400])
            break
        print("", flush=True)

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
