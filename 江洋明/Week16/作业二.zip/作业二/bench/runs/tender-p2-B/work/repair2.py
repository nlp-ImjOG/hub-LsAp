"""把「金额缺失」或「金额原文没带单位」的记录的原文行打出来，供人工核对。

判定可疑：amount_yuan is None，或 amount_raw 里没有 亿/万/千/百/%/折
（后者说明单位是从表头提示推出来的，正是最容易读错的那一档）。
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_news import extract_body  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

LABELS = (
    "中标", "成交", "金额", "报价", "单价", "总价", "预算", "控制价",
    "最高限价", "价格", "供应商", "候选人",
)
AMOUNT_LINE_RE = re.compile(r"(?:\d[\d,，]*(?:\.\d+)?)\s*(?:亿元|万元|元|%|％|折)")


def load_records() -> list[dict]:
    records: list[dict] = []
    for name in ("records.json", "records2.json"):
        path = ROOT / name
        if path.is_file():
            records.extend(json.loads(path.read_text(encoding="utf-8")))
    return records


def main() -> int:
    records = load_records()
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    flagged = []
    for rec in records:
        amount = rec["amount_yuan"]
        raw = rec["amount_raw"] or ""
        if amount is None or not re.search(r"[亿万千百%％折]", raw):
            flagged.append(rec)

    print(f"共 {len(records)} 条，其中需核对 {len(flagged)} 条\n")
    for rec in flagged:
        print("=" * 112)
        print(f"[{rec['url']}]")
        print(f"标题: {rec['title']}")
        print(
            f"当前: amount={rec['amount_yuan']} raw={rec['amount_raw']!r} "
            f"winner={rec['winner']!r} date={rec['published']} src={rec['extra'].get('parse_source')}"
        )
        result = fetcher.fetch(rec["url"])
        html = result.html if (result.ok and result.html) else ""
        if not html:
            from esg_toolkit.fetch import BrowserFetcher

            browser = fetcher._browser
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(rec["url"])
            html = br.html if br else ""
        if not html:
            print("   !! 抓取失败（requests + 浏览器都不行）")
            continue
        body = extract_body(html)
        shown = 0
        for raw_line in body.splitlines():
            line = re.sub(r"\s+", " ", raw_line).strip()
            if not line or len(line) > 220:
                continue
            if not AMOUNT_LINE_RE.search(line):
                continue
            if not any(label in line for label in LABELS):
                continue
            print("   >", line[:200])
            shown += 1
            if shown >= 8:
                break

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
