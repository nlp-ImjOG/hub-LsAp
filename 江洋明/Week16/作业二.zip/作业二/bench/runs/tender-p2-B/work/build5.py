"""最终构建（v5）：把 build2 与 build3 的修正表按 URL 逐字段合并，修掉「后写覆盖先写」的字段丢失。"""

from __future__ import annotations

import json
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
sys.path.insert(0, str(ROOT))

from build2 import CORRECTIONS as BASE_FIX  # noqa: E402
from build3 import CORRECTIONS as V3_FIX  # noqa: E402
from build4 import buyer_classification, term_category  # noqa: E402
from build3 import (  # noqa: E402
    DIRECTION_ALIASES,
    OUT_OF_WINDOW,
    RECORD_FIELDS,
    direction_of,
    evidence_of,
    load_records,
    title_key,
)
from esg_toolkit.aggregate import summarize  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TODAY = date(2026, 11, 27)
SINCE = date(TODAY.year - 2, TODAY.month, 1).isoformat()
UNTIL = TODAY.isoformat()

#: build2 里的两个键写错了（协议 / 路径），build3 已用正确的键替代 —— 这里剔除旧的。
DEAD_KEYS = {
    "https://hjzbcg.com/info-2199054-6.html",
    "https://www.bidding.csg.cn/zbxx/1200449283.jhtml",
}

FIX: dict[str, dict] = {}
for url in set(BASE_FIX) | set(V3_FIX):
    if url in DEAD_KEYS:
        continue
    FIX[url] = {**BASE_FIX.get(url, {}), **V3_FIX.get(url, {})}


def main() -> int:
    # 合并后检查：build2 有、build3 丢掉的字段
    lost = []
    for url, fix in BASE_FIX.items():
        if url in DEAD_KEYS:
            continue
        for key in fix:
            if key not in FIX.get(url, {}):
                lost.append((url, key))
    if lost:
        print("!! 合并后丢失的字段:", lost)

    raw_records = load_records()
    applied: set[str] = set()
    kept: list[TenderRecord] = []

    for item in raw_records:
        url = item["url"]
        if url in OUT_OF_WINDOW:
            continue
        fix = FIX.get(url, {})
        data = dict(item)
        extra = dict(data.get("extra") or {})
        for key, value in fix.items():
            if key in ("evidence", "note"):
                extra[key] = value
            else:
                data[key] = value
        data["extra"] = extra
        record = TenderRecord(**{k: data.get(k) for k in RECORD_FIELDS})
        record.category = direction_of(record.title, record.category)
        kept.append(record)
        if fix:
            applied.add(url)

    unmatched = set(FIX) - applied
    if unmatched:
        print("!! 以下修正没有匹配到任何记录:")
        for url in sorted(unmatched):
            print("   ", url)

    seen_urls: set[str] = set()
    seen_keys: set[str] = set()
    deduped: list[TenderRecord] = []
    dup_count = 0
    for record in kept:
        url_key = canonical_url(record.url)
        key = f"{title_key(record.title)}|{record.published or ''}"
        if (url_key and url_key in seen_urls) or (key in seen_keys):
            dup_count += 1
            continue
        if url_key:
            seen_urls.add(url_key)
        seen_keys.add(key)
        deduped.append(record)

    in_window = [r for r in deduped if not r.published or SINCE <= r.published <= UNTIL]
    outside = [r for r in deduped if r.published and not (SINCE <= r.published <= UNTIL)]

    stats = summarize(in_window)
    stats["buyers_by_title"] = buyer_classification(in_window)
    for hot in stats["hotspots"]:
        hot["category"] = term_category(hot["term"])

    rows = []
    for record in in_window:
        rows.append({
            "date": record.published or "",
            "title": record.title,
            "url": record.url,
            "buyer": record.buyer or "",
            "winner": record.winner or "",
            "amount_yuan": record.amount_yuan,
            "amount_raw": record.amount_raw or "",
            "direction": record.category or "未分类",
            "province": record.province or "未识别",
            "evidence": evidence_of(record),
            "note": record.extra.get("note", ""),
        })
    rows.sort(key=lambda r: (r["date"] or "9999", r["title"]), reverse=True)

    (ROOT / "records_final.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    (ROOT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"原始 {len(raw_records)} 条；应用修正 {len(applied)} 条；去重 {dup_count} 条；"
          f"入表 {len(in_window)} 条")
    print(f"统计区间：{SINCE} ~ {UNTIL}")
    print(f"有金额 {stats['with_amount']} 条；金额未披露 {stats['amount']['missing']} 条；"
          f"无日期 {stats['undated']} 条")
    for rec in outside:
        print("   [区间外]", rec.published, rec.title)
    amt = stats["amount"]
    print(f"金额合计 {amt['total_yuan']/1e4:.2f} 万元；中位数 {amt['median_yuan']/1e4:.2f} 万元；"
          f"均值 {amt['mean_yuan']/1e4:.2f} 万元；最大 {amt['max_yuan']/1e4:.2f} 万元；"
          f"最小 {amt['min_yuan']/1e4:.2f} 万元")
    print("\n-- 金额分布 --")
    for b in stats["buckets"]:
        print(f"  {b['bucket']:>12s}  {b['count']:>3d} 条  占比 {b['ratio']*100:5.1f}%  "
              f"金额 {b['total_yuan']/1e4:12.2f} 万  金额占比 {b['amount_ratio']*100:5.1f}%")
    print("\n-- 热点方向（标题词频） --")
    for h in stats["hotspots"]:
        print(f"  {h['term']:<14s} {h['count']:>3d} 条  {h['share']*100:5.1f}%  [{h['category']}]")
    print("\n-- 方向分布 --")
    for c in stats["categories"]:
        print(f"  {c['category']:<14s} {c['count']:>3d} 条  {c['total_yuan']/1e4:12.2f} 万")
    print("\n-- 地区 --")
    for r in stats["regions"]:
        print(f"  {r['region']:<8s} {r['count']:>3d} 条  {r['total_yuan']/1e4:12.2f} 万")
    print("\n-- 采购人类型（采购人字段+标题） --")
    for k, v in stats["buyers_by_title"].items():
        print(f"  {k:<20s} {v:>3d} 条")
    print("\n-- 月度走势 --")
    for t in stats["trend"]:
        print(f"  {t['month']}  {t['count']:>3d} 条  {t['total_yuan']/1e4:12.2f} 万")
    print("\n-- 脏字段检查（标题/采购人含模板占位符） --")
    for r in rows:
        if "{{" in r["title"] or "{{" in r["buyer"]:
            print("  !!", r["date"], r["title"], "|", r["url"])
    print("  （以上为空表示没有脏字段）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
