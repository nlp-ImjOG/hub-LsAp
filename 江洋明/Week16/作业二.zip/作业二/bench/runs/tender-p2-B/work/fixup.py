"""以公告页面的「总中标金额 / 总成交金额」行作为权威金额，回填到记录里。

为什么需要这一步：确定性解析器有两种失手——
  1. 多包项目：抓到的是「包1」的报价，不是项目总金额；
  2. 单位单独占一格：``17895567.74`` 后面跟的是表头的「万元」提示，
     实际原文写的是「（元）」，乘 10000 就错了。

本脚本**不重新推断**，只从页面表格里把
``总中标金额 | ￥1789.560000 万元（人民币）`` 这类行原样抠出来，
与记录里的 amount_yuan 比对，差异写入 fixup.json 供人工确认。

用法: python fixup.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402
from esg_toolkit.parse_tender import extract_rows  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TOTAL_LABEL_RE = re.compile(r"总(?:中标|成交|中标（成交）)(?:金额|价)")
NUM_UNIT_RE = re.compile(r"([\d,，]+(?:\.\d+)?)\s*(亿元|万元|千元|元)")
SUPPLIER_STOP = {"附件", "备注", "说明"}


def load_records() -> list[dict]:
    records: list[dict] = []
    for name in ("records.json", "records2.json"):
        path = ROOT / name
        if path.is_file():
            records.extend(json.loads(path.read_text(encoding="utf-8")))
    return records


def to_yuan(number: str, unit: str) -> float | None:
    try:
        value = float(number.replace(",", "").replace("，", ""))
    except ValueError:
        return None
    factor = {"亿元": 1e8, "万元": 1e4, "千元": 1e3, "元": 1.0}[unit]
    return value * factor


def find_total(rows: list[list[str]]) -> tuple[float | None, str | None]:
    """返回 (总金额_元, 原文行)。找不到返回 (None, None)。"""
    for cells in rows:
        if len(cells) < 2:
            continue
        label = cells[0].strip()
        if not TOTAL_LABEL_RE.search(label):
            continue
        for cell in cells[1:]:
            text = cell.strip()
            match = NUM_UNIT_RE.search(text)
            if match:
                return to_yuan(match.group(1), match.group(2)), " | ".join(cells)
    return None, None


def find_package_rows(rows: list[list[str]]) -> list[list[str]]:
    """抓「某供应商 | ... | 报价：N（元） | 分数」这类分包结果行。"""
    out = []
    for cells in rows:
        joined = " | ".join(cells)
        if not re.search(r"报价|投标报价总价|中标价|成交价|总价", joined):
            continue
        if not re.search(r"\d", joined):
            continue
        out.append(cells)
    return out


def main() -> int:
    records = load_records()
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    result_map: dict[str, dict] = {}
    for index, rec in enumerate(records, start=1):
        url = rec["url"]
        html = ""
        fetch_res = fetcher.fetch(url)
        if fetch_res.ok and fetch_res.html:
            html = fetch_res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html

        entry = {"url": url, "title": rec["title"]}
        if not html:
            entry["error"] = "fetch-failed"
            result_map[url] = entry
            print(f"[{index}/{len(records)}] FAIL {url}", flush=True)
            continue

        rows = extract_rows(html)
        total, total_row = find_total(rows)
        entry["page_total"] = total
        entry["page_total_row"] = total_row
        entry["package_rows"] = [" | ".join(c)[:400] for c in find_package_rows(rows)][:12]
        entry["current_amount"] = rec["amount_yuan"]
        entry["current_raw"] = rec["amount_raw"]
        entry["current_winner"] = rec["winner"]
        entry["current_published"] = rec["published"]
        entry["parse_source"] = rec["extra"].get("parse_source")
        result_map[url] = entry

        flag = ""
        if total is not None and rec["amount_yuan"] is not None:
            if abs(total - rec["amount_yuan"]) > max(1.0, total * 0.005):
                flag = "  <<< 差异"
        print(
            f"[{index}/{len(records)}] cur={rec['amount_yuan']} page={total} "
            f"{rec['published']} {rec['title'][:36]}{flag}",
            flush=True,
        )

    out = ROOT / "fixup.json"
    out.write_text(json.dumps(result_map, ensure_ascii=False, indent=2), encoding="utf-8")
    fetcher.close()
    print(f"\n共 {len(records)} 条 -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
