"""比对两条「池州」记录的 URL 原文，定位去重失效原因。"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

for name in ("records.json", "records2.json"):
    for row in json.loads((ROOT / name).read_text(encoding="utf-8")):
        if "chizhou" in row["url"]:
            print(name)
            print("  title =", repr(row["title"]))
            print("  url   =", repr(row["url"]))
            print("  date  =", repr(row["published"]), "amount =", row["amount_yuan"])
            print("  src   =", row["extra"].get("parse_source"))
            print()
