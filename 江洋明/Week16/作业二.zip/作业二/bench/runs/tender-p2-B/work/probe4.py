"""第五轮定点取证：补齐日期 / 中标人 / 金额单位。"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402
from esg_toolkit.parse_tender import extract_rows  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    ("天津津南林业碳汇", "http://ggzy.zwfwb.tj.gov.cn/jyxxcgjg/1670769.jhtml",
     r"中标|成交|金额|报价|元|日期|公告"),
    ("唐山银行", "https://www.12369zb.com/view/880/TbTLw5kBg7S5K-63cRKG.html",
     r"日期|时间|中标|价格|公告|发布"),
    ("盛京银行", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251114_25699821.htm",
     r"中标|成交|金额|公告时间|报价"),
    ("宁波节水", "http://slj.ningbo.gov.cn/col/col1229051307/art/2026/art_2d4a35d587d74fed887db18d015b74e4.html",
     r"中标|成交|金额|日期|发布|年|月"),
    ("宜兴GEP", "https://www.yixing.gov.cn/doc/2025/11/20/1366608.shtml",
     r"中标|成交|金额|日期|发布|年|月"),
    ("中国船舶", "https://csscbidding.com/jyxx/003001/003001004/20250604/98dd0490-a2df-49e7-8705-8aa19f20e3c6.html",
     r"中标|成交|金额|报价|候选人"),
    ("广东工业双碳", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202507/t20250724_25034196.htm",
     r"中标供应商|供应商名称|中标（成交）"),
    ("青海林业碳汇", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202606/t20260627_26828961.htm",
     r"中标|成交|金额|报价"),
    ("西安减污降碳", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202607/t20260702_26861655.htm",
     r"中标供应商|供应商名称|中标（成交）"),
    ("西安双控", "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202607/t20260731_27051407.htm",
     r"中标供应商|供应商名称|中标（成交）"),
]


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for label, url, anchor in TARGETS:
        print("=" * 114)
        print(f"### {label}\n### {url}")
        html = ""
        res = fetcher.fetch(url)
        if res.ok and res.html:
            html = res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html
        if not html:
            print("!! 抓取失败\n")
            continue

        pat = re.compile(anchor)
        shown = 0
        for cells in extract_rows(html):
            joined = " | ".join(cells)
            if not pat.search(joined):
                continue
            print("ROW:", joined[:330])
            shown += 1
            if shown >= 10:
                break

        n = 0
        for line in plain(html):
            if not pat.search(line) or len(line) > 300:
                continue
            print(">", line[:280])
            n += 1
            if n >= 14:
                break
        print("", flush=True)

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
