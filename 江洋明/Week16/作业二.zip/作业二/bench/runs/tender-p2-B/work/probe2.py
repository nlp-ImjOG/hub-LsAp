"""第三轮定点取证：把候选人/中标人/金额所在上下文整段打出来。

用法: python probe2.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

#: (标签, url, 锚点正则)
TARGETS = [
    ("上海双碳试点", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202512/t20251203_25836326.htm",
     r"中标金额|成交金额|报价|单价|金额"),
    ("国家能源", "https://www.chnenergybidding.com.cn/bidweb/001/001005/001005003/20250612/8887b51e-c2dc-42ea-b6f3-306d272e583b.html",
     r"第一中标候选人|第二中标候选人|中标候选人|投标报价"),
    ("青岛卷烟厂", "https://sdgy.tobacco.com.cn/p1/jggs/20261023/61389.html",
     r"成交候选人|响应报价|候选人名称|第一"),
    ("会泽", "https://www.ynzy-tobacco.com/c/2025-06-06/607216.shtml",
     r"中标候选人|投标不含税总价|第一"),
    ("大理", "https://www.ynzy-tobacco.com/c/2025-07-01/608219.shtml",
     r"中标候选人|不含增值税投标报价|第一"),
    ("苏州浦江源", "https://www.wujiang.gov.cn/zgwj/xezbxx/202511/41e7257102bc4d1fa46d06fa623738e5.shtml",
     r"成交单位|成交金额|项目名称|成交日期"),
    ("江西GEP", "https://drc.jiangxi.gov.cn/jxsfzhggwyh/col/col14590/content/content_2063876380782551040.html",
     r"发布时间|日期|中选单位|中选金额|项目名称"),
    ("蚌埠", "https://ggzy.bengbu.gov.cn/jyxxgk/002002/002002009/002002009001/20251029/a5a9f814-f5d8-46d5-a82e-34ad25e1ca13.html",
     r"成交供应商|中标|成交|金额|项目名称"),
    ("重汽绿厂", "http://www.ygcgfw.com/gggs/001001/001001004/20250427/e5fdc026-5151-4006-9c47-0c72a1ea7bc7.html",
     r"成交金额|成交供应商"),
    ("宿州", "https://ggzyjy.ahsz.gov.cn/jyxx/001002/001002004/001002004001/20261110/0504a4c0-2338-4413-aed9-9bf326cf4507.html",
     r"成交|金额|供应商|收费"),
]


def plain(html: str) -> str:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    lines = [re.sub(r"[ \t　]+", " ", ln).strip() for ln in text.split("\n")]
    return "\n".join(ln for ln in lines if ln)


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for label, url, anchor in TARGETS:
        print("=" * 116)
        print(f"### {label}\n### {url}")
        html = ""
        res = fetcher.fetch(url)
        if res.ok and res.html:
            html = res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html
        if not html:
            print("!! 抓取失败\n")
            continue

        text = plain(html)
        lines = text.split("\n")
        hit = False
        for i, line in enumerate(lines):
            if not re.search(anchor, line):
                continue
            window = " / ".join(x for x in lines[max(0, i - 6) : i + 8] if x)
            print("CTX:", window[:700])
            hit = True
            if hit and sum(1 for _ in ()) == 0:
                break
        print("", flush=True)

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
