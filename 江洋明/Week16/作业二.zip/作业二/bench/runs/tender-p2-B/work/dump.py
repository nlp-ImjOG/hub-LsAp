"""把全部记录导成紧凑清单，用于人工核对与后续写 corrections.json。"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def main() -> int:
    records: list[dict] = []
    for name in ("records.json", "records2.json"):
        path = ROOT / name
        if path.is_file():
            records.extend(json.loads(path.read_text(encoding="utf-8")))
    for i, r in enumerate(records, start=1):
        amount = r["amount_yuan"]
        amount_s = "—" if amount is None else f"{amount/1e4:.2f}万"
        print(
            f"{i:3d}\t{amount_s:>12s}\t{(r['published'] or '—'):10s}\t"
            f"{(r['province'] or '—'):6s}\t{(r['category'] or '—'):10s}\t"
            f"{r['title'][:40]:42s}\t{r['url']}"
        )
    print(f"\n共 {len(records)} 条")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
