"""最终构建：应用人工核对结果 → 去重 → 统计 → 导出报告所需数据。

人工核对的证据阶梯（从强到弱）：
  1. 公告页面的「总中标金额 / 总成交金额」行 —— 项目级权威金额，多包项目取总额；
  2. 公告正文表里的分标段金额 —— 多包项目交叉验证总额；
  3. 检索摘要 —— 页面已下线或 JS 渲染取不到正文时的 Tier C 证据。

统计区间沿用 Skill 脚本层口径：``date(today.year - 2, today.month, 1)`` ~ today。
"""

from __future__ import annotations

import json
import re
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import summarize  # noqa: E402
from esg_toolkit.keywords import classify_category  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TODAY = date(2026, 11, 27)
SINCE = date(TODAY.year - 2, TODAY.month, 1).isoformat()
UNTIL = TODAY.isoformat()

#: TenderRecord 的构造字段
RECORD_FIELDS = (
    "title", "url", "buyer", "winner", "amount_yuan", "amount_raw",
    "published", "package", "province", "category", "extra",
)

#: URL -> 修正字段。字段含义与 TenderRecord 一致。
CORRECTIONS: dict[str, dict] = {
    # ---------------- 金额口径：改用公告「总中标/成交金额」 ----------------
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202512/t20251204_25848874.htm": {
        "amount_yuan": 2910400, "amount_raw": "291.04万元（公告「总中标金额」）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202507/t20250731_25076755.htm": {
        "amount_yuan": 2928000,
        "amount_raw": "包1 648000＋包2 812000＋包3 788000＋包4 680000（元）＝292.80万元",
        "winner": "中环联合(北京)认证中心有限公司（包1）、河北省生态环境保护技术服务中心（包2）、"
                  "河北晶淼中恒绿色科技有限公司（包3）、河北环境能源交易所有限责任公司（包4）"},
    "https://ccgp-hebei.gov.cn/province/cggg/zhbgg/202507/t20250725_2230291.html": {
        "amount_yuan": 2516000,
        "amount_raw": "包5 480000＋包6 668000＋包7 550000＋包8 818000（元）",
        "winner": "中国大唐集团绿色低碳发展有限公司（包5）、生态环境部环境规划院（包6）、"
                  "河北省生态环境保护技术服务中心（包7）、北京中创碳投科技有限公司（包8）",
        "title": "碳资产价值实现机制建设工作（包5-包8）"},
    "https://ccgp-hebei.gov.cn/hd/hd_jz/cggg/zhbggAAAA/202504/t20250407_2170218.html": {
        "amount_yuan": 998000, "amount_raw": "998000元", "winner": "河钢数字技术股份有限公司"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202412/t20241210_23840419.htm": {
        "amount_yuan": 17895567.74,
        "amount_raw": "包1 17666567.74＋包2 139000＋包3 90000（元）；包4废标",
        "winner": "山西绿源碳索科技有限公司（包1）、山西同力达建设监理咨询有限公司（包2）、"
                  "山西晋信安科技有限公司（包3）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202507/t20250724_25034196.htm": {
        "amount_yuan": 3908000,
        "amount_raw": "包1 800000＋包2 790000＋包3 750000＋包4 780000＋包5 788000（元）＝390.80万元",
        "winner": "广州赛宝认证中心服务有限公司、中国质量认证中心有限公司、广州绿石碳科技股份有限公司、"
                  "广东省清洁生产协会、广东省循环经济和资源综合利用协会"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202512/t20251203_25836326.htm": {
        "amount_yuan": 4876000,
        "amount_raw": "正文「中标（成交金额）」4,876,000.00元（公告概要「总中标金额」栏显示 0，以正文为准）",
        "winner": "上海东方延华节能技术服务股份有限公司"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202509/t20250924_25409068.htm": {
        "amount_yuan": 1301700, "amount_raw": "130.17万元（公告「总中标金额」）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202607/t20260731_27051407.htm": {
        "amount_yuan": 590600,
        "amount_raw": "包1 297800＋包2 292800（元）＝59.06万元",
        "winner": "西安元拓迈理工程咨询有限公司（包1）、北京瓴碳智通科技有限公司（包2）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202607/t20260702_26861655.htm": {
        "amount_yuan": 2968000,
        "amount_raw": "包1 1188000＋包2 1200000＋包3 580000（元）＝296.80万元",
        "winner": "中节能咨询有限公司、中国启源工程设计研究院有限公司、中国科学院地球环境研究所"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202604/t20260422_26438642.htm": {
        "amount_yuan": 2622400, "amount_raw": "262.24万元（公告「总中标金额」）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202606/t20260627_26828961.htm": {
        "amount_yuan": 954700,
        "amount_raw": "95.47万元（包1 214700＋包2 390000＋包3 350000 元）",
        "winner": "国家林业和草原局林草调查规划院、中环联合（北京）认证中心有限公司、"
                  "广州赛宝认证中心服务有限公司"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202610/t20261015_27500850.htm": {
        "amount_yuan": 4490900, "amount_raw": "449.09万元（公告「总中标金额」）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202412/t20241214_23872833.htm": {
        "amount_yuan": 2431600, "amount_raw": "243.16万元（公告「总中标金额」）"},

    # ---------------- 表格结构特殊，人工读原文补齐 ----------------
    "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202507/t20250716_24976997.htm": {
        "amount_yuan": 508000, "amount_raw": "总成交金额 50.80万元",
        "winner": "创兆能建筑科技有限公司"},
    "https://cgjy.tobacco.com.cn/jgfwzbb/58239.jhtml": {
        "amount_yuan": 1000000, "amount_raw": "投标总报价(不含税) 1,000,000.00元",
        "winner": "杭州万泰认证有限公司",
        "title": "四川中烟工业有限责任公司2026-2028年碳达峰碳中和工作咨询项目（第二次）中标结果公告"},
    "https://csscbidding.com/jyxx/003001/003001004/20250604/98dd0490-a2df-49e7-8705-8aa19f20e3c6.html": {
        "amount_yuan": 363580, "amount_raw": "中标金额：363,580.00元",
        "winner": "船舶信息研究中心（中国船舶集团有限公司第七一四研究所）",
        "title": "中国船舶集团渤海造船有限公司碳达峰碳中和技术咨询中标结果公示"},
    "http://ggzy.zwfwb.tj.gov.cn/jyxxcgjg/1670769.jhtml": {
        "amount_yuan": 1195000, "amount_raw": "中标金额(万元) 119.5",
        "winner": "天津排放权交易所有限公司"},
    "https://ggzy.bengbu.gov.cn/jyxxgk/002002/002002009/002002009001/20251029/"
    "a5a9f814-f5d8-46d5-a82e-34ad25e1ca13.html": {
        "amount_yuan": 360000, "amount_raw": "中标（成交）价 36.0 万元",
        "winner": "漾青环保科技（上海）有限公司",
        "title": "蚌埠市大气污染物与温室气体融合排放清单更新、日用玻璃产品碳足迹核算服务项目",
        "published": "2025-10-29"},
    "https://ggzy.bozhou.gov.cn/jyxx/002002/002002011/20251009/"
    "30bcb56a-d7d0-4cda-81f0-9c4244783ab7.html": {
        "amount_yuan": 200000, "amount_raw": "中标金额（费率/其他）200000元"},
    "https://ggzy.zj.gov.cn/jyxxgk/002002/002002002/20250724/"
    "30be3b8f-6706-4989-9fe6-2387a449996e.html": {
        "amount_yuan": 260000, "amount_raw": "定标/成交结果：浙江农林大学（260000.00元）",
        "winner": "浙江农林大学"},
    "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb": {
        "amount_yuan": 449100, "amount_raw": "成交供应商的评审报价：449100.00元",
        "winner": "深圳市华仁智信技术有限公司",
        "title": "2026年应对气候变化技术服务项目（第二次）成交结果公告",
        "published": "2026-11-05"},
    "https://ggzyjy.ahsz.gov.cn/jyxx/001002/001002004/001002004001/20261110/"
    "0504a4c0-2338-4413-aed9-9bf326cf4507.html": {
        "amount_yuan": 498000, "amount_raw": "中标（成交）金额：肆拾玖万捌仟元整（498000.00元）",
        "winner": "中春环保科技（上海）有限公司"},
    "https://www.cntcitc.com.cn/more.html?chanType=3&contentId=472aead392044802812cf106506b8d6e": {
        "amount_yuan": 398000, "amount_raw": "中标金额：39.80万元",
        "winner": "盟浪可持续数字科技（深圳）有限责任公司",
        "published": "2025-02-26"},
    "https://www.cfet.com.cn/cms/default/webfile/2ywgg5/20260322/1220170026951114752.html": {
        "amount_yuan": 400000, "amount_raw": "中标价格：400,000.00元",
        "winner": "联合赤道环境评价股份有限公司"},
    "https://www.wujiang.gov.cn/zgwj/xezbxx/202511/41e7257102bc4d1fa46d06fa623738e5.shtml": {
        "amount_yuan": 176000, "amount_raw": "成交金额：人民币壹拾柒万陆仟元整（¥176000.00元）",
        "winner": "苏州尚若节能环保咨询有限公司",
        "published": "2025-11-11"},
    "https://www.ynzy-tobacco.com/c/2025-06-06/607216.shtml": {
        "amount_yuan": 690000,
        "amount_raw": "一标段 392000.00元＋二标段 298000.00元（投标不含税总价）",
        "winner": "中国检验认证集团云南有限公司（一标段）、广州能源检测研究院（二标段）"},
    "https://www.ynzy-tobacco.com/c/2025-07-01/608219.shtml": {
        "amount_yuan": 89622.64, "amount_raw": "不含增值税投标报价（元）：¥89622.64",
        "winner": "中国检验认证集团云南有限公司"},
    "https://ggzyjy.sc.gov.cn/jyxx/002007/002007001/20250522/"
    "598134b2-dcb2-4d04-9f7d-ba38f6e40687.html": {
        "amount_yuan": 136500,
        "amount_raw": "第一中标候选人 含税 144,690.00元（税率6%）／不含税 136,500.00元",
        "winner": "中标合信（北京）认证有限公司"},
    "https://sdgy.tobacco.com.cn/p1/jggs/20261023/61389.html": {
        "amount_yuan": 19811.32,
        "amount_raw": "第一成交候选人 响应报价：不含税 19811.32元，含税 21000.00元（税率6%）",
        "winner": "北京和碳环境技术有限公司",
        "title": "山东中烟工业有限责任公司青岛卷烟厂绿色供应链诊断项目成交候选人公示",
        "published": "2026-10-23"},
    "https://www.chnenergybidding.com.cn/bidweb/001/001005/001005003/20250612/"
    "8887b51e-c2dc-42ea-b6f3-306d272e583b.html": {
        "amount_yuan": 8510000, "amount_raw": "第一中标候选人 投标报价（人民币万元）851.000000",
        "winner": "中国信息通信研究院"},
    "https://hnsggzyjy.henan.gov.cn/jyxx/002002/002002003/20241218/"
    "6ebfda5b-4029-48e5-a261-e5c3ff56f96f.html": {
        "amount_yuan": 4991527, "amount_raw": "中标金额 4,991,527.00 元",
        "winner": "河南双碳实业有限公司"},
    "http://wgxj.yueyang.gov.cn/cxjs/zbtb/5947/content_2257743.html": {
        "amount_yuan": 17971200, "amount_raw": "成交金额 17,971,200.00",
        "winner": "湖南展亿能源工程有限公司",
        "buyer": "平江县第一人民医院"},
    "https://ccgp-hebei.gov.cn/sjz/sjz_jjjskfq/cggg/zhbggAAAA/202501/t20250106_2130173.html": {
        "amount_yuan": 779000, "amount_raw": "779000元",
        "winner": "碳为科技（河北）有限公司"},
    "https://ccgp-hebei.gov.cn/cd/cd/cggg/zhbggAAAS/202506/t20250620_2208852.html": {
        "amount_yuan": 8216153.84,
        "amount_raw": "A包 4156153.84＋B包 4060000（元）",
        "winner": "河北农业大学（A包）、中国科学院西北生态环境资源研究院（B包）"},
    "http://slj.ningbo.gov.cn/col/col1229051307/art/2026/art_2d4a35d587d74fed887db18d015b74e4.html": {
        "amount_yuan": 395000, "amount_raw": "中标金额：395000元",
        "winner": "水利部节约用水促进中心", "published": "2026-09-22"},
    "https://www.yixing.gov.cn/doc/2025/11/20/1366608.shtml": {
        "amount_yuan": 472000, "amount_raw": "中标金额 472000.00",
        "winner": "南京大学环境规划研究院集团股份公司", "published": "2025-11-20"},
    "https://ygcg.gzggzy.cn/qt/381568.jhtml": {
        "amount_yuan": 260000, "amount_raw": "总价包干 ¥260000元",
        "winner": "中诚信绿金科技（北京）有限公司"},
    "https://ggzy.zj.gov.cn/jyxxgk/002002/002002002/20250113/"
    "ee340fb6-e423-40e9-9294-f809157d0684.html": {
        "amount_yuan": 4250000, "amount_raw": "定标/成交结果：杭州一达环保技术咨询服务有限公司（4250000.0元）",
        "winner": "杭州一达环保技术咨询服务有限公司"},
    "https://e.ytport.com:8000/szytggf/zbxx/002003/20260130/"
    "dc1b04c1-eb9f-45c2-b773-3d8340d586c4.html": {
        "amount_yuan": 178000, "amount_raw": "中标价格（元）178000.00",
        "winner": "责任云（北京）控股集团有限公司"},
    "https://www.12369zb.com/view/880/TbTLw5kBg7S5K-63cRKG.html": {
        "amount_yuan": 80000, "amount_raw": "中标价格 8万",
        "winner": "联合赤道环境评价股份有限公司", "published": "2025-10-08",
        "evidence": "检索摘要"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251114_25699821.htm": {
        "amount_yuan": 850000, "amount_raw": "85万元",
        "winner": "联合赤道环境评价股份有限公司", "published": "2025-11-14",
        "evidence": "检索摘要（原页 404）"},

    # ---------------- 页面已下线 / JS 渲染取不到正文：Tier C 检索摘要 ----------------
    "http://www.ccgp-xizang.gov.cn/freecms/site/xizang/xzcggg/info/2025/151064.html": {
        "amount_yuan": 982500, "amount_raw": "98.25万元",
        "winner": "中云汇（成都）科技集团有限公司", "published": "2025-11-27",
        "evidence": "检索摘要（原页 404）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202509/t20250911_25643675.htm": {
        "amount_yuan": 466600, "amount_raw": "46.66万元",
        "winner": "哈尔滨盈源环境建设工程有限公司", "published": "2025-09-10",
        "evidence": "检索摘要（原页 404）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202509/t20250910_25327535.htm": {
        "amount_yuan": 588000, "amount_raw": "58.8万元",
        "winner": "四川山水绿碳科技有限公司", "published": "2025-09-10",
        "evidence": "检索摘要（原页 404）"},
    "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202501/t20250108_24036512.htm": {
        "amount_yuan": 990000, "amount_raw": "99万元",
        "winner": "中国国际工程咨询有限公司", "published": "2025-01-08",
        "evidence": "检索摘要（原页 404）"},
    "http://jsggzy.jszwfw.gov.cn/jyxx/003004/003004006/20250610/"
    "2460607c69404da0af6d464a153e9068.html": {
        "amount_yuan": 680000, "amount_raw": "68万元",
        "winner": "南京大学环境规划设计研究院集团股份公司", "published": "2025-06-10",
        "evidence": "检索摘要（原页取不到正文）"},
    "http://www.cnbiding.com.cn/zbyxx/083098801599.html": {
        "amount_yuan": 368000, "amount_raw": "36.8万元",
        "winner": "内蒙古弘和节能减排科技有限责任公司", "published": "2025-03-25",
        "evidence": "检索摘要（原页取不到正文）"},
    "https://ggzyjy.yantai.gov.cn/jyxx/003002/003002004/20251112/"
    "aea042f2-4cb0-4b05-b4d6-7eb37045ce72.html": {
        "amount_yuan": 2159800, "amount_raw": "215.98万元",
        "winner": "青岛威羽山环保科技有限公司", "published": "2025-11-12",
        "evidence": "检索摘要（原页取不到正文）"},
    "https://fzggw.ah.gov.cn/public/7011/149968421.html": {
        "amount_yuan": 248000, "amount_raw": "24.8万元",
        "winner": "安徽省工程咨询研究院", "published": "2025-04-23",
        "evidence": "检索摘要（原页取不到正文）"},
    "https://www.ahtba.org.cn/site/trade/affiche/detail/a34a4178-e4b9-11f1-b7f6-00163e1f3e9b": {
        "amount_yuan": 192000, "amount_raw": "19.2万元",
        "winner": "盟浪可持续数字科技（深圳）有限责任公司", "published": "2026-11-20",
        "title": "华安证券2027年度ESG评级管理等相关服务项目成交结果公告",
        "evidence": "检索摘要（原页取不到正文）"},
    "https://www.gdebidding.com/cqgzgg/208724.jhtml": {
        "amount_yuan": 338000, "amount_raw": "33.8万元",
        "winner": "责扬天下（北京）管理顾问有限公司",
        "evidence": "检索摘要（原页取不到正文）"},
    "https://www.gdebidding.com/zbxxgg/211553.jhtml": {
        "amount_yuan": 201400, "amount_raw": "20.14万元",
        "winner": "深圳市博奕方略企业管理咨询有限公司",
        "evidence": "检索摘要（原页取不到正文）"},

    # ---------------- 金额确实未披露 ----------------
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202609/t20260905_27274363.htm": {
        "amount_yuan": None, "amount_raw": "",
        "note": "公告概要「总中标金额」显示 ￥0.000000 万元，正文未列示金额 —— 未检索到"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202510/t20251027_25579601.htm": {
        "amount_yuan": None, "amount_raw": "",
        "note": "公告概要「总中标金额」显示 ￥0.000000 万元，正文未列示金额 —— 未检索到"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251111_25672673.htm": {
        "amount_yuan": None, "amount_raw": "",
        "note": "公告概要「总中标金额」显示 ￥0.000000 万元，正文未列示金额 —— 未检索到"},
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202601/t20260123_26110427.htm": {
        "amount_yuan": None, "amount_raw": "",
        "note": "公告概要「总中标金额」显示 ￥0.000000 万元，正文未列示金额 —— 未检索到"},
    "http://www.szxc.gov.cn/szxcrmzf/ztbgg/202511/0ffe15baf855409eb4de193debdb6e97.shtml": {
        "amount_yuan": None, "amount_raw": "",
        "winner": "江苏秋洋智慧科技集团有限公司",
        "note": "公告只披露预算金额 24,688,561.11 元（节能电费收益暂估值），未披露中标金额 —— 未检索到"},
    "https://www.bidding.csg.cn/zbxx/1200449283.jhtml": {
        "amount_yuan": None, "amount_raw": "",
        "winner": "众源科技（广东）股份有限公司",
        "note": "中标结果页只给了中标人，金额需下载中标通知书 —— 未检索到"},
    "http://www.ygcgfw.com/gggs/001001/001001004/20250427/"
    "e5fdc026-5151-4006-9c47-0c72a1ea7bc7.html": {
        "amount_yuan": None, "amount_raw": "",
        "winner": "山东正向国际低碳科技有限公司",
        "note": "公示表格「成交金额」列为空 —— 未检索到"},
    "http://www.ygcgfw.com/gggs/001001/001001004/20250710/"
    "f18a0af7-489b-499e-993e-a071244dfb39.html": {
        "amount_yuan": None, "amount_raw": "",
        "winner": "山东正向国际低碳科技有限公司",
        "note": "公示表格「成交金额」列为空 —— 未检索到"},

    # ---------------- 标题修正 ----------------
    "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202611/t20261106_27635357.htm": {
        "title": "锡东新城先导区低碳园区、超低能耗建筑、高品质建筑工程建设项目ESG评价技术服务"},
    "https://hjzbcg.com/info-2199054-6.html": {
        "title": "绍兴市生态环境局“无废供应链”建设试点项目（重招）"},
}

#: 统计区间外的记录（发布日期早于 since），直接剔除
OUT_OF_WINDOW = {
    "https://jxszwsjb.jiaxing.gov.cn/art/2023/8/15/art_1229744035_399740.html",
}


def load_records() -> list[dict]:
    records: list[dict] = []
    for name in ("records.json", "records2.json"):
        path = ROOT / name
        if path.is_file():
            records.extend(json.loads(path.read_text(encoding="utf-8")))
    return records


def title_key(title: str) -> str:
    return re.sub(r"[\s\-—_·、,，.。:：;；!！?？（）()【】\[\]“”\"'’‘]+", "", title or "")


def direction_of(title: str, fallback: str | None) -> str:
    """方向列按标题判定（与热点统计同口径）；标题判不出时退回解析器的分类。"""
    from_title = classify_category(title or "")
    if from_title:
        return from_title
    return fallback or "未分类"


def evidence_of(record: TenderRecord) -> str:
    explicit = record.extra.get("evidence")
    if explicit:
        return explicit
    source = record.extra.get("parse_source", "")
    if source == "page":
        return "公告页面"
    if source == "page+snippet":
        return "公告页面+检索摘要"
    if source == "snippet":
        return "检索摘要"
    return "公告页面"


def main() -> int:
    raw_records = load_records()
    applied: set[str] = set()
    kept: list[TenderRecord] = []
    dropped_out_of_window = 0

    for item in raw_records:
        url = item["url"]
        if url in OUT_OF_WINDOW:
            dropped_out_of_window += 1
            continue
        fix = CORRECTIONS.get(url, {})
        data = dict(item)
        extra = dict(data.get("extra") or {})
        for key, value in fix.items():
            if key in ("evidence", "note"):
                extra[key] = value
            else:
                data[key] = value
        data["extra"] = extra
        record = TenderRecord(**{k: data.get(k) for k in RECORD_FIELDS})
        record.category = direction_of(record.title, record.category)
        kept.append(record)
        if fix:
            applied.add(url)

    unmatched = set(CORRECTIONS) - applied
    if unmatched:
        print("!! 以下修正没有匹配到任何记录（URL 可能已变）:")
        for url in sorted(unmatched):
            print("   ", url)

    # 去重：规范化 URL 优先，其次「归一化标题 + 日期」
    seen_urls: set[str] = set()
    seen_keys: set[str] = set()
    deduped: list[TenderRecord] = []
    dup_count = 0
    for record in kept:
        url_key = canonical_url(record.url)
        key = f"{title_key(record.title)}|{record.published or ''}"
        if (url_key and url_key in seen_urls) or (key in seen_keys):
            dup_count += 1
            continue
        if url_key:
            seen_urls.add(url_key)
        seen_keys.add(key)
        deduped.append(record)

    # 统计区间过滤：无日期的记录无法证明落在区间内，单独留档披露
    in_window = [r for r in deduped if not r.published or SINCE <= r.published <= UNTIL]
    outside = [r for r in deduped if r.published and not (SINCE <= r.published <= UNTIL)]

    stats = summarize(in_window)

    rows = []
    for record in in_window:
        rows.append({
            "date": record.published or "",
            "title": record.title,
            "url": record.url,
            "buyer": record.buyer or "",
            "winner": record.winner or "",
            "amount_yuan": record.amount_yuan,
            "amount_raw": record.amount_raw or "",
            "direction": record.category or "未分类",
            "province": record.province or "未识别",
            "evidence": evidence_of(record),
            "note": record.extra.get("note", ""),
        })
    rows.sort(key=lambda r: (r["date"] or "9999", r["title"]), reverse=True)

    (ROOT / "records_final.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    (ROOT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"原始 {len(raw_records)} 条；应用修正 {len(applied)} 条；"
          f"区间外剔除 {dropped_out_of_window} 条；去重 {dup_count} 条；入表 {len(in_window)} 条")
    print(f"统计区间：{SINCE} ~ {UNTIL}")
    print(f"有金额 {stats['with_amount']} 条；金额未披露 {stats['amount']['missing']} 条；"
          f"无日期 {stats['undated']} 条")
    for rec in outside:
        print("   [区间外]", rec.published, rec.title)
    amt = stats["amount"]
    print(f"金额合计 {amt['total_yuan']/1e4:.2f} 万元；中位数 {amt['median_yuan']/1e4:.2f} 万元；"
          f"均值 {amt['mean_yuan']/1e4:.2f} 万元；最大 {amt['max_yuan']/1e4:.2f} 万元")
    print("\n-- 金额分布 --")
    for b in stats["buckets"]:
        print(f"  {b['bucket']:>12s}  {b['count']:>3d} 条  占比 {b['ratio']*100:5.1f}%  "
              f"金额 {b['total_yuan']/1e4:12.2f} 万  金额占比 {b['amount_ratio']*100:5.1f}%")
    print("\n-- 热点方向 --")
    for h in stats["hotspots"]:
        print(f"  {h['term']:<14s} {h['count']:>3d} 条  {h['share']*100:5.1f}%  [{h['category']}]")
    print("\n-- 方向分布 --")
    for c in stats["categories"]:
        print(f"  {c['category']:<14s} {c['count']:>3d} 条  {c['total_yuan']/1e4:12.2f} 万")
    print("\n-- 地区 Top12 --")
    for r in stats["regions"][:12]:
        print(f"  {r['region']:<8s} {r['count']:>3d} 条  {r['total_yuan']/1e4:12.2f} 万")
    print("\n-- 采购人类型 --")
    for k, v in stats["buyers"].items():
        print(f"  {k:<20s} {v:>3d} 条")
    print("\n-- 月度走势 --")
    for t in stats["trend"]:
        print(f"  {t['month']}  {t['count']:>3d} 条  {t['total_yuan']/1e4:12.2f} 万")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
