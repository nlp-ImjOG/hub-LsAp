"""第八轮：核对 4 条 amount=0 的记录（到底是「0 元」还是解析没抓到）。

用法: python probe7.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402
from esg_toolkit.parse_tender import extract_rows  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    ("安徽碳市场", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202609/t20260905_27274363.htm"),
    ("武汉江夏绿园", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202510/t20251027_25579601.htm"),
    ("大冶金牛河", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251111_25672673.htm"),
    ("武穴合同节水", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202601/t20260123_26110427.htm"),
]

PAT = re.compile(r"中标|成交|金额|报价|总价|单价|价格")


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for label, url in TARGETS:
        print("=" * 112)
        print(f"### {label}\n### {url}")
        html = ""
        res = fetcher.fetch(url)
        if res.ok and res.html:
            html = res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html
        if not html:
            print("!! 抓取失败\n")
            continue
        shown = 0
        for cells in extract_rows(html):
            joined = " | ".join(cells)
            if not PAT.search(joined) or not re.search(r"\d", joined):
                continue
            print("  ROW:", joined[:300])
            shown += 1
            if shown >= 10:
                break
        if not shown:
            print("  (无相关表格行)")
        print("", flush=True)

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
