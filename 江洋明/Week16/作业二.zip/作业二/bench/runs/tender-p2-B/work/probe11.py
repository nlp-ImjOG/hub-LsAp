"""第十二轮：对剩余 10 个「页面取不到」的公告，用真实浏览器 + 更长等待时间再试一次。

这些页面多为 JS 渲染的公共资源交易平台 SPA，之前 requests 与短等待的浏览器都只拿到骨架。
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    ("池州", "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb"),
    ("宿州", "https://ggzyjy.ahsz.gov.cn/jyxx/001002/001002004/001002004001/20261110/0504a4c0-2338-4413-aed9-9bf326cf4507.html"),
    ("光大银行", "https://www.cntcitc.com.cn/more.html?chanType=3&contentId=472aead392044802812cf106506b8d6e"),
    ("南方电网", "https://www.bidding.csg.cn/zbxx/1200449283.jhtml"),
    ("昌都", "http://www.ccgp-xizang.gov.cn/freecms/site/xizang/xzcggg/info/2025/151064.html"),
    ("色达", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202509/t20250910_25327535.htm"),
    ("自治州", "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202501/t20250108_24036512.htm"),
    ("哈尔滨呼兰", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202509/t20250911_25643675.htm"),
    ("安徽GEP", "https://fzggw.ah.gov.cn/public/7011/149968421.html"),
    ("农发行", "https://www.cfet.com.cn/cms/default/webfile/2ywgg5/20260322/1220170026951114752.html"),
]

PAT = re.compile(r"\d[\d,，]*(?:\.\d+)?\s*(?:亿元|万元|元)|中标|成交|供应商|公示时间|发布日期|公告时间")


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)

    for label, url in TARGETS:
        print("=" * 112)
        print(f"### {label}\n### {url}")
        res = browser.fetch(url)
        html = res.html if res and res.html else ""
        if not html:
            print("!! 浏览器抓取失败\n")
            continue
        n = 0
        for line in plain(html):
            if len(line) > 280 or not PAT.search(line):
                continue
            print("  >", line[:260])
            n += 1
            if n >= 18:
                break
        if not n:
            print("  (无匹配行)")
        print("", flush=True)

    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
