"""核对两条「页面+摘要」证据的记录。"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

for name in ("records.json", "records2.json"):
    for row in json.loads((ROOT / name).read_text(encoding="utf-8")):
        if row["extra"].get("parse_source") == "page+snippet":
            print(name, json.dumps(row, ensure_ascii=False, indent=2))
