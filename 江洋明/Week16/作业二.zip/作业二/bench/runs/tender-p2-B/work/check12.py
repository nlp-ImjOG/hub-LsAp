"""取哈尔滨华能项目的中标候选人名称（页面表格）。"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

URL = "https://hrbggzy.harbin.gov.cn/zbgs/20241120/4f53964a-897f-42d8-863d-21147d659cd0.html"


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)
    res = browser.fetch(URL)
    html = res.html if res and res.html else ""
    if not html:
        print("!! 抓取失败")
        return 1
    for m in re.finditer(r"预中标金额|中标候选人为|投标报价|单位名称", html):
        chunk = re.sub(r"\s+", " ", html[max(0, m.start() - 1500): m.end() + 400])
        chunk = re.sub(r"<[^>]+>", " ", chunk)
        print("  RAW:", re.sub(r"\s+", " ", chunk).strip()[:1200])
        print("  ---")
    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
