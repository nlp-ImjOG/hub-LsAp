"""把证据级别回写进 records_final.json，并重建 5.2 第 3 条的两个清单。"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORT = ROOT.parent / "report.md"
sys.path.insert(0, str(ROOT))

import build6  # noqa: E402
from build3 import evidence_of  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

FIX = build6.build5.FIX
PAGE_VERIFIED = {url for url, fix in FIX.items() if "evidence" not in fix}

rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))
for row in rows:
    if row["url"] in PAGE_VERIFIED:
        row["evidence"] = "公告页面"
    else:
        row["evidence"] = evidence_of(
            type("R", (), {"extra": {"evidence": row["evidence"]}, "url": row["url"]})())

(ROOT / "records_final.json").write_text(
    json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")

snippet = [r for r in rows if r["evidence"].startswith("检索摘要")]
dead = [r for r in snippet if "404" in r["evidence"] or "均取不到" in r["evidence"]]
alive = [r for r in snippet if r not in dead]
print(f"证据级别：页面 {sum(1 for r in rows if r['evidence']=='公告页面')}，"
      f"页面+摘要 {sum(1 for r in rows if r['evidence']=='公告页面+检索摘要')}，"
      f"摘要 {len(snippet)}")


def item(r: dict) -> str:
    return f"  - {r['date']} [{r['title']}]({r['url']})"


block = (
    f"3. **{len(snippet)} 条只能依据检索摘要**，原页面已下线或本次取不到正文。这批条目的金额可信度\n"
    f"   低于页面级证据，已单独标注证据级别，建议下单前复核。**链接已失效**的有：\n\n"
    + "\n".join(item(r) for r in dead)
    + "\n\n   其余**链接未必失效、但本次未取到正文**的条目（JS 渲染站点、证书错误、robots 拦截等）：\n\n"
    + "\n".join(item(r) for r in alive)
    + "\n"
)

text = REPORT.read_text(encoding="utf-8")
start = text.index("3. **")
end = text.index("\n4. **合同能源管理")
text = text[:start] + block + text[end:]
REPORT.write_text(text, encoding="utf-8")
print(f"已重建 5.2 第 3 条：失效链接 {len(dead)} 条，其余 {len(alive)} 条")
