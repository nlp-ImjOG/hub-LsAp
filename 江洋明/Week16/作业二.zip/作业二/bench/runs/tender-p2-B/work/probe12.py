"""第十三轮：把 3 个「数字被拆到别的标签里」的锚点周围原始 HTML 打出来。"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    ("池州", "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb",
     r"评审报价"),
    ("光大银行", "https://www.cntcitc.com.cn/more.html?chanType=3&contentId=472aead392044802812cf106506b8d6e",
     r"中标金额|公示时间|公告时间|发布"),
    ("农发行", "https://www.cfet.com.cn/cms/default/webfile/2ywgg5/20260322/1220170026951114752.html",
     r"中标价格|中标金额"),
]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)

    for label, url, anchor in TARGETS:
        print("=" * 112)
        print(f"### {label}\n### {url}")
        res = browser.fetch(url)
        html = res.html if res and res.html else ""
        if not html:
            print("!! 浏览器抓取失败\n")
            continue
        for m in re.finditer(anchor, html):
            lo = max(0, m.start() - 700)
            hi = min(len(html), m.end() + 700)
            chunk = re.sub(r"\s+", " ", html[lo:hi])
            print("  RAW:", chunk[:1400])
            print("  ---")
        print("", flush=True)

    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
