"""逐格审计：把含金额数字的表格行按单元格打出来，判定单位。

目的：确定性解析器在「单位单独占一格」的表里可能把 17895567.74（元）
按表头提示的「万元」乘了 10000。这里把每个候选行原样拆开，
人眼确认「哪个数字配哪个单位」，据此写 corrections.json。
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402
from esg_toolkit.parse_tender import extract_rows  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

DIGIT_RE = re.compile(r"\d[\d,，]*(?:\.\d+)?")


def load_records() -> list[dict]:
    records: list[dict] = []
    for name in ("records.json", "records2.json"):
        path = ROOT / name
        if path.is_file():
            records.extend(json.loads(path.read_text(encoding="utf-8")))
    return records


def main() -> int:
    records = load_records()
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for rec in records:
        raw = rec["amount_raw"] or ""
        digits = DIGIT_RE.findall(raw)
        probe = digits[0] if digits else ""
        if not probe:
            continue
        # 只审计「原文带单位」但归一后可疑，或「原文不带单位」的记录
        if re.search(r"[亿万千百%％折]", raw) and rec["amount_yuan"] is not None:
            continue

        print("=" * 112)
        print(f"[{rec['url']}]")
        print(f"标题: {rec['title']}")
        print(f"当前: amount={rec['amount_yuan']} raw={raw!r} winner={rec['winner']!r} date={rec['published']}")

        result = fetcher.fetch(rec["url"])
        html = result.html if (result.ok and result.html) else ""
        if not html:
            browser = fetcher._browser
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(rec["url"])
            html = br.html if br else ""
        if not html:
            print("   !! 抓取失败")
            continue

        rows = extract_rows(html)
        shown = 0
        for cells in rows:
            joined = " | ".join(cells)
            if not DIGIT_RE.search(joined):
                continue
            if not re.search(
                r"中标|成交|金额|报价|总价|单价|价格|控制价|限价|候选|供应商|包|标的|预算",
                joined,
            ):
                continue
            print("   ROW:", joined[:300])
            shown += 1
            if shown >= 10:
                break
        if not shown:
            print("   (无相关表格行)")

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
