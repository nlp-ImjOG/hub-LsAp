"""最终构建（v3）：补齐剩余证据 → 去重 → 统计 → 导出报告所需数据。

相对 build2.py 的增量：
  * 修正两条 URL 键（http://hjzbcg.com/…、https://www.bidding.csg.cn/zbgg/…）；
  * 补 4 条新证据（江西 GEP、洛阳师范学院合同节水、枣庄银行、池州采购人）；
  * 洛阳师范学院合同节水金额由检索摘要的 274 万更正为公告正文的 72,740,000.00 元；
  * 「方向」列增加补充别名表（只作 fallback，不覆盖 keyword-matrix 的判定）；
  * 采购人类型改为按「采购人字段 + 公告标题」匹配 Skill 的采购人规则表。
"""

from __future__ import annotations

import json
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
sys.path.insert(0, str(ROOT))

from build2 import (  # noqa: E402
    CORRECTIONS as BASE_CORRECTIONS,
    OUT_OF_WINDOW,
    RECORD_FIELDS,
    load_records,
    title_key,
)
from esg_toolkit.aggregate import (  # noqa: E402
    BUYER_RULES,
    extract_directions,
    summarize,
)
from esg_toolkit.keywords import classify_category  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TODAY = date(2026, 11, 27)
SINCE = date(TODAY.year - 2, TODAY.month, 1).isoformat()
UNTIL = TODAY.isoformat()

#: 标题里没命中 keyword-matrix 词表、但方向明确的补充别名。
#: 只在矩阵判定落空（或只命中「其他方向」）时生效，不覆盖矩阵结论。
DIRECTION_ALIASES: list[tuple[str, str]] = [
    ("合同能源管理", "绿色低碳与节能"),
    ("合同节水管理", "水与资源"),
    ("减污降碳", "绿色低碳与节能"),
    ("节能改造", "绿色低碳与节能"),
    ("节能服务", "绿色低碳与节能"),
    ("绿色低碳", "绿色低碳与节能"),
    ("碳排放", "双碳与碳中和"),
    ("碳市场", "双碳与碳中和"),
    ("碳预算", "双碳与碳中和"),
    ("气候变化", "双碳与碳中和"),
    ("碳汇", "碳足迹与核算"),
    ("碳资产", "生态产品价值GEP"),
    ("无废供应链", "供应链与责任"),
    ("供应链", "供应链与责任"),
    ("综合治理", "环境与生态治理"),
    ("生态修复", "环境与生态治理"),
    ("水质提升", "环境与生态治理"),
    ("污染管控", "环境与生态治理"),
    ("污染修复", "环境与生态治理"),
    ("生态产品", "生态产品价值GEP"),
    ("绿色金融", "绿色金融"),
    ("绿色债券", "绿色金融"),
    ("ESG报告", "ESG披露与鉴证"),
    ("ESG评价", "ESG评价"),
    ("ESG评估", "ESG评价"),
]

EXTRA_CORRECTIONS: dict[str, dict] = {
    # ---- 修正 URL 键（build2 里写错了协议/路径）----
    "http://hjzbcg.com/info-2199054-6.html": {
        "title": "绍兴市生态环境局“无废供应链”建设试点项目（重招）中标公告",
        "buyer": "绍兴市生态环境局（本级）",
        "published": "2026-07-25",
    },
    "https://www.bidding.csg.cn/zbgg/1200449283.jhtml": {
        "amount_yuan": None, "amount_raw": "",
        "buyer": "南方电网供应链科技（广东）有限公司",
        "winner": "众源科技（广东）股份有限公司",
        "note": "中标结果页只公布中标人，金额需下载中标通知书 —— 未检索到",
    },

    # ---- 新证据 ----
    "https://drc.jiangxi.gov.cn/jxsfzhggwyh/col/col14590/content/content_2063876380782551040.html": {
        "title": "江西省发展改革委（江西省数据局）关于江西省2025年度生态产品总值（GEP）核算及分析项目中选结果公告",
        "amount_yuan": 297800, "amount_raw": "中选金额（人民币）：297800.00元",
        "winner": "中科山水（北京）科技信息有限公司",
        "buyer": "江西省发展改革委（江西省数据局）",
        "published": "2026-06-08",
    },
    "https://zfcg.henan.gov.cn/henan/content?infoId=1921749": {
        "amount_yuan": 72740000, "amount_raw": "中标金额 72,740,000.00 元",
        "winner": "重庆金越水务股份有限公司",
        "buyer": "洛阳师范学院",
        "published": "2026-02-06",
        "note": "服务期限（托管期）10年，公告列示的中标金额为服务期合同总额",
    },
    "https://www.zaozhuangbank.com/zzbank/2025-09/12/article_2025091208165779389.html": {
        "amount_yuan": 330000, "amount_raw": "A包 20万元＋B包 13万元",
        "winner": "国泰海通证券、联合赤道环境评价股份有限公司",
        "buyer": "枣庄银行股份有限公司",
        "published": "2025-09-12",
        "evidence": "检索摘要（原页 requests 与浏览器均取不到，日期取自公告 URL 路径）",
    },
    "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb": {
        "buyer": "池州市生态环境局",
    },
}

CORRECTIONS = dict(BASE_CORRECTIONS)
for wrong in ("https://hjzbcg.com/info-2199054-6.html",
              "https://www.bidding.csg.cn/zbxx/1200449283.jhtml"):
    CORRECTIONS.pop(wrong, None)
CORRECTIONS.update(EXTRA_CORRECTIONS)


def direction_of(title: str, fallback: str | None) -> str:
    """方向列：先按 keyword-matrix 判定，判定落空或只命中「其他方向」时用补充别名。"""
    from_matrix = classify_category(title or "")
    if from_matrix and from_matrix != "其他方向":
        return from_matrix
    for alias, category in DIRECTION_ALIASES:
        if alias in (title or ""):
            return category
    if from_matrix:
        return from_matrix
    return fallback or "未分类"


def evidence_of(record: TenderRecord) -> str:
    explicit = record.extra.get("evidence")
    if explicit:
        return explicit
    source = record.extra.get("parse_source", "")
    return {
        "page": "公告页面",
        "page+snippet": "公告页面+检索摘要",
        "snippet": "检索摘要",
    }.get(source, "公告页面")


def buyer_classification(records: list[TenderRecord]) -> dict[str, int]:
    """按 Skill 的采购人规则表分类，匹配文本为「采购人字段 + 公告标题」。

    公告标题往往就是「采购人 + 项目名」，只用采购人字段会漏掉一大半央国企与银行。
    """
    counter: dict[str, int] = {}
    for record in records:
        text = f"{record.buyer} {record.title} {record.extra.get('buyer_raw', '')}"
        matched = "其他"
        for label, pattern in BUYER_RULES:
            if pattern and pattern in text:
                matched = label
                break
        counter[matched] = counter.get(matched, 0) + 1
    return dict(sorted(counter.items(), key=lambda kv: -kv[1]))


def other_direction_breakdown(records: list[TenderRecord]) -> list[dict]:
    """「其他方向」按具体方向词拆开 —— 合同能源管理体量太大，混在一起看不出结构。"""
    counter: dict[str, int] = {}
    totals: dict[str, float] = {}
    for record in records:
        if record.category != "其他方向":
            continue
        terms = sorted(set(extract_directions(record.title))) or ["未命中方向词"]
        for term in terms:
            counter[term] = counter.get(term, 0) + 1
            totals[term] = totals.get(term, 0.0) + (record.amount_yuan or 0)
    return [
        {"term": term, "count": count, "total_yuan": round(totals[term], 2)}
        for term, count in sorted(counter.items(), key=lambda kv: -kv[1])
    ]


def main() -> int:
    raw_records = load_records()
    applied: set[str] = set()
    kept: list[TenderRecord] = []

    for item in raw_records:
        url = item["url"]
        if url in OUT_OF_WINDOW:
            continue
        fix = CORRECTIONS.get(url, {})
        data = dict(item)
        extra = dict(data.get("extra") or {})
        for key, value in fix.items():
            if key in ("evidence", "note"):
                extra[key] = value
            else:
                data[key] = value
        data["extra"] = extra
        record = TenderRecord(**{k: data.get(k) for k in RECORD_FIELDS})
        record.category = direction_of(record.title, record.category)
        kept.append(record)
        if fix:
            applied.add(url)

    unmatched = set(CORRECTIONS) - applied
    if unmatched:
        print("!! 以下修正没有匹配到任何记录:")
        for url in sorted(unmatched):
            print("   ", url)

    # 去重
    seen_urls: set[str] = set()
    seen_keys: set[str] = set()
    deduped: list[TenderRecord] = []
    dup_count = 0
    for record in kept:
        url_key = canonical_url(record.url)
        key = f"{title_key(record.title)}|{record.published or ''}"
        if (url_key and url_key in seen_urls) or (key in seen_keys):
            dup_count += 1
            continue
        if url_key:
            seen_urls.add(url_key)
        seen_keys.add(key)
        deduped.append(record)

    in_window = [r for r in deduped if not r.published or SINCE <= r.published <= UNTIL]
    outside = [r for r in deduped if r.published and not (SINCE <= r.published <= UNTIL)]

    stats = summarize(in_window)
    stats["buyers_by_title"] = buyer_classification(in_window)
    stats["other_directions"] = other_direction_breakdown(in_window)

    rows = []
    for record in in_window:
        rows.append({
            "date": record.published or "",
            "title": record.title,
            "url": record.url,
            "buyer": record.buyer or "",
            "winner": record.winner or "",
            "amount_yuan": record.amount_yuan,
            "amount_raw": record.amount_raw or "",
            "direction": record.category or "未分类",
            "province": record.province or "未识别",
            "evidence": evidence_of(record),
            "note": record.extra.get("note", ""),
        })
    rows.sort(key=lambda r: (r["date"] or "9999", r["title"]), reverse=True)

    (ROOT / "records_final.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    (ROOT / "stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"原始 {len(raw_records)} 条；应用修正 {len(applied)} 条；去重 {dup_count} 条；"
          f"入表 {len(in_window)} 条")
    print(f"统计区间：{SINCE} ~ {UNTIL}")
    print(f"有金额 {stats['with_amount']} 条；金额未披露 {stats['amount']['missing']} 条；"
          f"无日期 {stats['undated']} 条")
    for rec in outside:
        print("   [区间外]", rec.published, rec.title)
    amt = stats["amount"]
    print(f"金额合计 {amt['total_yuan']/1e4:.2f} 万元；中位数 {amt['median_yuan']/1e4:.2f} 万元；"
          f"均值 {amt['mean_yuan']/1e4:.2f} 万元；最大 {amt['max_yuan']/1e4:.2f} 万元；"
          f"最小 {amt['min_yuan']/1e4:.2f} 万元")
    print("\n-- 金额分布 --")
    for b in stats["buckets"]:
        print(f"  {b['bucket']:>12s}  {b['count']:>3d} 条  占比 {b['ratio']*100:5.1f}%  "
              f"金额 {b['total_yuan']/1e4:12.2f} 万  金额占比 {b['amount_ratio']*100:5.1f}%")
    print("\n-- 热点方向（标题词频） --")
    for h in stats["hotspots"]:
        print(f"  {h['term']:<14s} {h['count']:>3d} 条  {h['share']*100:5.1f}%  [{h['category']}]")
    print("\n-- 方向分布 --")
    for c in stats["categories"]:
        print(f"  {c['category']:<14s} {c['count']:>3d} 条  {c['total_yuan']/1e4:12.2f} 万")
    print("\n-- 其他方向拆解 --")
    for t in stats["other_directions"]:
        print(f"  {t['term']:<14s} {t['count']:>3d} 条  {t['total_yuan']/1e4:12.2f} 万")
    print("\n-- 地区 --")
    for r in stats["regions"]:
        print(f"  {r['region']:<8s} {r['count']:>3d} 条  {r['total_yuan']/1e4:12.2f} 万")
    print("\n-- 采购人类型（采购人字段+标题） --")
    for k, v in stats["buyers_by_title"].items():
        print(f"  {k:<20s} {v:>3d} 条")
    print("\n-- 采购人类型（仅采购人字段，Skill 原口径） --")
    for k, v in stats["buyers"].items():
        print(f"  {k:<20s} {v:>3d} 条")
    print("\n-- 月度走势 --")
    for t in stats["trend"]:
        print(f"  {t['month']}  {t['count']:>3d} 条  {t['total_yuan']/1e4:12.2f} 万")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
