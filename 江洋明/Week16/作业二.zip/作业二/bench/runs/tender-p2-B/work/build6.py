"""最终构建（v6）：补上最后一条缺失的发布日期（取自公告 URL 路径），然后跑 v5 的全流程。"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import build5  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# 河南机电职业学院的公告 URL 路径带日期段 /20241218/，页面标题与项目号也一致
build5.FIX["https://hnsggzyjy.henan.gov.cn/jyxx/002002/002002003/20241218/"
            "6ebfda5b-4029-48e5-a261-e5c3ff56f96f.html"] = {
    **build5.FIX.get(
        "https://hnsggzyjy.henan.gov.cn/jyxx/002002/002002003/20241218/"
        "6ebfda5b-4029-48e5-a261-e5c3ff56f96f.html", {}),
    "published": "2024-12-18",
    "buyer": "河南机电职业学院",
    "evidence": "公告页面（日期取自公告 URL 路径）",
}

if __name__ == "__main__":
    raise SystemExit(build5.main())
