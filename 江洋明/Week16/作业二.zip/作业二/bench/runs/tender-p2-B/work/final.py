"""收尾：补最后一条页面证据（哈尔滨华能）→ 重跑统计 → 重新生成 report.md → 修一处措辞。

执行顺序很重要：先补证据并重跑统计，再渲染报告，最后修措辞。
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import build6  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HARBIN = ("https://hrbggzy.harbin.gov.cn/zbgs/20241120/"
          "4f53964a-897f-42d8-863d-21147d659cd0.html")

# 页面确认：中标候选人「黑龙江省碳配额节能管理服务有限公司」，预中标金额 93500 元（含税）
build6.build5.FIX[HARBIN] = {
    **build6.build5.FIX.get(HARBIN, {}),
    "amount_yuan": 93500,
    "amount_raw": "预中标金额：93500元（含税）",
    "winner": "黑龙江省碳配额节能管理服务有限公司",
    "buyer": "哈尔滨市华能集中供热有限公司",
    "published": "2024-11-20",
    "evidence": "公告页面",
}

# 1) 重跑统计
build6.build5.main()

# 2) 重新渲染报告（导入即渲染）
import make_report2  # noqa: E402,F401

# 3) 修一处措辞：方向词是「累计命中次数」，不是「公告条数」
REPORT = ROOT.parent / "report.md"
text = REPORT.read_text(encoding="utf-8")
if "三个词合计命中 44 条公告" in text:
    REPORT.write_text(
        text.replace("三个词合计命中 44 条公告", "三个方向词累计命中 44 次"), encoding="utf-8")
    print("已修正措辞：44 条公告 → 累计命中 44 次")
print("report.md 完成")
