"""第十五轮（最后一轮取证）：只取公告发布日期。

已解析出金额、但发布日期缺失的记录，用真实浏览器再取一次页面里的日期。
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    ("池州", "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb"),
    ("安徽GEP", "https://fzggw.ah.gov.cn/public/7011/149968421.html"),
    ("南方电网", "https://www.bidding.csg.cn/zbxx/1200449283.jhtml"),
    ("南京开发区", "http://jsggzy.jszwfw.gov.cn/jyxx/003004/003004006/20250610/2460607c69404da0af6d464a153e9068.html"),
    ("鄂尔多斯", "http://www.cnbiding.com.cn/zbyxx/083098801599.html"),
    ("烟台", "https://ggzyjy.yantai.gov.cn/jyxx/003002/003002004/20251112/aea042f2-4cb0-4b05-b4d6-7eb37045ce72.html"),
    ("昌都", "http://www.ccgp-xizang.gov.cn/freecms/site/xizang/xzcggg/info/2025/151064.html"),
    ("唐山银行", "https://www.12369zb.com/view/880/TbTLw5kBg7S5K-63cRKG.html"),
]

DATE_RE = re.compile(
    r"(20\d{2})[年\-/\.](\d{1,2})[月\-/\.](\d{1,2})|(\d{4})-(\d{2})-(\d{2})"
)
KEYS = re.compile(r"发布日期|发布时间|公告时间|公示时间|公示期|发布|信息时间|日期|时间")


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)

    for label, url in TARGETS:
        print("=" * 100)
        print(f"### {label}")
        res = browser.fetch(url)
        html = res.html if res and res.html else ""
        if not html:
            print("!! 抓取失败\n")
            continue
        for line in plain(html):
            if len(line) > 200 or not KEYS.search(line) or not DATE_RE.search(line):
                continue
            print("  >", line[:190])
        print("", flush=True)

    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
