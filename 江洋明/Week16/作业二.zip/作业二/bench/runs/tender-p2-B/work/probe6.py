"""第七轮：补齐多包项目的其余标段（不 break），并打印剩余几条的检索摘要。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TABLES = [
    ("广东工业双碳", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202507/t20250724_25034196.htm",
     "中标（成交）金额"),
    ("西安减污降碳", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202607/t20260702_26861655.htm",
     "中标（成交）金额"),
    ("西安双控", "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202607/t20260731_27051407.htm",
     "中标（成交）金额"),
]

HINT_KEYS = ["25699821", "12369zb", "chnenergybidding", "csscbidding", "slj.ningbo",
             "yixing.gov.cn", "sdgy.tobacco", "bidding.csg.cn", "suzhou", "wyz"]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for label, url, needle in TABLES:
        print("=" * 114)
        print(f"### {label}")
        res = fetcher.fetch(url)
        html = res.html if (res.ok and res.html) else ""
        if not html:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            html = br.html if br else ""
        if not html:
            print("!! 抓取失败\n")
            continue
        for table in re.findall(r"<table.*?</table>", html, flags=re.S | re.I):
            if needle not in table:
                continue
            for tr in re.findall(r"<tr.*?</tr>", table, flags=re.S | re.I):
                cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", tr, flags=re.S | re.I)
                vals = [re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", c)).strip() for c in cells]
                if not any(vals):
                    continue
                print("  TR:", " | ".join(vals)[:340])
        print("", flush=True)

    print("#" * 114)
    print("### 检索摘要")
    for name in ("candidates.json", "candidates2.json"):
        path = ROOT / name
        if not path.is_file():
            continue
        for item in json.loads(path.read_text(encoding="utf-8")):
            url = item.get("url", "")
            if any(k in url for k in HINT_KEYS):
                print("-" * 100)
                print("URL  :", url)
                print("TITLE:", item.get("title_hint", ""))
                print("HINT :", item.get("hint", "")[:600])

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
