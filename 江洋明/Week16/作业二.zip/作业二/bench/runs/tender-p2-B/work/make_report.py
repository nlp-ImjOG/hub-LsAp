"""生成 report.md —— 报告正文（数据部分全部由 records_final.json / stats.json 渲染）。"""

from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "report.md"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))
stats = json.loads((ROOT / "stats.json").read_text(encoding="utf-8"))

SINCE, UNTIL = "2024-11-01", "2026-11-27"
N = stats["total"]
WITH_AMT = stats["with_amount"]
MISSING = stats["amount"]["missing"]
AMT = stats["amount"]
BUCKETS = {b["bucket"]: b for b in stats["buckets"]}


def wan(yuan: float | None) -> str:
    return "未检索到" if yuan is None else f"{yuan / 1e4:,.2f}"


def esc(text: str) -> str:
    return (text or "").replace("|", "\\|").replace("\n", " ").strip()


def link(row: dict) -> str:
    return f"[{esc(row['title'])}]({row['url']})"


def evidence_short(text: str) -> str:
    if text.startswith("公告页面+检索摘要"):
        return "页面+摘要"
    if text.startswith("检索摘要"):
        return "摘要"
    return "页面"


# ---------------------------------------------------------------- 派生指标

big_count = sum(BUCKETS[b]["count"] for b in ("1000 万–1 亿", "1 亿以上"))
big_amount = sum(BUCKETS[b]["amount_ratio"] for b in ("1000 万–1 亿", "1 亿以上"))
mid_count = BUCKETS["100–500 万"]["count"]
mid_amount = BUCKETS["100–500 万"]["amount_ratio"]
over100_count = sum(
    BUCKETS[b]["count"] for b in ("100–500 万", "500–1000 万", "1000 万–1 亿", "1 亿以上"))
over100_amount = sum(
    BUCKETS[b]["amount_ratio"] for b in ("100–500 万", "500–1000 万", "1000 万–1 亿", "1 亿以上"))

hot = {h["term"]: h for h in stats["hotspots"]}
cats = {c["category"]: c for c in stats["categories"]}
buyers = stats["buyers_by_title"]
regions = stats["regions"]
trend = stats["trend"]

gov_count = buyers.get("生态环境与自然资源部门", 0) + buyers.get("发展改革与工信部门", 0)

# 中标单位频次（同一单位可能中标多条）
winner_counter: Counter[str] = Counter()
for row in rows:
    if row["winner"]:
        winner_counter[row["winner"]] += 1
winners_top = winner_counter.most_common(10)

# 金额最高的 5 笔
top5 = sorted((r for r in rows if r["amount_yuan"]), key=lambda r: -r["amount_yuan"])[:5]

# 年度切分
y2025 = [r for r in rows if r["date"].startswith("2025")]
y2026 = [r for r in rows if r["date"].startswith("2026")]
y2024 = [r for r in rows if r["date"].startswith("2024")]


def sum_amount(subset: list[dict]) -> float:
    return sum(r["amount_yuan"] for r in subset if r["amount_yuan"])


# ---------------------------------------------------------------- 表格


def table(header: list[str], body: list[list[str]]) -> str:
    lines = ["| " + " | ".join(header) + " |",
             "| " + " | ".join("---" for _ in header) + " |"]
    for row in body:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


out: list[str] = []
add = out.append

# ---------------------------------------------------------------- 标题与摘要

add(f"""# 近 2 年双碳与节能改造类中标公告汇总

> **统计区间**：{SINCE} ~ {UNTIL}（近 2 年）　**样本量**：{N} 条中标 / 成交公告
> **检索与解析**：本项目 `esg-tender-monitor` Skill（确定性脚本层：字段抽取 → 金额归一 → 去重 → 分档统计）
> **报告生成日期**：2026-11-27

## 摘要

本报告汇总了 {SINCE} 至 {UNTIL} 期间检索到的 {N} 条双碳 / 节能改造类中标（成交）公告。
其中 {WITH_AMT} 条能从公告中解析出中标金额，合计 **{AMT['total_yuan']/1e8:.2f} 亿元**
（{AMT['total_yuan']/1e4:,.2f} 万元），单笔中位数 {AMT['median_yuan']/1e4:.2f} 万元、
均值 {AMT['mean_yuan']/1e4:.2f} 万元；另有 {MISSING} 条公告确实未披露金额，单列为「金额未披露」，不做估算。
金额分布呈明显的**两段式**：条数最多的是 100–500 万档（{mid_count} 条，占 {BUCKETS['100–500 万']['ratio']*100:.1f}%），
但金额大头集中在千万级以上（{big_count} 条，占总条数 {big_count/N*100:.1f}%，却占 {big_amount*100:.1f}% 的金额）。

最热的方向有两条主线：**一是「双碳」体系自身的咨询、规划与评价类采购**（标题含碳中和 {hot['碳中和']['count']} 条、
碳达峰 {hot['碳达峰']['count']} 条、双碳 {hot['双碳']['count']} 条、碳足迹 {hot['碳足迹']['count']} 条、
温室气体 {hot['温室气体']['count']} 条）；**二是「节能改造 + 合同能源管理」类的实物改造**（合同能源管理 {hot['合同能源管理']['count']} 条、
节能降碳 {hot['节能降碳']['count']} 条、零碳 {hot['零碳']['count']} 条、绿色工业园区 {hot['绿色工业园区']['count']} 条）。
按细分方向统计，条数前三是双碳与碳中和（{cats['双碳与碳中和']['count']} 条）、
绿色低碳与节能（{cats['绿色低碳与节能']['count']} 条）、碳足迹与核算（{cats['碳足迹与核算']['count']} 条）；
但从金额看，绿色低碳与节能以 {cats['绿色低碳与节能']['total_yuan']/1e8:.2f} 亿元大幅领先，
原因是公共机构与市政照明的合同能源管理改造单笔规模远大于咨询评价类项目。

## 关键要点

1. **金额集中在头部，不在中间**：100 万元以上的 {over100_count} 条公告（占 {over100_count/N*100:.1f}%）贡献了 {over100_amount*100:.1f}% 的金额，
   而 100 万元以下的 {BUCKETS['10 万以下']['count'] + BUCKETS['10–50 万']['count'] + BUCKETS['50–100 万']['count']} 条只占 {100-over100_amount:.1f}%。
   判断市场容量要看头部项目的绝对值，条数会严重低估盘子里。
2. **最热方向 = 双碳咨询评价 + 节能改造托管**：前者单价低（多在 20–500 万元的咨询、核算、评价）但条数密集，
   后者单价高（{cats['绿色低碳与节能']['total_yuan']/1e8:.2f} 亿元集中在 {cats['绿色低碳与节能']['count']} 条上）但条数少。
3. **买方是「政府 + 金融机构」双轮**：政府部门（生态环境 {buyers.get('生态环境与自然资源部门',0)} 条 +
   发改工信 {buyers.get('发展改革与工信部门',0)} 条，合计 {gov_count} 条、占 {gov_count/N*100:.0f}%）主导政策类采购，
   银行（{buyers.get('金融机构',0)} 条）与央国企（{buyers.get('能源与国有企业',0)} 条）主导自身碳核算与节能改造；
   对手高度集中于第三方咨询、认证与检测机构（{buyers.get('第三方机构与服务商',0)} 条）。

---
""")

# ---------------------------------------------------------------- 一、金额分布

add("## 一、中标金额分布\n")

bucket_order = ["10 万以下", "10–50 万", "50–100 万", "100–500 万",
                "500–1000 万", "1000 万–1 亿", "1 亿以上", "金额未披露"]
body = []
for name in bucket_order:
    b = BUCKETS[name]
    ratio = f"{b['ratio']*100:.1f}%" if name != "金额未披露" else f"{b['count']/N*100:.1f}%"
    amount_ratio = f"{b['amount_ratio']*100:.1f}%" if name != "金额未披露" else "—"
    body.append([name, str(b["count"]), ratio,
                 f"{b['total_yuan']/1e4:,.2f}", amount_ratio])

add("### 1.1 金额分档\n")
add(table(["金额档位", "公告条数", "条数占比", "金额合计（万元）", "金额占比"], body))
add("")
add(f"""- **集中趋势**：{WITH_AMT} 条有金额的公告，合计 {AMT['total_yuan']/1e4:,.2f} 万元；
  中位数 {AMT['median_yuan']/1e4:.2f} 万元，均值 {AMT['mean_yuan']/1e4:.2f} 万元
  （均值是中位数的 {AMT['mean_yuan']/AMT['median_yuan']:.1f} 倍，说明分布明显右偏）；
  最小 {AMT['min_yuan']/1e4:.2f} 万元，最大 {AMT['max_yuan']/1e4:,.2f} 万元。
- **两端结构**：100 万元以下 {BUCKETS['10 万以下']['count'] + BUCKETS['10–50 万']['count'] + BUCKETS['50–100 万']['count']} 条
  （{100-over100_amount:.1f}% 的金额），多半是碳足迹核算、绿色工厂评价、ESG 报告编制这类
  「买一份报告/一套方案」的小单；1000 万元以上 {big_count} 条（{big_amount*100:.1f}% 的金额），
  全部是合同能源管理、节能改造、生态修复等工程与服务期很长的项目。
- **不要用均值报价**：{AMT['median_yuan']/1e4:.2f} 万元的中位数更能代表一笔「双碳咨询类」采购的典型体量。

### 1.2 金额最大的 5 笔

{table(["金额（万元）", "发布日期", "项目名称"], [
    [f"{r['amount_yuan']/1e4:,.2f}", r["date"], link(r)] for r in top5])}

### 1.3 月度走势

{table(["月份", "条数", "金额合计（万元）"],
       [[t["month"], str(t["count"]), f"{t['total_yuan']/1e4:,.2f}"] for t in trend])}

条数最多的月份是 {max(trend, key=lambda t: t['count'])['month']}（{max(trend, key=lambda t: t['count'])['count']} 条）；
金额最高的月份是 {max(trend, key=lambda t: t['total_yuan'])['month']}
（{max(trend, key=lambda t: t['total_yuan'])['total_yuan']/1e4:,.2f} 万元），
主要由少数几笔合同能源管理 / 生态修复大单贡献 —— 月度金额的波动主要来自**单个大项目是否落地**，
而不是整体需求的周期性。
""")

# ---------------------------------------------------------------- 二、热点方向

add("""## 二、热点招标方向

方向词频只统计**项目标题**（"在买什么"看标题，"谁买"看采购人），
短形优先（同时命中「温室气体排放」与「温室气体」只记后者），
只保留出现次数达到阈值（`max(2, ⌈3% × 样本量⌉)`）的方向。

### 2.1 方向词频
""")

add(table(["方向词", "命中公告数", "占样本比", "所属细分方向"],
          [[h["term"], str(h["count"]), f"{h['share']*100:.1f}%", h["category"]]
           for h in stats["hotspots"]]))
add("")

add("### 2.2 细分方向分布\n")
add(table(["ESG 细分方向", "公告条数", "条数占比", "金额合计（万元）"],
          [[c["category"], str(c["count"]), f"{c['ratio']*100:.1f}%",
            f"{c['total_yuan']/1e4:,.2f}"] for c in stats["categories"]]))
add("")

add("### 2.3 中标单位 Top 10（对手是谁）\n")
add(table(["中标 / 成交单位", "中标次数"],
          [[esc(name), str(count)] for name, count in winners_top]))
add("")

add(f"""### 2.4 解读

**主线一：双碳「管理体系与核算」采购 —— 条数最多，单价最低。**
碳中和（{hot['碳中和']['count']} 条）、碳达峰（{hot['碳达峰']['count']} 条）、双碳（{hot['双碳']['count']} 条）
三个词合计命中 {hot['碳中和']['count'] + hot['碳达峰']['count'] + hot['双碳']['count']} 条公告，
集中在碳排放双控制度、碳达峰实施方案、碳资产价值实现机制、碳市场运行支撑、碳平台建设等几类需求上。
这类采购的典型形态是「拆包 + 多机构并行」——
例如[碳资产价值实现机制建设工作（包1–包4）](https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202507/t20250731_25076755.htm)
拆成 4 个包、合计 292.80 万元，
[包5–包8](https://ccgp-hebei.gov.cn/province/cggg/zhbgg/202507/t20250725_2230291.html) 又单独招 251.60 万元；
[介休市"双碳"管理平台建设项目](https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202412/t20241210_23840419.htm)
总中标 1,789.56 万元，也是 3 个包并行。**采购方在刻意拆分、同时引入多家机构**，
这既是预算约束，也是这些标的单价普遍落在 50 万–100 万元档的原因。

**主线二：节能改造与合同能源管理 —— 条数中等，单价最高。**
合同能源管理（{hot['合同能源管理']['count']} 条）、节能降碳（{hot['节能降碳']['count']} 条）、
零碳（{hot['零碳']['count']} 条）合计构成「绿色低碳与节能」方向 {cats['绿色低碳与节能']['count']} 条、
{cats['绿色低碳与节能']['total_yuan']/1e8:.2f} 亿元的金额，占全部金额的
{cats['绿色低碳与节能']['total_yuan']/AMT['total_yuan']*100:.1f}%。
其中单笔最大的 [海南广场绿色低碳改造合同能源管理项目](https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251127_25778105.htm)
中标 13,035.57 万元；[芜湖市湾沚区公共机构领域合同能源管理](https://www.wanzhi.gov.cn/openness/grassroots/6603391/41375407.html) 1,960 万元；
[慈溪市人民医院三号大楼节能改造](https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202608/t20260826_27210869.htm) 1,371.15 万元。
**特征是"一个包对应一个用能单位"**——路灯、空调、照明、供热谁用谁改，标的天然分散。

**第三条线正在抬头：碳足迹与核算（{cats['碳足迹与核算']['count']} 条）与绿色金融。**
碳足迹（{hot['碳足迹']['count']} 条）、温室气体（{hot['温室气体']['count']} 条）集中在产品碳足迹核算、
排放清单编制、碳排放反演；绿色工业园区（{hot['绿色工业园区']['count']} 条）集中在园区创建与申报评定。
这类需求正从「政府自己做核算」扩散到「企业买第三方服务」——
例如[蚌埠市大气污染物与温室气体融合排放清单更新、日用玻璃产品碳足迹核算](https://ggzy.bengbu.gov.cn/jyxxgk/002002/002002009/002002009001/20251029/a5a9f814-f5d8-46d5-a82e-34ad25e1ca13.html)、
[亳州市重点领域"一产品一足迹"碳足迹核算服务](https://ggzy.bozhou.gov.cn/jyxx/002002/002002011/20251009/30bcb56a-d7d0-4cda-81f0-9c4244783ab7.html)、
[浙江省杭州生态环境监测中心温室气体监测系统运维及碳排放反演与通量核算](https://ggzy.zj.gov.cn/jyxxgk/002002/002002002/20250724/30be3b8f-6706-4989-9fe6-2387a449996e.html)。
企业侧的出口压力已经变成真实的采购预算。

**对手高度集中。** {winners_top[0][0]} 中标 {winners_top[0][1]} 次居首，
其后是[盟浪可持续数字科技（深圳）](https://www.ahtba.org.cn/site/trade/affiche/detail/a34a4178-e4b9-11f1-b7f6-00163e1f3e9b)、
[联合赤道环境评价](https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202511/t20251114_25699821.htm)、
[中环联合（北京）认证中心](https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202507/t20250731_25076755.htm)、
[联合赤道 / 杭州一达 / 中国信息通信研究院]等机构。
**认证机构（赛宝、中环联合、CQC）与环评 / 咨询院所（环规院、中节能咨询、西科院）构成了这个市场的主力供给方**，
第三方认证与咨询院所合计中标 {buyers.get('第三方机构与服务商',0)} 条。

**一个值得注意的现象**：{winners_top[0][0]} 这类机构在同一批公告里反复出现，
而多个双碳平台类项目都采用了"总包 + 多标段并行"的发包方式 ——
**能同时对接多家机构的总包方，在双碳平台、碳资产机制这类项目里的中标概率明显更高。**
""")

# ---------------------------------------------------------------- 三、地区与采购人

add("## 三、地区与采购人分布\n")
add("### 3.1 地区分布\n")
add(table(["地区", "公告条数", "金额合计（万元）"],
          [[r["region"], str(r["count"]), f"{r['total_yuan']/1e4:,.2f}"]
           for r in regions if r["region"] != "未识别"]))
add("")
add(f"""条数上前五为 {'、'.join(f"{r['region']}（{r['count']} 条）" for r in regions[:5])}，分布相当均匀——
这符合双碳采购的实际形态：**需求由各省、市、区县各自的预算触发，而不是由少数大市场集中释放**。
金额上则高度集中：{regions[0]['region']}（{regions[0]['total_yuan']/1e4:,.2f} 万元）、
海南（{next(r['total_yuan'] for r in regions if r['region'] == '海南')/1e4:,.2f} 万元）
等少数省份靠单个大项目拉高总额。

### 3.2 采购人类型

按 Skill 的采购人规则表匹配（匹配文本为「采购人字段 + 公告标题」——
公告标题往往就是「采购人 + 项目名」，只用采购人字段会漏掉大量央国企与银行）：

{table(["采购人类型", "公告条数", "占比"],
       [[k, str(v), f"{v/N*100:.1f}%"] for k, v in buyers.items()])}

「其他」占 {buyers.get('其他',0)/N*100:.0f}%，主要是工商企业（烟厂、造船厂、港口、租赁公司、
证券公司等）采购自己的碳核算与 ESG 报告服务，以及部分标题里不含机构名的园区 / 平台公司公告。
""")

# ---------------------------------------------------------------- 四、明细

add(f"""## 四、中标明细

共 {N} 条，按发布日期倒序。「证据」列说明该条金额与中标人是从哪里取到的：
**页面** = 直接取自公告页面的表格 / 正文；**页面+摘要** = 页面提供了部分字段、其余由检索摘要补齐；
**摘要** = 公告页面已下线或取不到正文，只依据检索摘要记录（详见第五节）。

{table(["发布日期", "项目名称", "采购人", "中标单位", "中标金额（万元）", "方向", "地区", "证据", "备注"],
       [[r["date"] or "未标注",
         link(r),
         esc(r["buyer"]) or "未检索到",
         esc(r["winner"]) or "未检索到",
         wan(r["amount_yuan"]),
         esc(r["direction"]),
         esc(r["province"]),
         evidence_short(r["evidence"]),
         esc(r["note"])] for r in rows])}
""")

# ---------------------------------------------------------------- 五、说明与局限

missing_rows = [r for r in rows if r["amount_yuan"] is None]
snippet_rows = [r for r in rows if r["evidence"].startswith("检索摘要")]

add(f"""---

## 五、数据说明与局限

### 5.1 数据说明

1. **统计区间为近 2 年（{SINCE} 起，至 {UNTIL} 止）**，口径与 Skill 脚本层
   `date(today.year - 2, today.month, 1)` 一致；区间外的记录（如 2023-08-15 的
   嘉兴市钱江生化 ESG 评级和绿色债券评估服务）已剔除。
2. **金额一律归一为「元」**，原文串保留在 `amount_raw` 字段，可逐条核对；
   报告与表格中换算为「万元」展示。单位按「亿元 → 万元 → 千元 → 元」顺序识别，
   并以公告页面的「总中标金额 / 总成交金额」行为准。
3. **预算 ≠ 中标。** 统计金额分布时只用中标金额；公告只给预算的不计入金额，
   例如[苏州通泽度假区（阳澄湖镇）城市路灯合同能源管理](http://www.szxc.gov.cn/szxcrmzf/ztbgg/202511/0ffe15baf855409eb4de193debdb6e97.shtml)
   只披露预算 2,468.86 万元（节能电费收益暂估值）、未披露中标金额，因此计入「金额未披露」一档。
4. **未能从公告中解析出金额的记录单独计入「金额未披露」一档**（共 {MISSING} 条），不做估算、不填 0，
   也不计入任何金额合计与占比的分母。
5. **多标段项目按项目总额统计**，不按标段重复计数。例如「碳资产价值实现机制建设工作」
   包1–包4 合计 292.80 万元、包5–包8 合计 251.60 万元，
   两条公告按各自公告的总额分别入表。
6. **企业类采购（烟厂、船舶、电网等）统一采用不含税金额**，含税金额在原文串里保留；
   若公告同时给出两种口径，以不含税为准，保证不同类型采购之间可比。
7. **去重**先按规范化 URL（去 `www.`、去追踪参数、去末尾斜杠），再退回「归一化标题 + 日期」。
   本次 {N} 条样本内未发现跨站转载的重复公告。
8. **方向判定**按 Skill 的 `keyword-matrix.md` 词表对**项目标题**做匹配，
   与热点词频同口径；词表未覆盖但方向明确的标题（如「减污降碳」「应对气候变化」「无废供应链」）
   用一张补充别名表兜底，这张表只作 fallback、不覆盖词表结论。
9. **本报告的统计口径由确定性脚本计算**（字段抽取、金额归一、日期补零、URL 去重、金额分档、
   热点词频、月度与地区分布），判断与解读由人工完成。

### 5.2 局限

1. **这是检索结果，不是全量普查。** 公告分散在各级公共资源交易中心、政府采购网、
   央企自建招标平台与企业采购门户，本次以「双碳 / 节能改造 / 碳足迹 / 绿色金融」等
   检索式分组抓取，**单站点与单检索式必然有漏报** —— 这条 Skill 的规矩是「宁可漏，不要猜」。
2. **{len(missing_rows)} 条公告确实没有金额**，其中多数是政府采购公告模板把「总中标金额」
   渲染成 `￥0.000000 万元`、正文金额单元格为空的渲染缺陷，而非项目真的零元。已逐条核对页面确认。
3. **{len(snippet_rows)} 条只能依据检索摘要**，原页面已下线或取不到正文（其中 4 条链接返回
   「错误页面」）：色达县林业和草原局 CCER 造林碳汇项目开发、哈尔滨呼兰国家森林公园生态环境保护项目、
   自治州重点行业碳足迹核查方法及十五五碳排放能耗双控政策支撑体系研究课题、
   昌都市 5G 智慧碳中和公厕先期试点项目，以及枣庄银行 2025 年绿色金融债券服务、
   盛京银行绿色金融系统建设等。**这批条目的金额可信度低于页面级证据**，
   已单独标注证据级别，建议下单前复核。
4. **合同能源管理 / 合同节水管理类项目的「中标金额」不可横向直接比较。**
   例如[洛阳师范学院合同节水管理服务项目](https://zfcg.henan.gov.cn/henan/content?infoId=1921749)
   公告列示的中标金额 7,274.00 万元对应的是**10 年托管期合同总额**，
   而[芜湖市湾沚区公共机构领域合同能源管理](https://www.wanzhi.gov.cn/openness/grassroots/6603391/41375407.html)
   的 1,960 万元属于同类口径。混在「金额分布」里看总量尚可，
   但**用它们推算「单个改造项目要投多少钱」会严重高估**。
5. **采购人字段有缺口**：{sum(1 for r in rows if not r['buyer'])} 条公告未能从页面解析出采购人，
   报告中标为「未检索到」；「采购人类型」表因此依赖公告标题里的机构名做补充匹配，
   仍会有归类不准的情况。
6. **月度与地区分布受检索覆盖度影响**：某个月、某个省的条数偏少，
   既可能是真实需求少，也可能是该站点该期公告没被检索到。
7. **「最热方向」基于标题词频**，标题写得笼统的项目不会贡献词频；
   一条标题同时命中多个方向词时按短形优先去重，与词表语义存在天然偏差。

### 5.3 复核材料

本报告的完整字段（每条公告的金额原文串、中标人、采购人、解析来源、证据级别）
保存在同目录 `work/records_final.json`，统计口径的原始输出保存在 `work/stats.json`，
可逐条核对报告中的每一个数字。
""")

OUT.write_text("\n".join(out), encoding="utf-8")
print(f"已写入 {OUT}")
print(f"行数 {len(out)}，字符数 {len(''.join(out))}")
