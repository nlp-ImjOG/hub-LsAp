"""找出标题是 Vue 模板占位符的那条记录，并回原页取真实项目名。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def main() -> int:
    rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))
    targets = [r for r in rows if "{{" in r["title"] or "{{" in (r["buyer"] or "")]
    for r in targets:
        print(json.dumps(r, ensure_ascii=False, indent=2))

    if not targets:
        return 0

    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)
    for r in targets:
        print("\n" + "=" * 90)
        print("###", r["url"])
        res = browser.fetch(r["url"])
        html = res.html if res and res.html else ""
        if not html:
            print("!! 抓取失败")
            continue
        for m in re.finditer(r"projectName|<title>|采购项目名称|项目名称", html):
            chunk = re.sub(r"\s+", " ", html[max(0, m.start() - 200): m.end() + 400])
            chunk = re.sub(r"<[^>]+>", " ", chunk)
            print("  RAW:", re.sub(r"\s+", " ", chunk).strip()[:600])
            print("  ---")
    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
