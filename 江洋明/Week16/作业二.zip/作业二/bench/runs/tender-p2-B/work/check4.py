"""补齐 4 条证据：江西 GEP 中选人、池州采购人、枣庄银行、洛阳师范学院合同节水。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))
by_title = {r["title"]: r for r in rows}

TARGETS = [
    ("江西GEP", "https://drc.jiangxi.gov.cn/jxsfzhggwyh/col/col14590/content/content_2063876380782551040.html",
     r"中选人|采购人|项目名称|中选金额"),
    ("池州", "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb",
     r"采购人|招标人|449100|tendererName"),
    ("枣庄银行", "https://www.zaozhuangbank.com/zzbank/2025-09/12/article_2025091208165779389.html",
     r"中标|成交|金额|万元|包|赤道|国泰海通"),
    ("洛阳师范学院", None, r"中标|成交|金额|万元|金越"),
]

for key in ("洛阳师范学院合同节水管理服务项目-中标公告",):
    for r in rows:
        if r["title"] == key:
            TARGETS[3] = ("洛阳师范学院", r["url"], TARGETS[3][2])


def windows(html: str, pattern: str, before: int = 260, after: int = 700, limit: int = 4) -> None:
    n = 0
    for m in re.finditer(pattern, html):
        lo = max(0, m.start() - before)
        hi = min(len(html), m.end() + after)
        chunk = re.sub(r"\s+", " ", html[lo:hi])
        chunk = re.sub(r"<[^>]+>", " ", chunk)
        chunk = re.sub(r"\s+", " ", chunk).strip()
        print("  RAW:", chunk[:900])
        n += 1
        if n >= limit:
            break
    if not n:
        print("  (无匹配)")


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)
    for label, url, pattern in TARGETS:
        print("\n" + "=" * 100)
        print("###", label, url)
        res = browser.fetch(url)
        html = res.html if res and res.html else ""
        if not html:
            print("!! 抓取失败")
            continue
        windows(html, pattern)
    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
