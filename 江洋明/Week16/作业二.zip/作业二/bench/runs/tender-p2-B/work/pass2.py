"""第二轮：对「金额仍缺失」的记录，把页面里所有可能带金额的原文行/单元格原样打出来。

这些记录的页面大多不是政府采购网的标准 key-value 表，而是
公共资源交易中心的「公告正文 + 报价表」混排结构，字段名五花八门
（成交价 / 中标价 / 报价（万元） / 最高限价 ...），确定性正则没覆盖到。

本脚本**只输出原文**，不推断。人工读完后写 corrections.json。

用法: python pass2.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402
from esg_toolkit.parse_news import extract_body  # noqa: E402
from esg_toolkit.parse_tender import extract_rows  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

#: 金额相关标签
LABEL_RE = re.compile(
    r"中标|成交|金额|报价|单价|总价|限价|控制价|价格|预算|费用|服务费|中标价|成交价"
)
#: 数字（含千分位）
NUM_RE = re.compile(r"\d[\d,，]*(?:\.\d+)?")


def load_records() -> list[dict]:
    records: list[dict] = []
    for name in ("records.json", "records2.json"):
        path = ROOT / name
        if path.is_file():
            records.extend(json.loads(path.read_text(encoding="utf-8")))
    return records


def main() -> int:
    records = load_records()
    todo = [r for r in records if r["amount_yuan"] is None]
    print(f"待补金额：{len(todo)} 条 / 共 {len(records)} 条\n", flush=True)

    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for index, rec in enumerate(todo, start=1):
        url = rec["url"]
        html = ""
        res = fetcher.fetch(url)
        if res.ok and res.html:
            html = res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html

        print("=" * 112)
        print(f"[{index}/{len(todo)}] {url}")
        print(f"标题: {rec['title']}")
        print(
            f"当前: amount=None winner={rec['winner']!r} date={rec['published']} "
            f"buyer={rec['buyer']!r} src={rec['extra'].get('parse_source')}"
        )
        if not html:
            print("   !! 抓取失败（requests + 浏览器都不行）", flush=True)
            continue

        # 1) 表格行
        shown = 0
        for cells in extract_rows(html):
            joined = " | ".join(cells)
            if not NUM_RE.search(joined) or not LABEL_RE.search(joined):
                continue
            print("   ROW:", joined[:260])
            shown += 1
            if shown >= 8:
                break

        # 2) 正文行
        body = extract_body(html)
        n = 0
        for raw_line in body.splitlines():
            line = re.sub(r"\s+", " ", raw_line).strip()
            if not line or len(line) > 260:
                continue
            if not LABEL_RE.search(line) or not NUM_RE.search(line):
                continue
            print("   >", line[:240])
            n += 1
            if n >= 8:
                break
        if shown == 0 and n == 0:
            print("   (无带数字的金额相关行)")
        print("", flush=True)

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
