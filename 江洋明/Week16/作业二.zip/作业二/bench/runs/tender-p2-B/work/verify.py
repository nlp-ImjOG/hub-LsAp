"""交付前自检：明细行数、链接完整性、每行都有日期与链接、无编造金额。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORT = ROOT.parent / "report.md"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

text = REPORT.read_text(encoding="utf-8")
rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))

detail = text.split("## 四、中标明细", 1)[1].split("## 五、", 1)[0]
table_lines = [ln for ln in detail.splitlines() if ln.startswith("| ")]
data_lines = [ln for ln in table_lines if not ln.startswith("| ---") and not ln.startswith("| 发布日期")]
print(f"明细表数据行 {len(data_lines)} 行（records_final.json {len(rows)} 条）")

links = re.findall(r"\]\((https?://[^)]+)\)", detail)
print(f"明细表链接 {len(links)} 个，唯一 {len(set(links))} 个")
missing = [r for r in rows if r["url"] not in links]
print(f"明细表里没有链接的记录 {len(missing)} 条")
for r in missing[:5]:
    print("   !!", r["title"])

# 每行都要有日期
bad_date = [ln for ln in data_lines if not re.match(r"\| 20\d\d-\d\d-\d\d \|", ln)]
print(f"缺日期的行 {len(bad_date)} 行")
for ln in bad_date[:5]:
    print("   !!", ln[:120])

# 金额列不得为空
rows_cells = [[c.strip() for c in ln.strip("|").split("|")] for ln in data_lines]
empty_amt = [c for c in rows_cells if len(c) > 4 and not c[4]]
print(f"金额列为空的行 {len(empty_amt)}")

# 报告里出现的金额合计与 stats.json 一致
stats = json.loads((ROOT / "stats.json").read_text(encoding="utf-8"))
print(f"\nstats 合计 {stats['amount']['total_yuan']/1e4:,.2f} 万元，报告出现次数：",
      text.count(f"{stats['amount']['total_yuan']/1e4:,.2f} 万元"))

print("\n关键要点自检：")
for token in ("统计区间为近 2 年", "金额一律归一为「元」", "未能从公告中解析出金额的记录单独计入",
              "预算 ≠ 中标", "数据说明", "局限"):
    print(f"  {token}: {'有' if token in text else '缺'}")

print("\n全文链接总数：", len(re.findall(r"\]\((https?://[^)]+)\)", text)))
print("正文长度：", len(text), "字符，", len(text.splitlines()), "行")
