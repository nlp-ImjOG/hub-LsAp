"""构建后的抽查：URL 未匹配的修正、未分类记录、金额 Top、采购人字段填充率。"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

rows = json.loads((ROOT / "records_final.json").read_text(encoding="utf-8"))

print("== 含 hjzbcg / bidding.csg 的记录 ==")
for r in rows:
    if "hjzbcg" in r["url"] or "bidding.csg" in r["url"] or "szxc" in r["url"]:
        print(f'  {r["date"]} | {r["title"][:44]} | {r["url"]}')
        print(f'      金额={r["amount_yuan"]} 证据={r["evidence"]}')

print("\n== 未分类记录 ==")
for r in rows:
    if r["direction"] == "未分类":
        print(f'  {r["date"]} | {r["title"][:50]} | {r["url"]}')
        print(f'      金额={r["amount_yuan"]} 采购人={r["buyer"][:40]!r}')

print("\n== 金额 Top 12 ==")
sized = [r for r in rows if r["amount_yuan"]]
for r in sorted(sized, key=lambda x: -x["amount_yuan"])[:12]:
    print(f'  {r["amount_yuan"]/1e4:12.2f} 万 | {r["date"]} | {r["title"][:52]}')
    print(f'      {r["url"]}')

print("\n== 无金额记录 ==")
for r in rows:
    if not r["amount_yuan"]:
        print(f'  {r["date"]} | {r["title"][:50]} | {r["note"][:60]}')

print("\n== 无日期记录 ==")
for r in rows:
    if not r["date"]:
        print(f'  {r["title"][:56]} | {r["url"]} | 金额={r["amount_yuan"]}')

print("\n== 采购人字段 ==")
empty = sum(1 for r in rows if not r["buyer"])
print(f"  空采购人 {empty} 条 / {len(rows)} 条")
for r in rows:
    if r["buyer"]:
        print(f'  {r["buyer"][:44]}')
