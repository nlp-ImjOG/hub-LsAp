"""补 3 条：江西 GEP 中选人、枣庄银行页面纯文本、几笔大额合同能源管理的原文串。"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

#: 大额合同能源管理类记录的原文串抽查
CHECK_TITLES = [
    "芜湖市湾沚区一体推进公共机构领域合同能源管理项目中标结果公告",
    "慈溪市人民医院医疗健康集团（慈溪市人民医院）三号大楼节能改造合同能源管理项目",
    "汇川区智慧路灯节能改造暨合同能源管理服务采购项目",
    "临淄城区路灯节能改造（合同能源管理）项目",
    "阳光大厦等集中办公区合同能源管理项目",
    "南沙区水资源和供节水服务项目(2026-2029年)",
]


def plain(html: str) -> list[str]:
    text = re.sub(r"<script.*?</script>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def main() -> int:
    print("== 大额合同能源管理类原文串 ==")
    all_rows = []
    for name in ("records.json", "records2.json"):
        all_rows.extend(json.loads((ROOT / name).read_text(encoding="utf-8")))
    for row in all_rows:
        if row["title"] in CHECK_TITLES:
            print(f'  {row["title"][:46]}')
            print(f'      raw={row["amount_raw"]!r}  yuan={row["amount_yuan"]}  '
                  f'src={row["extra"].get("parse_source")}  date={row["published"]}')

    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)

    print("\n" + "=" * 90)
    print("### 江西GEP 中选人")
    res = browser.fetch(
        "https://drc.jiangxi.gov.cn/jxsfzhggwyh/col/col14590/content/content_2063876380782551040.html")
    html = res.html if res and res.html else ""
    for m in re.finditer(r"中选人", html):
        chunk = re.sub(r"\s+", " ", html[max(0, m.start() - 300): m.end() + 500])
        chunk = re.sub(r"<[^>]+>", " ", chunk)
        print("  RAW:", re.sub(r"\s+", " ", chunk).strip()[:700])
        print("  ---")

    print("\n" + "=" * 90)
    print("### 枣庄银行 纯文本")
    res = browser.fetch(
        "https://www.zaozhuangbank.com/zzbank/2025-09/12/article_2025091208165779389.html")
    html = res.html if res and res.html else ""
    if not html:
        print("!! 抓取失败")
    for line in plain(html)[:80]:
        print("  >", line[:200])
    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
