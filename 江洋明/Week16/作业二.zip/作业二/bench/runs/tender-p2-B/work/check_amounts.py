"""检查解析异常：把 amount_raw / 原文里的金额串打出来核对。

用法: python check_amounts.py [记录文件.json ...]
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_news import extract_body  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

files = [a for a in sys.argv[1:] if a.endswith(".json")] or ["records.json", "records2.json"]
records = []
for name in files:
    path = ROOT / name
    if path.is_file():
        records.extend(json.loads(path.read_text(encoding="utf-8")))

config = Config.load()
config.cache_dir = ROOT / "cache"
fetcher = Fetcher(config)

for rec in records:
    print("=" * 100)
    print(f"标题: {rec['title']}")
    print(f"URL : {rec['url']}")
    print(
        f"解析: amount_yuan={rec['amount_yuan']} amount_raw={rec['amount_raw']!r} "
        f"winner={rec['winner']!r} published={rec['published']} src={rec['extra'].get('parse_source')}"
    )
    result = fetcher.fetch(rec["url"])
    if result.ok and result.html:
        body = extract_body(result.html)
        hits = re.findall(
            r"[^。；;\n]{0,70}?(?:中标|成交|金额|价|报价|单价|预算|控制价|总)[^。；;\n]{0,70}?"
            r"(?:\d[\d,，]*(?:\.\d+)?)\s*(?:亿元|万元|元|%|％)",
            body,
        )
        seen = set()
        for h in hits[:14]:
            h = re.sub(r"\s+", " ", h).strip()[:150]
            if h in seen:
                continue
            seen.add(h)
            print("   >", h)
    else:
        print("   !! 页面抓取失败:", result.error, result.status)

fetcher.close()
