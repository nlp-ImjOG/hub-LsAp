"""定点取证：对仍缺关键字段的公告，逐条把完整表格行 + <title> 打出来。

pass2.py 把长行截断到 260 字符，导致多包项目（包1..包N）看不到金额。
这里不截断，直接把整行打出来。

用法: python probe.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher, Fetcher  # noqa: E402
from esg_toolkit.parse_news import extract_body  # noqa: E402
from esg_toolkit.parse_tender import extract_rows  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

LABEL_RE = re.compile(r"中标|成交|金额|报价|单价|总价|限价|控制价|价格|预算|费用")
NUM_RE = re.compile(r"\d[\d,，]*(?:\.\d+)?")

TARGETS = [
    # (标签, url)
    ("河北碳资产包5-8", "https://ccgp-hebei.gov.cn/province/cggg/zhbgg/202507/t20250725_2230291.html"),
    ("鸡泽县", "https://ccgp-hebei.gov.cn/hd/hd_jz/cggg/zhbggAAAA/202504/t20250407_2170218.html"),
    ("宿州", "https://ggzyjy.ahsz.gov.cn/jyxx/001002/001002004/001002004001/20261110/0504a4c0-2338-4413-aed9-9bf326cf4507.html"),
    ("蚌埠", "https://ggzy.bengbu.gov.cn/jyxxgk/002002/002002009/002002009001/20251029/a5a9f814-f5d8-46d5-a82e-34ad25e1ca13.html"),
    ("池州", "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb"),
    ("苏州浦江源", "https://www.wujiang.gov.cn/zgwj/xezbxx/202511/41e7257102bc4d1fa46d06fa623738e5.shtml"),
    ("哈尔滨呼兰", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202509/t20250911_25643675.htm"),
    ("承德", "https://ccgp-hebei.gov.cn/cd/cd/cggg/zhbggAAAS/202506/t20250620_2208852.html"),
    ("江西GEP", "https://drc.jiangxi.gov.cn/jxsfzhggwyh/col/col14590/content/content_2063876380782551040.html"),
    ("色达", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202509/t20250910_25327535.htm"),
    ("石家庄", "https://ccgp-hebei.gov.cn/sjz/sjz_jjjskfq/cggg/zhbggAAAA/202501/t20250106_2130173.html"),
    ("青岛卷烟厂", "https://sdgy.tobacco.com.cn/p1/jggs/20261023/61389.html"),
    ("会泽", "https://www.ynzy-tobacco.com/c/2025-06-06/607216.shtml"),
    ("大理", "https://www.ynzy-tobacco.com/c/2025-07-01/608219.shtml"),
    ("南方电网", "https://www.bidding.csg.cn/zbxx/1200449283.jhtml"),
    ("农发行", "https://www.cfet.com.cn/cms/default/webfile/2ywgg5/20260322/1220170026951114752.html"),
    ("昌都", "http://www.ccgp-xizang.gov.cn/freecms/site/xizang/xzcggg/info/2025/151064.html"),
    ("华安证券", "https://www.ahtba.org.cn/site/trade/affiche/detail/a34a4178-e4b9-11f1-b7f6-00163e1f3e9b"),
    ("安徽GEP", "https://fzggw.ah.gov.cn/public/7011/149968421.html"),
    ("自治州", "https://www.ccgp.gov.cn/cggg/dfgg/cjgg/202501/t20250108_24036512.htm"),
    ("光大银行", "https://www.cntcitc.com.cn/more.html?chanType=3&contentId=472aead392044802812cf106506b8d6e"),
    ("重汽绿厂", "http://www.ygcgfw.com/gggs/001001/001001004/20250427/e5fdc026-5151-4006-9c47-0c72a1ea7bc7.html"),
    ("重汽绿链", "http://www.ygcgfw.com/gggs/001001/001001004/20250710/f18a0af7-489b-499e-993e-a071244dfb39.html"),
    ("天津津南", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202601/t20260108_25863718.htm"),
    ("国家能源", "https://www.chnenergybidding.com.cn/bidweb/001/001005/001005003/20250612/8887b51e-c2dc-42ea-b6f3-306d272e583b.html"),
    ("上海双碳试点", "https://www.ccgp.gov.cn/cggg/dfgg/zbgg/202512/t20251203_25836326.htm"),
]


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 3500
    fetcher = Fetcher(config)

    for label, url in TARGETS:
        print("=" * 118)
        print(f"### {label}\n### {url}")
        html = ""
        res = fetcher.fetch(url)
        if res.ok and res.html:
            html = res.html
        else:
            browser = getattr(fetcher, "_browser", None)
            if browser is None:
                browser = BrowserFetcher(config)
                fetcher._browser = browser
            br = browser.fetch(url)
            if br and br.html:
                html = br.html
        if not html:
            print("!! 抓取失败")
            continue

        t = re.search(r"<title[^>]*>(.*?)</title>", html, re.S | re.I)
        if t:
            print("TITLE:", re.sub(r"\s+", " ", t.group(1)).strip()[:160])

        shown = 0
        for cells in extract_rows(html):
            joined = " | ".join(cells)
            if not NUM_RE.search(joined) or not LABEL_RE.search(joined):
                continue
            print("ROW:", joined[:700])
            shown += 1
            if shown >= 14:
                break
        if shown == 0:
            print("(无带数字的金额相关表格行)")

        body = extract_body(html)
        n = 0
        for raw_line in body.splitlines():
            line = re.sub(r"\s+", " ", raw_line).strip()
            if not line or len(line) > 400:
                continue
            if not LABEL_RE.search(line) or not NUM_RE.search(line):
                continue
            print(">", line[:380])
            n += 1
            if n >= 12:
                break
        print("", flush=True)

    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
