"""清理 work/ 下会遮蔽标准库的模块名（inspect.py）与被 build2.py 取代的旧稿。"""

from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

for name in ("inspect.py", "build.py"):
    path = ROOT / name
    if path.is_file():
        os.remove(path)
        print("已删除", path.name)
