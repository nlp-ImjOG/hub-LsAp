"""抓取 + 解析中标公告（用 esg_toolkit 脚本层）。

流程与 Skill 规定的三级降级一致：
1. 抓公告页面 -> parse_tender_page（表格优先，正文正则兜底）
2. 页面抓不到 -> parse_tender_snippet（搜索摘要兜底）
3. 两者都失败 -> 丢弃（宁可漏，不要猜）

输出 work/records.json，每条记录带 parse_source 标明字段来自哪一级。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = (
    ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
)
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page, parse_tender_snippet  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def main() -> int:
    candidates = json.loads((ROOT / "candidates.json").read_text(encoding="utf-8"))

    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.output_dir = ROOT / "output"
    config.ensure_dirs()
    config.browser_wait_ms = 3500

    fetcher = Fetcher(config)
    records = []
    stats = {"page": 0, "snippet": 0, "failed": 0}

    for index, item in enumerate(candidates, start=1):
        url = item["url"]
        title_hint = item.get("title_hint", "")
        result = fetcher.fetch(url)

        record = None
        if result.ok and result.html:
            record = parse_tender_page(result.html, url=url, fallback_title=title_hint)

        if record is not None and (
            record.amount_yuan is not None and record.winner and record.published
        ):
            stats["page"] += 1
            source = "page"
        else:
            # 页面解析不完整（常见：字段不全 / 抓取失败），退回摘要级
            snippet_rec = parse_tender_snippet(item.get("hint", ""), url, title_hint)
            if snippet_rec is None:
                stats["failed"] += 1
                print(f"[{index}/{len(candidates)}] FAIL  {url}")
                continue
            merged = {
                "title": record.title if record and record.title else snippet_rec.title,
                "url": url,
                "buyer": (record.buyer if record and record.buyer else snippet_rec.buyer),
                "winner": (record.winner if record and record.winner else snippet_rec.winner),
                "amount_yuan": (
                    record.amount_yuan
                    if record and record.amount_yuan is not None
                    else snippet_rec.amount_yuan
                ),
                "amount_raw": (
                    record.amount_raw if record and record.amount_raw else snippet_rec.amount_raw
                ),
                "published": (
                    record.published if record and record.published else snippet_rec.published
                ),
                "package": record.package if record else snippet_rec.package,
                "province": record.province if record and record.province else snippet_rec.province,
                "category": record.category if record and record.category else snippet_rec.category,
                "extra": {**(snippet_rec.extra or {}), **(record.extra if record else {})},
            }
            # 区分「整条来自摘要」与「页面补全」
            if record is not None and record.amount_yuan is not None:
                source = "page+snippet"
            else:
                source = "snippet"
            stats["snippet"] += 1
            record = snippet_rec
            record.__dict__.update(merged)

        record.extra["parse_source"] = source
        record.extra["query_group"] = item.get("group", "")
        records.append(record.to_dict())
        print(
            f"[{index}/{len(candidates)}] {source:12s} "
            f"{(record.amount_yuan or 0)/1e4:>10.2f}万  "
            f"{(record.published or '-'):10s}  {record.title[:44]}"
        )

    (ROOT / "records.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    fetcher.close()
    print(f"\n完成：页面解析 {stats['page']} 条 / 摘要兜底 {stats['snippet']} 条 / 失败 {stats['failed']} 条")
    print(f"共 {len(records)} 条记录 -> {ROOT / 'records.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
