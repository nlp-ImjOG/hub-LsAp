"""抓取 + 解析中标公告（用 esg_toolkit 脚本层）—— 参数化版本。

用法: python collect2.py <candidates.json> <records_out.json>

三级降级（与 Skill 规定一致）：
1. 抓公告页面 -> parse_tender_page（表格优先，正文正则兜底）
2. 页面抓不到 -> parse_tender_snippet（搜索摘要兜底）
3. 两者都失败 -> 丢弃（宁可漏，不要猜）
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page, parse_tender_snippet  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def main() -> int:
    src = sys.argv[1] if len(sys.argv) > 1 else "candidates.json"
    dst = sys.argv[2] if len(sys.argv) > 2 else "records.json"
    candidates = json.loads((ROOT / src).read_text(encoding="utf-8"))

    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.output_dir = ROOT / "output"
    config.ensure_dirs()
    config.browser_wait_ms = 3500

    fetcher = Fetcher(config)
    records = []
    stats = {"page": 0, "snippet": 0, "failed": 0}

    for index, item in enumerate(candidates, start=1):
        url = item["url"]
        title_hint = item.get("title_hint", "")
        result = fetcher.fetch(url)

        page_record = None
        if result.ok and result.html:
            page_record = parse_tender_page(result.html, url=url, fallback_title=title_hint)

        if (
            page_record is not None
            and page_record.amount_yuan is not None
            and page_record.winner
            and page_record.published
        ):
            record = page_record
            source = "page"
            stats["page"] += 1
        else:
            snippet_record = parse_tender_snippet(item.get("hint", ""), url, title_hint)
            if snippet_record is None:
                stats["failed"] += 1
                print(f"[{index}/{len(candidates)}] FAIL  {url}", flush=True)
                continue
            record = snippet_record
            record.buyer = page_record.buyer if page_record and page_record.buyer else snippet_record.buyer
            record.winner = page_record.winner if page_record and page_record.winner else snippet_record.winner
            if page_record and page_record.amount_yuan is not None:
                record.amount_yuan = page_record.amount_yuan
                record.amount_raw = page_record.amount_raw
            record.published = page_record.published if page_record and page_record.published else snippet_record.published
            record.province = page_record.province if page_record and page_record.province else snippet_record.province
            record.category = page_record.category if page_record and page_record.category else snippet_record.category
            record.extra = {**(snippet_record.extra or {}), **(page_record.extra if page_record else {})}
            source = "page+snippet" if page_record is not None else "snippet"
            stats["snippet"] += 1

        record.extra["parse_source"] = source
        record.extra["query_group"] = item.get("group", "")
        records.append(record.to_dict())
        print(
            f"[{index}/{len(candidates)}] {source:12s} "
            f"{(record.amount_yuan or 0)/1e4:>10.2f}万  "
            f"{(record.published or '-'):10s}  {record.title[:44]}",
            flush=True,
        )

    (ROOT / dst).write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    fetcher.close()
    print(f"\n完成：页面解析 {stats['page']} / 摘要兜底 {stats['snippet']} / 失败 {stats['failed']}")
    print(f"共 {len(records)} 条 -> {ROOT / dst}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
