"""第十四轮：池州公告的成交供应商名称（金额已确认为 449100.00 元）。"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL_SCRIPTS = ROOT.parent / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import BrowserFetcher  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def main() -> int:
    config = Config.load()
    config.cache_dir = ROOT / "cache"
    config.browser_wait_ms = 12000
    browser = BrowserFetcher(config)
    url = "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb"
    res = browser.fetch(url)
    html = res.html if res and res.html else ""
    if not html:
        print("!! 抓取失败")
        return 1
    for m in re.finditer(r"供应商名称", html):
        lo = max(0, m.start() - 200)
        hi = min(len(html), m.end() + 700)
        chunk = re.sub(r"\s+", " ", html[lo:hi])
        chunk = re.sub(r"<[^>]+>", " ", chunk)
        chunk = re.sub(r"\s+", " ", chunk)
        print("RAW:", chunk[:900])
        print("---")
    browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
