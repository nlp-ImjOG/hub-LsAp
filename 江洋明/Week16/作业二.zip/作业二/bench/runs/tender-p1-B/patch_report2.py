#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""第二轮修正 make_report.py：

1. 采购人统计要把「未检索到」这个占位名剔掉 —— 否则"最多出现 7 次"说的其实
   是 7 条没公示采购人的公告，不是某一家甲方反复中标；
2. 「金额未披露」档的条数占比不该显示 0.00%（该档不进金额分母）；
3. 几处措辞与数字口径对齐。
"""

from __future__ import annotations

import io
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

TARGET = Path(__file__).resolve().parent / "make_report.py"
text = TARGET.read_text(encoding="utf-8")


def swap(old: str, new: str) -> None:
    global text
    if old not in text:
        raise SystemExit(f"补丁没命中：\n{old[:160]}")
    text = text.replace(old, new, 1)


# 1) 采购人统计：剔除占位名
swap(
    """buyer_counter = Counter((r.get("buyer") or "未检索到").strip() for r in records)
buyer_amount = Counter()
for record in records:
    buyer_amount[(record.get("buyer") or "未检索到").strip()] += record.get("amount_yuan") or 0
unique_buyers = len(buyer_counter)
top_buyer, top_buyer_count = buyer_counter.most_common(1)[0]""",
    """_buyer_names = [(r.get("buyer") or "").strip() for r in records]
buyer_missing = sum(1 for name in _buyer_names if not name)
buyer_counter = Counter(name for name in _buyer_names if name)
buyer_amount = Counter()
for record in records:
    name = (record.get("buyer") or "").strip()
    if name:
        buyer_amount[name] += record.get("amount_yuan") or 0
unique_buyers = len(buyer_counter)
top_buyer, top_buyer_count = buyer_counter.most_common(1)[0]""",
)

# 2) 摘要里补上"未公示采购人"的条数
swap(
    """采购人高度分散——{unique_buyers} 家去重采购人、{len(regions)} 个省级行政区，单一采购人最多只出现 {top_buyer_count} 次，说明这批需求是**区县与地市级政府各自下单**，而不是集中在少数甲方手里。""",
    """采购人高度分散——{unique_buyers} 家去重采购人（另有 {buyer_missing} 条公告没公示采购人字段）、{len(regions)} 个省级行政区，单一采购人最多只出现 {top_buyer_count} 次，说明这批需求是**区县与地市级政府各自下单**，而不是集中在少数甲方手里。""",
)

# 3) 关键要点 3：去掉硬编码的省区数、补空格
swap(
    """3. **没有"必须盯的甲方"**：{unique_buyers} 家采购人里最多的一家也只出现 {top_buyer_count} 次，25 个省区都有需求但集中在 {top_region['region']}（{top_region['count']} 条）；因此按**标的类型**筛（合同能源管理、温室气体清单、零碳园区）比按甲方筛更有效，区域上则值得单独关注{top_amount_region['region']}（{top_amount_region['count']} 条、{yuan(top_amount_region['total_yuan'])}）。""",
    """3. **没有"必须盯的甲方"**：{unique_buyers} 家采购人里最多的一家也只出现 {top_buyer_count} 次，{len(regions)} 个省区都有需求、但集中在{top_region['region']}（{top_region['count']} 条）；因此按**标的类型**筛（合同能源管理、温室气体清单、零碳园区）比按甲方筛更有效，区域上则值得单独关注{top_amount_region['region']}（{top_amount_region['count']} 条、{yuan(top_amount_region['total_yuan'])}）。""",
)

# 4) 分档表：「金额未披露」档不显示 0.00%
swap(
    """    add(
        f"| {row['bucket']} | {row['count']} | {row['ratio']:.2%} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | {row['amount_ratio']:.2%} |"
    )""",
    """    ratio_cell = "—" if row["bucket"] == "金额未披露" else f"{row['ratio']:.2%}"
    add(
        f"| {row['bucket']} | {row['count']} | {ratio_cell} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | {row['amount_ratio']:.2%} |"
    )""",
)

# 5) 1.3 的收尾句：别把标题塞进括号里
swap(
    """这 10 笔合计 {yuan(top10_sum)}，占全部已披露金额的 {top10_sum / total_yuan:.1%}。前 3 笔（{esc(top3[0]['title'][:22])}…等）就占 {top3_sum / total_yuan:.1%} —— 全部来自**生态修复 / 流域治理 / 绿色建筑改造**这类工程型标段，与前面那些几十万级的咨询类标段不是一个市场。""",
    """这 10 笔合计 {yuan(top10_sum)}，占全部已披露金额的 {top10_sum / total_yuan:.1%}；光前 3 笔就占 {top3_sum / total_yuan:.1%}。它们全部来自**生态修复 / 流域治理 / 绿色建筑改造**这类工程型标段，与前面那些几十万级的咨询类标段不是一个市场。""",
)

# 6) 2.4 的两条说明
swap(
    """- 「其他」{buyers.get('其他', 0)} 条里绝大多数是**区县级政府及其派出机构**（街道办、城管局、应急管理局、园区管委会、林场、医院、高校等）—— 采购层级下沉是这批需求的重要特征。
- {unique_buyers} 家去重采购人中，出现最多的一家也只有 {top_buyer_count} 次，**不存在单一"必跟"甲方**。""",
    """- 「其他」{buyers.get('其他', 0)} 条里，除 {buyer_missing} 条没公示采购人字段的以外，绝大多数是**区县级政府及其派出机构**（街道办、城管局、应急管理局、园区管委会、林场、医院、高校等）—— 采购层级下沉是这批需求的重要特征。
- {unique_buyers} 家去重采购人中，出现最多的一家也只有 {top_buyer_count} 次，**不存在单一"必跟"甲方**。""",
)

# 7) 局限：把"设备采购样本偏少"改成实测结论
swap(
    """2. **样本有偏**。检索词偏向咨询与规划类关键词，因此**设备采购类**（光伏、储能、充电桩）样本偏少；反过来，标题里带"零碳""温室气体"等词的咨询项目被放大。做绝对金额判断时要注意这个偏差。""",
    """2. **样本有偏**。检索词偏向咨询与规划类关键词：本样本里**设备采购类**（光伏、储能、充电桩、风电）一条都没有，反过来标题里带"零碳""温室气体"等词的咨询项目被放大。做绝对金额判断时要注意这个偏差 —— 结论适用于"咨询与技术服务类"市场，不能直接外推到设备采购。""",
)

# 8) 局限：补一条采购人缺失的说明
swap(
    """7. **样本量限制了细分的稳定性**。""",
    """7. **{buyer_missing} 条公告没公示采购人字段**，明细表里采购人写「未检索到」，采购人类型只能落在「其他」一档；这不影响金额与方向统计，但会影响"谁在买"这层判断。
8. **样本量限制了细分的稳定性**。""",
)

TARGET.write_text(text, encoding="utf-8")
print("make_report.py 第二轮补丁完成")
