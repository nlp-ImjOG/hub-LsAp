#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把 skill 的 import 挪到 RUN_DIR 定义之后（上一轮插错位置了）。"""

from __future__ import annotations

import io
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

TARGET = Path(__file__).resolve().parent / "make_report.py"
text = TARGET.read_text(encoding="utf-8")

OLD_BLOCK = """SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import AMOUNT_BUCKETS, BUYER_RULES  # noqa: E402

if hasattr(sys.stdout, "buffer"):"""

NEW_BLOCK = """if hasattr(sys.stdout, "buffer"):"""

if OLD_BLOCK not in text:
    raise SystemExit("补丁没命中（import 块）")
text = text.replace(OLD_BLOCK, NEW_BLOCK, 1)

OLD_ANCHOR = """RUN_DIR = Path(__file__).resolve().parent
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))"""

NEW_ANCHOR = """RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import AMOUNT_BUCKETS, BUYER_RULES  # noqa: E402

payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))"""

if OLD_ANCHOR not in text:
    raise SystemExit("补丁没命中（RUN_DIR 锚点）")
text = text.replace(OLD_ANCHOR, NEW_ANCHOR, 1)

TARGET.write_text(text, encoding="utf-8")
print("import 位置修正完成")
