#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""第三轮：给每张汇总表补一列「代表公告（带原始来源链接）」。

要求是"报告里的每一条内容都要有可点击的原始来源链接"——
明细表已经逐条给全了，汇总表也各挂一条代表性原文，读者不用翻到明细就能回查。
"""

from __future__ import annotations

import io
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

TARGET = Path(__file__).resolve().parent / "make_report.py"
text = TARGET.read_text(encoding="utf-8")


def swap(old: str, new: str) -> None:
    global text
    if old not in text:
        raise SystemExit(f"补丁没命中：\n{old[:160]}")
    text = text.replace(old, new, 1)


# 1) 引入 skill 的分档与采购人规则（口径不重造）
swap(
    """from collections import Counter
from datetime import date
from pathlib import Path
""",
    """from collections import Counter
from datetime import date
from pathlib import Path

SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import AMOUNT_BUCKETS, BUYER_RULES  # noqa: E402
""",
)

# 2) 加两个小工具
swap(
    """def direction_of(record: dict) -> str:
    return esc(record.get("category") or "未分类")
""",
    """def direction_of(record: dict) -> str:
    return esc(record.get("category") or "未分类")


def buyer_type(name: str) -> str:
    \"\"\"采购人类型 —— 直接用 skill 的 BUYER_RULES，报告与脚本同一套口径。\"\"\"
    for label, pattern in BUYER_RULES:
        if pattern and re.search(pattern, name):
            return label
    return "其他"


def bucket_label(value: float | None) -> str:
    if value is None:
        return "金额未披露"
    wan_value = value / 1e4
    for low, high, label in AMOUNT_BUCKETS:
        if low <= wan_value < high:
            return label
    return "金额未披露"


def representative(pool: list[dict]) -> str:
    \"\"\"一档里金额最大的一笔，带原始来源链接。\"\"\"
    if not pool:
        return "未检索到"
    best = max(pool, key=lambda r: r.get("amount_yuan") or 0)
    return f"{best['published']} {link(best)}"
""",
)

# 3) 1.1 金额分档：加「该档金额最大的一笔」
swap(
    """| 金额区间 | 公告数 | 条数占比 | 区间金额合计 | 占总金额 |
| --- | ---: | ---: | ---: | ---: |\"\"\")
for row in buckets:
    ratio_cell = "—" if row["bucket"] == "金额未披露" else f"{row['ratio']:.2%}"
    add(
        f"| {row['bucket']} | {row['count']} | {ratio_cell} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | {row['amount_ratio']:.2%} |"
    )""",
    """| 金额区间 | 公告数 | 条数占比 | 区间金额合计 | 占总金额 | 该档金额最大的一笔 |
| --- | ---: | ---: | ---: | ---: | --- |\"\"\")
for row in buckets:
    ratio_cell = "—" if row["bucket"] == "金额未披露" else f"{row['ratio']:.2%}"
    add(
        f"| {row['bucket']} | {row['count']} | {ratio_cell} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | {row['amount_ratio']:.2%} | "
        f"{representative([r for r in records if bucket_label(r.get('amount_yuan')) == row['bucket']])} |"
    )""",
)

# 4) 1.2 月度走势：加「当月金额最大的一笔」
swap(
    """| 月份 | 公告数 | 当月金额合计 |
| --- | ---: | ---: |\"\"\")
for row in trend:
    add(f"| {row['month']} | {row['count']} | {wan(row['total_yuan'])} 万元 |")""",
    """| 月份 | 公告数 | 当月金额合计 | 当月金额最大的一笔 |
| --- | ---: | ---: | --- |\"\"\")
for row in trend:
    add(
        f"| {row['month']} | {row['count']} | {wan(row['total_yuan'])} 万元 | "
        f"{representative([r for r in records if (r.get('published') or '')[:7] == row['month']])} |"
    )""",
)

# 5) 2.2 细分方向：加「金额最大的一笔」
swap(
    """add("| 细分方向 | 公告数 | 条数占比 | 金额合计 |")
add("| --- | ---: | ---: | ---: |")
for row in categories:
    add(
        f"| {row['category']} | {row['count']} | {row['ratio']:.2%} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} |"
    )""",
    """add("| 细分方向 | 公告数 | 条数占比 | 金额合计 | 金额最大的一笔 |")
add("| --- | ---: | ---: | ---: | --- |")
for row in categories:
    add(
        f"| {row['category']} | {row['count']} | {row['ratio']:.2%} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | "
        f"{representative([r for r in records if (r.get('category') or '未分类') == row['category']])} |"
    )""",
)

# 6) 2.3 地区：加「金额最大的一笔」
swap(
    """add("| 地区 | 公告数 | 金额合计 |")
add("| --- | ---: | ---: |")
for row in regions:
    add(f"| {row['region']} | {row['count']} | {wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} |")""",
    """add("| 地区 | 公告数 | 金额合计 | 金额最大的一笔 |")
add("| --- | ---: | ---: | --- |")
for row in regions:
    add(
        f"| {row['region']} | {row['count']} | {wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | "
        f"{representative([r for r in records if r.get('province') == row['region']])} |"
    )""",
)

# 7) 2.4 采购人类型：加「金额最大的一笔」
swap(
    """add("| 采购人类型 | 公告数 | 占比 |")
add("| --- | ---: | ---: |")
for name, count in buyers.items():
    add(f"| {name} | {count} | {count / len(records):.2%} |")""",
    """add("| 采购人类型 | 公告数 | 占比 | 金额最大的一笔 |")
add("| --- | ---: | ---: | --- |")
for name, count in buyers.items():
    add(
        f"| {name} | {count} | {count / len(records):.2%} | "
        f"{representative([r for r in records if buyer_type((r.get('buyer') or '').strip()) == name])} |"
    )""",
)

TARGET.write_text(text, encoding="utf-8")
print("make_report.py 第三轮补丁完成")
