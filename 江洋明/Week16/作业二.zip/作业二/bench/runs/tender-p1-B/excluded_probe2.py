#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""第二轮探测：换更宽的标签找中标人（供应商 / 名称 / 中标(成交)人 等）。

只在页面上确实写出中标人名称时才补录；写不出来就维持「未检索到」。
"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))

cache: dict[str, str] = {}
for meta_path in RUN_DIR.glob(".cache/*.meta.json"):
    data = json.loads(meta_path.read_text(encoding="utf-8"))
    html_path = meta_path.parent / (meta_path.name.replace(".meta.json", ".html"))
    if html_path.exists():
        cache[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")

LABELS = [
    "中标（成交）人", "中标(成交)人", "中标人", "成交人", "中标单位", "成交单位",
    "中标供应商", "成交供应商", "供应商名称", "中标（成交）供应商", "中标（成交）结果",
    "中标结果", "成交结果", "预中标", "第一中标候选人", "中标候选人",
]
DATE_RE = re.compile(r"20\d{2}[-/年]\s?\d{1,2}[-/月]\s?\d{1,2}")


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"[ \t\r\n]+", " ", text)


for row in payload["dropped"]["no_winner"]:
    url = row["url"]
    html = cache.get(url, "")
    print("=" * 100)
    print("URL:", url)
    if not html:
        print("  （无缓存）")
        continue
    text = flat(html)
    hits = 0
    for label in LABELS:
        for match in re.finditer(re.escape(label), text):
            hits += 1
            if hits > 4:
                break
            print(f"  [{label}]", re.sub(r"\s+", " ", text[match.start(): match.start() + 140])[:150])
        if hits > 4:
            break
    if not hits:
        print("  无中标人相关字样")
    dates = DATE_RE.findall(text)
    print("  页面里的日期串:", sorted(set(dates))[:8])
