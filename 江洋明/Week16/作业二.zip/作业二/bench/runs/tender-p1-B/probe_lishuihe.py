#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""赤水河支流石亮河项目：中标人字段抓成了表头「招标控制价（元）」，回原页看真实中标人。"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
target = next(
    r for r in payload["records"] if "石亮河" in r["title"]
)
print(target["url"])
print("当前字段:", json.dumps({k: target.get(k) for k in ("title", "buyer", "winner", "amount_yuan", "published")}, ensure_ascii=False))

html = ""
for meta_path in RUN_DIR.glob(".cache/*.meta.json"):
    data = json.loads(meta_path.read_text(encoding="utf-8"))
    if data["url"] == target["url"]:
        html = (meta_path.parent / meta_path.name.replace(".meta.json", ".html")).read_text(
            encoding="utf-8", errors="replace"
        )
        break

text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html).replace("&nbsp;", " "))
for label in ("中标人", "成交供应商", "中标（成交）人", "中标单位", "成交人", "中标结果", "第一名", "候选人", "中标候选人"):
    for match in list(re.finditer(re.escape(label), text))[:3]:
        print(f"  [{label}]", text[match.start(): match.start() + 150])
