#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""交付前体检 report.md：链接完整性、数字一致性、占位符残留。"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
report = (RUN_DIR / "report.md").read_text(encoding="utf-8")
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
records = payload["records"]
stats = payload["stats"]

problems: list[str] = []

# 1) 明细行数
detail_start = report.index("## 三、中标明细")
detail_end = report.index("## 四、")
detail = report[detail_start:detail_end]
rows = [line for line in detail.splitlines() if re.match(r"^\| \d+ \|", line)]
print(f"明细行数：{len(rows)}（语料 {len(records)} 条）")
if len(rows) != len(records):
    problems.append(f"明细行数 {len(rows)} != 语料 {len(records)}")

# 2) 每行都要有可点击链接 + 日期
urls_in_detail = []
for index, row in enumerate(rows, 1):
    cells = [cell.strip() for cell in row.strip("|").split(" | ")]
    if len(cells) != 8:
        problems.append(f"第 {index} 行列数异常：{len(cells)}")
        continue
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", cells[1]):
        problems.append(f"第 {index} 行日期格式异常：{cells[1]}")
    match = re.search(r"\[(.*?)\]\((https?://[^\s)]+)\)", cells[2])
    if not match:
        problems.append(f"第 {index} 行项目名称没有可点击链接")
    else:
        urls_in_detail.append(match.group(2))
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", cells[1]):
        problems.append(f"第 {index} 行没有日期")
    if cells[3] in ("", "None"):
        problems.append(f"第 {index} 行采购人为空（应写「未检索到」）")

print(f"明细里的链接数：{len(urls_in_detail)}，去重后 {len(set(urls_in_detail))}")
if len(urls_in_detail) != len(set(urls_in_detail)):
    problems.append("明细里有重复链接")

# 3) 明细链接 == 语料 URL（一条不漏、一条不多）
corpus_urls = {r["url"] for r in records}
detail_urls = set(urls_in_detail)
missing = corpus_urls - detail_urls
extra = detail_urls - corpus_urls
if missing:
    problems.append(f"语料里有 {len(missing)} 条没进明细：{list(missing)[:3]}")
if extra:
    problems.append(f"明细里有 {len(extra)} 条不在语料：{list(extra)[:3]}")

# 4) 正文里所有 markdown 链接都要是 http(s)
all_links = re.findall(r"\[([^\]]*)\]\(([^)]+)\)", report)
bad = [link for _, link in all_links if not link.startswith("http")]
if bad:
    problems.append(f"有 {len(bad)} 个非 http 链接：{bad[:3]}")
print(f"全文链接数：{len(all_links)}")

# 5) 汇总数字与语料一致
total_yuan = stats["amount"]["total_yuan"]
if f"{total_yuan:,.2f}" not in report:
    problems.append(f"总额 {total_yuan:,.2f} 在正文里找不到")
if str(len(records)) not in report:
    problems.append("样本量在正文里找不到")

# 6) 占位符 / 空值残留
for token in ("None", "nan", "TODO", "{}"):
    if token in report:
        problems.append(f"正文里出现可疑占位符：{token}")
if "{{" in report:
    # 第四节引用了 JS 模板串，属于有意引用，跳过
    print("提示：正文含 '{{'（第四节对 JS 模板串的引用，属有意保留）")

# 7) 每条公告的中标单位都有名字
empty_winner = [r for r in records if not (r.get("winner") or "").strip()]
if empty_winner:
    problems.append(f"语料里有 {len(empty_winner)} 条中标单位为空")

print()
if problems:
    print("发现 %d 个问题：" % len(problems))
    for item in problems:
        print("  -", item)
else:
    print("体检通过：链接、日期、行数、数字、占位符均无异常")
