#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""修正 make_report.py 里的三处表达式问题（补丁脚本，改完即可删）。"""

from __future__ import annotations

import io
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

TARGET = Path(__file__).resolve().parent / "make_report.py"
text = TARGET.read_text(encoding="utf-8")


def swap(old: str, new: str) -> None:
    global text
    if old not in text:
        raise SystemExit(f"补丁没命中：\n{old[:120]}")
    text = text.replace(old, new, 1)


# 1) 中标单位金额统计：改成正经的 Counter
swap(
    """winner_counter = Counter()
for record in records:
    name = re.sub(r"^(牵头供应商|联合体牵头人)\\s*[:：]\\s*", "", (record.get("winner") or "").strip())
    name = name.split("（联合体")[0].split("(联合体")[0].strip()
    if name:
        winner_counter[name] += 1
unique_winners = len(winner_counter)""",
    """winner_counter = Counter()
winner_amount = Counter()
for record in records:
    name = re.sub(r"^(牵头供应商|联合体牵头人)\\s*[:：]\\s*", "", (record.get("winner") or "").strip())
    name = name.split("（联合体")[0].split("(联合体")[0].strip()
    if name:
        winner_counter[name] += 1
        winner_amount[name] += record.get("amount_yuan") or 0
unique_winners = len(winner_counter)""",
)

# 2) 中标单位表：去掉临时的三元表达式
swap(
    """for name, count in winner_counter.most_common(8):
    add(f"| {esc(name)} | {count} | {wan(buyer_amount.get(name, 0)) if False else ''}{wan(sum(r.get('amount_yuan') or 0 for r in records if (r.get('winner') or '').strip().split('（联合体')[0].split('(联合体')[0].strip() == name))} 万元 |")""",
    """for name, count in winner_counter.most_common(8):
    add(f"| {esc(name)} | {count} | {wan(winner_amount[name])} 万元 |")""",
)

# 3) 局限章节里的未分类条数：直接数
swap(
    """{categories[-1]['count'] and sum(1 for r in records if not r.get('category'))} 条公告标题里没命中任何方向词""",
    """{sum(1 for r in records if not r.get('category'))} 条公告标题里没命中任何方向词""",
)

# 4) 去掉 replace 小把戏
swap(
    """- 中标方高度分散、且多为**本地化的中小技术服务商**（环保科技、检测认证、规划设计院），少数全国性机构（央信认证、责anything云系）靠"ESG 报告编制"这类标准化服务重复中标。""",
    """- 中标方高度分散、且多为**本地化的中小技术服务商**（环保科技、检测认证、规划设计院），少数全国性机构（中标合信、责任云系）靠"ESG 报告编制"这类标准化服务重复中标。""",
)
swap(
    """- 从**对手画像**看：合同能源管理类标段对手是节能服务公司，碳核算 / 清单类标段对手是检测认证与环境咨询机构，生态修复类标段对手是地方环保工程公司 —— 跨方向投标的资源不通用。
\"\"\".replace("责anything云系", "责任云系"))""",
    """- 从**对手画像**看：合同能源管理类标段对手是节能服务公司，碳核算 / 清单类标段对手是检测认证与环境咨询机构，生态修复类标段对手是地方环保工程公司 —— 跨方向投标的资源不通用。
\"\"\")""",
)

TARGET.write_text(text, encoding="utf-8")
print("make_report.py 补丁完成")
