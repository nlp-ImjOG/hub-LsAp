#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""逐条回原页核对：修正公告日期、采购人、项目名三处字段。

背景：部分页面把「招标公告」和「中标结果公告」放在同一页（同一 URL），
解析器取到的是前者（招标公告）的发布日期与标题，而中标金额来自后者。
这类记录的日期必须改成中标结果公告的发布时间，否则会落进错误的月份。
另有些页面解析不出采购人（中标公告里常只写「招标人：」）。

全部按确定性规则从原页抽取，命中即改并打印改动供复核。
"""

from __future__ import annotations

import glob
import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
BENCH_DIR = RUN_DIR.parents[1]
FIXTURE_DIR = BENCH_DIR / "fixtures"

#: 「中标结果公告 + 发布时间」——结果公告的真实发布日期
RESULT_DATE_RE = re.compile(
    r"(中标|成交|结果)(结果)?公告\s*发布时间\s*[：:]?\s*(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})"
)
#: 招标人 / 采购人 / 采购单位
BUYER_RE = re.compile(r"(招标人|采购人|采购单位|招标单位|建设单位)\s*[：:]\s*([^\s，,；;。]{4,40})")
#: 页面标题里的站点名残留
TITLE_ARTIFACT = ("公共资源交易", "监管网", "信息网", "详细页面", "交易中心", "人民政府网", "交易平台")


def load_html_map() -> dict[str, str]:
    html_map: dict[str, str] = {}
    for meta in glob.glob(str(RUN_DIR / ".cache" / "*.meta.json")):
        data = json.loads(Path(meta).read_text(encoding="utf-8"))
        html_path = Path(meta.replace(".meta.json", ".html"))
        if html_path.exists():
            html_map[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")
    manifest_path = FIXTURE_DIR / "manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in manifest:
            file_path = FIXTURE_DIR / item["file"]
            if file_path.exists():
                html_map.setdefault(
                    item["url"], file_path.read_text(encoding="utf-8", errors="replace")
                )
    return html_map


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"\s+", " ", text)


def main() -> int:
    html_map = load_html_map()
    payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))

    fixes: dict[str, dict] = {}
    for record in payload["records"]:
        html = html_map.get(record["url"], "")
        if not html:
            continue
        text = flat(html)
        patch: dict[str, str] = {}

        # 1) 日期：同一页里有结果公告时，以结果公告的发布时间为准
        hits = RESULT_DATE_RE.findall(text)
        if hits:
            _, _, year, month, day = hits[-1]
            found = f"{year}-{int(month):02d}-{int(day):02d}"
            if record["published"] and found != record["published"]:
                patch["published"] = found
                patch["published_evidence"] = (
                    f"页面同挂「中标结果公告」，其发布时间为 {found}"
                )

        # 2) 采购人：解析为空时，从「招标人/采购人/采购单位」补
        if not record.get("buyer"):
            for match in BUYER_RE.finditer(text):
                prefix = text[max(0, match.start() - 8) : match.start()]
                if "代理" in prefix:
                    continue
                value = match.group(2).strip()
                if value and not any(word in value for word in ("名称", "地址", "电话")):
                    patch["buyer"] = value
                    patch["buyer_evidence"] = f"原页字段「{match.group(1)}：{value}」"
                    break

        # 3) 标题：页面标题是站点名时，用「…中标结果公告」那句
        if any(word in record["title"] for word in TITLE_ARTIFACT):
            hit = re.search(r"([^\s]{6,60}?(?:中标|成交|结果)公告)\s*发布时间", text)
            if hit:
                patch["title"] = hit.group(1).strip()

        if patch:
            fixes[record["url"]] = patch
            print(f"{record['published']} {record['title'][:34]}")
            for key, value in patch.items():
                print(f"    {key}: {value}")
            print()

    (RUN_DIR / "record_fixes.json").write_text(
        json.dumps(fixes, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"需修正 {len(fixes)} 条 -> record_fixes.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
