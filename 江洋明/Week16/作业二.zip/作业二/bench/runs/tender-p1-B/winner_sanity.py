#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""体检：中标单位字段里混进表头/标签的记录。"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))

SUSPECT = re.compile(
    r"控制价|限价|预算|金额|名称|序号|供应商名称|中标人名称|成交供应商、成交金额|"
    r"项目名称|采购人|代理机构|报价单位|单位|元$|分$|得分|合计|总计|小计|无|/|、"
)
print("=== 可疑中标单位 ===")
for record in payload["records"]:
    winner = (record.get("winner") or "").strip()
    if not winner:
        continue
    if SUSPECT.search(winner) or len(winner) < 4 or len(winner) > 60:
        print(
            f"  {record['published']} | 疑似中标单位={winner!r} | {record['title'][:44]} | "
            f"{record['buyer'][:22]} | {record['url'][:70]}"
        )

print("\n=== 可疑标题（重复串/含表头词） ===")
for record in payload["records"]:
    title = (record.get("title") or "").strip()
    half = len(title) // 2
    if len(title) > 8 and title[:half].strip() == title[half:].strip():
        print(f"  {record['published']} | {title!r} | {record['url'][:70]}")
