#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""看这 8 个「没解析出中标人」的页面里，中标人到底写在哪。

目的是：能确定性取到就补进取值，取不到就老老实实写「未检索到」。
"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))

cache: dict[str, str] = {}
for meta_path in RUN_DIR.glob(".cache/*.meta.json"):
    data = json.loads(meta_path.read_text(encoding="utf-8"))
    html_path = meta_path.parent / (meta_path.name.replace(".meta.json", ".html"))
    if html_path.exists():
        cache[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")

WINNER_LABEL = re.compile(r"(中标[（(]?成交[）)]?人|成交[（(]?供应商|中标供应商|供应商名称|中标单位|成交单位|中标人|成交人)")
DATE_LABEL = re.compile(r"(公告发布时间|发布时间|发布日期|公示时间|成交时间|中标时间)")


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"[ \t\r\n]+", " ", text)


for row in payload["dropped"]["no_winner"]:
    url = row["url"]
    html = cache.get(url, "")
    print("=" * 100)
    print("URL:", url)
    if not html:
        print("  （无缓存）")
        continue
    text = flat(html)
    for match in list(WINNER_LABEL.finditer(text))[:6]:
        print("  中标人上下文:", re.sub(r"\s+", " ", text[match.start(): match.start() + 120])[:140])
    for match in list(DATE_LABEL.finditer(text))[:3]:
        print("  日期上下文  :", re.sub(r"\s+", " ", text[match.start(): match.start() + 60])[:80])
    if not WINNER_LABEL.search(text):
        print("  页面里没有中标人字样")
    if not DATE_LABEL.search(text):
        print("  页面里没有日期字样")
