# 脚本层调用说明（esg-tender-monitor）

> 本文件由 `作业二/scripts/build_skills.py` 自动生成，**不要手工编辑**。

## 一、输入

- **统计区间**：默认近 2 年。
- **增量监控**：与 `output/state/seen.json` 比对，只推送没推过的公告。
- **检索式**：见下方「推荐检索式」与 `references/keyword-matrix.md`。

## 二、检索

ESG 相关的招标公告分散在各级公共资源交易中心与政府采购网上，
单个站点搜不全，要按方向分多组检索式，每条取 8-10 条结果后合并去重。

### 推荐检索式

- `ESG 可持续发展 项目 中标公告`
- `双碳 碳达峰 碳中和 项目 中标公告`
- `碳足迹 温室气体 碳排放核算 项目 中标`
- `节能降碳 节能改造 合同能源管理 中标公告`
- `绿色低碳 绿色工厂 绿色园区 绿色建筑 中标公告`
- `污染防治 生态治理 生态修复 项目 中标公告`
- `绿色金融 绿色信贷 绿色债券 ESG评价 中标`
- `生态产品价值实现 GEP 碳汇 碳交易 中标`
- `水资源 节水 水务 流域治理 项目 中标公告`
- `绿色供应链 负责任采购 可持续采购 中标`

### 补充检索

结果不足时按站点补检索：

- `site:ccgp.gov.cn 双碳 中标`、`site:ggzy.gov.cn 碳达峰 中标`
- `生态环境局 中标公告 温室气体`、`公共资源交易中心 节能改造 中标`
- 按省份补：`省名 + 公共资源交易中心 + ESG/双碳/绿色 + 中标公告`


## 三、脚本层（确定性部分）

Skill 目录下的 `scripts/` 是作业二沉淀下来的确定性工具层，
它负责**可写成规则的活**：抽取、归一、去重、统计。

```bash
cd <skill 目录>
# 3. 生成汇总报告（可选：先跑脚本拿到确定性统计，再由你写说明）
python scripts/tender_report.py --years 2 --no-llm
#   产物：output/tender/esg-tender-<日期>.{md,json,html}

# 4. 生成每日增量推送
python scripts/tender_daily.py --dry-run   # 先看会推出什么
python scripts/tender_daily.py             # 推送并写状态

# 脚本层给出的确定性部分：
#   - 金额归一（单位换算）、日期归一、机构名清洗
#   - 去重（URL 规范化 + 标题归一）、省份与议题归类
#   - 金额分档、月度走势、热点方向、地区分布、采购人类型分布
# 你负责的部分：汇总说明、要点、对招标策略的解读
```

### 什么时候用脚本，什么时候自己来

| 任务 | 谁来做 | 理由 |
| --- | --- | --- |
| 抽取中标金额 | 脚本 | 单位换算规则明确，模型容易把「亿元」读成「元」 |
| 日期归一 | 脚本 | 非零填充日期是真实坑位，模型会漏 |
| 去重 | 脚本 | URL 规范化规则确定 |
| 金额分档 / 热点统计 | 脚本 | 加法与计数不该交给模型 |
| 判断这条动态对客户意味着什么 | **你** | 需要语义理解 |
| 写导语、要点、建议 | **你** | 需要语言表达 |

## 四、脚本层接口速查

| 模块 | 关键函数 | 作用 |
| --- | --- | --- |
| `esg_toolkit.parse_tender` | `parse_tender_page(html, url)` | 从公告页面解析中标记录 |
| `esg_toolkit.parse_tender` | `parse_tender_snippet(snippet, url)` | 从搜索摘要解析（页面抓不到时兜底） |
| `esg_toolkit.parse_tender` | `normalize_amount(raw, unit)` | 金额归一为「元」 |
| `esg_toolkit.parse_news` | `previous_month_window()` | 上一个自然月的时间窗 |
| `esg_toolkit.parse_news` | `dedupe(items)` | URL + 标题两级去重 |
| `esg_toolkit.aggregate` | `summarize(records)` | 一次性产出全部统计口径 |
| `esg_toolkit.render` | `render_markdown/json/html` | 三件套渲染 |
| `esg_toolkit.state` | `StateStore(path)` | 增量推送的已推送记录 |
