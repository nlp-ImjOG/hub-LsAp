#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""地区（采购人所在省级行政区）判定 —— 统一口径，每条都留证据。

判定链（先到先得，全部确定性）：
1. 公告「行政区域 / 所属地区」字段；
2. 公告「采购单位地址 / 采购人地址」里的行政区划；
3. 项目名 + 采购人名里的省份 / 地级市（skill 的 PROVINCES + CITY_TO_PROVINCE）；
4. 补充区县表（本语料里大量是县、区级采购人，skill 的市级表覆盖不到）；
5. 采购人所属集团注册地（少数总部在外省的国企采购平台）；
6. 域名线索（公网交易平台所在省）。

全部落空 → 「未检索到」，不猜。
输出 province_overrides.json，merge_report.py 直接套用。
"""

from __future__ import annotations

import glob
import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.keywords import infer_province  # noqa: E402

BENCH_DIR = RUN_DIR.parents[1]
FIXTURE_DIR = BENCH_DIR / "fixtures"

ADDRESS_LABELS = ("采购单位地址", "采购人地址", "招标人地址", "联系地址", "单位地址")
STOP_LABELS = ("联系电话", "联系方式", "联系人", "采购单位", "采购人", "代理机构", "邮编", "电子邮箱")

#: 补充区县表 —— skill 自带的 CITY_TO_PROVINCE 只覆盖地级市，本语料大量是县、区级采购人。
#: 每条都是标准行政区划归属，命中即用；冲突时以更长的县名优先。
EXTRA_PLACE_TO_PROVINCE = {
    "象山县": "浙江", "余姚市": "浙江", "慈溪市": "浙江", "江阴市": "江苏",
    "连云港市": "江苏", "盐城市": "江苏", "南通市": "江苏", "邳州市": "江苏",
    "莆田市": "福建", "铜陵市": "安徽", "铜官区": "安徽", "宿州市": "安徽",
    "宣城市": "安徽", "芜湖市": "安徽", "铜陵": "安徽", "黄山市": "安徽",
    "义乌市": "浙江", "宁波市": "浙江", "杭州市": "浙江", "嘉兴市": "浙江",
    "榆林市": "陕西", "镇安县": "陕西", "神木市": "陕西", "商洛市": "陕西",
    "屏山县": "四川", "理塘县": "四川", "江油市": "四川", "甘孜州": "四川",
    "赤峰市": "内蒙古", "松山区": "内蒙古",
    "绥化市": "黑龙江", "方正县": "黑龙江", "北林区": "黑龙江",
    "灵台县": "甘肃", "瓜州县": "甘肃", "酒泉市": "甘肃",
    "格尔木": "青海", "西宁市": "青海",
    "拜城县": "新疆", "阿克苏地区": "新疆", "巴音郭楞": "新疆", "尉犁县": "新疆",
    "阿勒泰市": "新疆", "库车市": "新疆", "新和县": "新疆", "沙湾市": "新疆",
    "伊宁市": "新疆", "沙依巴克区": "新疆",
    "郧西县": "湖北", "沙洋县": "湖北", "荆门市": "湖北", "武穴市": "湖北",
    "淮安市": "江苏", "理塘": "四川", "新和县": "新疆",
    "维西县": "云南", "昭通市": "云南", "普洱市": "云南",
    "临淄区": "山东", "青岛市": "山东", "潍坊市": "山东",
    "烟台市": "山东", "牟平区": "山东", "胶州市": "山东",
}

#: 采购人所属集团注册地（采购人本身是外省集团时，平台域名不代表采购人所在地）
ORG_TO_PROVINCE = {
    "鼎和财产保险": "广东",  # 佛山
    "南网产业": "广东",  # 广州
    "南方电网": "广东",
    "盐田港": "广东",  # 深圳
    "南方航空物流": "广东",  # 广州市东风中路 515 号（公告页页脚地址）
    "国网": "北京",  # 总部北京
    "中国邮政储蓄银行": "北京",  # 总部北京
}


def load_html_map() -> dict[str, str]:
    html_map: dict[str, str] = {}
    for meta in glob.glob(str(RUN_DIR / ".cache" / "*.meta.json")):
        data = json.loads(Path(meta).read_text(encoding="utf-8"))
        html_path = Path(meta.replace(".meta.json", ".html"))
        if html_path.exists():
            html_map[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")
    manifest_path = FIXTURE_DIR / "manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in manifest:
            file_path = FIXTURE_DIR / item["file"]
            if file_path.exists():
                html_map.setdefault(
                    item["url"], file_path.read_text(encoding="utf-8", errors="replace")
                )
    return html_map


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"\s+", " ", text)


def extract_address(text: str) -> str:
    for label in ADDRESS_LABELS:
        for match in re.finditer(re.escape(label), text):
            prefix = text[max(0, match.start() - 8) : match.start()]
            if "代理" in prefix:
                continue
            tail = text[match.end() : match.end() + 120]
            cut = len(tail)
            for stop in STOP_LABELS:
                index = tail.find(stop)
                if index != -1:
                    cut = min(cut, index)
            address = tail[:cut].strip(" ：:，,。;；")
            if len(address) >= 4:
                return address
    return ""


def match_place(text: str) -> tuple[str, str]:
    """补充区县表：最长名优先。"""
    hits = sorted(EXTRA_PLACE_TO_PROVINCE.items(), key=lambda item: -len(item[0]))
    for place, province in hits:
        if place in text:
            return province, place
    return "", ""


def main() -> int:
    html_map = load_html_map()
    payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))

    overrides: dict[str, dict] = {}
    unresolved = []
    for record in payload["records"]:
        html = html_map.get(record["url"], "")
        text = flat(html) if html else ""
        address = extract_address(text) if text else ""
        title_buyer = " ".join([record["title"], record["buyer"]])

        province, rule, evidence = "", "", ""
        region = record.get("extra", {}).get("region", "") if isinstance(record.get("extra"), dict) else ""
        if region:
            province = infer_province(region, "")
            if province:
                rule, evidence = "公告「行政区域」字段", region
        if not province and address:
            province = infer_province(address, "")
            if province:
                rule, evidence = "采购人地址字段", address[:60]
        if not province:
            province = infer_province(title_buyer, "")
            if province:
                rule, evidence = "项目名 + 采购人名", title_buyer[:60]
        if not province:
            province, place = match_place(title_buyer + " " + address)
            if province:
                rule, evidence = "补充区县表", place
        if not province:
            for org, prov in ORG_TO_PROVINCE.items():
                if org in title_buyer:
                    province, rule, evidence = prov, "采购人集团注册地", org
                    break
        if not province:
            province = infer_province("", record["url"])
            if province:
                rule, evidence = "交易平台域名", record["url"].split("/")[2]

        if province:
            overrides[record["url"]] = {
                "province": province,
                "rule": rule,
                "evidence": evidence,
            }
        else:
            unresolved.append({"title": record["title"], "buyer": record["buyer"], "url": record["url"]})

    (RUN_DIR / "province_overrides.json").write_text(
        json.dumps(overrides, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"判定成功 {len(overrides)} 条，仍未判定 {len(unresolved)} 条")
    for item in unresolved:
        print(f"- {item['title'][:40]} | {item['buyer'][:26]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
