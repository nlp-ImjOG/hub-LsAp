#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用 bench 的人工标注（ground_truth.json）回测合并后的语料。

这 32 条是人工核对过的真实公告字段（标题 / 采购人 / 中标人 / 日期 / 金额），
用来确认后面加的字段修正与金额校正没有把已经对的记录改坏。
"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
BENCH_DIR = RUN_DIR.parents[1]

truth = json.loads((BENCH_DIR / "ground_truth.json").read_text(encoding="utf-8"))
items = truth if isinstance(truth, list) else (truth.get("fixtures") or truth.get("items") or [])
print("ground truth 条数:", len(items))
if items:
    print("字段:", list(items[0].keys()))

merged = {
    record["url"]: record
    for record in json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))["records"]
}

ok = bad = missing = 0
for item in items:
    url = item.get("url")
    record = merged.get(url)
    if not record:
        missing += 1
        print("  不在合并语料:", str(url)[:80])
        continue
    diffs = []
    for key in ("title", "buyer", "winner", "published", "amount_yuan"):
        expected = item.get(key)
        actual = record.get(key)
        if expected is None and actual is None:
            continue
        if key == "amount_yuan":
            if expected is None and actual is None:
                continue
            if expected is not None and actual is not None and abs(float(expected) - float(actual)) < 0.5:
                continue
        elif str(expected).strip() == str(actual).strip():
            continue
        diffs.append(f"{key}: 真值={expected!r} 现值={actual!r}")
    if diffs:
        bad += 1
        print("  ##", item.get("published"), str(item.get("title"))[:40])
        for diff in diffs:
            print("      ", diff)
    else:
        ok += 1

print(f"\n一致 {ok} / 不一致 {bad} / 不在语料 {missing}")
