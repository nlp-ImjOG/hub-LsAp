#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""联网抓取候选中标公告，用 skill 的确定性解析器抽取字段。

用法：python fetch_live.py < urls.txt
urls.txt 每行一个 URL（可带 `|标题` 后缀）。
输出：live_records.json（抓取与解析结果）
"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

OUT = RUN_DIR / "live_records.json"

#: 统计区间（近 2 年）
SINCE = "2024-11-01"
UNTIL = "2026-11-27"


def main() -> int:
    src = Path(sys.argv[1])
    raw = [line.strip() for line in src.read_text(encoding="utf-8").splitlines()]
    targets = []
    for line in raw:
        if not line or line.startswith("#"):
            continue
        url, _, title = line.partition("|")
        targets.append((url.strip(), title.strip()))

    config = Config.load()
    config.cache_dir = RUN_DIR / ".cache"
    config.ensure_dirs()
    fetcher = Fetcher(config, use_cache=True, browser_fallback=True)

    records, failures = [], []
    for url, title in targets:
        try:
            result = fetcher.fetch(url)
        except Exception as exc:  # 单条失败不该中断整体
            failures.append({"url": url, "error": f"fetch 异常: {exc}"})
            print(f"[FAIL] {url} -> fetch 异常: {exc}")
            continue
        if not result.ok:
            failures.append({"url": url, "error": getattr(result, "error", "抓取失败")})
            print(f"[FAIL] {url} -> {getattr(result, 'error', '抓取失败')}")
            continue
        record = parse_tender_page(result.html, url=url, fallback_title=title)
        if record is None:
            failures.append({"url": url, "error": "解析不出结构化记录"})
            print(f"[SKIP] {url} -> 解析不出结构化记录")
            continue
        records.append(record.to_dict())
        print(
            f"[OK] {record.published} | {record.title} | {record.buyer} | {record.winner} | "
            f"{record.amount_yuan} | {record.category} | {record.province}"
        )

    OUT.write_text(
        json.dumps({"records": records, "failures": failures}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"\n抓取成功 {len(records)} 条 / 失败 {len(failures)} 条 -> {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
