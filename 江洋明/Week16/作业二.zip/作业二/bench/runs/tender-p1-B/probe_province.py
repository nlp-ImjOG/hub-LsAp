#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""探针：地区判定失败的记录，看看原页里有没有可用的地址线索。

地区应指采购人所在地。当前判定链是「行政区域字段 → 标题+采购人 → URL 域名」，
仍有 30 条落空。政务公告的「采购单位地址 / 采购人地址 / 采购人地址」里一般带
地级市名，可用城市→省份映射补齐 —— 这是确定性规则，不是猜。
"""

from __future__ import annotations

import glob
import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"))
from esg_toolkit.keywords import infer_province  # noqa: E402

CACHE_HTML: dict[str, str] = {}
for meta in glob.glob(str(RUN_DIR / ".cache" / "*.meta.json")):
    data = json.loads(Path(meta).read_text(encoding="utf-8"))
    html_path = Path(meta.replace(".meta.json", ".html"))
    if html_path.exists():
        CACHE_HTML[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")

ADDRESS_RE = re.compile(
    r"(?:采购单位地址|采购人地址|招标人地址|采购单位联系方式地址|单位地址)\s*[：:]\s*"
    r"([一-龥]{2,40}?(?:省|市|自治区)[一-龥0-9]{0,30}?)(?:联系电话|联系方式|$|\s{2,})"
)
REGION_RE = re.compile(r"(?:行政区域|所属地区|所属辖区|采购地区)\s*[：:]\s*([一-龥]{2,20})")


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html).replace("&nbsp;", " ")
    return re.sub(r"\s+", " ", text)


def main() -> int:
    payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
    missing = [r for r in payload["records"] if r["province"] == "未检索到"]
    print(f"地区未判定 {len(missing)} 条\n")
    for record in missing:
        html = CACHE_HTML.get(record["url"])
        found = ""
        if html:
            text = flat(html)
            for pattern in (REGION_RE, ADDRESS_RE):
                hit = pattern.search(text)
                if hit:
                    candidate = hit.group(1).strip()
                    province = infer_province(candidate, "")
                    if province:
                        found = f"{province}  <- {candidate[:28]}"
                        break
        print(f"{record['published']} {record['title'][:34]}")
        print(f"    buyer={record['buyer'][:30]} | 线索: {found or '（原页无可用地名线索）'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
