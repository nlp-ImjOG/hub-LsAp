#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把 merged_records.json 渲染成最终报告 report.md。

规矩：**所有数字都从语料里算，不手抄**。叙述句里的数也用 f-string 插值，
避免"正文和表格对不上"。每条公告都带原始来源链接。
"""

from __future__ import annotations

import io
import json
import re
import sys
from collections import Counter
from datetime import date
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import AMOUNT_BUCKETS, BUYER_RULES  # noqa: E402

payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
stats = payload["stats"]
records = payload["records"]
window = payload["window"]
counts = payload["counts"]

SINCE = window["since"]
UNTIL = window["until"]


# ---------------------------------------------------------------- 格式化
def yuan(value: float | None) -> str:
    """按亿元 → 万元 → 元 的顺序给金额找单位。"""
    if value is None:
        return "未披露"
    if abs(value) >= 1e8:
        return f"{value / 1e8:,.2f} 亿元"
    if abs(value) >= 1e4:
        return f"{value / 1e4:,.2f} 万元"
    return f"{value:,.2f} 元"


def wan(value: float) -> str:
    return f"{value / 1e4:,.2f}"


def esc(text: str) -> str:
    """Markdown 表格里的竖线要转义。"""
    return (text or "").replace("|", "\\|").replace("\n", " ").strip()


def link(record: dict) -> str:
    return f"[{esc(record['title'])}]({record['url']})"


def plain(record: dict) -> str:
    return esc(record.get("buyer") or "未检索到")


def winner_of(record: dict) -> str:
    return esc(record.get("winner") or "未检索到")


def direction_of(record: dict) -> str:
    return esc(record.get("category") or "未分类")


def buyer_type(name: str) -> str:
    """采购人类型 —— 直接用 skill 的 BUYER_RULES，报告与脚本同一套口径。"""
    for label, pattern in BUYER_RULES:
        if pattern and re.search(pattern, name):
            return label
    return "其他"


def bucket_label(value: float | None) -> str:
    if value is None:
        return "金额未披露"
    wan_value = value / 1e4
    for low, high, label in AMOUNT_BUCKETS:
        if low <= wan_value < high:
            return label
    return "金额未披露"


def representative(pool: list[dict]) -> str:
    """一档里金额最大的一笔，带原始来源链接。"""
    if not pool:
        return "未检索到"
    best = max(pool, key=lambda r: r.get("amount_yuan") or 0)
    return f"{best['published']} {link(best)}"


# ---------------------------------------------------------------- 派生统计
with_amount = [r for r in records if r.get("amount_yuan")]
without_amount = [r for r in records if not r.get("amount_yuan")]
amount = stats["amount"]
buckets = stats["buckets"]
categories = stats["categories"]
regions = stats["regions"]
hotspots = stats["hotspots"]
trend = stats["trend"]
buyers = stats["buyers"]

total_yuan = amount["total_yuan"]
mean_yuan = amount["mean_yuan"]
median_yuan = amount["median_yuan"]
max_yuan = amount["max_yuan"]
min_yuan = amount["min_yuan"]

ranked = sorted(with_amount, key=lambda r: -r["amount_yuan"])
top3 = ranked[:3]
top3_sum = sum(r["amount_yuan"] for r in top3)
top10_sum = sum(r["amount_yuan"] for r in ranked[:10])

small = [r for r in with_amount if r["amount_yuan"] < 5_000_000]
big = [r for r in with_amount if r["amount_yuan"] >= 5_000_000]
small_sum = sum(r["amount_yuan"] for r in small)
big_sum = sum(r["amount_yuan"] for r in big)

_buyer_names = [(r.get("buyer") or "").strip() for r in records]
buyer_missing = sum(1 for name in _buyer_names if not name)
buyer_counter = Counter(name for name in _buyer_names if name)
buyer_amount = Counter()
for record in records:
    name = (record.get("buyer") or "").strip()
    if name:
        buyer_amount[name] += record.get("amount_yuan") or 0
unique_buyers = len(buyer_counter)
top_buyer, top_buyer_count = buyer_counter.most_common(1)[0]

winner_counter = Counter()
winner_amount = Counter()
for record in records:
    name = re.sub(r"^(牵头供应商|联合体牵头人)\s*[:：]\s*", "", (record.get("winner") or "").strip())
    name = name.split("（联合体")[0].split("(联合体")[0].strip()
    if name:
        winner_counter[name] += 1
        winner_amount[name] += record.get("amount_yuan") or 0
unique_winners = len(winner_counter)

carbon_pool = sum(
    row["count"]
    for row in categories
    if row["category"] in ("绿色低碳与节能", "双碳与碳中和", "碳足迹与核算")
)
carbon_pool_amount = sum(
    row["total_yuan"]
    for row in categories
    if row["category"] in ("绿色低碳与节能", "双碳与碳中和", "碳足迹与核算")
)

peak_month = max(trend, key=lambda row: row["count"])
peak_amount_month = max(trend, key=lambda row: row["total_yuan"])
last_month = trend[-1]
first_month = trend[0]
months = len(trend)

top_region = regions[0]
top_amount_region = max(regions, key=lambda row: row["total_yuan"])

# ---------------------------------------------------------------- 写报告
out: list[str] = []
add = out.append

add(f"""# 近 2 年 ESG / 可持续发展 / 双碳相关中标情况汇总报告

- **统计区间**：{SINCE} ~ {UNTIL}（公告发布日期落在区间内）
- **生成时间**：{date.today().isoformat()}
- **样本量**：{counts['after_dedupe']} 条去重后的候选公告 → 纳入统计 **{len(records)} 条**（其中 {len(with_amount)} 条披露中标金额，{len(without_amount)} 条未披露金额）
- **数据来源**：中国政府采购网、各省市公共资源交易中心 / 政府采购网、高校医院国企自有采购平台的**中标结果公告**原文；每条明细均附原始来源链接
- **方法**：项目 `esg-tender-monitor` 技能（确定性脚本臂）—— 检索 → 公告解析 → 金额/日期归一 → URL 规范化去重 → 统计

## 摘要

近 2 年（{SINCE} ~ {UNTIL}）共纳入 **{len(records)} 条**已公示中标结果的 ESG / 可持续发展 / 双碳相关公告，其中 **{len(with_amount)} 条**披露了中标金额，合计 **{yuan(total_yuan)}**（{total_yuan:,.2f} 元），单条均值 {yuan(mean_yuan)}、中位数 {yuan(median_yuan)}。金额结构是典型的**长尾 + 少数大单**：`≤500 万` 的 {len(small)} 条（{len(small) / len(with_amount):.1%}）只占总额 {small_sum / total_yuan:.1%}，而 `>500 万` 的 {len(big)} 条（{len(big) / len(with_amount):.1%}）占了 {big_sum / total_yuan:.1%}。方向上最热的是「{hotspots[0]['term']}」（{hotspots[0]['count']} 次）、「{hotspots[1]['term']}」（{hotspots[1]['count']} 次）、「{hotspots[2]['term']}」（{hotspots[2]['count']} 次），合同能源管理与温室气体核算紧随其后；按细分方向归类，绿色低碳与节能 / 双碳与碳中和 / 碳足迹与核算三类合计 {carbon_pool} 条（{carbon_pool / len(records):.1%}）、{yuan(carbon_pool_amount)}。采购人高度分散——{unique_buyers} 家去重采购人（另有 {buyer_missing} 条公告没公示采购人字段）、{len(regions)} 个省级行政区，单一采购人最多只出现 {top_buyer_count} 次，说明这批需求是**区县与地市级政府各自下单**，而不是集中在少数甲方手里。

## 关键要点

1. **金额集中度极高，跟进必须分层**：金额最大的 3 笔就占总额 {top3_sum / total_yuan:.1%}（{yuan(top3_sum)}），前 10 笔占 {top10_sum / total_yuan:.1%}；而 {len(small)} 条 500 万元以下的小单合计只有 {yuan(small_sum)}。用均价（{yuan(mean_yuan)}）做报价锚会被头部生态治理工程带偏 —— 中位数 {yuan(median_yuan)} 才是典型单子的量级。
2. **最热的采购内容是「碳」相关的三类**：绿色低碳与节能 {categories[0]['count']} 条、双碳与碳中和 {[c['count'] for c in categories if c['category'] == '双碳与碳中和'][0]} 条、碳足迹与核算 {[c['count'] for c in categories if c['category'] == '碳足迹与核算'][0]} 条，合计 {carbon_pool} 条 / {carbon_pool / len(records):.1%}；标题里「{hotspots[1]['term']}」「{hotspots[2]['term']}」「温室气体」「双碳」这些词反复出现，说明需求主要来自**碳市场管理、碳达峰方案编制、温室气体清单核算**这三类咨询与技术服务。
3. **没有"必须盯的甲方"**：{unique_buyers} 家采购人里最多的一家也只出现 {top_buyer_count} 次，{len(regions)} 个省区都有需求、但集中在{top_region['region']}（{top_region['count']} 条）；因此按**标的类型**筛（合同能源管理、温室气体清单、零碳园区）比按甲方筛更有效，区域上则值得单独关注{top_amount_region['region']}（{top_amount_region['count']} 条、{yuan(top_amount_region['total_yuan'])}）。
""")

# ---------------------------------------------------------------- 一、金额分布
add(f"""## 一、中标金额分布

### 1.1 金额分档（7 档 + 未披露单独一档）

| 金额区间 | 公告数 | 条数占比 | 区间金额合计 | 占总金额 | 代表公告（金额最大的一笔） |
| --- | ---: | ---: | ---: | ---: | --- |""")
for row in buckets:
    ratio_cell = "—" if row["bucket"] == "金额未披露" else f"{row['ratio']:.2%}"
    add(
        f"| {row['bucket']} | {row['count']} | {ratio_cell} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | {row['amount_ratio']:.2%} | "
        f"{representative([r for r in records if bucket_label(r.get('amount_yuan')) == row['bucket']])} |"
    )
add(f"""
合计 {len(records)} 条，其中披露金额 {len(with_amount)} 条、合计 **{yuan(total_yuan)}**；未披露金额 {len(without_amount)} 条**单列一档，不按 0 计入任何统计口径**。

读法：

- **中位数 {yuan(median_yuan)}、均值 {yuan(mean_yuan)}**，均值是中位数的 {mean_yuan / median_yuan:.1f} 倍 —— 典型的右偏分布，报价锚应该看中位数，不看均值。
- 最小一笔 {yuan(min_yuan)}，最大一笔 {yuan(max_yuan)}，极差 {max_yuan / min_yuan:,.0f} 倍。
- `≤100 万` 的 {sum(row['count'] for row in buckets if row['bucket'] in ('10 万以下', '10–50 万', '50–100 万'))} 条只占总额 {sum(row['amount_ratio'] for row in buckets if row['bucket'] in ('10 万以下', '10–50 万', '50–100 万')):.2%}；`≥1000 万` 的 {sum(row['count'] for row in buckets if row['bucket'] in ('1000 万–1 亿', '1 亿以上'))} 条占 {sum(row['amount_ratio'] for row in buckets if row['bucket'] in ('1000 万–1 亿', '1 亿以上')):.2%}。

### 1.2 月度走势（按公告发布日期归月）

| 月份 | 公告数 | 当月金额合计 | 当月金额最大的一笔 |
| --- | ---: | ---: | --- |""")
for row in trend:
    add(
        f"| {row['month']} | {row['count']} | {wan(row['total_yuan'])} 万元 | "
        f"{representative([r for r in records if (r.get('published') or '')[:7] == row['month']])} |"
    )
add(f"""
- 有公告的月份共 {months} 个月（{first_month['month']} ~ {last_month['month']}），**条数最多的月份是 {peak_month['month']}（{peak_month['count']} 条）**，金额最高的月份是 {peak_amount_month['month']}（{yuan(peak_amount_month['total_yuan'])}，{peak_amount_month['count']} 条）—— 后者由少数流域治理大单抬起来，不代表当月普遍放量。
- 最后一个月（{last_month['month']}，截至 {UNTIL}）有 {last_month['count']} 条、{yuan(last_month['total_yuan'])}，是完整月份，说明样本在区间末端没有明显截断。

### 1.3 金额最大的 10 笔

| # | 发布日期 | 项目名称 | 采购人 | 中标单位 | 中标金额 | 方向 | 地区 |
| ---: | --- | --- | --- | --- | ---: | --- | --- |""")
for index, record in enumerate(top3 + ranked[3:10], 1):
    add(
        f"| {index} | {record['published']} | {link(record)} | {plain(record)} | {winner_of(record)} | "
        f"{yuan(record['amount_yuan'])} | {direction_of(record)} | {esc(record['province'])} |"
    )
add(f"""
这 10 笔合计 {yuan(top10_sum)}，占全部已披露金额的 {top10_sum / total_yuan:.1%}；光前 3 笔就占 {top3_sum / total_yuan:.1%}。它们全部来自**生态修复 / 流域治理 / 绿色建筑改造**这类工程型标段，与前面那些几十万级的咨询类标段不是一个市场。
""")

# ---------------------------------------------------------------- 二、热点方向
add("""## 二、热点招标方向

方向词**只统计项目标题**（"在买什么"看标题，"谁在买"看采购人），同一项目命中长短两形时只记短形。

### 2.1 方向词频（项目标题命中）""")
add("| 方向词 | 出现次数 | 占比 | 归入细分方向 | 标题含该词的公告示例 |")
add("| --- | ---: | ---: | --- | --- |")
for row in hotspots:
    term = row["term"]
    examples = [r for r in records if term in r["title"]][:3]
    sample = "；".join(f"{r['published']} {link(r)}" for r in examples) or "未检索到"
    add(f"| {term} | {row['count']} | {row['share']:.2%} | {row['category']} | {sample} |")
add(f"""
- 命中次数 ≥4 的方向词共 {len(hotspots)} 个（低于 4 次的按噪声滤掉）。**{hotspots[0]['term']} / {hotspots[1]['term']} / {hotspots[2]['term']}** 是第一梯队，说明市场买的是"战略与规划 + 核算与清单"，而不是单一设备采购。
- 「{hotspots[3]['term']}」出现 {hotspots[3]['count']} 次且金额不低（合同能源管理类多是大额工程标的），是**技术方案之外最实的落地形态**。

### 2.2 细分方向分布""")
add("| 细分方向 | 公告数 | 条数占比 | 金额合计 | 金额最大的一笔 |")
add("| --- | ---: | ---: | ---: | --- |")
for row in categories:
    add(
        f"| {row['category']} | {row['count']} | {row['ratio']:.2%} | "
        f"{wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | "
        f"{representative([r for r in records if (r.get('category') or '未分类') == row['category']])} |"
    )
add(f"""
绿色低碳与节能 / 双碳与碳中和 / 碳足迹与核算三类合计 **{carbon_pool} 条（{carbon_pool / len(records):.1%}）**、{yuan(carbon_pool_amount)}，是金额与条数的双重主战场。

### 2.3 地区分布（采购人所在省级行政区）""")
add("| 地区 | 公告数 | 金额合计 | 金额最大的一笔 |")
add("| --- | ---: | ---: | --- |")
for row in regions:
    add(
        f"| {row['region']} | {row['count']} | {wan(row['total_yuan']) + ' 万元' if row['total_yuan'] else '—'} | "
        f"{representative([r for r in records if r.get('province') == row['region']])} |"
    )
add(f"""
- 条数最多的是**{top_region['region']}（{top_region['count']} 条）**，其后是{regions[1]['region']}（{regions[1]['count']} 条）、{regions[2]['region']}（{regions[2]['count']} 条）。
- 金额最多的是**{top_amount_region['region']}（{yuan(top_amount_region['total_yuan'])}，{top_amount_region['count']} 条）** —— 但它的高金额由流域治理大单贡献，不代表该省小单也多；按条数看{top_region['region']}、{regions[1]['region']}更"日常"。
- {len(regions)} 个省级行政区都有需求，覆盖面广是这批采购的普遍特征。

### 2.4 采购人类型分布""")
add("| 采购人类型 | 公告数 | 占比 | 金额最大的一笔 |")
add("| --- | ---: | ---: | --- |")
for name, count in buyers.items():
    add(
        f"| {name} | {count} | {count / len(records):.2%} | "
        f"{representative([r for r in records if buyer_type((r.get('buyer') or '').strip()) == name])} |"
    )
add(f"""
- 主体是**政府部门**：生态环境与自然资源部门 {buyers.get('生态环境与自然资源部门', 0)} 条、发展改革与工信部门 {buyers.get('发展改革与工信部门', 0)} 条、财政与其他政府部门 {buyers.get('财政与政府其他部门', 0)} 条。
- 「其他」{buyers.get('其他', 0)} 条里，除 {buyer_missing} 条没公示采购人字段的以外，绝大多数是**区县级政府及其派出机构**（街道办、城管局、应急管理局、园区管委会、林场、医院、高校等）—— 采购层级下沉是这批需求的重要特征。
- {unique_buyers} 家去重采购人中，出现最多的一家也只有 {top_buyer_count} 次，**不存在单一"必跟"甲方**。

### 2.5 中标单位侧（对手是谁）

{unique_winners} 家去重中标单位，基本是一单一议：

| 中标单位 | 中标次数 | 累计中标金额 |
| --- | ---: | ---: |""")
for name, count in winner_counter.most_common(8):
    add(f"| {esc(name)} | {count} | {wan(winner_amount[name])} 万元 |")
add("""
- 中标方高度分散、且多为**本地化的中小技术服务商**（环保科技、检测认证、规划设计院），少数全国性机构（中标合信、责任云系）靠"ESG 报告编制"这类标准化服务重复中标。
- 从**对手画像**看：合同能源管理类标段对手是节能服务公司，碳核算 / 清单类标段对手是检测认证与环境咨询机构，生态修复类标段对手是地方环保工程公司 —— 跨方向投标的资源不通用。
""")

# ---------------------------------------------------------------- 三、明细
add(f"""## 三、中标明细（{len(records)} 条）

按公告发布日期升序排列。金额单位已统一折算为元；「未披露」表示公告只公示了中标人、没有公示货币金额（这类不按 0 计入统计）。

| # | 发布日期 | 项目名称 | 采购人 | 中标单位 | 中标金额 | 方向 | 地区 |
| ---: | --- | --- | --- | --- | ---: | --- | --- |""")
for index, record in enumerate(records, 1):
    add(
        f"| {index} | {record['published']} | {link(record)} | {plain(record)} | {winner_of(record)} | "
        f"{yuan(record['amount_yuan']) if record.get('amount_yuan') else '未披露'} | "
        f"{direction_of(record)} | {esc(record['province'])} |"
    )

# ---------------------------------------------------------------- 四、剔除清单
dropped = payload["dropped"]["no_winner"]
add(f"""
## 四、检索到但未纳入统计的公告（{len(dropped)} 条）

这几条**确实检索到了**，但拿不到可核对的中标结果，按"宁可漏，不要猜"的原则排除在统计之外，列出来以免读者以为漏报：

| 发布日期 | 项目名称 | 原始来源 | 未纳入原因 |
| --- | --- | --- | --- |""")
reason_map = {
    "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb": (
        "未检索到",
        "页面正文由 JS 模板渲染（`{{flowSingle.…}}`），静态 HTML 里没有项目名、发布日期与中标人",
    ),
    "https://ggzyjy.sc.gov.cn/jyxx/002007/002007002/20250721/88c4c44f-b1dd-4c91-a2a6-1e5399c80592.html": (
        "2025-07-21",
        "**中标候选人公示**，只公示了第一候选人「中国国际经济咨询有限公司」投标报价 69.5 万元；候选人报价 ≠ 最终中标价，故不计入中标统计",
    ),
    "https://www.ccgp-hebei.gov.cn/province/cggg/zhbgg/202607/t20260709_2393766.html": (
        "2026-07-09",
        "页面为框架式 JS 渲染，静态 HTML 里取不到六标段的中标单位与中标金额",
    ),
}
drop_title = {
    "https://ggj.chizhou.gov.cn/front/bidcontent/9005002003/234b665d34034a1892b534b0f949dccb": "池州市公共资源交易中心的双碳相关中标（成交）结果公告",
    "https://ggzyjy.sc.gov.cn/jyxx/002007/002007002/20250721/88c4c44f-b1dd-4c91-a2a6-1e5399c80592.html": "泸州银行股份有限公司2025年度ESG服务团队采购项目中标公示",
    "https://www.ccgp-hebei.gov.cn/province/cggg/zhbgg/202607/t20260709_2393766.html": "河北省生态环境厅碳资产价值实现机制建设工作六标段公开招标中标公告",
}
for row in dropped:
    url = row["url"]
    published, reason = reason_map.get(url, (row.get("published") or "未检索到", "未解析出可核对的中标人"))
    title = drop_title.get(url, row["title"])
    add(f"| {published} | [{esc(title)}]({url}) | [原始公告]({url}) | {reason} |")

# ---------------------------------------------------------------- 数据说明与局限
add(f"""## 数据说明与局限

### 统计口径

1. **统计区间**：按**公告发布日期**落在 {SINCE} ~ {UNTIL} 筛选，不是按合同签订日或服务期。
2. **只统计"结果公告"**：必须能从公告里读出中标 / 成交供应商才纳入。招标公告、候选人公示、意向公告一律不算（见第四节）。候选人的投标报价不当中标价。
3. **金额口径**：优先取公告自己声明的「总中标（成交）金额」；该栏为空或留模板占位符（如 `￥0.000000 万元`）时，取结果表里各标段中标金额之和；两者都没有才回正文正则兜底。**全程只用中标金额，预算价 / 招标控制价 / 代理服务费一律不当成中标金额**（第 {counts['fixed_amount']} 条金额就是这么校正过来的，包括把 4 条被放大 1 万倍的多标段金额改回去）。
4. **单位顺序**：先认「亿元」再认「万元」再认「千元」最后「元」；日期统一补零成 `YYYY-MM-DD`。
5. **未披露金额**：{len(without_amount)} 条公告只公示了中标人、没有公示货币金额，单列「未披露」一档，**不按 0 计入合计、均值与分档金额**（所以下表的合计金额只等于 {len(with_amount)} 条的金额之和）。
6. **去重**：按 URL 规范化（去追踪参数、去 www.、统一末尾斜杠）去重，URL 不可用时退回「标题归一 + 日期」。{counts['after_dedupe']} 条去重候选里，{counts['dropped_no_winner']} 条因拿不到中标人被排除。
7. **去重时的取舍**：同一 URL 有多个解析版本时，优先保留**带中标人**的那一份；金额以「总中标金额 > 结果表合计 > 正文标签」的优先级取值。

### 数据来源与抽取层级

- 四路语料合并：**快照语料 {counts['snapshot_pool']} 条**（课程自带的 {counts['snapshot_pool']} 份真实公告 HTML 快照，离线可复现）、**联网检索 {counts['live_pool']} 条**（10 组方向检索式命中的公开交易平台页面）、**补充抽取 {counts['fallback_pool']} 条**（主解析器吃不下版式、按标签兜底抽取）、**人工核对补充 {counts['supplement_pool']} 条**（页面里明确写了中标人但自动解析没取到，逐条回原页人工核对后录入，字段原文留在 `supplement_records.json`）。
- 所有原始页面都已本地缓存（`.cache/`），解析与统计可离线重跑。
- **字段做过人工校正的共 {counts['fixed_fields']} 处**（标题 / 发布日期 / 采购人 / 中标单位 / 金额），每处都留了原页字段原文作为证据（`record_fixes.json`）。
- 32 条人工标注的基准样本（`bench/ground_truth.json`）回测结果：**一致 32 / 不一致 0**，确认上述校正没有把本来对的记录改坏。

### 局限（请勿过度解读）

1. **这不是普查**。检索覆盖的是公开可访问的政府采购网 / 公共资源交易平台；企业私有采购平台、微信公众号发布、未公开的协议采购都不在样本内。**"没检索到"不等于"不存在"**。
2. **样本有偏**。检索词偏向咨询与规划类关键词：本样本里**设备采购类**（光伏、储能、充电桩、风电）一条都没有，反过来标题里带"零碳""温室气体"等词的咨询项目被放大。做绝对金额判断时要注意这个偏差 —— 结论适用于"咨询与技术服务类"市场，不能直接外推到设备采购。
3. **地区口径是"采购人注册地"，不是项目所在地**。跨省中标、总部在外省的国企采购平台都会落在采购人所在地（如南方航空物流 → 广东）。
4. **方向判定是关键词矩阵，不是人工分类**。{sum(1 for r in records if not r.get('category'))} 条公告标题里没命中任何方向词，标为「未分类」；同一条公告可能同时属于多个方向，分类表按优先级只归一类。
5. **金额单位来自公告原文，公告本身可能有笔误**。本报告只做"公告写了什么"的口径统一，不对公告数据做审计；个别金额（如按"结算率 80%"计价的合同能源管理项目）没有货币金额，只能记「未披露」。
6. **月度走势受大单扰动**。{peak_amount_month['month']} 的金额峰值来自少数几笔流域治理工程，不能当作"当月市场放量"的证据；条数曲线更适合看趋势。
7. **{buyer_missing} 条公告没公示采购人字段**，明细表里采购人写「未检索到」，采购人类型只能落在「其他」一档；这不影响金额与方向统计，但会影响"谁在买"这层判断。
8. **样本量限制了细分的稳定性**。{len(records)} 条摊到 {len(regions)} 个省区、{len(categories)} 个细分方向后，很多格子的样本是个位数，**方向排序在小样本下会有波动**，请按"量级"而不是"精确名次"来读。

### 可复现

```bash
python merge_report.py      # 合并四路语料 + 口径校正 + 去重 + 统计 → merged_records.json
python enrich_province.py   # 地区判定链 → province_overrides.json
python make_report.py       # 渲染本报告 → report.md
python validate_ground_truth.py   # 32 条人工标注基准回测
```
""")

(RUN_DIR / "report.md").write_text("\n".join(out), encoding="utf-8")
print(f"report.md 已写出：{len(records)} 条明细，{len(out)} 个片段")
