#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""对照检查：表格抽取的金额 与 解析器给的金额 差在哪。

差得离谱的（差 1e4 倍、或一个当元一个当万元）就是真错，必须改；
量级一致的差异留给人工判断。
"""

from __future__ import annotations

import glob
import io
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUN_DIR))
from table_amount import table_amount  # noqa: E402

BENCH_DIR = RUN_DIR.parents[1]
FIXTURE_DIR = BENCH_DIR / "fixtures"


def load_html_map() -> dict[str, str]:
    html_map: dict[str, str] = {}
    for meta in glob.glob(str(RUN_DIR / ".cache" / "*.meta.json")):
        data = json.loads(Path(meta).read_text(encoding="utf-8"))
        html_path = Path(meta.replace(".meta.json", ".html"))
        if html_path.exists():
            html_map[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")
    manifest_path = FIXTURE_DIR / "manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in manifest:
            file_path = FIXTURE_DIR / item["file"]
            if file_path.exists():
                html_map.setdefault(
                    item["url"], file_path.read_text(encoding="utf-8", errors="replace")
                )
    return html_map


def main() -> int:
    html_map = load_html_map()
    payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
    diffs = 0
    for record in payload["records"]:
        html = html_map.get(record["url"], "")
        if not html:
            continue
        table_value, evidence = table_amount(html)
        if not table_value:
            continue
        current = record.get("amount_yuan")
        if current and abs(table_value - current) < 0.5:
            continue
        diffs += 1
        ratio = (table_value / current) if current else 0
        flag = "  <<< 量级不符" if (current and (ratio > 100 or ratio < 0.01)) else ""
        print(f"{record['published']} {record['title'][:38]}")
        print(f"    解析器={current}  表格={table_value}  比值={ratio:.6g}{flag}")
        print(f"    证据：{evidence[:110]}")
        print(f"    {record['url'][:90]}")
    print(f"\n共 {diffs} 条与表格抽取不一致")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
