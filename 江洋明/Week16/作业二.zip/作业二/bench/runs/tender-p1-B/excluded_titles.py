#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""为「被剔除」的那 8 条补一个可读的项目名（页面 <title> / 标题标签）。

主解析器在这 8 个页面上吃不到项目名，只拿到表头串或模板串，
报告里不能直接甩 "{{flowSingle...}}" 给读者，所以回原页取页面标题。
"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))

cache: dict[str, str] = {}
for meta_path in RUN_DIR.glob(".cache/*.meta.json"):
    data = json.loads(meta_path.read_text(encoding="utf-8"))
    html_path = meta_path.with_suffix("").with_suffix(".html")
    if html_path.exists():
        cache[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")


def page_title(html: str) -> str:
    match = re.search(r"<title[^>]*>(.*?)</title>", html, re.S | re.I)
    if not match:
        return ""
    text = re.sub(r"<[^>]+>", " ", match.group(1))
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"\s+", " ", text).strip()


def headings(html: str) -> list[str]:
    out = []
    for match in re.finditer(r"<h[1-3][^>]*>(.*?)</h[1-3]>", html, re.S | re.I):
        text = re.sub(r"<[^>]+>", " ", match.group(1))
        text = text.replace("&nbsp;", " ").replace("&amp;", "&")
        text = re.sub(r"\s+", " ", text).strip()
        if text:
            out.append(text)
    return out


for row in payload["dropped"]["no_winner"]:
    url = row["url"]
    html = cache.get(url, "")
    print(f"URL   : {url}")
    print(f"解析标题: {row['title']}")
    print(f"页面title: {page_title(html)[:120] if html else '（无缓存页）'}")
    for text in headings(html)[:4]:
        print(f"  h*: {text[:120]}")
    print()
