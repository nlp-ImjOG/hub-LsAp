#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""补充抽取层：处理主解析器没覆盖到的页面版式，并做字段清洗。

清洗规则全是确定性的：
- 标签与取值之间允许空白 / 换行（政务站点常把「中标价：」和数字放在不同 span 里）；
- 中标人串里出现「中标人地址 / 中标价格 / 项目 / 地址」等后续标签时截断；
- 中标人以「（金额元）」结尾时把金额拆出来、中标人去掉括号尾巴；
- 中标人本身就是标签（如「中标价（结算率）」）判为无效；
- 「中标通知书」版式：``项目编码：XXX <公司名> ：你方于…`` 的固定结构；
- 大写金额（壹拾陆万捌仟元整）按数位规则换算。

抽不出来的字段留空 —— 不猜。输出 fallback_records.json，人工核对后再并入语料。
"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

from bs4 import BeautifulSoup

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_tender import normalize_amount  # noqa: E402

WINNER_LABELS = (
    "中标人名称", "中标人", "中标单位", "成交人", "成交供应商", "成交供应商名称",
    "中标供应商", "中标供应商名称", "中标成交供应商", "中标成交供应商名称",
    "供应商名称", "成交结果", "定标/成交结果", "定标成交结果", "第一中标候选人",
    "中标候选人", "候选人名称", "成交供应商名",
)

AMOUNT_LABELS = (
    "中标金额", "成交金额", "中标（成交）金额", "中标(成交)金额", "中标成交金额",
    "中标价格", "中标价", "成交价", "中标（成交）价格", "合同金额", "成交金额（元）",
    "中标价格（元）", "中标价格(元)", "中标金额（元）", "中标金额(元)", "中标金额(万元)",
)

WINNER_STOP = ("中标人地址", "中标价格", "中标金额", "中标人", "地址", "联系方式", "项目编号", "工期")

TRAILING_AMOUNT = re.compile(r"（\s*([\d,，.]+)\s*元\s*）\s*$")

CN_DIGITS = {
    "零": 0, "壹": 1, "贰": 2, "叁": 3, "肆": 4, "伍": 5, "陆": 6,
    "柒": 7, "捌": 8, "玖": 9,
}
CN_UNITS = {"拾": 10, "佰": 100, "仟": 1000}
CN_BIG = {"万": 10**4, "亿": 10**8}

ORG_SUFFIX = r"(?:有限责任公司|有限公司|集团公司|设计院|研究院|研究院有限公司|中心|事务所|公司|集团|院|所|厂|局)"


def norm_label(text: str) -> str:
    return re.sub(r"[\s:：()（）\[\]【】]", "", text or "")


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def parse_cn_amount(text: str) -> float | None:
    """大写金额 → 数字。``壹拾陆万捌仟元整`` → 168000。"""
    if not text:
        return None
    body = text.split("元")[0]
    if "角" in body or "分" in body or not body:
        return None
    total = section = number = 0
    for char in body:
        if char in CN_DIGITS:
            number = CN_DIGITS[char]
        elif char in CN_UNITS:
            section += (number or 1) * CN_UNITS[char]
            number = 0
        elif char in CN_BIG:
            total += (section + number) * CN_BIG[char]
            section = number = 0
        elif char in "整元":
            continue
        else:
            return None
    total += section + number
    return float(total) if total else None


def tidy_winner(raw: str) -> tuple[str, float | None]:
    value = clean(raw)
    amount = None
    match = TRAILING_AMOUNT.search(value)
    if match:
        amount = float(match.group(1).replace(",", "").replace("，", ""))
        value = value[: match.start()].strip()
    for stop in WINNER_STOP:
        index = value.find(stop)
        if index > 0:
            value = value[:index].strip()
    value = value.strip("：:，,;；。·-— ")
    if norm_label(value) in WINNER_LABELS or "结算率" in value or "中标价" in value:
        return "", amount
    return value, amount


def tidy_buyer(raw: str) -> str:
    value = clean(raw)
    value = re.sub(r"^名\s*称\s*[：:]\s*", "", value)
    for stop in ("地址", "招标代理机构", "代理机构", "联系方式", "电话", "采购人", "招标人"):
        index = value.find(stop)
        if index > 0:
            value = value[:index].strip()
    return value.strip("：:，,;；。 ")


def page_title(soup: BeautifulSoup) -> str:
    """页面标题：优先 h1/h2，再退到 <title>，去掉站点名后缀。"""
    for tag in soup.find_all(["h1", "h2", "h3"]):
        text = clean(tag.get_text(" "))
        if len(text) >= 8 and "工作日" not in text and "{" not in text:
            return text
    title = clean(soup.title.get_text(" ")) if soup.title else ""
    title = re.sub(r"[-_|—–]\s*[^-|_—–]{2,30}$", "", title) if len(title) > 30 else title
    return title


def extract(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    found = {"winner": "", "amount_raw": "", "buyer": ""}

    # 1) 表格行：标签格 + 取值格
    for row in soup.find_all("tr"):
        cells = [clean(cell.get_text(" ")) for cell in row.find_all(["td", "th"])]
        for index, cell in enumerate(cells):
            label = norm_label(cell)
            if not label or len(label) > 16:
                continue
            nxt = cells[index + 1] if index + 1 < len(cells) else ""
            inline = ""
            match = re.match(r"^[^：:]{0,12}[：:]\s*(.+)$", cell)
            if match:
                inline = clean(match.group(1))

            if label in WINNER_LABELS and not found["winner"]:
                value = inline or nxt
                if value and norm_label(value) not in WINNER_LABELS and len(value) <= 120:
                    found["winner"] = value
            elif label in AMOUNT_LABELS and not found["amount_raw"]:
                value = inline or nxt
                if not value or len(value) > 60:
                    continue
                if norm_label(value) in AMOUNT_LABELS:
                    continue
                found["amount_raw"] = value

    # 2) 扁平正文（空格连接，容忍标签与取值被拆到不同 span）
    text = clean(soup.get_text(" "))

    if not found["winner"]:
        match = re.search(
            r"(?:中标人名称|中标单位|成交供应商名称|中标供应商名称|成交供应商|中标人)\s*[：:]\s*"
            r"([^\n；;，,]{4,60})",
            text,
        )
        if match:
            found["winner"] = clean(match.group(1))

    if not found["winner"]:
        # 「中标通知书」版式：项目编码：<编号> <公司名> ：你方于…
        match = re.search(
            r"项目编码\s*[：:]\s*[A-Za-z0-9]+\s+([^：:]{4,60}?" + ORG_SUFFIX + r")\s*[：:]",
            text,
        )
        if match:
            found["winner"] = clean(match.group(1))

    if not found["amount_raw"]:
        match = re.search(
            r"(?:中标价|中标金额|成交金额|中标（成交）金额|投标总报价)\s*[（(]?[^）)\n]{0,14}[）)]?\s*[：:]\s*"
            r"([\d,，.]+\s*(?:亿元|万元|千元|元)?)",
            text,
        )
        if match:
            found["amount_raw"] = clean(match.group(1))

    match = re.search(
        r"(?:采购人名称|招标人名称|采购人|招标人|采购单位|招标单位)\s*[：:]\s*"
        r"([^\n]{4,60}?)(?:地址|联系方式|\s{2,}|$)",
        text,
    )
    if match:
        found["buyer"] = tidy_buyer(match.group(1))

    winner, trailing_amount = tidy_winner(found["winner"])
    amount_yuan, amount_raw = normalize_amount(found["amount_raw"])
    if amount_yuan is None and trailing_amount is not None:
        amount_yuan = trailing_amount
        amount_raw = f"{trailing_amount:.2f}元"
    if amount_yuan is None and found["amount_raw"]:
        cn = parse_cn_amount(found["amount_raw"])
        if cn is not None:
            amount_yuan, amount_raw = cn, found["amount_raw"]

    return {
        "winner": winner,
        "amount_yuan": amount_yuan,
        "amount_raw": amount_raw or found["amount_raw"],
        "buyer": found["buyer"],
        "title": page_title(soup),
    }


def main() -> int:
    payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
    targets = payload["dropped"]["no_winner"]

    config = Config.load()
    config.cache_dir = RUN_DIR / ".cache"
    fetcher = Fetcher(config, use_cache=True, browser_fallback=False)

    out = []
    for item in targets:
        url = item["url"]
        result = fetcher.fetch(url)
        if not result.ok:
            print(f"[FAIL] {url}")
            continue
        fields = extract(result.html)
        row = {
            "url": url,
            "title": fields["title"] or item["title"],
            "published": item["published"],
            "buyer": fields["buyer"],
            "winner": fields["winner"],
            "amount_yuan": fields["amount_yuan"],
            "amount_raw": fields["amount_raw"],
        }
        out.append(row)
        print(
            f"[{'OK' if row['winner'] else '..'}] {row['published']} | {row['title'][:34]} | "
            f"buyer={row['buyer'][:18]} | winner={row['winner'][:28]} | "
            f"amount={row['amount_yuan']} | raw={row['amount_raw'][:24]}"
        )

    (RUN_DIR / "fallback_records.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
