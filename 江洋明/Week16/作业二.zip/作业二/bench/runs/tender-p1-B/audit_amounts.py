#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""金额一致性审计：检查 106 条保留记录里有没有「取错金额」的。

三类风险：
1. 金额为 0 —— 多半是公告概要里的模板占位符没填（正文另有真实金额）；
2. 金额来源是「代理服务收费 / 收费金额 / 预算金额」等非中标口径；
3. 页面里同时存在多个中标金额口径（概要 vs 正文）且取值不一致。

逐条回到缓存的原始 HTML 里核对，不猜。
"""

from __future__ import annotations

import glob
import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent

#: 公告正文里的中标金额标签（正文优先于概要）
BODY_AMOUNT_RE = re.compile(
    r"中标[（(]成交[）)]金额\s*[：:]\s*([\d,，.]+)\s*(亿元|万元|千元|元)?",
)
SUMMARY_AMOUNT_RE = re.compile(r"总中标金额\s*(?:（?元）?)?\s*[：:]?\s*￥?\s*([\d,，.]+)\s*(亿元|万元|千元|元)?")
SUSPECT_RE = re.compile(r"代理|收费|预算|控制价|最高限价|服务费")

cache_by_url: dict[str, str] = {}
for meta in glob.glob(str(RUN_DIR / ".cache" / "*.meta.json")):
    data = json.loads(Path(meta).read_text(encoding="utf-8"))
    html_path = Path(meta.replace(".meta.json", ".html"))
    if html_path.exists():
        cache_by_url[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"\s+", " ", text)


def main() -> int:
    payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
    records = payload["records"]
    print(f"保留 {len(records)} 条\n")

    flagged = []
    for record in records:
        raw = record.get("amount_raw", "") or ""
        amount = record.get("amount_yuan")
        problems = []
        if amount is not None and float(amount) == 0:
            problems.append("金额为0")
        if SUSPECT_RE.search(raw):
            problems.append(f"金额来源可疑:{raw[:40]}")
        html = cache_by_url.get(record["url"])
        body = flat(html) if html else ""
        if html:
            body_hit = BODY_AMOUNT_RE.search(body)
            summary_hit = SUMMARY_AMOUNT_RE.search(body)
            body_val = None
            if body_hit:
                unit = body_hit.group(2) or "元"
                mult = {"亿元": 1e8, "万元": 1e4, "千元": 1e3, "元": 1}[unit]
                body_val = float(body_hit.group(1).replace(",", "")) * mult
            if body_val is not None and amount is not None and abs(body_val - float(amount)) > 0.5:
                problems.append(f"与正文金额不一致 正文={body_val} 摘要={amount}")
            if amount is not None and float(amount) == 0 and body_val:
                problems.append(f"概要为0/正文为{body_val}")
            if summary_hit and not body_hit:
                pass
        if problems:
            flagged.append((record, problems))
            print("!")
            print(f"  {record['published']} {record['title'][:40]}")
            print(f"  url={record['url']}")
            print(f"  amount_yuan={amount} raw={raw[:60]}")
            for problem in problems:
                print(f"  -> {problem}")
            if html:
                for pattern in (BODY_AMOUNT_RE, SUMMARY_AMOUNT_RE):
                    hit = pattern.search(body)
                    if hit:
                        print(f"  ctx: ...{body[max(0,hit.start()-60):hit.end()+60]}...")
            print()

    print(f"\n共标记 {len(flagged)} 条")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
