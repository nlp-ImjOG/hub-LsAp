#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""结果表金额抽取：按表格结构取「中标（成交）金额」列，不靠猜。

政务公告的结果数据有两种版式：
- **列式**：表头 `序号 | 供应商名称 | 中标（成交）金额 | 评审总得分`，数据行同列给值；
- **键值式**：一行两格 `中标（成交）金额 | 32.800000 (万元)`。

两种都覆盖；多标段项目按各标段求和（与公告概要栏的总金额一致）。
预算金额、代理服务费、收费金额这些**不是中标口径**的列一律排除。
"""

from __future__ import annotations

import re

from bs4 import BeautifulSoup

#: 表头 / 标签里表示「中标口径金额」的写法
AMOUNT_LABEL_RE = re.compile(
    r"^(?:中标[、,，]?成交金额|中标[、,，]?成交价|中标金额|成交金额|中标价|成交价)$"
)
#: 明确不是中标口径的列
EXCLUDE_RE = re.compile(r"预算|代理|收费|控制价|限价|服务费|报价率|费率|下浮|优惠")

NUMBER_UNIT_RE = re.compile(r"([\d,，.]+)\s*[（(]?\s*(亿元|万元|千元|元)?")
UNIT_MULT = {"亿元": 1e8, "万元": 1e4, "千元": 1e3, "元": 1}


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def norm(text: str) -> str:
    """标签归一：去掉空白、冒号、括号内容（含单位），保留中文标签本身。"""
    text = re.sub(r"[（(]\s*(?:亿元|万元|千元|元)?\s*[）)]", "", text or "")
    return re.sub(r"[\s:：()（）\[\]【】、,，]", "", text)


def parse_cell_amount(text: str, unit_hint: str) -> float | None:
    """从一个单元格文本里取金额。优先带单位的那个数，其次第一个数按表头单位计。"""
    if not text:
        return None
    if EXCLUDE_RE.search(text) and "中标" not in text and "成交" not in text:
        return None
    if "%" in text or "折扣" in text or "费率" in text:
        return None
    fallback = None
    for match in NUMBER_UNIT_RE.finditer(text):
        number = match.group(1).replace(",", "").replace("，", "")
        try:
            value = float(number)
        except ValueError:
            continue
        unit = match.group(2)
        if unit:
            return round(value * UNIT_MULT[unit], 2)
        if fallback is None:
            fallback = round(value * UNIT_MULT.get(unit_hint or "元", 1), 2)
    return fallback


def label_unit(text: str) -> str:
    """标签 / 表头自带的单位，如「中标金额（元）」→「元」。"""
    match = re.search(r"[（(]\s*(亿元|万元|千元|元)\s*[）)]", text or "")
    return match.group(1) if match else ""


def table_amount(html: str) -> tuple[float | None, str]:
    """返回 (总金额_元, 证据)。抽不到返回 (None, "")。"""
    soup = BeautifulSoup(html, "html.parser")
    for table in soup.find_all("table"):
        rows = table.find_all("tr")
        if not rows:
            continue
        cells_per_row = [[clean(cell.get_text(" ")) for cell in row.find_all(["td", "th"])] for row in rows]

        # 1) 键值式：整行两格，或标签格里自带「标签：数值」
        key_value_total, key_value_evidence = 0.0, []
        for cells in cells_per_row:
            for index, cell in enumerate(cells):
                label = norm(cell)
                if not label or EXCLUDE_RE.search(label):
                    continue
                inline = re.match(r"^([^：:]{0,16})[：:]\s*(.+)$", cell)
                value_text = ""
                hint = ""
                if inline and AMOUNT_LABEL_RE.match(norm(inline.group(1))):
                    value_text = inline.group(2)
                    hint = label_unit(cell)
                elif AMOUNT_LABEL_RE.match(label) and index + 1 < len(cells):
                    value_text = cells[index + 1]
                    hint = label_unit(cell)
                if not value_text:
                    continue
                amount = parse_cell_amount(value_text, hint)
                if amount and amount > 0:
                    key_value_total += amount
                    key_value_evidence.append(f"{cell[:18]}→{value_text[:22]}")
            if key_value_evidence:
                break

        if key_value_evidence:
            return round(key_value_total, 2), "；".join(key_value_evidence[:4])

        # 2) 列式：表头里有金额列，按同列取数据行的值
        header_index = None
        column = None
        hint = ""
        for row_index, cells in enumerate(cells_per_row[:3]):
            if len(cells) < 3:
                continue
            for index, cell in enumerate(cells):
                label = norm(cell)
                if not label or EXCLUDE_RE.search(label):
                    continue
                if AMOUNT_LABEL_RE.match(label):
                    header_index, column = row_index, index
                    hint = label_unit(cell)
                    break
            if column is not None:
                break
        if column is None:
            continue

        total, evidence = 0.0, []
        for cells in cells_per_row[header_index + 1 :]:
            if len(cells) <= column:
                continue
            value_text = cells[column]
            amount = parse_cell_amount(value_text, hint)
            if amount and amount > 0:
                total += amount
                evidence.append(value_text[:26])
        if evidence:
            return round(total, 2), f"表头「{cells_per_row[header_index][column][:14]}」；" + "；".join(evidence[:4])

    return None, ""
