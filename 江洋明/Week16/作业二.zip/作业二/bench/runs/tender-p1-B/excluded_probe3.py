#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""第三轮：定点确认 3 个页面的中标人名与日期上下文。

1) gdebidding 物流公司 ESG 报告 —— 表格里到底有没有中标人
2) 黄山市温室气体清单 —— 「中标（成交）供应商」前面那个名字
3) 甘肃银行 ESG 报告 —— 2025-11-28 是不是发布日期
"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
cache: dict[str, str] = {}
for meta_path in RUN_DIR.glob(".cache/*.meta.json"):
    data = json.loads(meta_path.read_text(encoding="utf-8"))
    html_path = meta_path.parent / (meta_path.name.replace(".meta.json", ".html"))
    if html_path.exists():
        cache[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")

TARGETS = {
    "gdebidding": "https://www.gdebidding.com/zbxxgg/211553.jhtml",
    "huangshan": "https://ggzy.huangshan.gov.cn/004/004007/004007002/20260901/0f6035a4-5a89-4a9e-b206-e1757c0d7f27.html",
    "gsei": "https://gsei.com.cn/html/1337/2025-11-28/content-638224.html",
}


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"[ \t\r\n]+", " ", text)


for key, url in TARGETS.items():
    html = cache.get(url, "")
    text = flat(html)
    print("=" * 100)
    print(key, url)
    if key == "gdebidding":
        for label in ("评审结果", "成交供应商", "中标人", "供应商", "第一名", "排序", "推荐", "名称", "报价", "结果"):
            for match in list(re.finditer(re.escape(label), text))[:2]:
                print(f"  [{label}]", re.sub(r"\s+", " ", text[match.start(): match.start() + 160])[:170])
    elif key == "huangshan":
        index = text.find("中标（成交）供应商业绩")
        print("  业绩前文:", re.sub(r"\s+", " ", text[max(0, index - 300): index + 40])[:360])
        index = text.find("三、中标")
        print("\n  三、中标 之后:", re.sub(r"\s+", " ", text[index: index + 420])[:440])
    else:
        for match in list(re.finditer(r"2025-11-28|2025年11月28", text))[:4]:
            print("  日期上下文:", re.sub(r"\s+", " ", text[max(0, match.start() - 90): match.start() + 40])[:150])
