#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用 skill 的确定性脚本层解析真实中标公告快照，产出报告所需的统计与明细。

数据来源：``作业二/bench/fixtures/`` 的 32 份真实中标公告 HTML 快照
（中国政府采购网、各省公共资源交易中心、各级政府网站）。
抽取、金额归一、日期归一、去重、分档、统计全部走
``.claude/skills/esg-tender-monitor/scripts/esg_toolkit`` —— 模型只负责解读与表达。
"""

from __future__ import annotations

import io
import json
import sys
from datetime import date
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import summarize  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

BENCH_DIR = RUN_DIR.parents[1]           # 作业二/bench
FIXTURE_DIR = BENCH_DIR / "fixtures"
MANIFEST = FIXTURE_DIR / "manifest.json"

YEARS = 2
TODAY = date(2026, 11, 27)
SINCE = date(TODAY.year - YEARS, TODAY.month, 1)
UNTIL = TODAY


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    print(f"快照数：{len(manifest)}")

    records = []
    failed = []
    for item in manifest:
        html = (FIXTURE_DIR / item["file"]).read_text(encoding="utf-8", errors="replace")
        record = parse_tender_page(
            html, url=item["url"], fallback_title=item.get("title", "")
        )
        if record is None:
            failed.append(item["file"])
            continue
        records.append(record)

    # 去重：URL 规范化（去追踪参数、去 www.、统一末尾斜杠）→ 退化到「标题+日期」
    seen: set[str] = set()
    unique = []
    duplicates = []
    for record in records:
        key = canonical_url(record.url) or f"{record.title}|{record.published or ''}"
        if key in seen:
            duplicates.append(record.url)
            continue
        seen.add(key)
        unique.append(record)

    # 统计区间过滤：判不出日期的记录不参与区间判定，但要在报告里披露
    in_window, out_of_window, undated = [], [], []
    for record in unique:
        if not record.published:
            undated.append(record)
            continue
        try:
            published = date.fromisoformat(record.published)
        except ValueError:
            undated.append(record)
            continue
        if SINCE <= published <= UNTIL:
            in_window.append(record)
        else:
            out_of_window.append(record)

    stats = summarize(in_window)
    payload = {
        "window": {"since": SINCE.isoformat(), "until": UNTIL.isoformat()},
        "counts": {
            "manifest": len(manifest),
            "parsed": len(records),
            "parse_failed": failed,
            "duplicates": duplicates,
            "unique": len(unique),
            "in_window": len(in_window),
            "out_of_window": len(out_of_window),
            "undated": len(undated),
        },
        "stats": stats,
        "records": [record.to_dict() for record in in_window],
    }
    out_path = RUN_DIR / "records.json"
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"统计区间：{SINCE} ~ {UNTIL}")
    print(json.dumps(payload["counts"], ensure_ascii=False, indent=2))
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    print(f"明细已写入：{out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
