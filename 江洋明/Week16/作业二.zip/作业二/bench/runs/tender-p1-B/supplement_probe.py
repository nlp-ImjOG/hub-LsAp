#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""补录前的最后确认：采购人名称、采购人地址、金额标签原文。"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
cache: dict[str, str] = {}
for meta_path in RUN_DIR.glob(".cache/*.meta.json"):
    data = json.loads(meta_path.read_text(encoding="utf-8"))
    html_path = meta_path.parent / (meta_path.name.replace(".meta.json", ".html"))
    if html_path.exists():
        cache[data["url"]] = html_path.read_text(encoding="utf-8", errors="replace")

URLS = [
    "https://www.gdebidding.com/zbxxgg/211553.jhtml",
    "https://ggzy.huangshan.gov.cn/004/004007/004007002/20260901/0f6035a4-5a89-4a9e-b206-e1757c0d7f27.html",
    "https://www.ywygzc.com/jyxx/002001/002001002/002001002005/20261014/2f7249fd-985b-4ec7-90a7-ed7cb257da08.html",
    "https://ygcg.gzggzy.cn/qt/381568.jhtml",
    "https://gsei.com.cn/html/1337/2025-11-28/content-638224.html",
]
LABELS = ["采购人", "采购单位", "采购方", "招标人", "建设单位", "地址", "项目名称", "项目编号", "采购方式", "资金来源"]


def flat(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"[ \t\r\n]+", " ", text)


for url in URLS:
    html = cache.get(url, "")
    text = flat(html)
    print("=" * 100)
    print(url)
    for label in LABELS:
        for match in list(re.finditer(re.escape(label), text))[:3]:
            snippet = re.sub(r"\s+", " ", text[match.start(): match.start() + 90])[:100]
            print(f"  [{label}] {snippet}")
