#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""最后一处措辞：1.1 表头改成「代表公告」—— 未披露档没有"金额最大"可言。"""

from __future__ import annotations

import io
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

TARGET = Path(__file__).resolve().parent / "make_report.py"
text = TARGET.read_text(encoding="utf-8")
OLD = "| 金额区间 | 公告数 | 条数占比 | 区间金额合计 | 占总金额 | 该档金额最大的一笔 |"
NEW = "| 金额区间 | 公告数 | 条数占比 | 区间金额合计 | 占总金额 | 代表公告（金额最大的一笔） |"
if OLD not in text:
    raise SystemExit("补丁没命中")
TARGET.write_text(text.replace(OLD, NEW, 1), encoding="utf-8")
print("表头措辞修正完成")
