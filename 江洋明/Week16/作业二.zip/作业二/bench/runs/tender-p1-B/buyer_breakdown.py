#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""拆解「其他」采购人这一档，看清里面到底是什么机构。"""

from __future__ import annotations

import io
import json
import re
import sys
from collections import Counter
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"))
from esg_toolkit.aggregate import BUYER_RULES  # noqa: E402

payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
records = payload["records"]
print("stats.buyers =", json.dumps(payload["stats"].get("buyers"), ensure_ascii=False))
print()


def classify(text: str) -> str:
    for label, pattern in BUYER_RULES:
        if pattern and re.search(pattern, text):
            return label
    return "其他"


others = []
for record in records:
    buyer = (record.get("buyer") or "").strip()
    if classify(buyer) == "其他":
        others.append(buyer or "未检索到")

for name, count in Counter(others).most_common(60):
    print(f"  {count} | {name[:46]}")
print(f"\n「其他」合计 {len(others)} 条")
