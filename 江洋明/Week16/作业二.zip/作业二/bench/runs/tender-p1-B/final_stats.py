#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""最终统计核对：补充语料的落地字段 + 全量分布。"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
stats = payload["stats"]
records = payload["records"]

print("=== 补充语料落地情况 ===")
for record in records:
    if record.get("extra", {}).get("source") == "人工核对补充":
        print(
            f"{record['published']} | {record['title'][:40]} | {record['buyer'][:20]} | "
            f"{record['winner'][:24]} | {record['amount_yuan']} | {record.get('category') or '未分类'} | "
            f"{record['province']} | {record['extra'].get('province_rule', '')}"
        )
        print(f"    amount_raw: {record['amount_raw']}")

print("\n=== amount ===")
print(json.dumps(stats["amount"], ensure_ascii=False))
print("=== buckets ===")
for row in stats["buckets"]:
    print(
        f"  {row['bucket']}: {row['count']} 条 | {row['total_yuan']:,.2f} 元 | "
        f"条数占比 {row['ratio']:.2%} | 金额占比 {row['amount_ratio']:.2%}"
    )
print("=== categories ===")
for row in stats["categories"]:
    print(
        f"  {row['category']}: {row['count']} 条 ({row['ratio']:.2%}) | {row['total_yuan']:,.2f} 元"
    )
print("=== buyers ===")
print(json.dumps(stats["buyers"], ensure_ascii=False))
print("=== regions ===")
for row in stats["regions"]:
    print(f"  {row['region']}: {row['count']} 条 | {row['total_yuan']:,.2f} 元")
print("=== hotspots ===")
for row in stats["hotspots"]:
    print(f"  {row['term']}: {row['count']} ({row['share']:.2%}) -> {row['category']}")
print("=== trend ===")
for row in stats["trend"]:
    print(f"  {row['month']}: {row['count']} 条 | {row['total_yuan']:,.2f} 元")

print("\n=== 金额 TOP 12 ===")
ranked = sorted(
    [r for r in records if r.get("amount_yuan")], key=lambda r: -r["amount_yuan"]
)
for record in ranked[:12]:
    print(
        f"  {record['amount_yuan']:>16,.2f} | {record['published']} | {record['title'][:34]} | "
        f"{record['province']} | {record.get('category') or '未分类'}"
    )
print("\n=== 金额最小的 5 条 ===")
for record in ranked[-5:]:
    print(
        f"  {record['amount_yuan']:>12,.2f} | {record['published']} | {record['title'][:38]} | {record['province']}"
    )

print("\n=== 未披露金额的记录 ===")
for record in records:
    if not record.get("amount_yuan"):
        print(
            f"  {record['published']} | {record['title'][:44]} | {record['buyer'][:20]} | "
            f"{record['winner'][:22]} | {record['province']}"
        )
