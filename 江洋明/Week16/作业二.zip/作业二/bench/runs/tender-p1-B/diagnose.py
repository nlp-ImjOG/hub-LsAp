#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""诊断：主解析器没抽出中标人的那些页面，字段长什么样。

只看正文里含「中标/成交/供应商/金额」的行，用来判断能不能用
「带标签的正则」做确定性兜底抽取（而不是猜）。
"""

from __future__ import annotations

import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.htmlutil import extract_body  # noqa: E402

KEY = re.compile(r"中标|成交|供应商|金额|价格|费率|折扣")

config = Config.load()
config.cache_dir = RUN_DIR / ".cache"
fetcher = Fetcher(config, use_cache=True, browser_fallback=False)

payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
targets = payload["dropped"]["no_winner"]
if len(sys.argv) > 1:
    targets = [t for t in targets if sys.argv[1] in t["url"]]

for item in targets:
    url = item["url"]
    result = fetcher.fetch(url)
    print("=" * 100)
    print(url)
    if not result.ok:
        print("  抓取失败")
        continue
    text = extract_body(result.html)
    hits = 0
    for line in text.splitlines():
        line = line.strip()
        if len(line) < 3 or len(line) > 220:
            continue
        if KEY.search(line):
            print("  |", line[:200])
            hits += 1
            if hits >= 14:
                break
