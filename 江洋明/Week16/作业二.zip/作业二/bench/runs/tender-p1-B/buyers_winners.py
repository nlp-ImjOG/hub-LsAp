#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""采购人与中标单位的分布 —— 给「谁在买、对手是谁」用。"""

from __future__ import annotations

import io
import json
import re
import sys
from collections import Counter
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import buyer_classification  # noqa: E402

payload = json.loads((RUN_DIR / "merged_records.json").read_text(encoding="utf-8"))
records = payload["records"]

buyer_counter = Counter()
buyer_amount = Counter()
for record in records:
    name = (record.get("buyer") or "未检索到").strip()
    name = re.sub(r"（[^）]*）|\([^)]*\)", "", name)
    buyer_counter[name] += 1
    buyer_amount[name] += record.get("amount_yuan") or 0

winner_counter = Counter()
winner_amount = Counter()
for record in records:
    name = (record.get("winner") or "").strip()
    name = re.sub(r"^(牵头供应商|联合体牵头人)\s*[:：]\s*", "", name)
    name = name.split("（联合体")[0].split("(联合体")[0].strip()
    if not name:
        continue
    winner_counter[name] += 1
    winner_amount[name] += record.get("amount_yuan") or 0

print("=== 采购人（出现次数） ===")
for name, count in buyer_counter.most_common(18):
    print(f"  {count} 次 | {name[:36]} | {buyer_amount[name]:,.2f} 元")
print(f"  采购人去重后共 {len(buyer_counter)} 家")

print("\n=== 中标单位（出现次数） ===")
for name, count in winner_counter.most_common(15):
    print(f"  {count} 次 | {name[:40]} | {winner_amount[name]:,.2f} 元")
print(f"  中标单位去重后共 {len(winner_counter)} 家")

print("\n=== 采购人类型（skill 的 BUYER_RULES） ===")
groups = Counter()
for record in records:
    groups[buyer_classification(record.get("buyer") or "")] += 1
for name, count in groups.most_common():
    print(f"  {name}: {count}")
