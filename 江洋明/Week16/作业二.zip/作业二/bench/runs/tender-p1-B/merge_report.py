#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""合并四路语料 → 口径修正 → 去重 → 统计，产出报告所需的全部数字。

语料来源：
- 快照语料：bench/fixtures 的 32 份真实公告快照（离线、可复现）；
- 联网检索语料：10 组方向检索式 → 94 个候选 URL → 抓原页解析；
- 补充抽取语料：主解析器吃不下版式的页面，按标签兜底抽取；
- 人工核对补充语料：页面里明确写了中标人，但主解析器/兜底抽取都没取到的 5 条，
  逐条回原页人工核对后录入（supplement_records.json，字段与原文标签一并留存）。

口径修正（全部是确定性规则，不猜）：
1. 字段修正（record_fixes.json）—— 同一页里既挂「招标公告」又挂「中标结果公告」时，
   以结果公告的发布时间与标题为准；解析不出采购人时回原页取「招标人/采购人」；
   中标单位被解析成表头时回原页取「中标单位」。
2. 金额修正 —— 公告「概要」栏常留模板占位符 `￥0.000000 万元`，正文「中标（成交）金额」
   才是真值。摘要为 0 而正文有值时以正文为准，并记录修正来源。
3. 地区修正（province_overrides.json）—— 地区指**采购人**所在省级行政区，
   判定链与证据见 enrich_province.py；落空写「未检索到」。
4. 方向修正 —— 统一按「标题+采购人+中标人」判定，四路语料同口径。

过滤口径：
1. 必须解析出中标/成交供应商 —— 只有结果公告才满足；
2. 发布日期必须落在统计区间内；
3. URL 规范化去重，退化为「标题+日期」。

统计全部交给 skill 的确定性脚本层（aggregate.summarize）。
"""

from __future__ import annotations

import glob
import io
import json
import re
import sys
from datetime import date
from pathlib import Path

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

RUN_DIR = Path(__file__).resolve().parent
SKILL_SCRIPTS = RUN_DIR / ".claude" / "skills" / "esg-tender-monitor" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from esg_toolkit.aggregate import summarize  # noqa: E402
from esg_toolkit.keywords import classify_category  # noqa: E402
from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402

from table_amount import table_amount  # noqa: E402

SINCE = date(2024, 11, 1)
UNTIL = date(2026, 11, 27)

#: 站点名 / 模板串，不是项目名
TITLE_ARTIFACT = (
    "{", "工作日", "公共资源交易", "监管网", "信息网", "详细页面", "交易中心",
    "人民政府网", "交易平台", "中标公告", "成交公告", "结果公告",
)

#: 正文里的中标金额标签（**不能**匹配「代理服务收费金额」）
BODY_AMOUNT_RE = re.compile(
    r"(?:中\s*标\s*[（(]\s*成\s*交\s*[）)]\s*金\s*额|中\s*标\s*金\s*额|成\s*交\s*金\s*额|"
    r"中\s*标\s*价\s*格|成\s*交\s*价\s*格)\s*[：:]\s*"
    r"([\d,，.]+)\s*[\(（]?\s*(亿元|万元|千元|元)\s*[\)）]?"
)
UNIT_MULT = {"亿元": 1e8, "万元": 1e4, "千元": 1e3, "元": 1}

CACHE_HTML: dict[str, str] = {}
for _meta in glob.glob(str(RUN_DIR / ".cache" / "*.meta.json")):
    _data = json.loads(Path(_meta).read_text(encoding="utf-8"))
    _html_path = Path(_meta.replace(".meta.json", ".html"))
    if _html_path.exists():
        CACHE_HTML[_data["url"]] = _html_path.read_text(encoding="utf-8", errors="replace")


def flat_text(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return re.sub(r"\s+", " ", text)


#: 公告概要栏的总金额（多标段项目的权威总额）
SUMMARY_TOTAL_RE = re.compile(
    r"总\s*(?:中标|成交)\s*金额\s*[：:]?\s*[￥¥]?\s*([\d,，.]+)\s*(亿元|万元|千元|元)?"
)


def body_amount(url: str) -> tuple[float | None, str, str]:
    """从缓存原页里取正文的中标金额（不含代理服务费）。

    返回 ``(金额_元, 原文, 说明)``。
    """
    html = CACHE_HTML.get(url)
    if not html:
        return None, "", ""
    text = flat_text(html)
    for match in BODY_AMOUNT_RE.finditer(text):
        prefix = text[max(0, match.start() - 24) : match.start()]
        if "代理" in prefix:
            continue
        number = match.group(1).replace(",", "").replace("，", "")
        unit = match.group(2) or "元"
        try:
            value = float(number) * UNIT_MULT[unit]
        except ValueError:
            continue
        if value <= 0:
            continue
        raw = match.group(0).strip()
        note = f"{raw}（正文口径；概要栏为模板占位符 ￥0.000000 万元）"
        return value, raw, note
    return None, "", ""


def correct_amount(record) -> str:
    """金额口径校正（返回说明，空串表示没动）。

    口径：**优先用公告自己声明的「总中标（成交）金额」**；该栏为空或留模板占位符
    （`￥0.000000 万元`）时，用结果表里各标段中标金额之和。

    为什么不用解析器的原始值：多标段项目解析器只取到第一个标段（如北京碳排放权
    项目 6 个包只取 61.5 万），还有的页面把「评审总得分」当成了金额（神木 83.83），
    更有把各包金额求和成裸数字后套上「万元」提示、把 298.99 万放大成 298.99 亿的
    （维西森林抚育）。这些都属于口径错误，不是笔误。
    """
    html = CACHE_HTML.get(record.url)
    text = flat_text(html) if html else ""

    summary_value = 0.0
    summary_text = ""
    match = SUMMARY_TOTAL_RE.search(text)
    if match:
        try:
            number = float(match.group(1).replace(",", "").replace("，", ""))
            summary_value = number * UNIT_MULT.get(match.group(2) or "元", 1)
            summary_text = match.group(0).strip()
        except ValueError:
            summary_value = 0.0

    table_value, table_evidence = (None, "")
    if html:
        try:
            table_value, table_evidence = table_amount(html)
        except Exception:
            table_value, table_evidence = (None, "")

    if summary_value and summary_value > 0:
        if abs((record.amount_yuan or 0) - summary_value) > 0.5:
            record.extra["amount_note"] = "按公告概要栏「总中标/成交金额」校正"
            record.amount_yuan = round(summary_value, 2)
            record.amount_raw = summary_text
            return record.extra["amount_note"]
        return ""

    if table_value and table_value > 0:
        if abs((record.amount_yuan or 0) - table_value) > 0.5:
            record.extra["amount_note"] = "概要栏未填金额，按结果表各标段中标金额之和校正"
            record.amount_yuan = table_value
            record.amount_raw = table_evidence
            return record.extra["amount_note"]
        return ""

    # 都没取到：金额缺失时回正文正则口径
    if not record.amount_yuan:
        value, raw_text, note = body_amount(record.url)
        if value:
            record.amount_yuan = value
            record.amount_raw = raw_text
            record.extra["amount_note"] = note
            return note
    return ""


def is_artifact(title: str) -> bool:
    return len(title) < 8 or any(word in title for word in TITLE_ARTIFACT)


def load_records(path: Path, source: str) -> list[TenderRecord]:
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    items = data["records"] if "records" in data else data
    out = []
    for item in items:
        out.append(
            TenderRecord(
                title=item["title"],
                url=item["url"],
                buyer=item.get("buyer", ""),
                winner=item.get("winner", ""),
                amount_yuan=item.get("amount_yuan"),
                amount_raw=item.get("amount_raw", ""),
                published=item.get("published"),
                package=item.get("package", ""),
                province=item.get("province", ""),
                category=item.get("category", ""),
                extra=dict(item.get("extra") or {}, source=source),
            )
        )
    return out


def load_fallback(path: Path, main_titles: dict[str, str]) -> list[TenderRecord]:
    """补充抽取语料。标题择优：主解析器的项目名优先，除非它是站点名/模板串。"""
    if not path.exists():
        return []
    rows = json.loads(path.read_text(encoding="utf-8"))
    out = []
    for row in rows:
        page_title = row.get("title", "")
        main_title = main_titles.get(row["url"], "")
        title = main_title if (main_title and not is_artifact(main_title)) else page_title
        if is_artifact(title) and page_title and not is_artifact(page_title):
            title = page_title
        out.append(
            TenderRecord(
                title=title,
                url=row["url"],
                buyer=row.get("buyer", ""),
                winner=row.get("winner", ""),
                amount_yuan=row.get("amount_yuan"),
                amount_raw=row.get("amount_raw", ""),
                published=row.get("published"),
                province="",
                category="",
                extra={"source": "补充抽取"},
            )
        )
    return out


def key_of(record: TenderRecord) -> str:
    canon = canonical_url(record.url)
    return canon or f"{record.title}|{record.published or ''}"


def load_json(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def apply_fixes(record, patch: dict) -> int:
    """把 record_fixes.json 里的字段修正打到记录上，返回改动条数。"""
    changed = 0
    for field in ("title", "published", "buyer", "winner"):
        if field in patch and patch[field] and patch[field] != getattr(record, field):
            setattr(record, field, patch[field])
            record.extra.setdefault("fix_note", []).append(
                patch.get(f"{field}_evidence", f"{field} 已修正")
            )
            changed += 1
    if patch.get("amount_yuan") is not None:
        if abs((record.amount_yuan or 0) - float(patch["amount_yuan"])) > 0.5:
            record.amount_yuan = float(patch["amount_yuan"])
            if patch.get("amount_raw"):
                record.amount_raw = patch["amount_raw"]
            record.extra.setdefault("fix_note", []).append(
                patch.get("amount_evidence", "金额已修正")
            )
            changed += 1
    return changed


def main() -> int:
    previous = load_json(RUN_DIR / "merged_records.json")
    main_titles = {row["url"]: row["title"] for row in previous.get("dropped", {}).get("no_winner", [])}
    fixes = load_json(RUN_DIR / "record_fixes.json")
    provinces = load_json(RUN_DIR / "province_overrides.json")

    snapshot = load_records(RUN_DIR / "records.json", "快照语料")
    live = load_records(RUN_DIR / "live_records.json", "联网检索")
    fallback = load_fallback(RUN_DIR / "fallback_records.json", main_titles)
    supplement = load_records(RUN_DIR / "supplement_records.json", "人工核对补充")

    pool = snapshot + live + fallback + supplement
    seen: dict[str, TenderRecord] = {}
    for record in pool:
        key = key_of(record)
        existing = seen.get(key)
        if existing is None or (not existing.winner.strip() and record.winner.strip()):
            seen[key] = record
    unique = list(seen.values())

    kept, dropped_no_winner, dropped_undated, dropped_out_of_window = [], [], [], []
    for record in unique:
        if not record.winner.strip():
            dropped_no_winner.append(record)
            continue
        if not record.published:
            dropped_undated.append(record)
            continue
        published = date.fromisoformat(record.published)
        if not (SINCE <= published <= UNTIL):
            dropped_out_of_window.append(record)
            continue
        kept.append(record)

    # ---- 字段修正 ----
    fixed_fields = 0
    for record in kept:
        patch = fixes.get(record.url)
        if patch:
            fixed_fields += apply_fixes(record, patch)

    # ---- 金额 / 方向 / 地区修正 ----
    fixed_amount, fixed_province = 0, 0
    for record in kept:
        note = correct_amount(record)
        if note:
            fixed_amount += 1
        record.category = classify_category(
            " ".join([record.title, record.buyer, record.winner])
        ) or record.category
        override = provinces.get(record.url)
        if override and override.get("province"):
            record.province = override["province"]
            record.extra["province_rule"] = override.get("rule", "")
            fixed_province += 1
        elif not record.province:
            record.province = "未检索到"

    kept.sort(key=lambda r: (r.published or "", r.title))
    stats = summarize(kept)

    payload = {
        "window": {"since": SINCE.isoformat(), "until": UNTIL.isoformat()},
        "counts": {
            "snapshot_pool": len(snapshot),
            "live_pool": len(live),
            "fallback_pool": len(fallback),
            "supplement_pool": len(supplement),
            "after_dedupe": len(unique),
            "dropped_no_winner": len(dropped_no_winner),
            "dropped_undated": len(dropped_undated),
            "dropped_out_of_window": len(dropped_out_of_window),
            "kept": len(kept),
            "fixed_fields": fixed_fields,
            "fixed_amount": fixed_amount,
            "fixed_province": fixed_province,
        },
        "dropped": {
            "no_winner": [
                {"title": r.title, "url": r.url, "published": r.published}
                for r in dropped_no_winner
            ],
            "undated": [{"title": r.title, "url": r.url} for r in dropped_undated],
            "out_of_window": [
                {"title": r.title, "url": r.url, "published": r.published}
                for r in dropped_out_of_window
            ],
        },
        "stats": stats,
        "records": [r.to_dict() for r in kept],
    }
    (RUN_DIR / "merged_records.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(payload["counts"], ensure_ascii=False, indent=2))
    print("--- 被剔除（无中标人） ---")
    for row in payload["dropped"]["no_winner"]:
        print(f"  {row.get('published', '无日期')} | {row['title'][:46]} | {row['url']}")
    print("--- 保留明细 ---")
    for index, record in enumerate(kept, 1):
        print(
            f"{index}|{record.published}|{record.title}|{record.buyer}|{record.winner}|"
            f"{record.amount_yuan}|{record.amount_raw}|{record.category}|{record.province}|"
            f"{record.extra.get('source')}|{record.url}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
