# -*- coding: utf-8 -*-
"""ESG 招投标汇总报告的统计计算（去重 + 四个口径）。
按 skill 要求：金额单位先亿元再万元；预算不计入；未披露单列一档不算 0。
"""
import json, re, sys, io, collections
from urllib.parse import urlsplit, urlunsplit, parse_qsl

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = r"E:\个人\AI学习\AI大模型应用\作业\16-江洋明-第十六周作业\作业二\bench\runs\tender-p3-A"

rows = []
for p in ("esg_data_p1.json", "esg_data_p2.json", "esg_data_p3.json", "esg_data_p4.json"):
    with open(BASE + "\\" + p, encoding="utf-8") as f:
        rows.extend(json.load(f))

TRACK_PARAMS = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "from", "spm"}

def norm_url(u):
    pr = urlsplit(u)
    q = [(k, v) for k, v in parse_qsl(pr.query) if k.lower() not in TRACK_PARAMS]
    net = pr.netloc.lower()
    if net.startswith("www."):
        net = net[4:]
    path = pr.path.rstrip("/") or "/"
    return urlunsplit((pr.scheme.lower(), net, path, urlunsplit if False else "&".join(f"{k}={v}" for k, v in sorted(q)), ""))

def norm_title(s):
    s = re.sub(r"[\s（）()【】\[\]、,，。.:：;；\-—－_“”\"'’‘]+", "", s)
    return s

# ---- 去重：URL 规范化优先，退回「标题归一 + 日期」 ----
seen, dedup, dupes = {}, [], []
for r in rows:
    k = norm_url(r["url"])
    if k in seen:
        dupes.append((k, seen[k]["project"], r["project"]))
        continue
    tk = norm_title(r["project"])[:30] + "|" + r["date"]
    if any(tk == s for s in seen.values()):
        continue
    seen[k] = r
    dedup.append(r)

# 二次检查：标题归一重复
seen_t = {}
final = []
for r in dedup:
    tk = norm_title(r["project"])[:30]
    if tk in seen_t:
        dupes.append(("TITLE", seen_t[tk], r["project"]))
        continue
    seen_t[tk] = r["project"]
    final.append(r)

print(f"原始条数 {len(rows)} → URL规范化去重后 {len(final)} 条；被折叠 {len(rows)-len(final)} 条")
for d in dupes:
    print("  DUP:", d[0], "|", d[1][:40], "<=>", d[2][:40])

# ---- 口径 1：中标金额分布（7 档 + 未披露） ----
def bucket(a):
    if a is None: return "未披露"
    if a < 100000: return "10万以下"
    if a < 500000: return "10万–50万"
    if a < 1000000: return "50万–100万"
    if a < 5000000: return "100万–500万"
    if a < 10000000: return "500万–1000万"
    if a < 100000000: return "1000万–5000万"
    return "1亿以上"

ORDER = ["10万以下", "10万–50万", "50万–100万", "100万–500万", "500万–1000万", "1000万–5000万", "1亿以上", "未披露"]
bcount = collections.Counter(); bsum = collections.Counter()
for r in final:
    b = bucket(r["amount_yuan"]); bcount[b] += 1
    if r["amount_yuan"] is not None: bsum[b] += r["amount_yuan"]
print("\n=== 中标金额分布 ===")
for b in ORDER:
    print(f"  {b:<12} {bcount[b]:>3} 条  占比 {bcount[b]/len(final)*100:5.1f}%  金额合计 {bsum[b]/1e4:>12,.2f} 万元")

amts = [r["amount_yuan"] for r in final if r["amount_yuan"] is not None]
tot = sum(amts)
print(f"\n  有金额公告 {len(amts)} 条，合计 {tot:,.2f} 元 = {tot/1e8:.4f} 亿元；均值 {tot/len(amts)/1e4:,.2f} 万元；中位数 {sorted(amts)[len(amts)//2]/1e4:,.2f} 万元")
print(f"  单笔最大 {max(amts)/1e8:.4f} 亿元；单笔最小 {min(amts)/1e4:,.2f} 万元")

# ---- 口径 2：月度走势 ----
mm = collections.defaultdict(lambda: [0, 0])
for r in final:
    k = r["date"][:7]; mm[k][0] += 1
    if r["amount_yuan"] is not None: mm[k][1] += r["amount_yuan"]
print("\n=== 月度走势 ===")
for k in sorted(mm):
    print(f"  {k}  {mm[k][0]:>2} 条  {mm[k][1]/1e4:>12,.2f} 万元")

# ---- 口径 3：热点招标方向（标题命中，短形优先） ----
print("\n=== 热点招标方向 ===")
dc = collections.Counter(r["direction"] for r in final)
for d, c in dc.most_common():
    s = sum(r["amount_yuan"] for r in final if r["direction"] == d and r["amount_yuan"] is not None)
    print(f"  {d:<16} {c:>3} 条  {s/1e4:>12,.2f} 万元")

# ---- 口径 4：地区与采购人 ----
def ptype(p):
    if re.search(r"生态环境局|自然资源局|发展和改革委员会|发展改革局|水务局|水利局|住房和城乡建设|机关|管理局|人民政府|管委会|管理委员会|统计局|林业局|财务局|金融管理局|应急管理局|政府", p): return "政府部门"
    if re.search(r"银行|保险|信托|证券", p): return "金融机构"
    if re.search(r"大学|学院|研究所|研究院|科学院|中心|监测中心|图书馆|博物馆|医院|学校|事业", p): return "事业单位/科研院校"
    if re.search(r"集团|股份|公司|电力|能源|港|机场|铁路|城投|投资", p): return "国有企业/企业"
    return "其他"

print("\n=== 地区分布 ===")
rc = collections.Counter(r["region"] for r in final)
for d, c in rc.most_common():
    s = sum(r["amount_yuan"] for r in final if r["region"] == d and r["amount_yuan"] is not None)
    print(f"  {d:<6} {c:>3} 条  {s/1e4:>12,.2f} 万元")

print("\n=== 采购人类型 ===")
tc = collections.Counter(ptype(r["purchaser"]) for r in final)
for d, c in tc.most_common():
    s = sum(r["amount_yuan"] for r in final if ptype(r["purchaser"]) == d and r["amount_yuan"] is not None)
    print(f"  {d:<12} {c:>3} 条  {s/1e4:>12,.2f} 万元")

print("\n=== 高频中标单位 ===")
wc = collections.Counter(r["winner"] for r in final)
for d, c in wc.most_common(12):
    print(f"  {c:>2} 次  {d}")

# ---- 明细表 markdown ----
def cell(s):
    return str(s).replace("|", "\\|").replace("\n", " ")

lines = ["| 发布日期 | 项目名称（原始来源） | 采购人 | 中标（成交）单位 | 中标金额 | 方向 | 地区 |",
         "| --- | --- | --- | --- | --- | --- | --- |"]
for r in sorted(final, key=lambda x: x["date"], reverse=True):
    amt = r["amount_raw"]
    lines.append(f"| {r['date']} | [{cell(r['project'])}]({r['url']}) | {cell(r['purchaser'])} | {cell(r['winner'])} | {cell(amt)} | {r['direction']} | {r['region']} |")
with open(BASE + r"\detail_table.md", "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
print(f"\n明细表已写入 detail_table.md（{len(final)} 行）")

# 按方向拆分，供分段追加
with open(BASE + r"\detail_table.json", "w", encoding="utf-8") as f:
    json.dump(final, f, ensure_ascii=False, indent=1)
