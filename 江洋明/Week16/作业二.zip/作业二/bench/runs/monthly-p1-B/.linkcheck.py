"""核对 report.md 里所有唯一链接的可达性，输出统计与明细。

用法：python .linkcheck.py
输出：控制台打印总链接数、各状态码计数、以及非 200 的链接明细。
"""
import io
import re
import sys
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

REPORT = "report.md"
LINK_RE = re.compile(r"https?://[^\s)），,、|\"'>]+")
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}


def probe(url):
    req = urllib.request.Request(url, headers=HEADERS, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            resp.read(2048)
            return url, resp.status, ""
    except urllib.error.HTTPError as exc:
        return url, exc.code, f"HTTPError {exc.code}"
    except Exception as exc:  # noqa: BLE001 - 需要把各种网络异常一并归类
        return url, None, type(exc).__name__


def main():
    with open(REPORT, encoding="utf-8") as fh:
        urls = sorted(set(LINK_RE.findall(fh.read())))
    print(f"唯一链接总数：{len(urls)}")

    with ThreadPoolExecutor(max_workers=12) as pool:
        results = list(pool.map(probe, urls))

    ok = [r for r in results if r[1] == 200]
    bad = [r for r in results if r[1] != 200]
    print(f"返回 200：{len(ok)}")
    print(f"非 200：{len(bad)}")
    print("--- 非 200 明细 ---")
    for url, status, err in bad:
        print(f"{status if status else 'ERR':>6}  {err:<18} {url}")


if __name__ == "__main__":
    main()
