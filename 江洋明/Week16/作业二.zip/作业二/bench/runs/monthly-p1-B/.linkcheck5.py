"""修正版链接核验：打印确切的不可达 URL，并抓取关键页标题用于人工确认。"""
import io
import re
import ssl
import sys
import urllib.error
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

REPORT = "report.md"
LINK_RE = re.compile(r"https?://[^\s)），,、|\"'>]+")
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9",
}
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE


def one(url, ctx=None):
    req = urllib.request.Request(url, headers=HEADERS, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=25, context=ctx) as resp:
            resp.read(1024)
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code
    except Exception:  # noqa: BLE001
        return None


def probe(url):
    if one(url) == 200:
        return url, 200, "https"
    alt = url.replace("https://", "http://", 1)
    if one(alt) == 200:
        return url, 200, "http"
    if one(url, CTX) == 200:
        return url, 200, "insecure"
    return url, None, "fail"


def title(url):
    req = urllib.request.Request(url, headers=HEADERS, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            raw = resp.read(20000)
    except Exception as exc:  # noqa: BLE001
        return f"ERR {exc}"
    for enc in ("utf-8", "gbk"):
        try:
            text = raw.decode(enc)
        except UnicodeDecodeError:
            continue
        m = re.search(r"<title[^>]*>(.*?)</title>", text, re.S | re.I)
        if m:
            return " ".join(m.group(1).split())
    return "(no title)"


with open(REPORT, encoding="utf-8") as fh:
    urls = sorted(set(LINK_RE.findall(fh.read())))
print(f"唯一链接总数：{len(urls)}")
with ThreadPoolExecutor(max_workers=10) as pool:
    results = list(pool.map(probe, urls))
ok = [r for r in results if r[1] == 200]
bad = [r for r in results if r[1] != 200]
print("可达方式分布：", dict(Counter(r[2] for r in ok)))
print(f"最终可达：{len(ok)}   不可达：{len(bad)}")
print("--- 不可达明细 ---")
for url, _status, _way in bad:
    print(f"  {url}")
print()
print("--- 关键页标题确认 ---")
for url in [
    "http://zrzy.wuhai.gov.cn/zrzy/1442257/qtgsgg/2496277/index.html",
    "http://zrzy.wuhai.gov.cn/zrzy/1442195/1442202/2192005/2496282/index.html",
    "http://xingtai.gov.cn/ywdt/jrxt/xtyw/202610/t20261010_736322.html",
    "https://coal.in-en.com/html/coal-2668726.shtml",
]:
    print(f"{title(url)}\n    {url}")
