"""对非 200 链接做二次诊断：打印底层异常原因，并对 https 失败的站点补试 http。

用法：python .linkcheck2.py
"""
import io
import socket
import ssl
import sys
import urllib.error
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}

TARGETS = [
    "https://hainanqu.gov.cn/mobile/c/2026-10-20/197915.shtml",
    "https://nxyjglt.nx.gov.cn/xwzx/gzdt/202610/t20261012_5368841.html",
    "https://wap.sasac.gov.cn//n2588025/n2588124/c36042676/content.html",
    "https://wap.sasac.gov.cn//n2588025/n2588124/c36061919/content.html",
    "https://www.ce.cn/cysc//newmain/yc/jsxw/202610/t20261015_3258635.shtml",
    "https://www.cets.org.cn/xyyw/7504.jhtml",
    "https://www.cqn.com.cn/zj/content/2026-10/30/content_9178740.htm",
    "https://www.shxcoal.com/news/news?id=11607",
    "https://www.shxcoal.com/responsibility?id=11451",
    "https://www.shxcoal.com/responsibility?id=11664",
    "https://xingtai.gov.cn/ywdt/jrxt/xtyw/202610/t20261010_736322.html",
    "https://zrzy.wuhai.gov.cn/zrzy/1442195/1442202/2192005/2496282/index.html",
    "https://zrzy.wuhai.gov.cn/zrzy/1442257/qtgsgg/2496277/index.html",
]


def describe(url, timeout=25):
    req = urllib.request.Request(url, headers=HEADERS, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read(2048)
            return f"OK {resp.status}"
    except urllib.error.HTTPError as exc:
        return f"HTTP {exc.code} {exc.reason}"
    except urllib.error.URLError as exc:
        reason = exc.reason
        if isinstance(reason, ssl.SSLCertVerificationError):
            return f"URLError SSL证书校验失败: {reason.reason}"
        if isinstance(reason, socket.timeout):
            return "URLError 超时"
        if isinstance(reason, ConnectionResetError):
            return "URLError 连接被重置"
        if isinstance(reason, socket.gaierror):
            return f"URLError DNS解析失败: {reason}"
        return f"URLError {type(reason).__name__}: {reason}"
    except Exception as exc:  # noqa: BLE001
        return f"{type(exc).__name__}: {exc}"


for url in TARGETS:
    line = f"{url}\n    https -> {describe(url)}"
    if url.startswith("https://"):
        http_url = "http://" + url[len("https://"):]
        line += f"\n    http  -> {describe(http_url)}"
    print(line)
