"""确认改为 http 的几个页面的标题与正文要点，确保换协议后指向同一篇原文。"""
import io
import re
import sys
import urllib.error
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

H = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9",
}

URLS = [
    "http://wap.sasac.gov.cn/n2588025/n2588124/c36061919/content.html",
    "http://wap.sasac.gov.cn/n2588025/n2588124/c36042676/content.html",
    "http://xingtai.gov.cn/ywdt/jrxt/xtyw/202610/t20261010_736322.html",
    "http://zrzy.wuhai.gov.cn/zrzy/1442257/qtgsgg/2496277/index.html",
    "https://coal.in-en.com/html/coal-2668726.shtml",
]

for url in URLS:
    req = urllib.request.Request(url, headers=H, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read(120000)
            status = resp.status
    except urllib.error.HTTPError as exc:
        print(f"[{exc.code}] {url}\n")
        continue
    except Exception as exc:  # noqa: BLE001
        print(f"[ERR {type(exc).__name__}] {url}\n")
        continue
    text = ""
    for enc in ("utf-8", "gbk"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    m = re.search(r"<title[^>]*>(.*?)</title>", text, re.S | re.I)
    title = " ".join(m.group(1).split()) if m else "(无)"
    body = re.sub(r"<script.*?</script>|<style.*?</style>", " ", text, flags=re.S | re.I)
    body = re.sub(r"<[^>]+>", " ", body)
    body = " ".join(body.split())
    print(f"[{status}] {url}")
    print(f"   标题: {title}")
    print(f"   摘要: {body[:260]}")
    for kw in ["日期", "2026", "公乌素", "海勃湾", "木垒", "绿证", "邢东", "香港", "国家电网"]:
        idx = body.find(kw)
        if idx >= 0:
            print(f"   [{kw}] ...{body[max(0, idx-50):idx+70]}...")
    print()
