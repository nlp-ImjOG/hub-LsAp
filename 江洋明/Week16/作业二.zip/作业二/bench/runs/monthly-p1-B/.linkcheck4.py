"""最终链接核验：https 优先，失败则按 http -> 忽略证书校验 两条退路重试。

用法：python .linkcheck4.py
"""
import io
import re
import ssl
import sys
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

REPORT = "report.md"
LINK_RE = re.compile(r"https?://[^\s)），,、|\"'>]+")
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE


def one(url, ctx=None):
    req = urllib.request.Request(url, headers=HEADERS, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=25, context=ctx) as resp:
            resp.read(1024)
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code
    except Exception:  # noqa: BLE001
        return None


def probe(url):
    """返回 (最终状态码, 走的哪条路径)。"""
    status = one(url)
    if status == 200:
        return 200, "https 直连"
    alt = url.replace("https://", "http://", 1)
    status = one(alt)
    if status == 200:
        return 200, "http 退路"
    status = one(url, CTX)
    if status == 200:
        return 200, "忽略证书校验"
    return status, "失败"


def main():
    with open(REPORT, encoding="utf-8") as fh:
        urls = sorted(set(LINK_RE.findall(fh.read())))
    print(f"唯一链接总数：{len(urls)}")
    with ThreadPoolExecutor(max_workers=10) as pool:
        results = list(pool.map(probe, urls))
    ok = [r for r in results if r[0] == 200]
    bad = [r for r in results if r[0] != 200]
    from collections import Counter

    print("可达方式分布：", dict(Counter(r[1] for r in ok)))
    print(f"最终可达：{len(ok)}   不可达：{len(bad)}")
    print("--- 不可达明细 ---")
    for url, (status, way) in bad:
        print(f"{str(status):>6}  {url}")


if __name__ == "__main__":
    main()
