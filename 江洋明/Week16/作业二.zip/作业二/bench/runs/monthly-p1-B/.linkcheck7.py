"""核验第二组候选链接（10 月窗口内的左云沉陷区报道）。"""
import io
import re
import ssl
import sys
import urllib.error
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

H = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9",
}
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

CANDIDATES = [
    "https://m.chinadevelopment.com.cn/checklist.php?s=index/detail/id/2021743",
    "https://www.chinadevelopment.com.cn/checklist.php?s=index/detail/id/2021743",
    "https://www.toutiao.com/article/7701686341490295330",
    "https://www.toutiao.com/article/7707230007517397504",
    "https://www.toutiao.com/article/7705393609964732943",
    "https://www.dtradio.com.cn/top/folder307/2026-10-30/f6wWWC3rpGt1HdyD.html",
]


def fetch(url, ctx=None):
    req = urllib.request.Request(url, headers=H, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, b""
    except Exception as exc:  # noqa: BLE001
        return None, f"{type(exc).__name__}: {exc}".encode()


for url in CANDIDATES:
    status, raw = fetch(url)
    how = "https"
    if status != 200:
        alt = url.replace("https://", "http://", 1)
        s2, raw2 = fetch(alt)
        if s2 == 200:
            status, raw, how = s2, raw2, "http"
        else:
            s3, raw3 = fetch(url, CTX)
            if s3 == 200:
                status, raw, how = s3, raw3, "insecure"
            else:
                status = status or s3
    print(f"[{status} via {how}] {url}")
    if status == 200:
        text = ""
        for enc in ("utf-8", "gbk"):
            try:
                text = raw.decode(enc)
            except UnicodeDecodeError:
                continue
            break
        m = re.search(r"<title[^>]*>(.*?)</title>", text, re.S | re.I)
        print("   标题:", " ".join(m.group(1).split())[:120] if m else "(无)")
        body = re.sub(r"<script.*?</script>|<style.*?</style>", " ", text, flags=re.S | re.I)
        body = re.sub(r"<[^>]+>", " ", body)
        body = " ".join(body.split())
        print("   正文前段:", body[:400])
        for kw in ["板上发电", "板下修复", "板下复绿", "樟子松", "旧高山", "58万", "沉陷区", "2026-10", "10月"]:
            idx = body.find(kw)
            if idx >= 0:
                print(f"   [{kw}] ...{body[max(0, idx-60):idx+80]}...")
    print()
