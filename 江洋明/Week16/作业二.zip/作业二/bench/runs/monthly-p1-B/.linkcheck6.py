"""核验候选替换链接的可达性与正文要点。"""
import io
import re
import ssl
import sys
import urllib.error
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

H = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9",
}
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

CANDIDATES = [
    "https://m.chinadevelopment.com.cn/checklist.php?s=index/detail/id/2021743.shtml",
    "https://www.chinadevelopment.com.cn/checklist.php?s=index/detail/id/2021743.shtml",
    "https://www.zuoyun.gov.cn/zyxrmzfz/tzggnr/202604/e0922df1274e4821a4df3dd5213c7315.shtml",
    "https://www.dtradio.com.cn/top/folder17/2026-10-28/xaxysUBLrBrtbpqc.html",
    "https://www.dtradio.com.cn/local/folder25/folder82/folder276/2026-10-28/uVELYsSDsOsl9DZl.html",
]


def fetch(url, ctx=None):
    req = urllib.request.Request(url, headers=H, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, b""
    except Exception as exc:  # noqa: BLE001
        return None, f"{type(exc).__name__}: {exc}".encode()


for url in CANDIDATES:
    status, raw = fetch(url)
    how = "https"
    if status != 200:
        alt = url.replace("https://", "http://", 1)
        s2, raw = fetch(alt)
        if s2 == 200:
            status, how = s2, "http"
        else:
            s3, raw3 = fetch(url, CTX)
            if s3 == 200:
                status, raw, how = s3, raw3, "insecure"
            else:
                status = status or s3
    print(f"[{status} via {how}] {url}")
    if status == 200:
        text = ""
        for enc in ("utf-8", "gbk"):
            try:
                text = raw.decode(enc)
            except UnicodeDecodeError:
                continue
            break
        m = re.search(r"<title[^>]*>(.*?)</title>", text, re.S | re.I)
        print("   标题:", " ".join(m.group(1).split()) if m else "(无)")
        body = re.sub(r"<script.*?</script>|<style.*?</style>", " ", text, flags=re.S | re.I)
        body = re.sub(r"<[^>]+>", " ", body)
        body = " ".join(body.split())
        for kw in ["板上发电", "板下修复", "板下复绿", "樟子松", "覆土", "张家场", "旧高山", "58万", "58 万", "沉陷区"]:
            idx = body.find(kw)
            if idx >= 0:
                print(f"   [{kw}] ...{body[max(0, idx-70):idx+90]}...")
    print()
