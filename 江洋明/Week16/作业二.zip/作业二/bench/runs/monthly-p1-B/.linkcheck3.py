"""对证书链不完整的站点用不校验证书的 SSL 再确认页面真实存在，并尝试 hainanqu 的其他路径。"""
import io
import ssl
import sys
import urllib.error
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9",
}
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE


def probe(url, ctx=None):
    req = urllib.request.Request(url, headers=HEADERS, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=25, context=ctx) as resp:
            body = resp.read(4000)
            return resp.status, body
    except urllib.error.HTTPError as exc:
        return exc.code, b""
    except Exception as exc:  # noqa: BLE001
        return None, f"{type(exc).__name__}: {exc}".encode()


print("=== 不校验证书重试 ===")
for url in [
    "https://nxyjglt.nx.gov.cn/xwzx/gzdt/202610/t20261012_5368841.html",
    "https://wap.sasac.gov.cn/n2588025/n2588124/c36042676/content.html",
    "https://wap.sasac.gov.cn/n2588025/n2588124/c36061919/content.html",
    "https://xingtai.gov.cn/ywdt/jrxt/xtyw/202610/t20261010_736322.html",
    "https://zrzy.wuhai.gov.cn/zrzy/1442257/qtgsgg/2496277/index.html",
    "https://zrzy.wuhai.gov.cn/zrzy/1442195/1442202/2192005/2496282/index.html",
    "https://www.cets.org.cn/xyyw/7504.jhtml",
]:
    status, body = probe(url, CTX)
    print(f"{status}  {url}")
    if isinstance(body, bytes) and len(body) > 100:
        try:
            text = body.decode("utf-8", errors="ignore")
        except Exception:  # noqa: BLE001
            text = ""
        print("     " + " ".join(text.split())[:220])

print()
print("=== hainanqu.gov.cn 路径变体 ===")
for url in [
    "https://hainanqu.gov.cn/c/2026-10-20/197915.shtml",
    "http://hainanqu.gov.cn/c/2026-10-20/197915.shtml",
    "http://hainanqu.gov.cn/mobile/c/2026-10-20/197915.shtml",
    "http://www.hainanqu.gov.cn/mobile/c/2026-10-20/197915.shtml",
]:
    status, body = probe(url)
    print(f"{status}  {url}")
    if isinstance(body, bytes) and len(body) > 50:
        print("     " + " ".join(body.decode("utf-8", errors="ignore").split())[:200])
