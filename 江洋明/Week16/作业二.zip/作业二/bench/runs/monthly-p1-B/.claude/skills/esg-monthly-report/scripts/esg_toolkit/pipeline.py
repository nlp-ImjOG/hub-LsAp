"""端到端流水线：检索 → 抓取 → 解析 → 去重 → 聚合。

三个 CLI（月报 / 汇总 / 每日推送）跑的都是这条流水线，区别只在：

============  ==================  ==========================
CLI           走哪条路线            时间窗
============  ==================  ==========================
月报          news（时政路线）      上一个自然月
汇总          tender（中标路线）    近 2 年
每日推送      tender + 状态差集     最近一次运行至今
============  ==================  ==========================

**为什么要有这个模块**：Skill 与脚本的差别不在"会不会搜索"，而在"谁来做抽取与聚合"。
把这条流水线固化下来，脚本臂就有一个稳定、可测、可复现的对照组；
Skill 臂则由 Claude Code 会话直接跑同一套检索式，再自行完成抽取与汇总。
两者共用 :mod:`esg_toolkit.keywords` 里的同一份口径，差异因此只剩"抽取与聚合由谁做"。
"""

from __future__ import annotations

import time
from typing import Callable, Iterable

from .aggregate import summarize
from .config import Config
from .fetch import Fetcher
from .impact import classify_impact
from .keywords import ESG_CATEGORIES, is_esg_related
from .models import NewsItem, SearchHit, TenderRecord
from .parse_news import (
    classify_tier,
    dedupe,
    extract_body,
    in_window,
    news_from_hits,
    published_from_html,
    relevance_score,
)
from .parse_tender import parse_tender_page, parse_tender_snippet
from .providers.base import SearchUnavailable
from .urls import canonical_url, site_of

Logger = Callable[[str], None]

# ---------------------------------------------------------------- 检索式

#: 月报的三个板块 —— 与《作业.txt》案例一的三条要求一一对应
NEWS_BOARDS: dict[str, list[str]] = {
    "ESG 政策、评级与标准动态": [
        "ESG 政策 监管 动态 最新",
        "ESG 评级 标准 披露 要求 最新",
        "交易所 可持续发展报告 指引 准则",
        "生态环境部 碳市场 碳排放 双碳 政策 通知",
    ],
    "行业动态与最佳实践": [
        "煤炭 能源 电力 行业 ESG 动态 最佳实践",
        "煤炭行业 绿色低碳 转型 政策 新闻",
        "矿山 绿色矿山 生态修复 行业进展",
        "能源企业 碳排放 核算 披露 实践",
    ],
    "公司动态、对标企业行动与建议": [
        "中国神华 ESG 可持续发展报告 最新",
        "中国神华 公告 碳中和 减排 绿色矿山",
        "中国神华 绿色电力 绿证 低碳 最新进展",
        "中国中煤 中国华能 国家能源集团 ESG 关键行动 最新",
    ],
}

#: 招投标检索式 —— 覆盖 ESG 的十个细分方向
TENDER_QUERIES: list[str] = [
    "ESG 可持续发展 项目 中标公告",
    "双碳 碳达峰 碳中和 项目 中标公告",
    "碳足迹 温室气体 碳排放核算 项目 中标",
    "节能降碳 节能改造 合同能源管理 中标公告",
    "绿色低碳 绿色工厂 绿色园区 绿色建筑 中标公告",
    "污染防治 生态治理 生态修复 项目 中标公告",
    "绿色金融 绿色信贷 绿色债券 ESG评价 中标",
    "生态产品价值实现 GEP 碳汇 碳交易 中标",
    "水资源 节水 水务 流域治理 项目 中标公告",
    "绿色供应链 负责任采购 可持续采购 中标",
]

#: 每个板块给报告的引言模板（模型可在此基础上改写）
BOARD_INTROS: dict[str, str] = {
    "ESG 政策、评级与标准动态": "本期检索到的政策、评级方法与披露标准相关动态。",
    "行业动态与最佳实践": "本期检索到的客户所属行业动态与可借鉴的最佳实践。",
    "公司动态、对标企业行动与建议": "本期检索到的客户公司动态、对标企业 ESG 关键行动，及其对客户 ESG 的影响与建议。",
}

#: 板块标题的序号前缀。
#:
#: Skill 方法层写死了三个板块标题是「一、」「二、」「三、」开头的（见
#: ``esg-monthly-report/SKILL.md`` 的"输出格式"一节）。脚本臂要跟纯方法臂
#: 用**完全一样**的标题 —— 否则 A/B 对比时，读者分不清差别是"内容写得好"
#: 还是"标题写法不一样"，盲评的"结构"分也就没了参照。
CN_ORDINALS: tuple[str, ...] = ("一", "二", "三", "四", "五", "六", "七", "八")


def _noop(_: str) -> None:
    return None


# ---------------------------------------------------------------- 检索


def search_many(
    provider,
    queries: Iterable[str],
    count: int = 8,
    log: Logger = _noop,
    label: str = "",
) -> list[SearchHit]:
    """跑多条检索式，合并结果并按规范化 URL 去重。

    单条检索式失败（超时、模型输出解析不了）不会中断整批 —— 记一条日志继续。
    但如果**所有**检索式都失败，就把异常抛出去：静默返回空列表会让上层
    生成一份"本期未检索到相关内容"的空报告，看起来像正常结果。
    """
    queries = list(queries)
    hits: list[SearchHit] = []
    seen: set[str] = set()
    failures = 0
    usage_total = 0

    for index, query in enumerate(queries, start=1):
        prefix = f"[{label}] " if label else ""
        log(f"{prefix}检索 {index}/{len(queries)}：{query}")
        try:
            got = provider.search(query, count=count)
        except SearchUnavailable as exc:
            failures += 1
            log(f"{prefix}  ! 检索失败：{exc}")
            continue

        usage = getattr(provider, "last_usage", None)
        if usage is not None:
            usage_total += getattr(usage, "input_tokens", 0) + getattr(usage, "output_tokens", 0)

        for hit in got:
            key = canonical_url(hit.url) or hit.title
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            hits.append(hit)

    if queries and failures == len(queries):
        raise SearchUnavailable(f"全部 {len(queries)} 条检索式都失败，放弃本次运行")

    log(f"{prefix}检索完成：{len(hits)} 条结果，消耗约 {usage_total} tokens")
    return hits


# ---------------------------------------------------------------- 招投标


def _merge_record(page: TenderRecord | None, snippet: TenderRecord | None) -> TenderRecord | None:
    """合并页面解析与摘要解析的结果：页面优先，摘要补空。

    页面抓不到时摘要就是唯一来源；两者都有时，页面通常更准（字段更全、
    表格优先于正则）。
    """
    if page is None:
        return snippet
    if snippet is None:
        return page

    merged = TenderRecord(
        title=page.title or snippet.title,
        url=page.url or snippet.url,
        buyer=page.buyer or snippet.buyer,
        winner=page.winner or snippet.winner,
        amount_yuan=page.amount_yuan if page.amount_yuan is not None else snippet.amount_yuan,
        amount_raw=page.amount_raw or snippet.amount_raw,
        published=page.published or snippet.published,
        package=page.package or snippet.package,
        province=page.province or snippet.province,
        category=page.category or snippet.category,
        extra={**snippet.extra, **page.extra},
    )
    return merged


def collect_tenders(
    config: Config,
    provider,
    fetcher: Fetcher | None = None,
    queries: list[str] | None = None,
    count: int = 8,
    since: str | None = None,
    until: str | None = None,
    fetch_pages: bool = True,
    log: Logger = _noop,
) -> list[TenderRecord]:
    """检索并解析中标记录。

    策略：**先解析摘要（免费），再按需抓页面**。只有当摘要里缺金额或缺中标单位
    时才去抓页面 —— 抓页面是整个流程里最慢的一步（可能 403、可能超时），
    不该对每条结果都做。

    时间窗 ``since`` / ``until`` 为闭区间，格式 ``YYYY-MM-DD``；``None`` 表示不限。
    """
    queries = queries or TENDER_QUERIES
    fetcher = fetcher or Fetcher(config)

    hits = search_many(provider, queries, count=count, log=log, label="招标")

    records: list[TenderRecord] = []
    fetched = 0
    for hit in hits:
        snippet_record = parse_tender_snippet(hit.snippet, hit.url, hit.title)

        needs_page = snippet_record is None or (
            snippet_record.amount_yuan is None or not snippet_record.winner
        )
        page_record = None
        if fetch_pages and needs_page and hit.url:
            result = fetcher.fetch(hit.url)
            fetched += 1
            if result.ok and result.html:
                page_record = parse_tender_page(result.html, hit.url, hit.title)

        record = _merge_record(page_record, snippet_record)
        if record is None:
            continue

        # ESG 相关性闸门：标题 + 摘要里必须命中 ESG 关键词
        haystack = f"{record.title} {hit.snippet}"
        if not is_esg_related(haystack):
            continue

        # **时间窗闸门**（闭区间）。
        #
        # 日期在这里是**已经确定**的：公告页先抓、字段先解析完，才走到这一步，
        # 所以不存在"等日期补出来再筛"的漏洞（新闻那条路线就有那个问题，
        # 见 :func:`collect_news`）。
        #
        # 日期判不出来的记录**保留**，但要在报告里单独计数 ——
        # 让它们混进"近 2 年"的结论里，等于拿没验证过的数据充数。
        if record.published:
            if since and record.published < since:
                continue
            if until and record.published > until:
                continue

        records.append(record)

    log(f"招标：抓取 {fetched} 个页面，解析出 {len(records)} 条记录")

    # 去重：同一份公告在多个站点转载
    seen: set[str] = set()
    unique: list[TenderRecord] = []
    for record in records:
        key = record.record_id
        if key in seen:
            continue
        seen.add(key)
        unique.append(record)

    unique.sort(key=lambda r: (r.published or ""), reverse=True)
    return unique


def tender_payload(
    records: list[TenderRecord],
    meta: dict,
    notes: list[str] | None = None,
) -> dict:
    """把中标记录组装成报告 payload。"""
    stats = summarize(records)
    #: 报告种类 —— 渲染层据此决定"统计概览"画哪几行（招投标和月报不是一回事）
    stats["kind"] = "tender"
    payload = {
        "meta": {**meta, "notes": notes or meta.get("notes", [])},
        "summary": "",
        "highlights": [],
        "sections": [],
        "records": [record.to_dict() for record in records],
        "stats": stats,
        "tables": {
            "buckets": stats["buckets"],
            "trend": stats["trend"],
            "hotspots": stats["hotspots"],
            "regions": stats["regions"],
            "categories": stats["categories"],
        },
    }
    return payload


# ---------------------------------------------------------------- 新闻


def collect_news(
    provider,
    fetcher: Fetcher | None = None,
    boards: dict[str, list[str]] | None = None,
    count: int = 8,
    start: str | None = None,
    end: str | None = None,
    fetch_bodies: bool = False,
    max_per_board: int = 12,
    log: Logger = _noop,
) -> dict[str, list[NewsItem]]:
    """按板块检索并整理新闻动态。

    返回 ``{板块名: [NewsItem, ...]}``。每个板块内部按相关性排序后截断。
    """
    boards = boards or NEWS_BOARDS
    fetcher = fetcher or Fetcher(Config.load())

    result: dict[str, list[NewsItem]] = {}

    for board, queries in boards.items():
        hits = search_many(provider, queries, count=count, log=log, label=board[:10])
        items = news_from_hits(hits, start=start, end=end, require_esg=True)

        # 板块三才判影响方向（政策板块的"发布"不是利好）
        enable_impact = "公司" in board
        for item in items:
            if not item.topic:
                item.topic = _guess_topic(item)
            if enable_impact:
                direction, trigger = classify_impact(item.title)
                item.impact = direction
                if trigger:
                    item.summary = f"[{direction}·{trigger}] {item.summary}".strip()

        if fetch_bodies:
            for item in items[:max_per_board]:
                if not item.url:
                    continue
                fetched = fetcher.fetch(item.url)
                if fetched.ok and fetched.html:
                    body = extract_body(fetched.html)
                    if body:
                        item.summary = body[:600]
                    # 抓到页面就能补日期 —— 搜索引擎给的 published 空的那些
                    if not item.published:
                        item.published = published_from_html(fetched.html)

        # **日期补全之后要再过一次时间窗。**
        # 上面补出来的日期常常在窗口外（搜索引擎没给日期的条目，抓到页面才
        # 看出是 11 月的），不重筛的话，月报里会混进别的月份的内容 ——
        # 而月报的整个前提就是"过去一个月"。
        if start and end:
            items = [item for item in items if in_window(item.published, start, end)]

        items = sorted(items, key=lambda i: relevance_score(i), reverse=True)[:max_per_board]
        result[board] = items
        log(f"月报板块「{board}」：保留 {len(items)} 条")

    return result


def _guess_topic(item: NewsItem) -> str:
    """给没有议题的新闻兜一个分类。"""
    haystack = f"{item.title} {item.summary}"
    best = ""
    best_hits = 0
    for category, words in ESG_CATEGORIES.items():
        hits = sum(1 for word in words if word in haystack)
        if hits > best_hits:
            best, best_hits = category, hits
    return best


def news_payload(
    boards: dict[str, list[NewsItem]],
    meta: dict,
    notes: list[str] | None = None,
    advice: list[str] | None = None,
) -> dict:
    """把分板块的新闻组装成月报 payload。"""
    sections = []
    for index, (board, items) in enumerate(boards.items()):
        section = {
            #: 展示用标题带序号，与方法层写死的三个板块标题一致
            "heading": f"{CN_ORDINALS[index % len(CN_ORDINALS)]}、{board}",
            #: 板块本身的键（不带序号），给程序匹配用
            "key": board,
            "intro": BOARD_INTROS.get(board, ""),
            "items": [item.to_dict() for item in items],
        }
        if board == "公司动态、对标企业行动与建议" and advice:
            section["advice"] = advice
        sections.append(section)

    topics = sorted(
        {
            item.topic
            for items in boards.values()
            for item in items
            if item.topic
        }
    )

    all_items = [item for items in boards.values() for item in items]
    stats = {
        #: 报告种类 —— 渲染层据此决定"统计概览"画哪几行
        "kind": "news",
        "total": len(all_items),
        #: 有发布日期的条数：月报是"过去一个月"的动态，日期缺失就是没交代清楚
        "dated": sum(1 for item in all_items if item.published),
        "topics": len(topics),
        "sources": len({item.source for item in all_items if item.source}),
        #: A 级信源（监管与官方）条数 —— 月报最看重的信源
        "tier_a": sum(1 for item in all_items if item.source_tier == "A"),
        "boards": {board: len(items) for board, items in boards.items()},
    }

    return {
        "meta": {**meta, "notes": notes or meta.get("notes", [])},
        "summary": "",
        "highlights": [],
        "sections": sections,
        "records": [],
        "stats": stats,
        "topics": topics,
    }


def news_facts(boards: dict[str, list[NewsItem]]) -> dict:
    """给 LLM 写摘要用的"事实清单"。

    只包含标题、日期、来源、议题、影响方向 —— **不含大段正文**：
    让模型基于事实清单写导语，而不是基于原文改写，输出更可控、也更短。
    """
    facts = {"boards": {}, "topics": []}
    topics: set[str] = set()

    for board, items in boards.items():
        rows = []
        for item in items:
            if item.topic:
                topics.add(item.topic)
            rows.append(
                {
                    "title": item.title,
                    "date": item.published or "",
                    "source": item.source or site_of(item.url),
                    "topic": item.topic,
                    "impact": item.impact,
                }
            )
        facts["boards"][board] = rows

    facts["topics"] = sorted(topics)
    return facts


# ---------------------------------------------------------------- 工具


def write_artifacts(output_dir, name: str, payload: dict, render_markdown, render_json, render_html) -> dict:
    """把 payload 落成 Markdown / JSON / HTML 三件套。"""
    from pathlib import Path

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    md_path = output_dir / f"{name}.md"
    json_path = output_dir / f"{name}.json"
    html_path = output_dir / f"{name}.html"

    md_path.write_text(render_markdown(payload), encoding="utf-8")
    json_path.write_text(render_json(payload), encoding="utf-8")
    html_path.write_text(render_html(payload), encoding="utf-8")

    return {"markdown": md_path, "json": json_path, "html": html_path}


def now_stamp() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")
