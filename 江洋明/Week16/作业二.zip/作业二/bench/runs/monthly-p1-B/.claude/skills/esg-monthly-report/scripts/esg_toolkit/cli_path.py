"""把 CLI 名字解析成**可直接执行**的路径。

单独抽成一个模块，是因为有两处都要用：搜索后端
(:mod:`esg_toolkit.providers.claude_cli`) 和叙事层
(:mod:`esg_toolkit.llm`)。叙事层漏掉这一步时**不会报错**，只会静默退回
确定性摘要 —— 报告看起来正常，但"模型写的导语"其实是模板拼的，
很容易被当成"模型写不出来"的结论，实际是路径没解析对。

Windows 上 npm 装的包是 ``claude.cmd`` 批处理包装器，批处理里会写真正的 exe 路径。
``CreateProcess`` 只认 ``.exe``，直接跑 ``claude`` 会报
``FileNotFoundError: [WinError 2]``。

这里不经过 ``cmd.exe /c`` —— 那样会把提示词里的引号、``&``、``%``
交给 cmd 再解析一遍，提示词里恰好有 JSON 示例的双引号，很容易被截断。
直接从包装器脚本里把真正的 ``.exe`` 抠出来最稳。
"""

from __future__ import annotations

import os
import re
import shutil
from pathlib import Path

__all__ = ["resolve_cli"]

#: Windows 上 npm 装的包是 ``claude.cmd`` 批处理包装器，批处理里会写真正的 exe 路径
_CMD_EXE_RE = re.compile(r'"([^"\n]*?\.exe)"', re.I)


def resolve_cli(cli: str) -> str:
    """把 CLI 名字解析成可以直接 ``subprocess.run`` 的路径。

    解析不到时原样返回，让调用方拿到一条更直白的"找不到可执行文件"。
    """
    resolved = shutil.which(cli)
    if not resolved:
        return cli
    if not resolved.lower().endswith((".cmd", ".bat")):
        return resolved

    try:
        text = Path(resolved).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return resolved

    base = str(Path(resolved).parent)
    for candidate in _CMD_EXE_RE.findall(text):
        expanded = candidate.replace("%~dp0", base).replace("%dp0%", base)
        path = Path(os.path.normpath(expanded))
        if path.is_file():
            return str(path)
    return resolved
