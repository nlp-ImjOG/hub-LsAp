"""HTML 正文提取。

单独抽一个模块，是因为"从公告页里把正文捞出来"这件事**月报和招投标两条线都要用**：
前者需要新闻正文，后者需要公告正文。放在 :mod:`esg_toolkit.parse_news` 里
会让招投标解析依赖"新闻"模块，语义不对。

去噪只做**可枚举**的活：去掉脚本、导航、页脚，剥掉纯装饰性文本。
判断"这段话说了什么"不在这里做 —— 那是 LLM 的活。
"""

from __future__ import annotations

import re

__all__ = ["extract_body", "NOISE_TAGS", "NOISE_PATTERNS", "chrome_lines"]

#: 页面里的导航、页脚、脚本等噪声区域
#:
#: 注意**不要**把 ``form`` 放进来 —— 中国政府采购网把整个公告正文包在
#: ``<form>`` 里（实测：辽宁那份温室气体清单公告的正文全在 form 内），
#: 删掉 form 等于把整篇文章删掉，正文只剩 600 字。
#: 要删的是表单**控件**，不是 form 本身。
NOISE_TAGS = (
    "script",
    "style",
    "noscript",
    "nav",
    "header",
    "footer",
    "aside",
    "input",
    "button",
    "select",
    "option",
    "textarea",
    "iframe",
    "svg",
)

#: 抽取正文时剥掉的导航性文本
NOISE_PATTERNS = [
    r"^\s*(首页|导航|网站首页|联系我们|网站地图|版权|备案|打印|分享|字号)\s*$",
    r"当前位置[：:].*$",
]

#: 政务与采购网站的固定 chrome（导航条、页脚联系信息）——
#: 它们既干扰阅读，也会污染省份判定（页脚里的"北京市"会让厦门的公告判成北京）
chrome_lines = re.compile(
    r"^(政采法规|购买服务|监督检查|信息公告|国际专栏|网站服务|服务热线|服务投诉"
    r"|当前位置|网站首页|财政采购|公告查询|政策法规|办事指南|常见问题"
    r"|中国政府采购网|财政部唯一指定|国家级政府采购|会员服务|平台介绍"
    r"|关于我们|联系我们|网站地图|版权所有|主办单位|承办单位|技术支持)",
)


def extract_body(html: str) -> str:
    """抽取页面正文。

    只做"去噪"不做"理解"：去掉脚本、导航、页脚后留下可读文本，
    剩下的判断交给上层。
    """
    if not html:
        return ""

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html, "lxml")
    for tag in soup(list(NOISE_TAGS)):
        tag.decompose()

    text = soup.get_text("\n")
    lines: list[str] = []
    for raw in text.splitlines():
        line = re.sub(r"[ \t\xa0]+", " ", raw).strip()
        if not line:
            continue
        if any(re.match(pattern, line) for pattern in NOISE_PATTERNS):
            continue
        if chrome_lines.match(line):
            continue
        lines.append(line)

    return "\n".join(lines)
