"""搜索后端协议。

脚本层不直接依赖某一个搜索引擎：上层只认 :class:`SearchProvider` 协议。
这样 A/B 实验里两臂可以共用同一个后端，把"搜索源差异"这个变量隔离掉，
对比结论才站得住。
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ..models import SearchHit


class SearchUnavailable(RuntimeError):
    """搜索后端不可用（缺 key、鉴权失败、超时……）。

    单独一个异常类型，是为了让上层能区分"后端坏了"和"这一查没有结果"——
    前者要重试或换后端，后者是正常业务结果。
    """


@runtime_checkable
class SearchProvider(Protocol):
    """检索后端协议。"""

    name: str

    def search(self, query: str, count: int = 10) -> list[SearchHit]:
        """执行一次检索，返回若干条结果。

        实现要求：
        - 没有任何结果时返回空列表，不要抛异常；
        - 后端本身出问题（鉴权/超时/网络）时抛 :class:`SearchUnavailable`。
        """
        ...
