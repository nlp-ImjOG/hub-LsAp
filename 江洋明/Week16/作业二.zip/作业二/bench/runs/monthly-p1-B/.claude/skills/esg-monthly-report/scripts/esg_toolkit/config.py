"""全局配置。

约定（与本仓库其他周次一致）：
- **绝不硬编码 API key**，只从环境变量 / `.env` 读取；
- `.env` 不入库（见 `.gitignore`）；
- 仓库里已有的第三方 key 实测已全部 401 失效，所以默认搜索后端是 claude CLI。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# 目录层级：作业二/scripts/esg_toolkit/config.py
PACKAGE_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = PACKAGE_DIR.parent
HOME_DIR = SCRIPTS_DIR.parent  # 作业二
WEEK16_DIR = HOME_DIR.parent  # 16-江洋明-第十六周作业


def _find_shared_assets() -> Path | None:
    """向上找跨周复用的 ``asserts/`` 目录。

    ``asserts/`` 在**课程根目录**下（``AI大模型应用/asserts``），而本仓库在
    ``AI大模型应用/作业/16-.../作业二`` —— 中间隔了两层。写死层数早晚会错，
    所以直接向上逐级找：哪一级存在 ``asserts/llm.qwen.env`` 就是它。

    找不到就返回 ``None``（不报错 —— 单机独立运行时本来就没有共享资产）。
    """
    for ancestor in (HOME_DIR, WEEK16_DIR, *WEEK16_DIR.parents):
        candidate = ancestor / "asserts"
        if (candidate / "llm.qwen.env").is_file():
            return candidate
    return None

DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


def parse_env_file(path: Path) -> dict[str, str]:
    """极简 `.env` 解析。

    支持 ``KEY=value``、``export KEY=value``、``#`` 注释、空行。
    不处理引号转义等复杂语法 —— 这个够用，且不引入第三方依赖。
    """
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if key:
            values[key] = value
    return values


def load_env_files(extra_paths: list[Path] | None = None) -> dict[str, str]:
    """收集 ``.env`` 候选文件，按优先级从低到高依次加载。

    优先级：仓库内 `asserts/llm.*.env` 等共享资产 < 作业目录 `.env` < 进程环境变量。
    这里只读取，不会写回文件。
    """
    candidates: list[Path] = []
    shared = _find_shared_assets()
    if shared is not None:
        # 共享资产优先级最低 —— 作业目录的 .env 要能覆盖它。
        candidates.append(shared / "llm.qwen.env")
        candidates.append(shared / "llm.deepseek.env")
    candidates += [
        HOME_DIR / ".env",
        HOME_DIR / "scripts" / ".env",
    ]
    if extra_paths:
        candidates.extend(extra_paths)

    merged: dict[str, str] = {}
    for path in candidates:
        merged.update(parse_env_file(Path(path)))
    return merged


@dataclass
class Config:
    """运行时配置。

    字段默认值即可用；需要覆盖时用环境变量（见 :meth:`load`）。
    """

    # 搜索后端：claude-cli（默认，唯一实测可用）或 bocha（需自备 key）
    search_provider: str = "claude-cli"
    claude_cli: str = "claude"
    claude_timeout: int = 420
    claude_search_count: int = 8

    bocha_api_key: str = ""
    bocha_endpoint: str = "https://api.bocha.cn/v1/web-search"
    bocha_count: int = 10

    # 抓取
    user_agent: str = DEFAULT_USER_AGENT
    request_timeout: int = 30
    max_retries: int = 3
    retry_backoff: float = 1.5
    #: requests 失败后是否用真实浏览器兜底（应对 ccgp.gov.cn 的 JS 挑战）
    browser_fallback: bool = True
    #: 浏览器打开页面后等待 JS 挑战完成的毫秒数
    browser_wait_ms: int = 4000

    # 路径
    cache_dir: Path = field(default_factory=lambda: HOME_DIR / "output" / "cache")
    output_dir: Path = field(default_factory=lambda: HOME_DIR / "output")
    state_path: Path = field(default_factory=lambda: HOME_DIR / "output" / "state" / "seen.json")

    # 推送（可选，留空则只落地文件）
    webhook_url: str = ""

    # 登录中文输出（Windows 控制台默认 GBK）
    force_utf8: bool = True

    @classmethod
    def load(cls, env: dict[str, str] | None = None) -> "Config":
        """按"进程环境变量 > .env > 默认值"的顺序组装配置。"""
        file_env = load_env_files()
        merged: dict[str, str] = {**file_env, **(env or {})}
        merged.update({k: v for k, v in os.environ.items() if v != ""})

        def pick(key: str, default: str) -> str:
            return merged.get(key, default)

        def pick_int(key: str, default: int) -> int:
            try:
                return int(merged.get(key, default))
            except (TypeError, ValueError):
                return default

        def pick_path(key: str, default: Path) -> Path:
            raw = merged.get(key)
            return Path(raw).expanduser() if raw else default

        def pick_bool(key: str, default: bool) -> bool:
            raw = merged.get(key)
            if raw is None:
                return default
            return raw.strip().lower() not in ("0", "false", "no", "off", "")

        return cls(
            search_provider=pick("ESG_SEARCH_PROVIDER", "claude-cli"),
            claude_cli=pick("ESG_CLAUDE_CLI", "claude"),
            claude_timeout=pick_int("ESG_CLAUDE_TIMEOUT", 420),
            claude_search_count=pick_int("ESG_SEARCH_COUNT", 8),
            bocha_api_key=pick("BOCHA_API_KEY", ""),
            bocha_endpoint=pick("BOCHA_ENDPOINT", "https://api.bocha.cn/v1/web-search"),
            bocha_count=pick_int("ESG_BOCHA_COUNT", 10),
            user_agent=pick("ESG_USER_AGENT", DEFAULT_USER_AGENT),
            request_timeout=pick_int("ESG_REQUEST_TIMEOUT", 30),
            max_retries=pick_int("ESG_MAX_RETRIES", 3),
            browser_fallback=pick_bool("ESG_BROWSER_FALLBACK", True),
            browser_wait_ms=pick_int("ESG_BROWSER_WAIT_MS", 4000),
            cache_dir=pick_path("ESG_CACHE_DIR", HOME_DIR / "output" / "cache"),
            output_dir=pick_path("ESG_OUTPUT_DIR", HOME_DIR / "output"),
            state_path=pick_path("ESG_STATE_PATH", HOME_DIR / "output" / "state" / "seen.json"),
            webhook_url=pick("ESG_WEBHOOK_URL", ""),
        )

    def ensure_dirs(self) -> None:
        """建好运行期需要的目录。"""
        for path in (self.output_dir, self.cache_dir, self.state_path.parent):
            path.mkdir(parents=True, exist_ok=True)
