"""默认搜索后端：claude CLI + 内置 WebSearch。

为什么不用 Bocha：仓库里现有的 Bocha / DeepSeek / DashScope key 实测全部 401 失效
（见《作业一/docs/01-设计说明.md》§3）。claude CLI 自带的 WebSearch 是当前唯一
可用的检索通道。

更重要的是**公平性**：Skill 臂（Claude Code 会话里直接用 WebSearch 工具）和脚本臂
（这里起一个 claude 子进程）用的是同一个搜索引擎引擎。评测里唯一变化的变量因此是
"抽取与聚合由谁完成"，而不是"两臂搜到的东西不一样"。若两臂用不同搜索源，
对比会被搜索差异污染，结论不成立。
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..cli_path import resolve_cli
from ..models import SearchHit
from ..urls import site_of
from .base import SearchUnavailable

# 让模型只吐 JSON 数组，减少解析歧义
PROMPT_TEMPLATE = """请使用 WebSearch 工具搜索下面的查询，返回最多 {count} 条结果。

严格只输出一个 JSON 数组，不要任何解释文字，不要用 markdown 代码块包裹。
每个元素只包含这四个字段：
{{"title": 标题, "url": 链接, "snippet": 结果摘要, "published": "YYYY-MM-DD" 或 null}}

查询：{query}
"""


@dataclass
class Usage:
    """一次检索的用量统计，供 A/B 实验的 token / 耗时指标使用。"""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    duration_ms: int = 0
    cost_usd: float = 0.0
    extra: dict[str, Any] = field(default_factory=dict)


def extract_json_array(text: str) -> list[dict[str, Any]]:
    """从模型输出里抠出 JSON 数组。

    模型偶尔会加代码块围栏或前后缀说明，逐级降级解析：
    整体解析 → 去掉围栏 → 截取第一个 ``[`` 到最后一个 ``]``。
    """
    if not text:
        return []
    text = text.strip()

    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text).strip()

    try:
        data = json.loads(text)
        return data if isinstance(data, list) else []
    except json.JSONDecodeError:
        pass

    start = text.find("[")
    end = text.rfind("]")
    if start != -1 and end > start:
        try:
            data = json.loads(text[start : end + 1])
            return data if isinstance(data, list) else []
        except json.JSONDecodeError:
            return []
    return []


def extract_envelope(stdout: str) -> dict[str, Any]:
    """从 claude CLI 的 stdout 里取出 JSON 信封。

    CLI 正常输出就是一行 JSON；偶尔前面会混进告警行，因此整行解析失败时
    退化为"逐行找第一份能解析的 JSON"。
    """
    stdout = (stdout or "").strip()
    if not stdout:
        return {}
    try:
        data = json.loads(stdout)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    for line in stdout.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            return data
    return {}


class ClaudeCliSearchProvider:
    """通过 ``claude -p`` 子进程调用内置 WebSearch。"""

    name = "claude-cli"

    def __init__(
        self,
        cli: str = "claude",
        timeout: int = 420,
        cwd: str | None = None,
        extra_args: list[str] | None = None,
    ) -> None:
        self.cli = cli
        self.timeout = timeout
        self.cwd = cwd
        self.extra_args = list(extra_args or [])
        #: 最近一次调用的用量，由 :meth:`search` 填充
        self.last_usage = Usage()

    def build_command(self, query: str, count: int) -> list[str]:
        prompt = PROMPT_TEMPLATE.format(count=count, query=query)
        return [
            self.cli,
            "-p",
            prompt,
            "--allowedTools",
            "WebSearch",
            "--output-format",
            "json",
            *self.extra_args,
        ]

    def search(self, query: str, count: int = 10) -> list[SearchHit]:
        # 第一个元素换成真正可执行的路径，其余保持 build_command 的逻辑
        cmd = [resolve_cli(self.cli), *self.build_command(query, count)[1:]]
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout,
                stdin=subprocess.DEVNULL,
                cwd=self.cwd,
            )
        except FileNotFoundError as exc:
            raise SearchUnavailable(f"找不到可执行文件：{self.cli}") from exc
        except subprocess.TimeoutExpired as exc:
            raise SearchUnavailable(f"检索超时（{self.timeout}s）：{query}") from exc

        envelope = extract_envelope(proc.stdout)
        if not envelope:
            raise SearchUnavailable(
                f"claude CLI 未返回可解析的 JSON（returncode={proc.returncode}）："
                f"{(proc.stderr or '').strip()[:300]}"
            )
        if envelope.get("is_error"):
            raise SearchUnavailable(f"claude CLI 返回错误：{str(envelope)[:300]}")

        self.last_usage = _read_usage(envelope)

        items = extract_json_array(envelope.get("result", ""))
        hits: list[SearchHit] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            url = str(item.get("url") or "").strip()
            title = str(item.get("title") or "").strip()
            if not url and not title:
                continue
            hits.append(
                SearchHit(
                    title=title,
                    url=url,
                    snippet=str(item.get("snippet") or "").strip(),
                    published=_normalize_date(item.get("published")),
                    source=site_of(url),
                )
            )
        return hits


def _normalize_date(value: Any) -> str | None:
    """把模型给的日期规整成 ISO；给不出就 None。"""
    if not value:
        return None
    text = str(value).strip()
    match = re.search(r"(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})", text)
    if not match:
        return None
    year, month, day = (int(g) for g in match.groups())
    if not (1 <= month <= 12 and 1 <= day <= 31):
        return None
    return f"{year:04d}-{month:02d}-{day:02d}"


def _read_usage(envelope: dict[str, Any]) -> Usage:
    usage = envelope.get("usage") or {}
    if not isinstance(usage, dict):
        usage = {}
    return Usage(
        input_tokens=int(usage.get("input_tokens") or 0),
        output_tokens=int(usage.get("output_tokens") or 0),
        cache_read_tokens=int(usage.get("cache_read_input_tokens") or 0),
        duration_ms=int(envelope.get("duration_api_ms") or 0),
        cost_usd=float(envelope.get("total_cost_usd") or 0.0),
    )
