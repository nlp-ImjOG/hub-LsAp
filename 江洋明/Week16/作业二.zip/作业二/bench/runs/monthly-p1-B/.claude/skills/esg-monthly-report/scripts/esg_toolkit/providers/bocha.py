"""Bocha 搜索后端（可选）。

Bocha 返回结构化 JSON、字段更规整，做日期过滤和去重比通用搜索更顺手。
但仓库里现存的 Bocha key 实测 401 失效，所以默认后端是 claude CLI；
自己申请到 key 后设 ``BOCHA_API_KEY`` 即可切换（``ESG_SEARCH_PROVIDER=bocha``）。

保留这个实现有两个理由：
1. provider 抽象只有一种实现时是"过度设计"，两种实现才说明抽象是真的；
2. 评测脚本需要在同一 provider 下跑两臂，切换后应能立刻换引擎而不是改代码。
"""

from __future__ import annotations

from typing import Any

from ..models import SearchHit
from ..urls import site_of
from .base import SearchUnavailable


class BochaSearchProvider:
    """调用 https://api.bocha.cn/v1/web-search。"""

    name = "bocha"

    def __init__(
        self,
        api_key: str,
        endpoint: str = "https://api.bocha.cn/v1/web-search",
        count: int = 10,
        timeout: int = 30,
    ) -> None:
        self.api_key = api_key
        self.endpoint = endpoint
        self.count = count
        self.timeout = timeout

    def search(self, query: str, count: int = 10) -> list[SearchHit]:
        if not self.api_key:
            raise SearchUnavailable("未配置 BOCHA_API_KEY，无法使用 Bocha 后端")

        import requests  # 延迟导入：没装 requests 时不该让 claude-cli 后端也失效

        payload = {"query": query, "summary": True, "count": count or self.count}
        try:
            resp = requests.post(
                self.endpoint,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=self.timeout,
            )
        except Exception as exc:  # 网络层任何异常都归为"后端不可用"
            raise SearchUnavailable(f"Bocha 请求失败：{exc}") from exc

        if resp.status_code != 200:
            raise SearchUnavailable(f"Bocha 返回 HTTP {resp.status_code}：{resp.text[:200]}")

        try:
            data = resp.json()
        except ValueError as exc:
            raise SearchUnavailable("Bocha 返回的不是合法 JSON") from exc

        pages = (
            (data.get("data") or {}).get("webPages") or {}
        ).get("value") or []
        return [_to_hit(page) for page in pages if isinstance(page, dict)]


def _to_hit(page: dict[str, Any]) -> SearchHit:
    url = str(page.get("url") or "").strip()
    snippet = str(page.get("snippet") or page.get("summary") or "").strip()
    return SearchHit(
        title=str(page.get("name") or "").strip(),
        url=url,
        snippet=snippet,
        published=_normalize_date(page.get("datePublished") or page.get("publishDate")),
        source=site_of(url) or str(page.get("displayUrl") or "").strip(),
    )


def _normalize_date(value: Any) -> str | None:
    import re

    if not value:
        return None
    text = str(value).strip()
    match = re.search(r"(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})", text)
    if not match:
        return None
    year, month, day = (int(g) for g in match.groups())
    if not (1 <= month <= 12 and 1 <= day <= 31):
        return None
    return f"{year:04d}-{month:02d}-{day:02d}"
