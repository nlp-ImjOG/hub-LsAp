"""esg_toolkit —— ESG 场景的确定性工具层。

这个包负责**可重复、可测试**的那部分工作：检索接入、抓取、字段抽取、去重、
时间窗、统计聚合、渲染、增量状态。

需要"理解、判断、写"的环节留给 Skill（LLM 侧）。两者的边界是：
凡是能写成确定规则的，就不要交给模型推理 —— 这是作业二要验证的核心命题。
"""

from __future__ import annotations

__version__ = "0.1.0"

__all__ = [
    "config",
    "models",
    "urls",
    "providers",
    "fetch",
    "parse_tender",
    "parse_news",
    "aggregate",
    "render",
    "state",
]
