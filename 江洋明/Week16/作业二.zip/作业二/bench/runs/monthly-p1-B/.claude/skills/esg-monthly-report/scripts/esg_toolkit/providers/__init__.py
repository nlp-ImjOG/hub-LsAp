"""搜索后端集合与工厂。"""

from __future__ import annotations

from ..config import Config
from .base import SearchProvider, SearchUnavailable
from .bocha import BochaSearchProvider
from .claude_cli import ClaudeCliSearchProvider

__all__ = [
    "SearchProvider",
    "SearchUnavailable",
    "ClaudeCliSearchProvider",
    "BochaSearchProvider",
    "build_provider",
]


def build_provider(config: Config) -> SearchProvider:
    """按配置装配搜索后端。

    默认 ``claude-cli``；显式指定 ``bocha`` 但没配 key 时，抛
    :class:`SearchUnavailable` 而不是静默降级 —— 静默降级会让评测悄悄换了
    搜索源，两臂就不再可比。
    """
    name = (config.search_provider or "claude-cli").strip().lower()

    if name in {"claude-cli", "claude_cli", "claude"}:
        return ClaudeCliSearchProvider(
            cli=config.claude_cli,
            timeout=config.claude_timeout,
        )

    if name == "bocha":
        if not config.bocha_api_key:
            raise SearchUnavailable(
                "ESG_SEARCH_PROVIDER=bocha 需要 BOCHA_API_KEY；"
                "仓库里现存的 key 实测已失效，请自备后设置环境变量。"
            )
        return BochaSearchProvider(
            api_key=config.bocha_api_key,
            endpoint=config.bocha_endpoint,
            count=config.bocha_count,
            timeout=config.request_timeout,
        )

    raise SearchUnavailable(f"未知的搜索后端：{config.search_provider}")
