"""URL 规范化。

同一份招标公告经常在多个站点转载，URL 也带着各自的追踪参数。
统一规范化之后才能跨轮次、跨站点识别"这是同一条公告"。
"""

from __future__ import annotations

from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

# 常见追踪参数，不影响公告身份，规范化时剔除
TRACKING_PARAMS = frozenset(
    {
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_term",
        "utm_content",
        "spm",
        "from",
        "share_token",
        "shareid",
        "timestamp",
        "_t",
        "rnd",
    }
)


def canonical_url(url: str) -> str:
    """把 URL 规范化成"同一条公告只有一个形态"的字符串。

    规则：统一协议与主机名大小写、去掉 ``www.`` 前缀、剔除追踪参数、
    参数按键排序、去掉路径尾部斜杠、丢弃锚点。

    空串原样返回，调用方可以安全地对空 URL 做去重。
    """
    if not url:
        return ""

    url = url.strip()
    parts = urlsplit(url)

    scheme = (parts.scheme or "http").lower()
    netloc = parts.netloc.lower()

    if netloc.startswith("www."):
        netloc = netloc[4:]

    query_pairs = [
        (k, v)
        for k, v in parse_qsl(parts.query, keep_blank_values=False)
        if k.lower() not in TRACKING_PARAMS
    ]
    query_pairs.sort()

    path = parts.path.rstrip("/") or "/"

    return urlunsplit((scheme, netloc, path, urlencode(query_pairs), ""))


def site_of(url: str) -> str:
    """取 URL 的站点名（主机名去掉 www.），用于信源分级。"""
    if not url:
        return ""
    netloc = urlsplit(url).netloc.lower()
    if netloc.startswith("www."):
        netloc = netloc[4:]
    return netloc
