#!/usr/bin/env python
"""ESG 招投标汇总（案例二上半部分）—— 脚本臂。

对应《作业.txt》案例二第 1 条：汇总过去 2 年 ESG、可持续发展、双碳相关的
中标情况，分析并汇总热点招标情况及中标金额分布。

本脚本产出的四张图正好对应作业要求的两个"分析"：

- **热点招标情况** → 热点方向词频（按项目标题统计）+ 地区分布 + 采购人类型分布；
- **中标金额分布** → 金额分档 + 月度走势 + 金额集中趋势。

用法::

    python tender_report.py                     # 汇总近 2 年
    python tender_report.py --years 3
    python tender_report.py --no-fetch          # 不抓公告页面，只用搜索摘要
    python tender_report.py --dry-run
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from esg_toolkit.cli import echo_result, force_utf8, make_logger, resolve_outdir  # noqa: E402
from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.llm import summarize_tenders  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page  # noqa: E402
from esg_toolkit.pipeline import (  # noqa: E402
    TENDER_QUERIES,
    collect_tenders,
    now_stamp,
    tender_payload,
    write_artifacts,
)
from esg_toolkit.providers import build_provider  # noqa: E402
from esg_toolkit.providers.base import SearchUnavailable  # noqa: E402
from esg_toolkit.render import (  # noqa: E402
    default_meta,
    render_html,
    render_json,
    render_markdown,
)


def load_fixture_records(log) -> list:
    """从 ``bench/fixtures/`` 的真实公告快照解析出中标记录。

    为什么要有这条路径：报告产物要能**离线复现**。走线上检索时，
    今天的搜索结果决定了明天的报告长什么样，交作业时截图就对不上了。
    32 份快照是固定的，解析口径改了重跑一次即可，截图永远一致。
    """
    bench_dir = Path(__file__).resolve().parents[1] / "bench"
    fixture_dir = bench_dir / "fixtures"
    truth_path = bench_dir / "ground_truth.json"
    if not truth_path.is_file():
        raise FileNotFoundError(f"找不到 {truth_path}")

    entries = json.loads(truth_path.read_text(encoding="utf-8")).get("fixtures", [])
    records = []
    for entry in entries:
        html_path = fixture_dir / entry["file"]
        if not html_path.is_file():
            log(f"  ! 跳过缺失的快照：{entry['file']}")
            continue
        html = html_path.read_text(encoding="utf-8", errors="replace")
        record = parse_tender_page(
            html, url=entry["url"], fallback_title=entry.get("title", "")
        )
        if record is None:
            log(f"  ! 未能解析出结构化记录：{entry['file']}")
            continue
        records.append(record)
    return records


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="生成 ESG 招投标汇总报告（案例二·脚本臂）")
    parser.add_argument("--years", type=int, default=2, help="回溯年数，默认 2 年")
    parser.add_argument("--out", default="", help="输出目录；默认 作业二/output/tender")
    parser.add_argument("--name", default="", help="产物文件名（不含扩展名）")
    parser.add_argument("--provider", default="", help="搜索后端：claude-cli / bocha")
    parser.add_argument("--count", type=int, default=8, help="每条检索式取回的结果数")
    parser.add_argument("--no-fetch", action="store_true", help="不抓公告页面，只用搜索摘要")
    parser.add_argument("--no-llm", action="store_true", help="不调用 LLM 写汇总说明")
    parser.add_argument("--dry-run", action="store_true", help="只打印检索式，不真正跑")
    parser.add_argument(
        "--from-fixtures",
        action="store_true",
        help="离线模式：用 bench/fixtures/ 的真实公告快照出报告（可复现，不联网）",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    args = build_parser().parse_args(argv)
    log = make_logger(True)

    today = date.today()
    since = date(today.year - args.years, today.month, 1).isoformat()
    until = today.isoformat()
    period_label = f"{since} ~ {until}"
    log(f"统计区间：{period_label}（近 {args.years} 年）")

    if args.dry_run:
        for query in TENDER_QUERIES:
            log(f"  - {query}")
        return 0

    config = Config.load()
    if args.provider:
        config.search_provider = args.provider
    config.ensure_dirs()

    out_dir = Path(args.out) if args.out else resolve_outdir(config, "tender")
    name = args.name or f"esg-tender-{today.strftime('%Y%m%d')}"

    if args.from_fixtures:
        # 离线模式：不联网，直接吃真实公告快照
        provider_name = "fixtures（离线快照）"
        log(f"离线模式：解析 {args.years} 年公告快照…")
        records = load_fixture_records(log)
    else:
        try:
            provider = build_provider(config)
        except SearchUnavailable as exc:
            log(f"搜索后端不可用：{exc}")
            return 2

        log(f"搜索后端：{provider.name}")
        provider_name = provider.name
        fetcher = Fetcher(config)

        records = collect_tenders(
            config,
            provider,
            fetcher=fetcher,
            queries=TENDER_QUERIES,
            count=args.count,
            since=since,
            until=until,
            fetch_pages=not args.no_fetch,
            log=log,
        )

    # 日期判不出来的记录：统计区间是"近 N 年"，这些条目证明不了自己落在区间里，
    # 数量摆到报告里，不藏。
    undated = sum(1 for record in records if not record.published)

    notes = [
        f"统计区间为近 {args.years} 年（{since} 起）。",
        "金额一律归一为「元」；原文串保留在 amount_raw 字段，可逐条核对。",
        "未能从公告中解析出金额的记录单独计入「金额未披露」一档，不做估算。",
    ]
    if undated:
        # 只有真的存在"日期判不出来"的记录时才提这一句 ——
        # 写「有 0 条记录……」是废话，读起来像出了状况。
        notes.append(
            f"有 {undated} 条记录解析不出发布日期（无法核实是否落在统计区间内），"
            "在统计概览里单独计数，不参与月度走势统计。"
        )
    notes.append(
        f"检索后端：{provider_name}；抽取与统计由确定性脚本完成，"
        "汇总说明由模型基于已统计数字撰写（不重新计算）。"
    )

    meta = default_meta(
        title="ESG / 可持续发展 / 双碳 招投标汇总报告",
        client="中国神华",
        period_start=since,
        period_end=until,
        data_source=(
            "bench/fixtures/ 的真实中标公告快照（离线可复现）"
            if args.from_fixtures
            else "公开网络检索（WebSearch）+ 各省公共资源交易中心 / 中国政府采购网公告"
        ),
        notes=notes,
    )

    payload = tender_payload(records, meta)
    stats = payload["stats"]
    amount = stats["amount"]

    payload["summary"] = (
        f"共汇总 {stats['total']} 条 ESG 相关中标记录，其中 {stats['with_amount']} 条"
        f"披露了中标金额，合计 {amount['total_yuan'] / 1e4:.1f} 万元，"
        f"中位数 {amount['median_yuan'] / 1e4:.1f} 万元。"
    )

    if not args.no_llm:
        log("调用模型撰写汇总说明…")
        facts = {
            "total": stats["total"],
            "with_amount": stats["with_amount"],
            "amount": stats["amount"],
            "hotspots": stats["hotspots"][:10],
            "regions": stats["regions"][:10],
            "buyers": stats["buyers"],
            "buckets": stats["buckets"],
        }
        narrative = summarize_tenders(config.claude_cli, period_label, facts)
        if narrative:
            payload["summary"] = narrative["summary"]
            payload["highlights"] = narrative["highlights"]
        else:
            log("  ! 模型未返回可用文本，保留确定性摘要")

    paths = write_artifacts(
        out_dir, name, payload, render_markdown, render_json, render_html
    )
    log("产物已生成：")
    for kind, path in paths.items():
        log(f"  {kind}: {path}")

    echo_result(
        {
            "period": period_label,
            "total": stats["total"],
            "with_amount": stats["with_amount"],
            "hotspots": stats["hotspots"][:5],
            "artifacts": {kind: str(path) for kind, path in paths.items()},
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
