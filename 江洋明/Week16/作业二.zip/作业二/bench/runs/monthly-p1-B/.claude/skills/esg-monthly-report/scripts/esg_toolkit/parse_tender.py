"""招标 / 中标公告解析。

公告页面的现实情况比想象中乱，解析器因此走**三级降级**：

1. **表格**：政务网站的公告几乎都是 key-value 表（``采购项目名称:`` /
   ``中标、成交金额`` ``(万元):``），这是最可靠的来源；
2. **正文正则**：没有表格时，从扁平文本里按标签正则捞字段；
3. **搜索摘要**：页面抓不到时（``ccgp.gov.cn`` 的 JS 挑战），用搜索引擎返回的
   摘要解析 —— 摘要里通常已经包含中标单位和金额。

三级都拿不到关键字段时返回 ``None``，由上层决定丢弃还是交给 LLM 读原文。
**宁可漏，不要猜** —— 金额猜错比没有金额危害大得多。

## 表格解析踩过的坑

全部来自真实公告（见 ``bench/fixtures/``，32 份快照）：

- ``采购单位`` 和 ``采购单位联系方式`` 都存在，只按标签匹配会取到**电话号码**；
- 中标结果表是「**表头行 + 数据行**」两行结构，直接按表头行取值会拿到
  「供应商地址」这种列名；
- 政府采购网的结果表列名是「中标供应商名称」/「中标供应商地址」，
  公共资源交易平台的是「中标人」/「中标价」，还有的写「供应商名称」/「评审总得分」——
  三套写法都得认；
- ``行政区域 | 浙江省 | 公告时间 | 2026年02月06日`` 是**一行两对**标签，
  只看第一格会漏掉公告时间；
- 金额栏可能写 ``￥174.000000 万元（人民币）``，也可能写 ``1,740,000.00元``，
  还可能单位单独占一格 —— 三种都要认；
- 合同能源管理类项目的中标金额是「**折扣：95.00%**」，不是固定金额，
  硬转成数字会得到一个假的 95 元。
"""

from __future__ import annotations

import re

from .htmlutil import extract_body
from .keywords import classify_category, infer_province
from .models import TenderRecord

# ---------------------------------------------------------------- 基础工具

NUMBER_RE = re.compile(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?")
DATE_RE = re.compile(r"(\d{4})\s*[-/年.]\s*(\d{1,2})\s*[-/月.]\s*(\d{1,2})")

#: 金额单位 -> 换算成「元」的倍数
UNIT_FACTORS: dict[str, float] = {
    "亿元": 1e8,
    "万元": 1e4,
    "千元": 1e3,
    "元": 1.0,
}

#: 表格里的字段别名。左边的正则命中后，取该行的值。
FIELD_PATTERNS: dict[str, str] = {
    "title": r"采购项目名称|招标项目名称|项目名称|标段名称|采购需求名称",
    "buyer": r"采购人名称|招标人名称|招标人|采购人|采购单位|招标单位",
    "winner": (
        r"中标[、,，]?成交供应商|中标供应商|成交供应商|中标[、,，]?成交人|中标人|供应商名称"
    ),
    "amount": r"中标[、,，]?成交金额|中标金额|成交金额|中标[、,，]?成交价|中标价|成交价",
    "published": (
        r"中标日期|成交日期|结果日期"
        r"|本项目信息公告日期|本项目信息发布日期|公告日期|公告时间|发布时间|发布日期|公示日期"
    ),
    "package": r"采购项目编号\s*/\s*包号|标段|包号|分包",
    "project_no": r"采购项目编号|项目编号|招标编号|采购编号",
    "region": r"行政区域|所属地区|所属辖区|采购地区",
}

#: 「纯联系方式」类标签。命中说明这一格是电话/地址，不是机构名。
#:
#: 注意不能简单地"标签里出现联系方式就排除"——政府采购网写的是
#: ``采购人名称、地址和联系方式:``，那**正是**采购人字段。
#: 所以只有当标签**整体**就是「XX联系方式 / XX地址 / XX电话」时才排除。
CONTACT_ONLY_RE = re.compile(
    r"^(?:采购单位|采购人|招标人|招标单位|代理机构|供应商|中标供应商|成交供应商|项目|单位)?"
    r"(?:联系方式|联系电话|电话|传真|地址|邮编|邮箱|电子邮箱)$"
)

#: 「字段说明行」里的列名。这一整行只有列名，数据在下一行。
LABEL_ROW_ANCHORS: set[str] = {
    "采购项目编号",
    "采购项目编号/包号",
    "包号",
    "标段名称",
    "标项名称",
    "合同包名称",
    "合同包号",
    "采购需求名称",
}

#: 已知的列名（归一化后）。用来识别"整行都是列名"的字段说明行，
#: 也用来判断某个取值本身是不是又一个列名（那就说明取错行了）。
LABEL_LIKE_VALUES: set[str] = {
    "采购项目编号",
    "采购项目编号/包号",
    "包号",
    "标段名称",
    "标项名称",
    "合同包名称",
    "合同包号",
    "采购需求名称",
    "标的名称",
    "品目号",
    "品目名称",
    "供应商名称",
    "供应商地址",
    "社会信用代码",
    "评审总得分",
    "中标成交金额",
    "中标成交金额元",
    "中标成交金额元元",
    "备注",
    "序号",
    "总中标金额",
    "中标价",
    "中标价元",
    "中标人",
    "合同包",
    "标段",
}

#: 结果表里「供应商」列的列名写法。三套公告模板各用一套。
SUPPLIER_COLUMN_RE = re.compile(
    r"^(?:中标成交|中标、成交|中标|成交)?供应商名称$"
    r"|^供应商$"
    r"|^中标人$|^成交人$|^中标单位$|^成交单位$"
    r"|^中标供应商$|^成交供应商$|^中标供应商名称$"
)

#: 结果表里「金额」列的列名写法。
AMOUNT_COLUMN_RE = re.compile(r"金额|^中标价|^成交价")

#: 结果表里「得分」列的列名写法。
SCORE_COLUMN_RE = re.compile(r"得分|合计|评分|排序")

#: 标签单元格归一化时要去掉的字符
_CELL_STRIP_RE = re.compile(r"[\s()（）\[\]【】：:、]")


def detect_unit(text: str) -> str:
    """从文本里找金额单位。

    顺序重要：``亿元`` 必须排在 ``元`` 前面，否则"亿元"会被误判成"元"。
    """
    if not text:
        return ""
    for unit in ("亿元", "万元", "千元", "元"):
        if unit in text:
            return unit
    return ""


def normalize_amount(
    raw: str | None, unit_hint: str | None = None
) -> tuple[float | None, str]:
    """把金额串归一为「元」。

    返回 ``(金额_元, 原文)``。解析不出时返回 ``(None, 原文)``——不猜。

    单位优先级：金额串自带的单位 > 表头单位提示 > 无（按元处理）。

    「折扣：95.00%」「中标价格(费率%): 96.00 %」这类**没有固定金额**的写法
    返回 ``None`` —— 合同能源管理、设计类项目常见，中标额是按折扣/费率算的，
    硬换算成 95 元是编数据。
    """
    if raw is None:
        return None, ""
    text = str(raw).strip()
    if not text:
        return None, ""

    if "折扣" in text or "%" in text or "费率" in text:
        return None, text

    match = NUMBER_RE.search(text)
    if not match:
        return None, text

    number_text = match.group(0)
    try:
        value = float(number_text.replace(",", ""))
    except ValueError:
        return None, text

    unit = detect_unit(text) or (unit_hint or "")
    factor = UNIT_FACTORS.get(unit, 1.0)
    return round(value * factor, 2), text


def extract_discount(raw: str | None) -> str:
    """从金额串里取出折扣率，如 ``折扣：95.00%`` -> ``95.00%``。"""
    if not raw:
        return ""
    match = re.search(r"折扣[：:]\s*([\d.]+\s*%)", str(raw))
    return match.group(1).replace(" ", "") if match else ""


def parse_date(raw: str | None) -> str | None:
    """把日期串解析成 ISO ``YYYY-MM-DD``。

    公告里日期常见三种写法：``2026-11-25``、``2026年11月25日``、``2026-11-3``。
    第三种**月份/日期不补零**，是最容易踩的坑，这里统一补齐。
    """
    if not raw:
        return None
    match = DATE_RE.search(str(raw))
    if not match:
        return None
    year, month, day = (int(g) for g in match.groups())
    if not (1 <= month <= 12 and 1 <= day <= 31):
        return None
    return f"{year:04d}-{month:02d}-{day:02d}"


def clean_org(text: str) -> str:
    """从「名称 + 地址」混合串里取出机构名。

    常见形态：

    - ``中国科学院城市环境研究所 福建省厦门市集美区...``（空格分隔）
    - ``航天联志技术有限公司,安徽省合肥市...``（逗号分隔）
    - ``名称:绍兴市上虞区杭州湾综合管理办公室 地址:绍兴市上虞区 ...``（键值串）
    """
    value = re.sub(r"\s+", " ", (text or "").strip())
    if not value:
        return ""

    # 去掉前缀标签
    value = re.sub(r"^(中标[、,，]?成交)?供应商名称[、,，]?地址[：:]?\s*", "", value)
    value = re.sub(r"^(名称|单位名称|机构名称|企业名称)[：:]\s*", "", value)
    value = re.sub(
        r"^(中标单位|成交供应商|中标供应商|供应商名称|中标人|招标人|采购人)[：:]\s*",
        "",
        value,
    )

    # 截断到第一个「地址 / 联系人 / 电话」之前
    value = re.split(
        r"\s*(?:地址|联系人|联系电话|联系方式|电话|传真|邮编|电子邮箱|邮箱)\s*[：:]", value
    )[0].strip()

    if not value:
        return ""

    # 优先在中文/英文逗号处切开
    match = re.match(r"^(.+?)[，,；;]\s*", value)
    if match and len(match.group(1)) <= 40:
        return match.group(1).strip()

    # 其次按空格切，取第一段
    parts = value.split(" ")
    if len(parts) > 1 and len(parts[0]) <= 40:
        return parts[0].strip()

    return value


# ---------------------------------------------------------------- 表格解析


def extract_rows(html: str) -> list[list[str]]:
    """把页面里所有表格行摊平成 ``[[单元格, 单元格, ...], ...]``。"""
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html or "", "lxml")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    rows: list[list[str]] = []
    for tr in soup.find_all("tr"):
        cells = [
            re.sub(r"\s+", " ", td.get_text(" ", strip=True)).strip()
            for td in tr.find_all(["td", "th"])
        ]
        cells = [c for c in cells if c]
        if cells:
            rows.append(cells)
    return rows


def _normalize_cell(cell: str) -> str:
    """归一化单元格：去掉空格与各类括号，便于比较。"""
    return _CELL_STRIP_RE.sub("", cell or "")


def _is_label_row(cells: list[str]) -> bool:
    """判断这一行是不是「字段说明行」。

    政府采购网的结构是::

        采购项目编号/包号 | 采购项目编号 | 包号 | 标段名称 | 采购需求名称
        2026-ZS1366-1    | 2026-ZS1366  | 1    | 某某项目 | 某某需求

    第一行整行都是列名，第二行才是数据。不识别的话会把「标段名称」
    当成包号的值 —— 实测踩过。

    判据：至少 3 格，且**每一格**都是已知列名，且至少含一个结构型列名。
    """
    if len(cells) < 3:
        return False
    normalized = [_normalize_cell(cell) for cell in cells]
    if not all(cell in LABEL_LIKE_VALUES for cell in normalized):
        return False
    return any(cell in LABEL_ROW_ANCHORS for cell in normalized)


def _map_label_row(labels: list[str], data: list[str]) -> dict[str, str]:
    """把「字段说明行」和它的数据行对应起来，取出包号、项目编号。"""
    fields: dict[str, str] = {}
    normalized = [_normalize_cell(cell) for cell in labels]

    for index, cell in enumerate(normalized):
        if index >= len(data):
            break
        value = data[index].strip()
        if not value or value in LABEL_LIKE_VALUES:
            continue
        if cell in ("标段名称", "标项名称", "合同包名称") and "package" not in fields:
            fields["package"] = value
        elif cell == "采购项目编号" and "project_no" not in fields:
            fields["project_no"] = value
    return fields


def _detect_result_header(cells: list[str]) -> dict[str, int | None] | None:
    """识别中标结果表 / 评审结果表的**表头行**，返回列名 -> 列序号。

    判据：至少 3 格，且存在「供应商」列。真实数据行不可能整行都是列名，
    而结果表一定有一列写供应商 —— 三套公告模板的列名写法都不一样，
    所以按正则匹配而不是写死。

    少于 3 格不算表头：``['供应商名称', '某某公司']`` 是 key-value 行，
    不是表头。

    首格特别长的也不算表头：那种行是**嵌套表格拍平**的产物
    （首格塞了整张表的文字），后面几格才是真正的列名。
    """
    if len(cells) < 3:
        return None
    if len(_normalize_cell(cells[0])) > 24:
        return None

    supplier: int | None = None
    amount: int | None = None
    score: int | None = None

    for index, cell in enumerate(cells):
        normalized = _normalize_cell(cell)
        if supplier is None and SUPPLIER_COLUMN_RE.match(normalized):
            supplier = index
        if amount is None and AMOUNT_COLUMN_RE.search(normalized):
            amount = index
        if score is None and SCORE_COLUMN_RE.search(normalized):
            score = index

    if supplier is None:
        return None
    return {"supplier": supplier, "amount": amount, "score": score}


def _collect_data_rows(rows: list[list[str]], index: int) -> list[list[str]]:
    """收集表头之后的数据行。

    规则：表头后的**第一行**总是数据；再往后只有当首格是纯数字（序号）
    才继续收 —— 否则会把下一张表的表头当成数据收进来。遇到新的表头也停。
    """
    data_rows: list[list[str]] = []
    cursor = index + 1
    while cursor < len(rows):
        cells = rows[cursor]
        if len(cells) < 2:
            break
        if _detect_result_header(cells) is not None:
            break
        if data_rows and not re.fullmatch(r"\d+", cells[0].strip()):
            break
        data_rows.append(cells)
        cursor += 1
    return data_rows


def _match_field(label: str) -> str | None:
    """判断一个标签命中了哪个字段。"""
    if not label or len(label) > 24:
        return None

    normalized = _normalize_cell(label)
    if CONTACT_ONLY_RE.match(normalized):
        # 「采购单位联系方式」「供应商地址」这类格子不是机构名
        return None

    for field, pattern in FIELD_PATTERNS.items():
        if re.search(pattern, label):
            return field
    return None


def _row_pairs(cells: list[str]) -> list[tuple[str, str]]:
    """把一行拆成若干「标签 - 取值」对。

    政务公告里有两种行结构：

    - ``['采购项目名称', '某某项目']`` —— 一对；
    - ``['行政区域', '浙江省', '公告时间', '2026年02月06日 16:35']`` —— **两对**。

    只看第一格会把「公告时间」整行漏掉，所以两对的情况要显式处理。
    """
    if len(cells) >= 4:
        return [(cells[0], cells[1]), (cells[2], " ".join(cells[3:]))]
    if len(cells) >= 2:
        return [(cells[0], " ".join(cells[1:]))]
    return []


def fields_from_rows(rows: list[list[str]]) -> dict[str, str]:
    """从表格行里抽取字段。

    表格结构不统一：有的行是 ``[标签, 值]``，有的把标签和单位拆成两格
    （``["中标、成交金额", "(万元):", "37.5"]``），有的是一行两对标签，
    结果表还是「表头行 + 数据行」两行结构。这里统一处理。
    """
    fields: dict[str, str] = {}
    amount_unit_hint = ""
    total_amount = ""
    pending_labels: list[str] | None = None

    for index, cells in enumerate(rows):
        if not cells:
            continue

        # ---- 字段说明行：整行都是列名，数据在下一行 ----
        if _is_label_row(cells):
            pending_labels = cells
            continue

        # ---- 结果表表头：供应商 / 金额 / 得分 三列结构 ----
        header = _detect_result_header(cells)
        if header is not None:
            data_rows = _collect_data_rows(rows, index)
            if data_rows:
                supplier_index = header["supplier"]
                if supplier_index is not None and supplier_index < len(data_rows[0]):
                    fields.setdefault("winner", data_rows[0][supplier_index])

                amount_index = header["amount"]
                if amount_index is not None:
                    values = [
                        row[amount_index]
                        for row in data_rows
                        if amount_index < len(row)
                    ]
                    if values:
                        fields.setdefault("amount", _join_amounts(values))
                        fields.setdefault("amount_unit", detect_unit(values[0]))
                        if any("折扣" in value for value in values):
                            fields.setdefault("discount", _first_discount(values))
            continue

        # ---- 字段说明行的数据行 ----
        if pending_labels is not None:
            for key, value in _map_label_row(pending_labels, cells).items():
                fields.setdefault(key, value)
            pending_labels = None
            continue

        # ---- 普通 key-value 行 ----
        # 有些公告把「标签：值」写在一格里（``['中标人: 某某公司']``），
        # 先拆开再走统一的解析。
        if len(cells) == 1:
            split = re.match(r"^([^：:]{2,24})[：:]\s*(.+)$", cells[0])
            if split:
                cells = [split.group(1), split.group(2)]

        for label, value in _row_pairs(cells):
            if not label:
                continue
            matched = _match_field(label)
            if not matched:
                # 也可能是 ``["(万元):", "37.5"]`` 这种单位独占一格
                if detect_unit(label) and len(cells) >= 2:
                    amount_unit_hint = amount_unit_hint or detect_unit(label)
                continue

            value = value.strip()
            if not value or value in LABEL_LIKE_VALUES:
                continue

            if matched == "amount":
                if "费率" in label or "%" in label:
                    # 「中标价格(费率%): 96.00 %」不是固定金额
                    fields.setdefault("rate", value)
                    continue
                unit_hint = detect_unit(label) or amount_unit_hint
                amount_text = ""
                for offset, cell in enumerate(cells[1:]):
                    cell_unit = detect_unit(cell)
                    if offset == 0 and cell_unit and not re.search(r"\d", cell):
                        unit_hint = unit_hint or cell_unit
                        continue
                    if re.search(r"\d", cell):
                        unit_hint = unit_hint or cell_unit
                        amount_text = cell
                        break
                if not amount_text:
                    # 值不在本行，去下一行找
                    for next_cells in rows[index + 1 : index + 3]:
                        for cell in next_cells:
                            if re.search(r"\d", cell):
                                amount_text = cell
                                break
                        if amount_text:
                            break
                if amount_text:
                    if "总" in label:
                        total_amount = total_amount or amount_text
                    else:
                        fields.setdefault("amount", amount_text)
                    fields["amount_unit"] = unit_hint
                    if "折扣" in amount_text:
                        fields.setdefault("discount", extract_discount(amount_text))
                continue

            if matched == "published":
                # 「中标日期」比「招标公告日期」更贴近结果公告的发布时点 ——
                # 两者分开存，最终取值时结果日期优先。
                if re.search(r"中标日期|成交日期|结果日期", label):
                    fields.setdefault("published_result", value)
                else:
                    fields.setdefault("published", value)
                continue

            if matched in ("buyer", "winner"):
                if matched == "buyer":
                    value = (
                        _extract_after_label(
                            value, r"采购人名称|招标人名称|采购人|招标人|采购单位"
                        )
                        or value
                    )
                fields.setdefault(matched, value)
                continue

            fields.setdefault(matched, value)

    if total_amount and not fields.get("amount"):
        # 「总中标金额」只在结果表里没有金额时用。两者都有时以**结果表的
        # 分项金额**为准 —— 那是合同金额；「总」那一行是汇总值，实测遇到过
        # 两者对不上（上海数智管理：表里 2622440.00 元，总额写 262.240000 万元）。
        fields["amount"] = total_amount
        fields["amount_unit"] = detect_unit(total_amount) or fields.get("amount_unit", "")

    return fields


def _join_amounts(values: list[str]) -> str:
    """多包项目：把各包金额加起来。

    单包时原样返回，避免把 ``总价：798000（元）`` 这种串改写掉。
    """
    if len(values) == 1:
        return values[0]

    total = 0.0
    for value in values:
        amount, _ = normalize_amount(value)
        if amount is None:
            return values[0]
        total += amount
    return str(round(total, 2))


def _first_discount(values: list[str]) -> str:
    for value in values:
        discount = extract_discount(value)
        if discount:
            return discount
    return ""


def _extract_after_label(value: str, label_pattern: str) -> str:
    """从 ``采购人名称：厦门市生态环境局 地址：...`` 里截出机构名。

    ``label_pattern`` 是"或"关系，必须用非捕获组包起来 —— 否则正则的
    交替优先级会让 ``(.+)`` 落到最后一个分支上，取出来的 group 全错位。
    """
    match = re.search(rf"(?:{label_pattern})\s*[：:]\s*(.+)", value)
    if not match:
        return ""
    candidate = re.split(r"\s*地址\s*[：:]", match.group(1))[0]
    return candidate.strip()


# ---------------------------------------------------------------- 正则解析

TEXT_PATTERNS: dict[str, str] = {
    # 注意 "采购项目名称" 与 "项目名称" 都可能出现在正文里，后者要能覆盖
    "title": r"(?:采购|招标)?项目名称\s*[：:]\s*(.+)",
    "buyer": (
        r"(?:采购人名称|招标人名称|采购人|招标人|采购单位|招标单位)"
        r"\s*[：:]\s*(.+?)(?:\s*地址|\s*联系方式|\n|$)"
    ),
    "winner": (
        r"(?:中标[、,，]?成交供应商名称[、,，]?地址|中标[、,，]?成交供应商名称"
        r"|中标[、,，]?成交供应商|中标供应商名称|成交供应商名称"
        r"|中标供应商|成交供应商|中标单位|供应商名称)\s*[：:]\s*(.+?)(?:\s*地址|\n|$)"
    ),
    "package": r"采购项目编号\s*/\s*包号\s*[：:]\s*(.+)",
    "project_no": r"(?:采购项目编号|项目编号|招标编号)\s*[：:]\s*(.+)",
    "region": r"(?:行政区域|所属地区)\s*[：:]\s*(.+)",
}

#: 结果公告的发布时点。``中标日期`` 比 ``招标公告日期`` 更贴近"这条结果
#: 是什么时候公布的"，所以优先找前者。
PUBLISHED_RESULT_RE = re.compile(r"(?:中标日期|成交日期|结果日期)\s*[：:]\s*(.+)")
PUBLISHED_FALLBACK_RE = re.compile(
    r"(?:本项目信息公告日期|本项目信息发布日期|发布日期|公告日期|公告时间|发布时间|信息时间)"
    r"\s*[：:]\s*(.+)"
)

#: 「1.采购人信息 / 名 称：XXX」这种分节写法。
#:
#: 标签是「名 称」（中间还带一个空格），不是「采购人名称」，所以正则里
#: 的字段匹配抓不到 —— 得靠前面的分节标题来定位。
BUYER_SECTION_RE = re.compile(
    r"(?:采购人|招标人)(?:信息|单位)[\s\S]{0,60}?名\s*称\s*[：:]\s*(.+?)(?:\s*地址|\n|$)"
)

#: 金额必须**带单位**才算命中。
#:
#: 不带单位会误伤：结果表的表头被拍平成文本后是
#: "中标/成交金额 1 江苏龙腾工程设计股份有限公司 …"，不带单位的话
#: 序号「1」会被当成金额。宁可漏掉，也不拿序号当金额。
AMOUNT_TEXT_RE = re.compile(
    r"(?:中标|成交)[^。\n]{0,10}?(?:金额|价)\s*[：:]?\s*"
    r"([\d,，]+(?:\.\d+)?)\s*[（(]?\s*(亿元|万元|千元|元)\s*[）)]?"
)


def fields_from_text(text: str) -> dict[str, str]:
    """从扁平正文里用正则抽字段。"""
    fields: dict[str, str] = {}

    for field, pattern in TEXT_PATTERNS.items():
        match = re.search(pattern, text)
        if match:
            fields[field] = match.group(1).strip()

    published = PUBLISHED_RESULT_RE.search(text)
    if published:
        fields["published_result"] = published.group(1).strip()
    else:
        fallback = PUBLISHED_FALLBACK_RE.search(text)
        if fallback:
            fields["published"] = fallback.group(1).strip()

    if not fields.get("buyer"):
        section = BUYER_SECTION_RE.search(text)
        if section:
            fields["buyer"] = section.group(1).strip()

    match = AMOUNT_TEXT_RE.search(text)
    if match:
        fields["amount"] = f"{match.group(1)}{match.group(2)}"
        fields["amount_unit"] = match.group(2)

    return fields


# ---------------------------------------------------------------- 对外接口


def _merge_fields(*sources: dict[str, str]) -> dict[str, str]:
    """合并多来源字段，前面的优先（更可靠的来源在前）。"""
    merged: dict[str, str] = {}
    for source in sources:
        for key, value in source.items():
            if key in merged and merged[key]:
                continue
            if value:
                merged[key] = value
    return merged


#: 站点名的常见结尾。``<title>`` 只有这些词、又没有公告字样时，
#: 说明它是网站名而不是公告标题 —— 直接拿来当标题会得到"荆门公共资源交易网"。
SITE_NAME_TAIL_RE = re.compile(
    r"(网|平台|中心|系统|网站|交易网|交易中心|资源交易中心|政务|信息网|门户)$"
)

#: 公告类型词。标题里**只有**这些词，说明它是"这是一则中标公告"这种
#: 栏目名，不是项目名。
GENERIC_TITLE_WORDS: tuple[str, ...] = (
    "中标", "成交", "结果", "公告", "公示", "通知", "采购", "招标",
    "更正", "变更", "澄清", "流标", "废标", "终止", "重招",
)


def _is_generic_title(title: str) -> bool:
    """标题是否只是公告类型词，没有项目内容。

    莆田公共资源交易网那份公告的页面标题就是"中标（成交）结果公告" ——
    拿它当报告标题等于什么都没说（真实标题是"湄洲岛上既有建筑节能改造项目
    （合同能源管理）"）。

    判据不是"标题里含不含公告字样"，而是**去掉通用词之后还剩不剩东西**：
    "某某项目中标公告"去掉"中标/公告"还剩"某某项目"，是真标题；
    "中标（成交）结果公告"去掉后只剩括号和标点，是通用标题。
    """
    if not title:
        return True
    residue = title
    for word in GENERIC_TITLE_WORDS:
        residue = residue.replace(word, "")
    residue = re.sub(r"[\s（）()【】\[\]〈〉《》、,，.。:：;；\-—_·|/\\\"'“”‘’]", "", residue)
    return not residue


def _clean_title(text: str) -> str:
    """清理标题：去掉编号尾巴。

    北京公共资源交易平台把编号也塞进标题：
    ``平谷区金海湖岸线整治和生态修复项目中标结果公告 交易项目编号：S110000A001...``
    """
    value = re.sub(r"\s+", " ", (text or "").strip())
    value = re.sub(
        r"\s*[（(]?\s*(交易项目编号|招标项目编号|项目编号|采购项目编号)\s*[：:]\s*[^）)\s]*\s*[）)]?\s*$",
        "",
        value,
    )
    return value.strip()


def _page_title(html: str, body_text: str = "") -> str:
    """从页面**内容**里取公告标题（不碰 ``<title>``）。

    ``<title>`` 常常只是网站名（宣城市公共资源交易中心的 ``<title>`` 就是
    "宣城市公共资源交易中心"），所以优先找页面里的标题元素。

    返回空串表示"这个页面里找不到像公告标题的东西"，由调用方决定
    用搜索结果标题兜底。
    """
    from bs4 import BeautifulSoup

    if not html:
        return ""

    soup = BeautifulSoup(html, "lxml")

    candidates: list[str] = []
    for tag in soup.find_all("h1"):
        candidates.append(re.sub(r"\s+", " ", tag.get_text(" ", strip=True)))
    for tag in soup.find_all(class_=re.compile(r"title", re.I)):
        text = re.sub(r"\s+", " ", tag.get_text(" ", strip=True))
        if text and text not in candidates:
            candidates.append(text)

    # 标题里应该带这些词，否则多半是「办理流程公开」这类栏目名
    title_words = ("公告", "结果", "通知", "公示", "中标", "成交", "更正", "变更")

    picked = ""
    for text in candidates:
        if len(text) < 8:
            continue
        if any(word in text for word in title_words):
            if len(text) > len(picked):
                picked = text
    if picked:
        return _clean_title(picked)

    for text in candidates:
        if len(text) >= 8 and len(text) > len(picked):
            picked = text
    if picked:
        return _clean_title(picked)

    # 再从正文里找一行以「公告」结尾的标题
    for line in (body_text or "").splitlines():
        line = line.strip()
        if len(line) >= 10 and line.endswith(("公告", "公示", "通知")):
            return _clean_title(line)

    return ""


#: 只含日期的一行（标题正下方常放发布日期）
DATE_LINE_RE = re.compile(r"^\s*(\d{4})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})\s*日?\s*$")


def _header_date(title: str, body_text: str) -> str:
    """标题正下方的日期 —— 政务站点普遍把公告发布日期显示在那里。

    为什么单独抽一条：公告正文里自称的日期**不一定**是这份结果的发布日期。
    北京市石景山区那份中标公告，正文第八节写着"公告发布时间：2026年06月05日"
    （其实是采购公告的日期），而站点自己在标题下面标的是 2026-07-03 ——
    URL 路径 ``/2026/7/`` 和 CMS 的 ``publishdate`` 也都是 07-03。

    报告要回答的是"这条结果什么时候进入公众视野"，所以日期以**信源站发布的
    那一刻**为准：优先「中标日期」，其次标题旁的日期，最后才信正文里的字段。

    判据很紧：必须在正文里找到与标题**完全相同**的一行，且它的**下一行**
    是纯日期。32 份样本里只有 1 份触发，其余不误伤。
    """
    if not title or not body_text:
        return ""

    key = re.sub(r"\s+", "", title)
    lines = [line for line in body_text.splitlines() if line.strip()]
    for index, line in enumerate(lines[:-1]):
        if re.sub(r"\s+", "", line) != key:
            continue
        match = DATE_LINE_RE.match(lines[index + 1])
        if match:
            year, month, day = (int(part) for part in match.groups())
            if 1 <= month <= 12 and 1 <= day <= 31:
                return f"{year:04d}-{month:02d}-{day:02d}"
    return ""


def _site_title(html: str) -> str:
    """页面 ``<title>``，去掉站点后缀。实在没别的标题时才用。"""
    from bs4 import BeautifulSoup

    if not html:
        return ""

    soup = BeautifulSoup(html, "lxml")
    if not soup.title or not soup.title.string:
        return ""

    title = re.sub(r"\s+", " ", soup.title.string).strip()
    # 去掉「- 中国政府采购网」这类站点后缀
    title = re.sub(r"\s*[-|_]\s*[^-|_]{2,20}(网|平台|中心|系统)\s*$", "", title)
    title = title.strip()
    if not title:
        return ""
    # 只剩一个网站名就别用了
    if SITE_NAME_TAIL_RE.search(title) and not any(
        word in title for word in ("公告", "结果", "中标", "成交", "通知", "公示")
    ):
        return ""
    return _clean_title(title)


def parse_tender_page(
    html: str, url: str = "", fallback_title: str = ""
) -> TenderRecord | None:
    """解析一个完整的公告页面。"""
    if not html:
        return None

    rows = extract_rows(html)
    table_fields = fields_from_rows(rows)

    body_text = extract_body(html)
    text_fields = fields_from_text(body_text)

    fields = _merge_fields(table_fields, text_fields)

    # 标题的优先级：表格里的「采购项目名称」最结构化，其次是页面标题元素，
    # 再退到正文正则、搜索结果标题，最后才是站点 ``<title>``。
    #
    # 但要跳过**通用标题**（"中标（成交）结果公告"这种栏目名）—— 见
    # :func:`_is_generic_title`。通用标题等于没标题，不如退到下一个候选。
    title_candidates: list[str] = [
        table_fields.get("title", ""),
        _page_title(html, body_text),
        text_fields.get("title", ""),
        fallback_title,
        _site_title(html),
    ]
    title = ""
    for candidate in title_candidates:
        if candidate and not _is_generic_title(candidate):
            title = candidate
            break
    if not title:
        # 全是通用标题 —— 退而求其次，用第一个非空的
        title = next((c for c in title_candidates if c), "")
    if not title:
        return None

    amount_yuan, amount_raw = normalize_amount(
        fields.get("amount"), fields.get("amount_unit")
    )

    discount = fields.get("discount", "")
    if discount and (amount_yuan is None or amount_yuan == 0):
        # 合同能源管理这类项目没有固定中标额，只给折扣率
        amount_yuan = None

    winner_raw = fields.get("winner", "")
    winner = clean_org(winner_raw)
    buyer = clean_org(fields.get("buyer", ""))

    published = (
        parse_date(fields.get("published_result"))
        or _header_date(title, body_text)
        or parse_date(fields.get("published"))
    )

    # 分类与省份：标题、采购人、正文一起判断，信息更全。
    # 正文用**去噪后**的版本 —— 政务站点的页脚里有"北京市"，用它判省份
    # 会把一篇厦门的公告判成北京。
    haystack = " ".join(
        [
            title,
            buyer,
            winner_raw,
            fields.get("package", ""),
            fields.get("region", ""),
            body_text[:3000],
        ]
    )
    category = classify_category(haystack)
    # 省份先看**行政区域**字段：它是采购公告里明写归属地的字段，比正文
    # 可靠得多。库车那份公告的正文里中标人是"深圳市华仁智信技术有限公司"，
    # 按正文找地名会先撞上"深圳"判成广东；行政区域写的是"新疆维吾尔自治区"。
    province = infer_province(fields.get("region", ""), "") or infer_province(haystack, url)

    extra = {
        key: value
        for key, value in {
            "project_no": fields.get("project_no", ""),
            "winner_raw": winner_raw,
            "buyer_raw": fields.get("buyer", ""),
            "region": fields.get("region", ""),
            "discount": discount,
            "rate": fields.get("rate", ""),
        }.items()
        if value
    }

    return TenderRecord(
        title=title.strip(),
        url=url,
        buyer=buyer,
        winner=winner,
        amount_yuan=amount_yuan,
        amount_raw=amount_raw,
        published=published,
        package=fields.get("package", ""),
        province=province,
        category=category,
        extra=extra,
    )


def parse_tender_snippet(
    snippet: str, url: str = "", title: str = ""
) -> TenderRecord | None:
    """从搜索摘要里解析中标记录。

    页面抓不到时的兜底：搜索引擎返回的摘要常常已经包含中标单位与金额。
    """
    if not snippet:
        return None

    fields = fields_from_text(snippet)

    amount_match = AMOUNT_TEXT_RE.search(snippet)
    if amount_match:
        fields["amount"] = f"{amount_match.group(1)}{amount_match.group(2)}"
        fields["amount_unit"] = amount_match.group(2)

    record_title = title or fields.get("title", "")
    if not record_title:
        return None

    amount_yuan, amount_raw = normalize_amount(
        fields.get("amount"), fields.get("amount_unit")
    )

    winner = clean_org(fields.get("winner", ""))
    buyer = clean_org(fields.get("buyer", ""))
    published = parse_date(fields.get("published_result")) or parse_date(
        fields.get("published")
    )

    haystack = " ".join([record_title, buyer, winner, snippet])
    category = classify_category(haystack)
    province = infer_province(haystack, url)

    return TenderRecord(
        title=record_title.strip(),
        url=url,
        buyer=buyer,
        winner=winner,
        amount_yuan=amount_yuan,
        amount_raw=amount_raw,
        published=published,
        package=fields.get("package", ""),
        province=province,
        category=category,
        extra={"source": "snippet"},
    )
