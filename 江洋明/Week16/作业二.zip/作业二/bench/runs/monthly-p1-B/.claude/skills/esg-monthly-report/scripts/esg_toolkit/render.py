"""报告渲染：Markdown / JSON / HTML 三件套。

同一份 payload 渲染成三种形态：

- **Markdown** —— 给人读、方便贴进周报、方便 diff；
- **JSON** —— 给下游程序（评测、推送、看板）；
- **HTML** —— 交付与截图取证。

HTML 里的图表遵循一份固定的可视化规范（配色取自 dataviz skill 的参考调色板）：
四张图都是**单序列**的量值图，所以用同一支蓝色（sequential hue 的主色），
不引入分类色板；文字一律用文字色而非数据色；每张图下面都配一张数据表，
颜色永远不是唯一的信息通道。
"""

from __future__ import annotations

import html
import json
import math
from datetime import datetime
from typing import Any

# ---------------------------------------------------------------- 视觉规范
# 取自 dataviz skill 的参考调色板（明/暗两套都是选定值，不是自动翻转）
PALETTE = {
    "light": {
        "surface": "#fcfcfb",
        "page": "#f9f9f7",
        "text_primary": "#0b0b0b",
        "text_secondary": "#52514e",
        "muted": "#898781",
        "grid": "#e1e0d9",
        "baseline": "#c3c2b7",
        "series": "#2a78d6",
        "good": "#0ca30c",
        "critical": "#d03b3b",
        "border": "rgba(11,11,11,0.10)",
    },
    "dark": {
        "surface": "#1a1a19",
        "page": "#0d0d0d",
        "text_primary": "#ffffff",
        "text_secondary": "#c3c2b7",
        "muted": "#898781",
        "grid": "#2c2c2a",
        "baseline": "#383835",
        "series": "#3987e5",
        "good": "#0ca30c",
        "critical": "#d03b3b",
        "border": "rgba(255,255,255,0.10)",
    },
}

STATUS_COLORS = {"利好": "good", "风险": "critical", "中性": "muted"}
STATUS_ICONS = {"利好": "▲", "风险": "▼", "中性": "■"}


# ---------------------------------------------------------------- 格式化


def fmt_count(value: Any) -> str:
    """整数，千分位。"""
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return "—"


def fmt_amount(yuan: Any) -> str:
    """金额（元）转中文习惯的「万元 / 亿元」。"""
    if yuan is None:
        return "—"
    try:
        value = float(yuan)
    except (TypeError, ValueError):
        return "—"
    if value >= 1e8:
        return f"{value / 1e8:.2f} 亿元"
    if value >= 1e4:
        return f"{value / 1e4:.1f} 万元"
    return f"{value:,.0f} 元"


def esc(value: Any) -> str:
    """HTML 转义。"""
    return html.escape(str(value if value is not None else ""), quote=True)


def _nice_ceiling(value: float) -> float:
    """把轴上限抬到一个好看的整数刻度。"""
    if value <= 0:
        return 1.0
    exponent = math.floor(math.log10(value))
    base = 10**exponent
    for factor in (1, 1.5, 2, 2.5, 3, 4, 5, 7.5, 10):
        if value <= factor * base:
            return factor * base
    return 10 * base


# ---------------------------------------------------------------- 图表片段


def _column_chart(
    rows: list[dict],
    label_key: str,
    value_key: str,
    unit: str = "",
    palette: dict[str, str] | None = None,
) -> str:
    """竖向柱状图（单序列，量值）。

    柱宽封顶 24px，柱顶 4px 圆角、基线端方角；每根柱带 ``title`` 原生提示，
    图表下方另配数据表，颜色不作为唯一信息通道。
    """
    palette = palette or PALETTE["light"]
    rows = [row for row in rows if row.get(value_key) is not None]
    if not rows:
        return '<p class="empty">本期无可展示的数据。</p>'

    values = [float(row[value_key]) for row in rows]
    peak = max(values) or 1.0

    cells = []
    for row in rows:
        label = str(row.get(label_key, ""))
        value = float(row[value_key])
        height_pct = max(2.0, value / peak * 100.0)
        tip = f"{label}：{fmt_count(int(value))}{unit}"
        cells.append(
            # 柱高必须是**占绘图区高度**的百分比，不能占整列高度。
            # 整列里还有数值标签和类别标签，百分比挂在整列上时最高的那根柱
            # 会溢出并被 flex 压缩 —— 实测 15 被压成 165px、11 是 154px，
            # 读出来的比例是 1.07 而不是 1.36，图表就在骗人了。
            # 所以绘图区单独成盒（.col-plot，固定高度），百分比只对它生效。
            f'<div class="col" title="{esc(tip)}">'
            f'<div class="col-value">{esc(fmt_count(int(value)))}</div>'
            f'<div class="col-plot">'
            f'<div class="col-bar" style="height:{height_pct:.2f}%"></div>'
            f'</div>'
            f'<div class="col-label">{esc(label)}</div>'
            f"</div>"
        )

    return (
        '<div class="chart chart-cols">'
        + "".join(cells)
        + "</div>"
    )


def _row_chart(
    rows: list[dict],
    label_key: str,
    value_key: str,
    unit: str = "",
    palette: dict[str, str] | None = None,
    max_rows: int = 12,
) -> str:
    """横向条形图（单序列，量值，按量值降序）。

    条形右端 4px 圆角、基线端方角；数值直接标在条尾。
    """
    palette = palette or PALETTE["light"]
    rows = [row for row in rows if row.get(value_key) is not None]
    if not rows:
        return '<p class="empty">本期无可展示的数据。</p>'

    rows = sorted(rows, key=lambda r: float(r[value_key]), reverse=True)[:max_rows]
    peak = max(float(row[value_key]) for row in rows) or 1.0

    lines = []
    for row in rows:
        label = str(row.get(label_key, ""))
        value = float(row[value_key])
        width_pct = max(1.0, value / peak * 100.0)
        tip = f"{label}：{fmt_count(int(value))}{unit}"
        lines.append(
            f'<div class="row" title="{esc(tip)}">'
            f'<div class="row-label">{esc(label)}</div>'
            f'<div class="row-track"><div class="row-bar" style="width:{width_pct:.2f}%"></div></div>'
            f'<div class="row-value">{esc(fmt_count(int(value)))}</div>'
            f"</div>"
        )

    return '<div class="chart chart-rows">' + "".join(lines) + "</div>"


def _line_chart(
    rows: list[dict],
    label_key: str,
    value_key: str,
    unit: str = "",
    palette: dict[str, str] | None = None,
) -> str:
    """折线图（单序列，随时间变化）。

    2px 线宽、圆角连接；端点圆点直径 ≥8px 且带 2px 表面色描边（跨线时仍清晰）；
    只标最后一个点的数值，其余交给 X 轴与数据表。
    """
    palette = palette or PALETTE["light"]
    rows = [row for row in rows if row.get(value_key) is not None]
    if not rows:
        return '<p class="empty">本期无可展示的数据。</p>'

    width, height = 760, 260
    pad_left, pad_right, pad_top, pad_bottom = 52, 28, 20, 40

    values = [float(row[value_key]) for row in rows]
    peak = _nice_ceiling(max(values))
    plot_w = width - pad_left - pad_right
    plot_h = height - pad_top - pad_bottom

    def x_at(index: int) -> float:
        if len(rows) == 1:
            return pad_left + plot_w / 2
        return pad_left + plot_w * index / (len(rows) - 1)

    def y_at(value: float) -> float:
        return pad_top + plot_h * (1 - value / peak)

    # 网格线与 Y 轴刻度
    ticks = []
    for step in range(5):
        value = peak * step / 4
        y = y_at(value)
        ticks.append(
            f'<line class="grid" x1="{pad_left}" y1="{y:.1f}" x2="{width - pad_right}" y2="{y:.1f}"/>'
            f'<text class="axis-text" x="{pad_left - 10}" y="{y + 4:.1f}" text-anchor="end">'
            f"{esc(fmt_count(int(value)))}</text>"
        )

    points = [(x_at(i), y_at(v)) for i, v in enumerate(values)]
    polyline = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)

    dots = []
    for index, (x, y) in enumerate(points):
        tip = f"{rows[index][label_key]}：{fmt_count(int(values[index]))}{unit}"
        dots.append(
            f'<circle class="dot" cx="{x:.1f}" cy="{y:.1f}" r="4.5"><title>{esc(tip)}</title></circle>'
        )

    # X 轴标签：点多时抽稀，避免标签重叠
    step = 1 if len(rows) <= 12 else max(1, len(rows) // 12)
    x_labels = []
    for index in range(0, len(rows), step):
        x_labels.append(
            f'<text class="axis-text" x="{x_at(index):.1f}" y="{height - pad_bottom + 20}" '
            f'text-anchor="middle">{esc(rows[index][label_key])}</text>'
        )

    last_x, last_y = points[-1]
    end_label = (
        f'<text class="end-label" x="{last_x:.1f}" y="{last_y - 12:.1f}" text-anchor="end">'
        f"{esc(fmt_count(int(values[-1])))}</text>"
    )

    return (
        f'<svg class="chart chart-line" viewBox="0 0 {width} {height}" '
        f'preserveAspectRatio="xMidYMid meet" role="img">'
        + "".join(ticks)
        + f'<polyline class="line" points="{polyline}"/>'
        + "".join(dots)
        + "".join(x_labels)
        + end_label
        + f'<line class="baseline" x1="{pad_left}" y1="{pad_top + plot_h}" '
        f'x2="{width - pad_right}" y2="{pad_top + plot_h}"/>'
        + "</svg>"
    )


def _table(headers: list[str], rows: list[list[Any]]) -> str:
    """数据表。每张图下面都配一张——颜色永远不是唯一的信息通道。"""
    if not rows:
        return ""
    head = "".join(f"<th>{esc(h)}</th>" for h in headers)
    body = "".join(
        "<tr>" + "".join(f"<td>{esc(cell)}</td>" for cell in row) + "</tr>"
        for row in rows
    )
    return f'<table class="data-table"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>'


# ---------------------------------------------------------------- Markdown


def _md_escape(text: str) -> str:
    return (text or "").replace("|", "\\|").replace("\n", " ").strip()


def render_markdown(payload: dict) -> str:
    """把 payload 渲染成 Markdown 报告。"""
    meta = payload.get("meta", {})
    lines: list[str] = []

    lines.append(f"# {meta.get('title', 'ESG 报告')}")
    lines.append("")

    # 元信息行
    facts = []
    if meta.get("client"):
        facts.append(f"**客户**：{meta['client']}")
    if meta.get("period_start"):
        facts.append(
            f"**统计区间**：{meta['period_start']} ~ {meta.get('period_end', '')}"
        )
    if meta.get("generated_at"):
        facts.append(f"**生成时间**：{meta['generated_at']}")
    if meta.get("data_source"):
        facts.append(f"**数据来源**：{meta['data_source']}")
    for fact in facts:
        lines.append(fact)
        lines.append("")

    if payload.get("summary"):
        lines.append("## 摘要")
        lines.append("")
        lines.append(str(payload["summary"]).strip())
        lines.append("")

    highlights = payload.get("highlights") or []
    if highlights:
        lines.append("## 关键要点")
        lines.append("")
        for item in highlights:
            lines.append(f"- {item}")
        lines.append("")

    stats = payload.get("stats") or {}
    if stats:
        lines.append("## 统计概览")
        lines.append("")
        lines.append("| 指标 | 数值 |")
        lines.append("| --- | --- |")
        # 月报与招投标报告的"概览"不是一回事 —— 早前两边共用一套行，
        # 月报里于是出现「披露金额的项目 0 条 / 中标金额合计 0 元」这种
        # 与内容无关的字段。按 ``stats.kind`` 分开画。
        if stats.get("kind") == "news":
            total = stats.get("total", 0)
            dated = stats.get("dated", 0)
            lines.append(f"| 动态条目总数 | {fmt_count(total)} |")
            lines.append(
                f"| 有明确发布日期 | {fmt_count(dated)}（{dated / total * 100:.1f}%）"
                if total
                else "| 有明确发布日期 | — |"
            )
            lines.append(f"| 覆盖议题数 | {fmt_count(stats.get('topics', 0))} |")
            lines.append(f"| 覆盖信源数 | {fmt_count(stats.get('sources', 0))} |")
            lines.append(f"| 其中 A 级信源条目 | {fmt_count(stats.get('tier_a', 0))} |")
        else:
            lines.append(f"| 项目总数 | {fmt_count(stats.get('total', 0))} |")
            # 日期判不出来的记录没法证明落在统计区间里，单独摆一行出来
            lines.append(f"| 发布日期未确认 | {fmt_count(stats.get('undated', 0))} |")
            amount = stats.get("amount") or {}
            lines.append(f"| 披露金额的项目 | {fmt_count(amount.get('count', 0))} |")
            lines.append(f"| 中标金额合计 | {fmt_amount(amount.get('total_yuan', 0))} |")
            lines.append(f"| 中标金额中位数 | {fmt_amount(amount.get('median_yuan', 0))} |")
            lines.append(f"| 最大单笔 | {fmt_amount(amount.get('max_yuan'))} |")
        lines.append("")

    sections = payload.get("sections") or []
    for section in sections:
        lines.append(f"## {section.get('heading', '')}")
        lines.append("")
        if section.get("intro"):
            lines.append(str(section["intro"]).strip())
            lines.append("")
        items = section.get("items") or []
        if not items:
            lines.append("> 本期未检索到相关内容。")
            lines.append("")
            continue
        for item in items:
            title = _md_escape(str(item.get("title", "")))
            url = item.get("url", "")
            date = item.get("published") or "日期未标注"
            source = item.get("source") or ""
            meta_bits = " · ".join(x for x in [date, source] if x)
            link = f"[{title}]({url})" if url else title
            lines.append(f"### {link}")
            lines.append("")
            if meta_bits:
                lines.append(f"*{meta_bits}*")
                lines.append("")
            if item.get("impact") or item.get("topic"):
                tags = []
                if item.get("topic"):
                    tags.append(f"议题：{item['topic']}")
                if item.get("impact"):
                    tags.append(f"影响：{item['impact']}")
                lines.append(" · ".join(tags))
                lines.append("")
            if item.get("summary"):
                lines.append(str(item["summary"]).strip())
                lines.append("")

        advice = section.get("advice") or []
        if advice:
            lines.append("**建议**")
            lines.append("")
            for tip in advice:
                lines.append(f"- {tip}")
            lines.append("")

    records = payload.get("records") or []
    if records:
        lines.append("## 中标明细")
        lines.append("")
        # 列要和 HTML 版一致 —— Markdown 与 HTML 是同一份报告的两种形态，
        # 少列会被当成"这个字段没抽出来"，而不是"这个版式没放"。
        lines.append(
            "| 发布日期 | 项目名称 | 采购人 | 中标单位 | 中标金额 | 方向 | 地区 |"
        )
        lines.append("| --- | --- | --- | --- | --- | --- | --- |")
        for record in records:
            lines.append(
                "| {date} | [{title}]({url}) | {buyer} | {winner} | {amount} | {category} | {region} |".format(
                    date=record.get("published") or "未标注",
                    title=_md_escape(str(record.get("title", ""))),
                    url=record.get("url", ""),
                    buyer=_md_escape(str(record.get("buyer", "") or "—")),
                    winner=_md_escape(str(record.get("winner", "") or "—")),
                    amount=fmt_amount(record.get("amount_yuan")),
                    category=_md_escape(str(record.get("category", "") or "—")),
                    region=_md_escape(str(record.get("province", "") or "—")),
                )
            )
        lines.append("")

    notes = meta.get("notes") or []
    if notes:
        lines.append("## 数据说明与局限")
        lines.append("")
        for note in notes:
            lines.append(f"- {note}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


# ---------------------------------------------------------------- JSON


def render_json(payload: dict) -> str:
    """机器可读形态。"""
    return json.dumps(payload, ensure_ascii=False, indent=2, default=str)


# ---------------------------------------------------------------- HTML

HTML_CSS = """
:root { color-scheme: light; }
* { box-sizing: border-box; }
body {
  margin: 0; padding: 32px 28px 64px;
  background: var(--page); color: var(--text-primary);
  font-family: system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
  font-size: 15px; line-height: 1.7;
}
.viz-root {
  --surface-1: #fcfcfb; --page: #f9f9f7;
  --text-primary: #0b0b0b; --text-secondary: #52514e; --muted: #898781;
  --grid: #e1e0d9; --baseline: #c3c2b7; --series: #2a78d6;
  --good: #0ca30c; --critical: #d03b3b;
  --border: rgba(11,11,11,0.10);
}
@media (prefers-color-scheme: dark) {
  :root:where(:not([data-theme="light"])) { color-scheme: dark; }
  :root:where(:not([data-theme="light"])) .viz-root {
    --surface-1: #1a1a19; --page: #0d0d0d;
    --text-primary: #ffffff; --text-secondary: #c3c2b7; --muted: #898781;
    --grid: #2c2c2a; --baseline: #383835; --series: #3987e5;
    --border: rgba(255,255,255,0.10);
  }
}
.wrap { max-width: 1080px; margin: 0 auto; }
header.report { border-bottom: 1px solid var(--border); padding-bottom: 20px; margin-bottom: 26px; }
header.report h1 { font-size: 28px; margin: 0 0 10px; letter-spacing: .01em; }
.meta-line { color: var(--text-secondary); font-size: 13.5px; display: flex; flex-wrap: wrap; gap: 6px 20px; }
.meta-line b { color: var(--text-primary); font-weight: 600; }
.card {
  background: var(--surface-1); border: 1px solid var(--border); border-radius: 10px;
  padding: 22px 24px; margin-bottom: 20px;
}
h2 { font-size: 19px; margin: 30px 0 12px; }
h2:first-of-type { margin-top: 0; }
h3 { font-size: 15.5px; margin: 22px 0 8px; }
p { margin: 0 0 12px; }
.summary { font-size: 15.5px; color: var(--text-secondary); }
ul.highlights { margin: 0 0 4px; padding-left: 20px; }
ul.highlights li { margin-bottom: 6px; }

/* 统计磁贴 */
.tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(168px, 1fr)); gap: 14px; margin-bottom: 20px; }
.tile { background: var(--surface-1); border: 1px solid var(--border); border-radius: 10px; padding: 16px 18px; }
.tile .label { color: var(--text-secondary); font-size: 12.5px; margin-bottom: 6px; }
.tile .value { font-size: 25px; font-weight: 600; letter-spacing: -.01em; }
.tile .unit { font-size: 13px; color: var(--text-secondary); font-weight: 400; margin-left: 3px; }
.hero { text-align: left; }
.hero .value { font-size: 48px; line-height: 1.1; }

/* 图表 */
.grid-2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(430px, 1fr)); gap: 20px; align-items: start; }
.chart-title { font-size: 14.5px; font-weight: 600; margin: 0 0 2px; }
.chart-sub { font-size: 12.5px; color: var(--muted); margin: 0 0 16px; }
.chart-cols { display: flex; align-items: flex-start; gap: 10px; }
.col { flex: 1 1 0; display: flex; flex-direction: column; align-items: center; min-width: 0; }
.col-value { font-size: 11.5px; color: var(--text-secondary); margin-bottom: 4px; font-variant-numeric: tabular-nums; height: 15px; line-height: 15px; }
.col-plot { height: 210px; width: 100%; display: flex; align-items: flex-end; justify-content: center; }
.col-bar { width: 100%; max-width: 24px; background: var(--series); border-radius: 4px 4px 0 0; }
.col-label { font-size: 11px; color: var(--muted); margin-top: 7px; text-align: center; line-height: 1.35; word-break: break-all; }
.chart-rows { display: flex; flex-direction: column; gap: 8px; }
.row { display: grid; grid-template-columns: minmax(84px, 27%) 1fr 58px; align-items: center; gap: 12px; }
.row-label { font-size: 12.5px; color: var(--text-secondary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.row-track { height: 18px; background: transparent; }
.row-bar { height: 18px; background: var(--series); border-radius: 0 4px 4px 0; min-width: 3px; }
.row-value { font-size: 12.5px; color: var(--text-primary); text-align: right; font-variant-numeric: tabular-nums; }
.chart-line { width: 100%; height: auto; }
.chart-line .grid { stroke: var(--grid); stroke-width: 1; }
.chart-line .baseline { stroke: var(--baseline); stroke-width: 1; }
.chart-line .line { fill: none; stroke: var(--series); stroke-width: 2; stroke-linejoin: round; stroke-linecap: round; }
.chart-line .dot { fill: var(--series); stroke: var(--surface-1); stroke-width: 2; }
.chart-line .axis-text { fill: var(--muted); font-size: 11px; font-family: system-ui, sans-serif; }
.chart-line .end-label { fill: var(--text-primary); font-size: 12px; font-weight: 600; font-family: system-ui, sans-serif; }
.empty { color: var(--muted); font-size: 13px; }

/* 数据表 */
.data-table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 12.5px; }
.data-table th { text-align: left; font-weight: 600; color: var(--text-secondary); border-bottom: 1px solid var(--border); padding: 7px 8px; }
.data-table td { border-bottom: 1px solid var(--grid); padding: 7px 8px; color: var(--text-primary); }
.data-table td:nth-child(n+3) { font-variant-numeric: tabular-nums; }
.table-scroll { overflow-x: auto; }

/* 动态条目 */
.item { border-top: 1px solid var(--grid); padding: 14px 0; }
.item:first-child { border-top: none; }
.item-title { font-weight: 600; color: var(--text-primary); text-decoration: none; font-size: 15px; }
.item-title:hover { text-decoration: underline; }
.item-meta { font-size: 12.5px; color: var(--muted); margin: 4px 0 8px; display: flex; flex-wrap: wrap; gap: 4px 14px; }
.chip { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; padding: 1px 8px; border-radius: 999px; border: 1px solid var(--border); color: var(--text-secondary); }
.chip .mark { font-size: 10px; }
.chip.good .mark { color: var(--good); }
.chip.critical .mark { color: var(--critical); }
.chip.muted .mark { color: var(--muted); }
.item-summary { color: var(--text-secondary); font-size: 14px; margin: 0; }
.advice { margin-top: 18px; padding: 14px 16px; border-radius: 8px; background: rgba(42,120,214,0.06); border: 1px solid var(--border); }
.advice-title { font-size: 13px; font-weight: 600; margin: 0 0 8px; color: var(--text-primary); }
.advice ul { margin: 0; padding-left: 20px; color: var(--text-secondary); font-size: 13.5px; }
.advice li { margin-bottom: 6px; }
.notes { color: var(--text-secondary); font-size: 13px; }
footer.report { margin-top: 34px; padding-top: 16px; border-top: 1px solid var(--border); color: var(--muted); font-size: 12.5px; }
"""


def _stat_tile(label: str, value: str, unit: str = "", hero: bool = False) -> str:
    cls = "tile hero" if hero else "tile"
    unit_html = f'<span class="unit">{esc(unit)}</span>' if unit else ""
    return (
        f'<div class="{cls}"><div class="label">{esc(label)}</div>'
        f'<div class="value">{esc(value)}{unit_html}</div></div>'
    )


def _impact_chip(impact: str) -> str:
    if not impact:
        return ""
    role = STATUS_COLORS.get(impact, "muted")
    icon = STATUS_ICONS.get(impact, "■")
    return (
        f'<span class="chip {role}"><span class="mark">{icon}</span>'
        f"{esc(impact)}</span>"
    )


def render_html(payload: dict, title: str = "") -> str:
    """把 payload 渲染成独立 HTML 报告（无外部依赖，可离线截图）。"""
    meta = payload.get("meta", {})
    stats = payload.get("stats") or {}
    tables = payload.get("tables") or {}
    page_title = title or meta.get("title", "ESG 报告")

    parts: list[str] = []
    parts.append("<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'>")
    parts.append("<meta name='viewport' content='width=device-width,initial-scale=1'>")
    parts.append(f"<title>{esc(page_title)}</title>")
    parts.append(f"<style>{HTML_CSS}</style></head><body><div class='viz-root'><div class='wrap'>")

    # 页眉
    parts.append("<header class='report'>")
    parts.append(f"<h1>{esc(meta.get('title', page_title))}</h1>")
    meta_bits = []
    if meta.get("client"):
        meta_bits.append(f"<span>客户 <b>{esc(meta['client'])}</b></span>")
    if meta.get("period_start"):
        meta_bits.append(
            f"<span>统计区间 <b>{esc(meta['period_start'])} ~ "
            f"{esc(meta.get('period_end', ''))}</b></span>"
        )
    if meta.get("generated_at"):
        meta_bits.append(f"<span>生成时间 <b>{esc(meta['generated_at'])}</b></span>")
    if meta.get("data_source"):
        meta_bits.append(f"<span>数据来源 <b>{esc(meta['data_source'])}</b></span>")
    parts.append(f"<div class='meta-line'>{''.join(meta_bits)}</div>")
    parts.append("</header>")

    # 摘要
    if payload.get("summary"):
        parts.append("<div class='card'><h2>摘要</h2>")
        parts.append(f"<p class='summary'>{esc(payload['summary'])}</p>")
        highlights = payload.get("highlights") or []
        if highlights:
            items = "".join(f"<li>{esc(h)}</li>" for h in highlights)
            parts.append(f"<ul class='highlights'>{items}</ul>")
        parts.append("</div>")

    # 统计磁贴
    amount = stats.get("amount") or {}
    regions = stats.get("regions") or []
    region_count = len([r for r in regions if r.get("region") != "未识别"])
    tiles = []
    if stats:
        if stats.get("kind") == "news":
            # 月报的磁贴 —— 与招投标报告不是一套指标
            total = stats.get("total", 0)
            dated = stats.get("dated", 0)
            tiles.append(_stat_tile("动态条目总数", fmt_count(total), hero=True))
            tiles.append(
                _stat_tile(
                    "有发布日期",
                    f"{dated} 条",
                    unit=f"（{dated / total * 100:.1f}%）" if total else "",
                )
            )
            tiles.append(_stat_tile("覆盖议题", fmt_count(stats.get("topics", 0))))
            tiles.append(_stat_tile("覆盖信源", fmt_count(stats.get("sources", 0))))
            tiles.append(_stat_tile("A 级信源条目", fmt_count(stats.get("tier_a", 0))))
        else:
            tiles.append(_stat_tile("中标项目总数", fmt_count(stats.get("total", 0)), hero=True))
            tiles.append(_stat_tile("发布日期未确认", fmt_count(stats.get("undated", 0))))
            tiles.append(_stat_tile("披露金额项目", fmt_count(stats.get("with_amount", 0))))
            tiles.append(_stat_tile("中标金额合计", fmt_amount(amount.get("total_yuan", 0))))
            tiles.append(_stat_tile("中标金额中位数", fmt_amount(amount.get("median_yuan", 0))))
            if region_count:
                tiles.append(_stat_tile("覆盖省份", fmt_count(region_count)))
    if tiles:
        parts.append(f"<div class='tiles'>{''.join(tiles)}</div>")

    # 图表区
    bucket_rows = tables.get("buckets") or []
    trend_rows = tables.get("trend") or []
    hotspot_rows = tables.get("hotspots") or []
    region_rows = tables.get("regions") or []
    category_rows = tables.get("categories") or []

    if bucket_rows or trend_rows or hotspot_rows or region_rows:
        parts.append("<div class='grid-2'>")

        if bucket_rows:
            parts.append("<div class='card'>")
            parts.append("<p class='chart-title'>中标金额分档分布</p>")
            parts.append("<p class='chart-sub'>按项目条数统计，未披露金额单独计为一档</p>")
            parts.append(
                _column_chart(
                    [r for r in bucket_rows if r.get("count")],
                    "bucket",
                    "count",
                    " 个项目",
                )
            )
            parts.append(
                _table(
                    ["金额区间", "项目数", "占比", "金额合计"],
                    [
                        [
                            r.get("bucket"),
                            fmt_count(r.get("count")),
                            f"{r.get('ratio', 0) * 100:.1f}%",
                            fmt_amount(r.get("total_yuan")),
                        ]
                        for r in bucket_rows
                    ],
                )
            )
            parts.append("</div>")

        if trend_rows:
            parts.append("<div class='card'>")
            parts.append("<p class='chart-title'>月度中标数量走势</p>")
            parts.append("<p class='chart-sub'>按公告发布日期归月</p>")
            parts.append(_line_chart(trend_rows, "month", "count", " 个项目"))
            parts.append(
                _table(
                    ["月份", "项目数", "金额合计"],
                    [
                        [r.get("month"), fmt_count(r.get("count")), fmt_amount(r.get("total_yuan"))]
                        for r in trend_rows
                    ],
                )
            )
            parts.append("</div>")

        if hotspot_rows:
            parts.append("<div class='card'>")
            parts.append("<p class='chart-title'>热点方向词频</p>")
            parts.append("<p class='chart-sub'>项目标题中命中的 ESG 方向词出现次数（短形优先）</p>")
            parts.append(_row_chart(hotspot_rows, "term", "count", " 次"))
            parts.append("</div>")

        if region_rows:
            parts.append("<div class='card'>")
            parts.append("<p class='chart-title'>地区分布</p>")
            parts.append("<p class='chart-sub'>按采购人所在省份统计项目数</p>")
            parts.append(_row_chart(region_rows, "region", "count", " 个项目"))
            parts.append(
                _table(
                    ["省份", "项目数", "金额合计"],
                    [
                        [r.get("region"), fmt_count(r.get("count")), fmt_amount(r.get("total_yuan"))]
                        for r in region_rows
                    ],
                )
            )
            parts.append("</div>")

        if category_rows:
            parts.append("<div class='card'>")
            parts.append("<p class='chart-title'>ESG 细分方向分布</p>")
            parts.append("<p class='chart-sub'>按项目名称与采购人自动归类</p>")
            parts.append(_row_chart(category_rows, "category", "count", " 个项目"))
            parts.append("</div>")

        parts.append("</div>")

    # 板块
    for section in payload.get("sections") or []:
        parts.append(f"<h2>{esc(section.get('heading', ''))}</h2>")
        items = section.get("items") or []
        if section.get("intro"):
            parts.append(f"<div class='card'><p class='summary'>{esc(section['intro'])}</p></div>")
        if not items:
            parts.append("<div class='card'><p class='empty'>本期未检索到相关内容。</p></div>")
            continue

        parts.append("<div class='card'>")
        for item in items:
            url = item.get("url", "")
            title = str(item.get("title", ""))
            heading = (
                f"<a class='item-title' href='{esc(url)}' target='_blank' rel='noopener'>{esc(title)}</a>"
                if url
                else f"<span class='item-title'>{esc(title)}</span>"
            )
            parts.append("<div class='item'>")
            parts.append(heading)
            meta_line = []
            if item.get("published"):
                meta_line.append(f"<span>{esc(item['published'])}</span>")
            if item.get("source"):
                meta_line.append(f"<span>{esc(item['source'])}</span>")
            if item.get("topic"):
                meta_line.append(f"<span>议题 {esc(item['topic'])}</span>")
            chip = _impact_chip(str(item.get("impact", "")))
            if chip:
                meta_line.append(chip)
            if meta_line:
                parts.append(f"<div class='item-meta'>{''.join(meta_line)}</div>")
            if item.get("summary"):
                parts.append(f"<p class='item-summary'>{esc(item['summary'])}</p>")
            parts.append("</div>")

        advice = section.get("advice") or []
        if advice:
            parts.append("<div class='advice'><p class='advice-title'>建议</p><ul>")
            for tip in advice:
                parts.append(f"<li>{esc(tip)}</li>")
            parts.append("</ul></div>")
        parts.append("</div>")

    # 中标明细表
    records = payload.get("records") or []
    if records:
        parts.append("<h2>中标明细</h2>")
        parts.append("<div class='card table-scroll'>")
        parts.append(
            _table(
                ["发布日期", "项目名称", "采购人", "中标单位", "中标金额", "方向", "来源"],
                [
                    [
                        r.get("published") or "未标注",
                        str(r.get("title", "")),
                        r.get("buyer") or "—",
                        r.get("winner") or "—",
                        fmt_amount(r.get("amount_yuan")),
                        r.get("category") or "—",
                        (r.get("url") or ""),
                    ]
                    for r in records
                ],
            )
        )
        parts.append("</div>")

    notes = meta.get("notes") or []
    if notes:
        parts.append("<h2>数据说明与局限</h2>")
        parts.append("<div class='card'><ul class='notes'>")
        for note in notes:
            parts.append(f"<li>{esc(note)}</li>")
        parts.append("</ul></div>")

    parts.append(
        "<footer class='report'>本报告由 ESG Skill 与确定性脚本层协同生成；"
        "所有结论均以标注来源为准，未能核实的内容不作断言。</footer>"
    )
    parts.append("</div></div></body></html>")

    return "".join(parts)


def default_meta(
    title: str,
    client: str = "",
    period_start: str = "",
    period_end: str = "",
    data_source: str = "",
    notes: list[str] | None = None,
) -> dict:
    """组装一份标准 meta。"""
    return {
        "title": title,
        "client": client,
        "period_start": period_start,
        "period_end": period_end,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data_source": data_source,
        "notes": notes or [],
    }
