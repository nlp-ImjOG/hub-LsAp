"""CLI 共用工具。

约定（与本仓库其他周次一致）：

- **日志走 stderr，最终产物路径走 stdout** —— 这样 ``python monthly_report.py > out.txt``
  拿到的是干净的结果，而不是被日志糊住的文本；
- Windows 控制台默认 GBK，入口处强制 stdout/stderr 为 UTF-8。
"""

from __future__ import annotations

import io
import sys
from pathlib import Path
from typing import Callable

__all__ = ["force_utf8", "make_logger", "resolve_outdir", "echo_result"]


#: 保活引用。
#:
#: ``TextIOWrapper`` 被回收时会把它包着的 buffer 一起关掉。如果不留着它，
#: pytest 的 capture 对象（``CaptureIO``）会因为底层 buffer 被关而报
#: ``ValueError: I/O operation on closed file`` —— 单元测试直接挂。
#: 留着引用，wrapper 活到进程结束，buffer 就不会被提前关掉。
_UTF8_WRAPPERS: list[io.TextIOWrapper] = []


def force_utf8() -> None:
    """把 stdout / stderr 换成 UTF-8。

    Windows 控制台默认编码是 GBK，脚本里只要出现生僻字或 emoji 就会
    ``UnicodeEncodeError``。包一层 ``TextIOWrapper`` 是本仓库的通用做法。

    已经是 UTF-8 的流**不再包一层**（比如 pytest 的 capture、或者本函数
    已经包过一次）—— 重复包既没必要，又会把别人的 buffer 提前关掉。
    """
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        encoding = str(getattr(stream, "encoding", "") or "")
        if encoding.lower().replace("-", "") == "utf8":
            continue
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            continue
        wrapper = io.TextIOWrapper(
            buffer, encoding="utf-8", errors="replace", line_buffering=True
        )
        _UTF8_WRAPPERS.append(wrapper)
        setattr(sys, stream_name, wrapper)


def make_logger(verbose: bool = True) -> Callable[[str], None]:
    """返回一个写 stderr 的日志函数。"""
    if not verbose:
        return lambda _message: None

    def log(message: str) -> None:
        print(message, file=sys.stderr, flush=True)

    return log


def resolve_outdir(config, sub: str) -> Path:
    """确定输出目录并确保存在。"""
    path = Path(config.output_dir) / sub
    path.mkdir(parents=True, exist_ok=True)
    return path


def echo_result(payload: dict) -> None:
    """把最终结果（产物路径等）打到 stdout。"""
    import json

    print(json.dumps(payload, ensure_ascii=False, indent=2))
