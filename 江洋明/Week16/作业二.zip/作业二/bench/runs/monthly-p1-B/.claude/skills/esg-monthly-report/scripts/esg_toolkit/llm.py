"""LLM 叙事层 —— 只负责"把事实写成话"。

分工原则（贯穿整个项目）：

============  ==================================  ==================
层            做什么                              谁来做
============  ==================================  ==================
**语义层**    判断这条动态对客户意味着什么、        LLM
              写摘要与要点、给建议
**确定性层**  搜索式生成、字段抽取、金额归一、      代码
              去重、统计聚合
============  ==================================  ==================

判断标准很简单：**能写成规则的就别交给模型**。模型加法会错、会把没披露的金额
猜成 0、会把"待定"读成"已完成"；代码不会。

本模块是"语义层"的脚本侧入口。它调用 ``claude -p``（与搜索后端同一个 CLI），
拿到的结果只用于**文字**：摘要、要点、建议。凡是需要精确数字的地方，
数字都从 :mod:`esg_toolkit.aggregate` 的统计结果里取，绝不让模型自己算。
"""

from __future__ import annotations

import json
import re
import subprocess
from typing import Any

from .cli_path import resolve_cli

__all__ = ["ask", "summarize_news", "summarize_tenders", "extract_json_object"]

# 生成摘要时的约束：不许编数字、不许编事实、不许加免责声明式的空话
_GROUND_RULES = """硬性要求：
1. 只使用给定的事实，不引入任何外部知识，不编造数字、机构、日期、事件；
2. 事实里没有的信息就不写，宁可少写也不要猜；
3. 不要写"综上所述""随着……的深入发展"之类的套话；
4. 全部用简体中文输出。"""


def ask(cli: str, prompt: str, timeout: int = 300, cwd: str | None = None) -> str:
    """跑一次 ``claude -p``，返回纯文本结果。

    失败时抛 :class:`RuntimeError` —— 调用方决定是降级还是中断，
    不在这里悄悄返回空串（空串会让"模型没说话"和"模型说了空话"混为一谈）。

    ``cli`` 要先经 :func:`resolve_cli` 解析：Windows 上它其实是 ``claude.cmd``，
    ``CreateProcess`` 只认 ``.exe``，不解析就报 ``FileNotFoundError``。
    漏了这一步的后果很隐蔽 —— 叙事层会静默退回确定性摘要，报告看起来正常，
    但"模型写的那部分"其实是模板拼的，很容易被误读成"模型写不出来"。
    """
    cmd = [resolve_cli(cli), "-p", prompt, "--output-format", "text"]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            stdin=subprocess.DEVNULL,
            cwd=cwd,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(f"找不到可执行文件：{cli}") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"调用 LLM 超时（{timeout}s）") from exc

    if proc.returncode != 0:
        raise RuntimeError(
            f"claude CLI 退出码 {proc.returncode}：{(proc.stderr or '').strip()[:300]}"
        )

    return (proc.stdout or "").strip()


def extract_json_object(text: str) -> dict[str, Any]:
    """从模型输出里抠出 JSON 对象（带围栏、前缀说明都能处理）。"""
    if not text:
        return {}

    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text).strip()

    try:
        data = json.loads(text)
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end > start:
        try:
            data = json.loads(text[start : end + 1])
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError:
            return {}
    return {}


# ---------------------------------------------------------------- 摘要生成

_NEWS_PROMPT = """你是一名 ESG 顾问，请根据下面的**已核实事实**写一份月报导语。

客户：{client}
统计区间：{period}
覆盖议题：{topics}

已核实事实（JSON）：
{facts}

请输出一个 JSON 对象，只有两个字段：
{{"summary": "3-5 句导语", "highlights": ["要点1", "要点2", "要点3"]}}

{ground_rules}"""

_TENDER_PROMPT = """你是一名招投标分析顾问，请根据下面的**已统计好的数字**写一段汇总说明。

统计区间：{period}

已统计好的数字（JSON，不要重新计算，直接引用）：
{facts}

请输出一个 JSON 对象，只有两个字段：
{{"summary": "3-5 句汇总说明", "highlights": ["要点1", "要点2", "要点3"]}}

{ground_rules}"""


def summarize_news(cli: str, client: str, period: str, facts: dict, timeout: int = 300) -> dict:
    """为月报生成导语与要点。失败返回空 dict，由调用方用确定性摘要兜底。"""
    prompt = _NEWS_PROMPT.format(
        client=client,
        period=period,
        topics="、".join(facts.get("topics", [])) or "ESG 综合",
        facts=json.dumps(facts, ensure_ascii=False, indent=2),
        ground_rules=_GROUND_RULES,
    )
    try:
        data = extract_json_object(ask(cli, prompt, timeout=timeout))
    except RuntimeError:
        return {}

    summary = str(data.get("summary") or "").strip()
    highlights = [str(h).strip() for h in (data.get("highlights") or []) if str(h).strip()]
    if not summary:
        return {}
    return {"summary": summary, "highlights": highlights}


def summarize_tenders(cli: str, period: str, facts: dict, timeout: int = 300) -> dict:
    """为招投标汇总生成说明段落。失败返回空 dict。"""
    prompt = _TENDER_PROMPT.format(
        period=period,
        facts=json.dumps(facts, ensure_ascii=False, indent=2),
        ground_rules=_GROUND_RULES,
    )
    try:
        data = extract_json_object(ask(cli, prompt, timeout=timeout))
    except RuntimeError:
        return {}

    summary = str(data.get("summary") or "").strip()
    highlights = [str(h).strip() for h in (data.get("highlights") or []) if str(h).strip()]
    if not summary:
        return {}
    return {"summary": summary, "highlights": highlights}


_ADVICE_PROMPT = """你是一名给企业高管看的 ESG 顾问。请根据下面的**已核实事实**，
给出 3-5 条对客户的具体、可执行的建议。

客户：{client}
统计区间：{period}

已核实事实（JSON）：
{facts}

建议的写法要求：
1. 每条建议一句话，落到具体动作（例如"核查排放数据口径是否覆盖范围三"），
   不要写"加强重视""提升意识"这类正确的废话；
2. 只基于给定事实，事实里没有的信息不要当成已知；
3. 如果事实不足以支撑某条建议，就不要写。

只输出一个 JSON 数组，元素是字符串，不要任何解释文字。

{ground_rules}"""


def advise_news(cli: str, client: str, period: str, facts: dict, timeout: int = 300) -> list[str]:
    """为月报的第三板块生成建议。失败返回空列表。"""
    prompt = _ADVICE_PROMPT.format(
        client=client,
        period=period,
        facts=json.dumps(facts, ensure_ascii=False, indent=2),
        ground_rules=_GROUND_RULES,
    )
    try:
        raw = ask(cli, prompt, timeout=timeout)
    except RuntimeError:
        return []

    text = raw.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text).strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("[")
        end = text.rfind("]")
        if start == -1 or end <= start:
            return []
        try:
            data = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return []

    if not isinstance(data, list):
        return []
    return [str(item).strip() for item in data if str(item).strip()]
