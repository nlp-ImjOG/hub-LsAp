"""影响方向的保守启发式（利好 / 中性 / 风险）。

这一层刻意做得很保守，因为它一旦"自作聪明"就会污染报告：

- **只看标题**，不看正文 —— 标题里的"处罚""获批"基本不会指错，正文里就未必了；
- **只认明确的动作词**，拿不准就判"中性"，不硬凑利好；
- **只在"公司动态"板块启用** —— 政策板块的"发布"是常态，不是利好。

诚实说明：这只是一份**可复现的启发式**，不是权威判断。Skill 臂由模型读全文判读，
两者的差异本身就是评测的一项（见 ``bench/run_ab.py`` 的人工一致性口径）。
"""

from __future__ import annotations

import re

__all__ = ["classify_impact", "IMPACT_RISK_WORDS", "IMPACT_POSITIVE_WORDS"]

# 风险词：负面事件
IMPACT_RISK_WORDS: list[str] = [
    "处罚", "罚款", "违规", "约谈", "立案", "追责", "警示", "整改", "责令",
    "事故", "伤亡", "泄漏", "超标", "污染", "停产", "限产", "召回", "下架",
    "失信", "违约", "诉讼", "处罚决定", "不予", "撤销", "亏损", "减值", "退市",
    "重大缺陷", "安全风险", "问询函", "监管措施", "责令改正",
]

# 利好词：明确的正向进展
IMPACT_POSITIVE_WORDS: list[str] = [
    "获批", "批复", "通过评审", "认证", "认定", "入选", "荣获", "获奖", "示范",
    "标杆", "首发", "首次", "投产", "建成", "投运", "签署", "揭牌", "上线",
    "达标", "满分", "领先", "优秀", "表彰", "入选榜单", "获评",
]

# 只在这些词构成"动作"时才判风险/利好 —— 避免"安全生产形势严峻"被当成利好
_RISK_RE = re.compile("|".join(IMPACT_RISK_WORDS))
_POSITIVE_RE = re.compile("|".join(IMPACT_POSITIVE_WORDS))


def classify_impact(title: str, enabled: bool = True) -> tuple[str, str]:
    """返回 ``(影响方向, 命中的触发词)``。

    拿不准时返回 ``("中性", "")`` —— 报告里写"中性"比编一个方向诚实。
    """
    if not enabled or not title:
        return "中性", ""

    # 风险优先：一条标题同时含"整改完成"和"处罚"时，风险是更值得报告的一面
    risk = _RISK_RE.search(title)
    if risk:
        return "风险", risk.group(0)

    positive = _POSITIVE_RE.search(title)
    if positive:
        return "利好", positive.group(0)

    return "中性", ""
