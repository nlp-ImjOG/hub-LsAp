# 脚本层调用说明（esg-monthly-report）

> 本文件由 `作业二/scripts/build_skills.py` 自动生成，**不要手工编辑**。

## 一、输入

- **客户档案**：见 `references/client-profile.md`（默认客户：中国神华）。
- **统计区间**：上一个自然月（`2026-10-01` ~ `2026-10-31`）。口径固定，不使用"最近 30 天"。
- **检索式**：见 `references/source-map.md` 里的三组检索式。

## 二、检索

按 `references/source-map.md` 的检索式逐条搜索，每条取 8-10 条结果。
优先看 A 级信源；B 级用于补充行业动态；C/D 级只在 A、B 级没有覆盖时使用。


## 三、脚本层（确定性部分）

Skill 目录下的 `scripts/` 是作业二沉淀下来的确定性工具层，
它负责**可写成规则的活**：抽取、归一、去重、统计。

```bash
cd <skill 目录>
# 3. 生成月报（可选：先跑脚本拿到确定性事实，再由你写导语）
python scripts/monthly_report.py --client 中国神华 --period 2026-10 --no-llm
#   产物：output/monthly/esg-monthly-2026-10.{md,json,html}

# 脚本层给出的确定性部分：
#   - 按自然月过滤、去重、信源分级、相关性排序、议题归类
#   - 影响方向判定（标题级启发式，见 references/ 里的说明）
# 你负责的部分：导语、要点、对客户的建议
```

### 什么时候用脚本，什么时候自己来

| 任务 | 谁来做 | 理由 |
| --- | --- | --- |
| 抽取中标金额 | 脚本 | 单位换算规则明确，模型容易把「亿元」读成「元」 |
| 日期归一 | 脚本 | 非零填充日期是真实坑位，模型会漏 |
| 去重 | 脚本 | URL 规范化规则确定 |
| 金额分档 / 热点统计 | 脚本 | 加法与计数不该交给模型 |
| 判断这条动态对客户意味着什么 | **你** | 需要语义理解 |
| 写导语、要点、建议 | **你** | 需要语言表达 |

## 四、脚本层接口速查

| 模块 | 关键函数 | 作用 |
| --- | --- | --- |
| `esg_toolkit.parse_tender` | `parse_tender_page(html, url)` | 从公告页面解析中标记录 |
| `esg_toolkit.parse_tender` | `parse_tender_snippet(snippet, url)` | 从搜索摘要解析（页面抓不到时兜底） |
| `esg_toolkit.parse_tender` | `normalize_amount(raw, unit)` | 金额归一为「元」 |
| `esg_toolkit.parse_news` | `previous_month_window()` | 上一个自然月的时间窗 |
| `esg_toolkit.parse_news` | `dedupe(items)` | URL + 标题两级去重 |
| `esg_toolkit.aggregate` | `summarize(records)` | 一次性产出全部统计口径 |
| `esg_toolkit.render` | `render_markdown/json/html` | 三件套渲染 |
| `esg_toolkit.state` | `StateStore(path)` | 增量推送的已推送记录 |
