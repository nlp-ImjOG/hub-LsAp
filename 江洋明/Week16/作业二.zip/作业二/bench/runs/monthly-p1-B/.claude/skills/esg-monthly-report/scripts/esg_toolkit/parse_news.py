"""新闻 / 公告动态处理（ESG 月报用）。

这一层做的是"筛选"里**可以写成规则**的部分：正文抽取、URL 去重、时间窗过滤、
信源分级、相关性打分。

需要判断力的部分（这条动态到底对客户 ESG 意味着什么、利好还是风险）留给 LLM ——
脚本负责把"脏活"做干净，把判断权交回去。
"""

from __future__ import annotations

import re
from datetime import date, datetime

from .htmlutil import NOISE_PATTERNS, NOISE_TAGS, extract_body
from .keywords import ESG_CATEGORIES, classify_category, source_tier
from .models import NewsItem, SearchHit
from .urls import canonical_url, site_of

__all__ = [
    "canonical_url",
    "site_of",
    "extract_body",
    "dedupe",
    "in_window",
    "relevance_score",
    "news_from_hits",
    "previous_month_window",
    "classify_tier",
    "published_from_url",
    "published_from_html",
]


#: URL 里常见的日期写法。
#:
#: 政务与主流媒体的稿件链接几乎都把发布日期编进路径里，这是**不联网**就能
#: 拿到日期的最省事办法 —— 搜索引擎返回的 ``published`` 字段经常是空的
#: （模型自己填的，它不一定填），月报里于是出现一堆「日期未标注」。
#:
#: 注意 ``t20260128_26126762.htm`` 这种写法：日期前面是字母 ``t`` 而不是斜杠，
#: 所以模式**不能**要求前面一定有 ``/``。
_URL_DATE_PATTERNS = (
    # 20261028 / t20261028_xxx / 2026-10-28 / 2026/10/28
    re.compile(r"(?<!\d)(\d{4})[-_/]?(\d{2})[-_/]?(\d{2})(?!\d)"),
    # 月份/日期可能不补零：2026/10/8
    re.compile(r"(?<!\d)(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?!\d)"),
)

#: 页面里常见的发布日期标注。
_HTML_DATE_PATTERNS = (
    re.compile(r"article:published_time\"[^>]*content=\"([^\"]+)\"", re.I),
    re.compile(r"og:published_time\"[^>]*content=\"([^\"]+)\"", re.I),
    re.compile(r"\"datePublished\"\s*:\s*\"([^\"]+)\""),
    re.compile(r"(?:发布时间|发布日期|发表时间|来源日期|时间)\s*[:：]\s*([0-9]{4}[-/年][0-9]{1,2}[-/月][0-9]{1,2}日?)"),
)


def _normalize_date_parts(year: int, month: int, day: int) -> str | None:
    """把年月日规整成 ISO；越界就返回 None（宁可没有日期，不要错日期）。"""
    if not (1 <= month <= 12 and 1 <= day <= 31):
        return None
    try:
        return date(year, month, day).isoformat()
    except ValueError:
        return None


def published_from_url(url: str) -> str | None:
    """从 URL 路径里抠发布日期。

    中国政府采购网、交易所公告页、绝大多数主流媒体的稿件链接都把日期编进
    路径（``/202610/t20261028_12345.htm``、``/2026-10/28/``）。这是**零成本**
    的日期来源：不用多抓一次页面，也不用信搜索引擎给的那个经常是空的
    ``published`` 字段。
    """
    if not url:
        return None
    for pattern in _URL_DATE_PATTERNS:
        match = pattern.search(url)
        if not match:
            continue
        year, month, day = (int(g) for g in match.groups())
        normalized = _normalize_date_parts(year, month, day)
        if normalized:
            return normalized
    return None


def published_from_html(html: str) -> str | None:
    """从页面 HTML 里抠发布日期。

    优先看结构化元数据（``article:published_time``、JSON-LD 的
    ``datePublished``），再退化到正文里的「发布时间：2026-10-28」这种写法。
    """
    if not html:
        return None
    for pattern in _HTML_DATE_PATTERNS:
        match = pattern.search(html)
        if not match:
            continue
        normalized = _parse_loose_date(match.group(1))
        if normalized:
            return normalized
    return None


def _parse_loose_date(raw: str) -> str | None:
    """把 ``2026-10-28`` / ``2026年10月28日`` / ``2026/10/28`` 规整成 ISO。"""
    match = re.search(r"(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})", str(raw))
    if not match:
        return None
    year, month, day = (int(g) for g in match.groups())
    return _normalize_date_parts(year, month, day)


def classify_tier(url: str) -> str:
    """信源分级：A 监管/官方、B 主流财经媒体、C 行业媒体、D 其他。"""
    return source_tier(site_of(url))


def previous_month_window(today: date | None = None) -> tuple[str, str]:
    """上一个自然月的时间窗（含首尾，闭区间）。

    ESG 月报按自然月走，而不是"最近 30 天"——客户看的是月报，
    口径必须稳定，否则两次运行的结果无法对比。
    """
    today = today or date.today()
    if today.month == 1:
        year, month = today.year - 1, 12
    else:
        year, month = today.year, today.month - 1

    start = date(year, month, 1)
    if month == 12:
        end = date(year, 12, 31)
    else:
        end = date(year, month + 1, 1).toordinal() - 1
        end = date.fromordinal(end)

    return start.isoformat(), end.isoformat()


def in_window(published: str | None, start: str, end: str) -> bool:
    """日期是否落在 ``[start, end]`` 闭区间内。

    日期判不出来的记录返回 ``True``（保留）—— 宁可让上层多看一眼，
    也不要因为日期缺失就把一条真实动态悄悄丢掉。但这属于"边界情况"，
    调用方通常会把它们单独归到"日期未确认"里。
    """
    if not published:
        return True
    try:
        value = datetime.strptime(published, "%Y-%m-%d").date()
        start_date = datetime.strptime(start, "%Y-%m-%d").date()
        end_date = datetime.strptime(end, "%Y-%m-%d").date()
    except ValueError:
        return True
    return start_date <= value <= end_date


def _title_key(title: str) -> str:
    """标题归一化，用于识别"同一件事的不同报道"。

    只保留中日韩文字、字母和数字，其余（空格、标点、书名号……）全部去掉 ——
    这样"神华发布 ESG 报告"和"神华发布ESG报告！"会归成同一个键。
    """
    return re.sub(r"[^0-9A-Za-z一-鿿]+", "", title or "").lower()


def dedupe(items: list[NewsItem]) -> list[NewsItem]:
    """去重：先按规范化 URL，再按归一化标题。

    保留先出现的那条（调用方应把更高质量的来源排在前面）。
    """
    seen_urls: set[str] = set()
    seen_titles: set[str] = set()
    result: list[NewsItem] = []

    for item in items:
        url_key = canonical_url(item.url)
        title_key = _title_key(item.title)
        if url_key and url_key in seen_urls:
            continue
        if title_key and title_key in seen_titles:
            continue
        if url_key:
            seen_urls.add(url_key)
        if title_key:
            seen_titles.add(title_key)
        result.append(item)

    return result


def relevance_score(
    item: NewsItem,
    category_weights: dict[str, float] | None = None,
    tier_weights: dict[str, float] | None = None,
) -> float:
    """相关性打分：命中多少 ESG 议题 + 信源等级。

    分值只用来**排序**，不用来**丢弃**——丢不丢由更明确的规则决定，
    这样调权重不会悄悄改变结果集。
    """
    category_weights = category_weights or {}
    tier_weights = tier_weights or {"A": 3.0, "B": 2.0, "C": 1.0, "D": 0.5}

    haystack = " ".join([item.title, item.summary, item.topic])
    score = 0.0

    for category, words in ESG_CATEGORIES.items():
        hits = sum(1 for word in words if word in haystack)
        if hits:
            score += category_weights.get(category, 1.0) * hits

    if item.topic:
        score += 1.5

    score += tier_weights.get(item.source_tier, 0.5)

    if item.impact in {"利好", "风险"}:
        score += 0.5

    return round(score, 3)


def news_from_hits(
    hits: list[SearchHit],
    start: str | None = None,
    end: str | None = None,
    require_esg: bool = True,
) -> list[NewsItem]:
    """把搜索结果转成新闻条目，可选地按时间窗过滤。

    ``require_esg=True`` 时只保留命中 ESG 关键词的条目 —— 这是月报
    "自主筛选"的第一道闸门。
    """
    items: list[NewsItem] = []

    for hit in hits:
        haystack = f"{hit.title} {hit.snippet}"
        if require_esg and not _looks_like_esg(haystack):
            continue
        # 搜索引擎给的 published 经常是空的，先用 URL 里的日期兜底
        published = hit.published or published_from_url(hit.url)
        if start and end and not in_window(published, start, end):
            continue

        items.append(
            NewsItem(
                title=hit.title,
                url=hit.url,
                published=published,
                source=hit.source or site_of(hit.url),
                source_tier=classify_tier(hit.url),
                topic=classify_category(haystack),
                summary=hit.snippet,
            )
        )

    return dedupe(items)


def _looks_like_esg(text: str) -> bool:
    """ESG 关键词粗筛（新闻口径）。

    用的是 :data:`ESG_NEWS_KEYWORDS` 而不是招投标那份更严的表 ——
    月报看的是政策与行业动态，"全国碳市场扩围"这类条目没有"双碳"字样，
    却被严表挡在门外（实测会漏掉相当一部分政策类动态）。
    """
    from .keywords import ESG_NEWS_KEYWORDS

    return any(word in text for word in ESG_NEWS_KEYWORDS)
