"""网页抓取。

四件必须做对的事：
1. **中文编码**：政务站点大量用 GBK/GB2312，猜错编码整页都是乱码，抽取必然全错；
2. **403 兜底**：``ccgp.gov.cn`` 对裸 UA 直接 403，需要带 Referer 重试；
3. **JS 挑战兜底**：``ccgp.gov.cn`` 的 403 页面里嵌了一段 JS，会算出 cookie 后自动刷新 ——
   纯 requests 无论如何都过不去（实测三种 UA + Referer 全被拦）。必须用真实浏览器
   跑一遍那段 JS，页面才会放行。见 :class:`BrowserFetcher`；
4. **缓存**：同一批公告会被反复抓（搜索、渲染、评测），缓存能显著省时间，
   同时保证"同一份输入"在两臂里内容一致。
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from urllib.parse import urlsplit

from .config import Config

CHARSET_RE = r"""charset\s*=\s*["']?\s*([a-zA-Z0-9_\-]+)"""

# 轮换的 UA —— 政务站点对某些 UA 放行、对某些拦截
USER_AGENTS: list[str] = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.4 Safari/605.1.15",
]


@dataclass
class FetchResult:
    """一次抓取的结果。"""

    url: str
    ok: bool
    status: int = 0
    text: str = ""
    html: str = ""
    error: str = ""
    from_cache: bool = False

    @property
    def empty(self) -> bool:
        return not self.ok or not self.text


def detect_encoding(content: bytes, content_type: str = "") -> str:
    """探测网页编码。

    顺序：HTTP 头 → HTML meta → utf-8。GBK 系列站点如果头和 meta 都没写，
    靠 utf-8 严格解码失败来兜底（见 :func:`decode_bytes`）。
    """
    import re

    match = re.search(CHARSET_RE, content_type or "", re.I)
    if match:
        return match.group(1).lower()

    match = re.search(CHARSET_RE.encode(), content[:8192], re.I)
    if match:
        return match.group(1).decode("ascii", "ignore").lower()

    return "utf-8"


def decode_bytes(content: bytes, content_type: str = "") -> str:
    """按候选编码依次尝试解码，返回第一个成功的。

    ``gb18030`` 是 ``gbk``/``gb2312`` 的超集，放在候选里能多救回一批生僻字。
    """
    candidates = [detect_encoding(content, content_type), "utf-8", "gb18030"]
    seen: set[str] = set()
    for encoding in candidates:
        if not encoding or encoding in seen:
            continue
        seen.add(encoding)
        try:
            return content.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return content.decode("utf-8", errors="replace")


class BrowserFetcher:
    """用真实浏览器（Playwright/Chromium）抓取有 JS 挑战的站点。

    为什么需要它：``ccgp.gov.cn`` 的 403 响应里嵌了一段 JS，会在浏览器里算出
    一个 cookie 再刷新页面。纯 HTTP 客户端拿到的永远是那个挑战页。
    实测换 UA、加 Referer、加 Sec-Fetch-* 头都无效 —— 只有真的执行那段 JS 才放行。

    代价是慢（每个页面 3-5 秒），所以只在 requests 失败后才启用，
    并且浏览器实例在整个进程里复用。
    """

    def __init__(self, config: Config) -> None:
        self.config = config
        self._playwright = None
        self._browser = None
        self._context = None
        self.available: bool | None = None

    def _ensure(self) -> bool:
        """确保浏览器可用；不可用时返回 False（调用方据此降级）。"""
        if self.available is False:
            return False
        if self._browser is not None:
            return True

        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.available = False
            return False

        try:
            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.launch()
            self._context = self._browser.new_context(
                user_agent=USER_AGENTS[0],
                locale="zh-CN",
                viewport={"width": 1440, "height": 900},
            )
        except Exception:
            self.available = False
            self.close()
            return False

        self.available = True
        return True

    def fetch(self, url: str, wait_ms: int | None = None) -> FetchResult | None:
        """用浏览器抓一个 URL。浏览器不可用或出错时返回 ``None``。"""
        if not self._ensure():
            return None

        wait_ms = wait_ms or self.config.browser_wait_ms

        page = None
        try:
            page = self._context.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=self.config.request_timeout * 1000)
            # 挑战页会自己刷新，给它时间算 cookie
            page.wait_for_timeout(wait_ms)
            html = page.content()
            if not html or "403 Forbidden" in html[:400]:
                return None
            return FetchResult(url=url, ok=True, status=200, text=html, html=html)
        except Exception:
            return None
        finally:
            if page is not None:
                try:
                    page.close()
                except Exception:
                    pass

    def close(self) -> None:
        """关掉浏览器，释放资源。"""
        for attr in ("_context", "_browser"):
            obj = getattr(self, attr, None)
            if obj is not None:
                try:
                    obj.close()
                except Exception:
                    pass
                setattr(self, attr, None)
        if self._playwright is not None:
            try:
                self._playwright.stop()
            except Exception:
                pass
            self._playwright = None


class Fetcher:
    """带缓存与重试的抓取器。"""

    def __init__(
        self,
        config: Config,
        use_cache: bool = True,
        browser_fallback: bool = True,
    ) -> None:
        self.config = config
        self.use_cache = use_cache
        self.browser_fallback = browser_fallback
        self.cache_dir = Path(config.cache_dir)
        self._browser: BrowserFetcher | None = None
        if self.use_cache:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------------- 缓存

    def _cache_paths(self, url: str) -> tuple[Path, Path]:
        digest = hashlib.sha1(url.encode("utf-8")).hexdigest()
        return self.cache_dir / f"{digest}.html", self.cache_dir / f"{digest}.meta.json"

    def read_cache(self, url: str) -> FetchResult | None:
        html_path, meta_path = self._cache_paths(url)
        if not (html_path.is_file() and meta_path.is_file()):
            return None
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            html = html_path.read_text(encoding="utf-8")
        except (OSError, json.JSONDecodeError):
            return None
        return FetchResult(
            url=url,
            ok=bool(meta.get("ok")),
            status=int(meta.get("status") or 0),
            text=str(meta.get("text") or ""),
            html=html,
            error=str(meta.get("error") or ""),
            from_cache=True,
        )

    def write_cache(self, result: FetchResult) -> None:
        """写缓存。

        **失败不写缓存**：403 / 超时往往是暂时的（WAF 限流、对方站点抽风）。
        缓存住失败等于把一次临时拦截固化下来 —— 下一轮直接读到 ok=False 的缓存，
        连浏览器兜底都不会触发，公告就永远抓不到了。
        """
        if not self.use_cache or not result.ok:
            return
        html_path, meta_path = self._cache_paths(result.url)
        try:
            html_path.write_text(result.html or "", encoding="utf-8")
            meta_path.write_text(
                json.dumps(
                    {
                        "url": result.url,
                        "ok": result.ok,
                        "status": result.status,
                        "text": result.text,
                        "error": result.error,
                        "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        except OSError:
            pass  # 缓存写不进去不该让主流程失败

    # ---------------------------------------------------------------- 抓取

    def fetch(self, url: str, timeout: int | None = None) -> FetchResult:
        """抓一个 URL，失败返回 ``ok=False`` 的结果而不是抛异常。

        批量抓取时单条失败不该中断整体流程——调用方按 ``ok`` 分流处理。
        """
        if not url:
            return FetchResult(url=url, ok=False, error="空 URL")

        if self.use_cache:
            cached = self.read_cache(url)
            if cached is not None:
                return cached

        timeout = timeout or self.config.request_timeout
        import requests

        parts = urlsplit(url)
        referer = f"{parts.scheme}://{parts.netloc}/" if parts.scheme and parts.netloc else ""

        last_error = ""
        last_status = 0
        for attempt in range(max(1, self.config.max_retries)):
            headers = {
                "User-Agent": USER_AGENTS[attempt % len(USER_AGENTS)],
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            }
            if referer:
                headers["Referer"] = referer

            try:
                resp = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                time.sleep(self.config.retry_backoff * (attempt + 1))
                continue

            last_status = resp.status_code
            if resp.status_code == 200:
                html = decode_bytes(resp.content, resp.headers.get("Content-Type", ""))
                result = FetchResult(
                    url=url,
                    ok=True,
                    status=200,
                    text=html,
                    html=html,
                )
                self.write_cache(result)
                return result

            if resp.status_code in (403, 405, 429):
                # 换 UA / 带 Referer 再试
                last_error = f"HTTP {resp.status_code}"
                time.sleep(self.config.retry_backoff * (attempt + 1))
                continue

            last_error = f"HTTP {resp.status_code}"
            break

        result = FetchResult(url=url, ok=False, status=last_status, error=last_error)

        # requests 走不通时，用真实浏览器再试一次（应对 JS 挑战）
        if self.browser_fallback and last_status in (403, 405, 429):
            if self._browser is None:
                self._browser = BrowserFetcher(self.config)
            browser_result = self._browser.fetch(url)
            if browser_result is not None:
                self.write_cache(browser_result)
                return browser_result

        self.write_cache(result)
        return result

    def close(self) -> None:
        """关掉浏览器（如果有开）。"""
        if self._browser is not None:
            self._browser.close()
            self._browser = None

    def fetch_many(self, urls: Iterable[str], timeout: int | None = None) -> list[FetchResult]:
        """顺序抓多个 URL，结果与入参一一对应。"""
        return [self.fetch(url, timeout=timeout) for url in urls]
