"""增量状态。

"每天推送新的招标信息"这件事的关键不是搜索，而是**记住上次推过什么**。
状态文件里存已推送公告的 ID，次日跑批时做差集即为新增。

状态文件是纯 JSON，可读可 diff，出了问题直接打开看就行——
比引入 SQLite 更适合这个体量，也方便老师检查。
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from .models import TenderRecord

STATE_VERSION = 1


class StateStore:
    """已推送公告的持久化存储。"""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._data: dict[str, object] = {
            "version": STATE_VERSION,
            "updated_at": "",
            "records": {},
        }
        self.load()

    # ---------------------------------------------------------------- 读写

    def load(self) -> None:
        """读取状态文件；文件不存在或损坏时按空状态继续。"""
        if not self.path.is_file():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if isinstance(data, dict) and isinstance(data.get("records"), dict):
            self._data = data

    def save(self) -> None:
        """原子写入：先写临时文件再替换，避免中途崩溃写坏状态。"""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(
            json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temp.replace(self.path)

    # ---------------------------------------------------------------- 查询

    @property
    def records(self) -> dict:
        return self._data["records"]  # type: ignore[return-value]

    def seen_ids(self) -> set[str]:
        """已推送过的公告 ID 集合。"""
        return set(self.records.keys())

    def has(self, record_id: str) -> bool:
        return record_id in self.records

    # ---------------------------------------------------------------- 写入

    def filter_new(self, records: list[TenderRecord]) -> list[TenderRecord]:
        """挑出没推送过的记录（不写状态）。"""
        seen = self.seen_ids()
        return [record for record in records if record.record_id not in seen]

    def record(self, records: list[TenderRecord]) -> list[TenderRecord]:
        """登记这些公告，返回其中**新增**的部分。

        调用顺序有讲究：先 :meth:`filter_new` 拿到新增，再 :meth:`save` 落盘。
        这样"推送成功才记状态"的语义由调用方控制——
        推送失败时不要 save，下次重跑还能推出来。
        """
        new_records = self.filter_new(records)
        for record in new_records:
            self.records[record.record_id] = {
                "title": record.title,
                "url": record.url,
                "published": record.published,
                "amount_yuan": record.amount_yuan,
                "recorded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
        return new_records

    def prune(self, keep_days: int = 180) -> int:
        """清理过老的记录，返回清理条数。

        老记录留着对"是不是新的"没有帮助，却会让状态文件无限膨胀。
        """
        cutoff = time.time() - keep_days * 86400
        stale = []
        for record_id, entry in self.records.items():
            recorded_at = str(entry.get("recorded_at", ""))
            try:
                stamp = time.mktime(time.strptime(recorded_at, "%Y-%m-%d %H:%M:%S"))
            except ValueError:
                continue
            if stamp < cutoff:
                stale.append(record_id)
        for record_id in stale:
            del self.records[record_id]
        return len(stale)
