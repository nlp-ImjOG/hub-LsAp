#!/usr/bin/env python
"""ESG 月报（案例一）—— 脚本臂。

对应《作业.txt》案例一：汇总过去一个月的时政信息，帮客户生成 ESG 月报，
至少覆盖三个板块：

1. ESG 政策、评级、标准等相关的动态；
2. 客户所属行业层面相关的新闻动态、最佳实践；
3. 客户公司动态对 ESG 的影响与建议、对标企业的 ESG 关键行动。

这个脚本是**作业二**的"有确定性 script"版本；作业一的 Skill 是"无 script"版本。
两者跑的是同一套检索式（:data:`esg_toolkit.pipeline.NEWS_BOARDS`），
差别只在**谁来做抽取、筛选与汇总**。

用法::

    python monthly_report.py                      # 生成上一个自然月的月报
    python monthly_report.py --client 中国神华
    python monthly_report.py --period 2026-10     # 指定月份
    python monthly_report.py --no-llm             # 只跑确定性部分，不调 LLM 写导语
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from esg_toolkit.cli import echo_result, force_utf8, make_logger, resolve_outdir  # noqa: E402
from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.llm import advise_news, summarize_news  # noqa: E402
from esg_toolkit.parse_news import previous_month_window  # noqa: E402
from esg_toolkit.pipeline import (  # noqa: E402
    NEWS_BOARDS,
    collect_news,
    news_facts,
    news_payload,
    write_artifacts,
)
from esg_toolkit.providers import build_provider  # noqa: E402
from esg_toolkit.providers.base import SearchUnavailable  # noqa: E402
from esg_toolkit.render import (  # noqa: E402
    default_meta,
    render_html,
    render_json,
    render_markdown,
)

DEFAULT_CLIENT = "中国神华"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="生成 ESG 月报（案例一·脚本臂）")
    parser.add_argument("--client", default=DEFAULT_CLIENT, help="客户名称")
    parser.add_argument(
        "--period",
        default="",
        help="统计月份，格式 YYYY-MM；默认上一个自然月",
    )
    parser.add_argument("--out", default="", help="输出目录；默认 作业二/output/monthly")
    parser.add_argument("--name", default="", help="产物文件名（不含扩展名）")
    parser.add_argument("--provider", default="", help="搜索后端：claude-cli / bocha")
    parser.add_argument("--count", type=int, default=8, help="每条检索式取回的结果数")
    parser.add_argument("--no-llm", action="store_true", help="不调用 LLM 写导语与建议")
    parser.add_argument(
        "--fetch-bodies",
        action="store_true",
        help="抓取每条新闻的正文作为摘要（慢，默认关闭）",
    )
    parser.add_argument("--dry-run", action="store_true", help="只打印检索式，不真正跑")
    return parser


def resolve_period(period: str) -> tuple[str, str, str]:
    """返回 ``(开始日期, 结束日期, 展示用的区间描述)``。"""
    if period:
        year, _, month = period.partition("-")
        try:
            start = date(int(year), int(month), 1)
        except (TypeError, ValueError):
            raise SystemExit(f"月份格式不对：{period}（应为 YYYY-MM）")
        if start.month == 12:
            next_month = date(start.year + 1, 1, 1)
        else:
            next_month = date(start.year, start.month + 1, 1)
        end = date.fromordinal(next_month.toordinal() - 1)
    else:
        start_str, end_str = previous_month_window()
        return start_str, end_str, f"{start_str} ~ {end_str}"

    end_str = end.isoformat()
    return start.isoformat(), end_str, f"{start.isoformat()} ~ {end_str}"


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    args = build_parser().parse_args(argv)
    log = make_logger(True)

    start, end, period_label = resolve_period(args.period)
    log(f"统计区间：{period_label}（客户：{args.client}）")

    if args.dry_run:
        for board, queries in NEWS_BOARDS.items():
            log(f"[{board}]")
            for query in queries:
                log(f"  - {query}")
        return 0

    config = Config.load()
    if args.provider:
        config.search_provider = args.provider
    config.ensure_dirs()

    out_dir = Path(args.out) if args.out else resolve_outdir(config, "monthly")
    name = args.name or f"esg-monthly-{start[:7]}"

    try:
        provider = build_provider(config)
    except SearchUnavailable as exc:
        log(f"搜索后端不可用：{exc}")
        return 2

    log(f"搜索后端：{provider.name}")
    fetcher = Fetcher(config)

    boards = collect_news(
        provider,
        fetcher=fetcher,
        boards=NEWS_BOARDS,
        count=args.count,
        start=start,
        end=end,
        fetch_bodies=args.fetch_bodies,
        log=log,
    )

    meta = default_meta(
        title=f"{args.client} ESG 月报",
        client=args.client,
        period_start=start,
        period_end=end,
        data_source="公开网络检索（WebSearch）+ 中国政府采购网等公开渠道",
        notes=[
            "报告按自然月统计（上月 1 日至月末），口径固定，可跨月对比。",
            "所有结论均以标注来源为准；未能核实的内容不作断言。",
            f"检索后端：{provider.name}；抽取、去重与排序由确定性脚本完成，"
            "导语与建议由模型基于已核实事实撰写。",
        ],
    )

    payload = news_payload(boards, meta)

    # ---- 确定性兜底：模型不可用时也要有一份能读的摘要
    total = sum(len(items) for items in boards.values())
    payload["summary"] = (
        f"本期共整理 {total} 条 ESG 相关动态，覆盖政策与标准、行业实践、"
        f"客户与对标企业三方面。"
    )

    if not args.no_llm:
        facts = news_facts(boards)
        log("调用模型撰写导语与要点…")
        narrative = summarize_news(config.claude_cli, args.client, period_label, facts)
        if narrative:
            payload["summary"] = narrative["summary"]
            payload["highlights"] = narrative["highlights"]
        else:
            log("  ! 模型未返回可用文本，保留确定性摘要")

        advice = advise_news(config.claude_cli, args.client, period_label, facts)
        if advice:
            for section in payload["sections"]:
                if section.get("key") == "公司动态、对标企业行动与建议":
                    section["advice"] = advice
        else:
            log("  ! 模型未返回建议")

    paths = write_artifacts(
        out_dir, name, payload, render_markdown, render_json, render_html
    )
    log("产物已生成：")
    for kind, path in paths.items():
        log(f"  {kind}: {path}")

    echo_result(
        {
            "period": period_label,
            "client": args.client,
            "total": total,
            "boards": {board: len(items) for board, items in boards.items()},
            "artifacts": {kind: str(path) for kind, path in paths.items()},
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
