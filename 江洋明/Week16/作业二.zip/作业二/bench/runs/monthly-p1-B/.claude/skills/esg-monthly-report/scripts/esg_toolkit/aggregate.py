"""统计聚合。

招投标汇总要回答三个问题：**钱花在哪**（金额分布）、**大家都在买什么**（热点方向）、
**趋势如何**（月度变化）。这些全是确定性的计数与求和，写成代码比让模型算可靠得多
—— 模型做加法会错，代码不会。

"热点方向"用**规范方向词表**（见 :mod:`esg_toolkit.keywords`）统计，而不是中文分词。
原因很实际：没有分词器时，中文 n-gram 切出来的多半是"合管理平"这种碎片，
既噪声大又不可解释；而方向词表本身就是可交付的资产 ——
Skill 的 ``references/keyword-matrix.md`` 讲的正是这份表，脚本与 Skill 因此共用同一套口径。
"""

from __future__ import annotations

import math
import re
import statistics
from collections import Counter, defaultdict

from .keywords import DIRECTION_CATEGORY, ESG_DIRECTIONS
from .models import TenderRecord

# ---------------------------------------------------------------- 金额分档
# 档位以「万元」为界，报告里展示中文区间
AMOUNT_BUCKETS: list[tuple[float, float, str]] = [
    (0, 10, "10 万以下"),
    (10, 50, "10–50 万"),
    (50, 100, "50–100 万"),
    (100, 500, "100–500 万"),
    (500, 1000, "500–1000 万"),
    (1000, 10000, "1000 万–1 亿"),
    (10000, float("inf"), "1 亿以上"),
]

# 采购人分类规则：(分类名, 正则)。顺序即优先级，先匹配先算。
BUYER_RULES: list[tuple[str, str]] = [
    ("生态环境与自然资源部门", r"生态环境局|环保局|自然资源局|林业局|水务局|农业农村局"),
    ("发展改革与工信部门", r"发展和改革委员会|发改委|经济和信息化局|工信局|能源局"),
    ("财政与政府其他部门", r"财政局|教育局|卫健委|住房和城乡建设局|交通运输局|水利局|国资委"),
    ("公共资源交易中心", r"公共资源交易中心|招标代理|政府采购中心"),
    ("能源与国有企业", r"能源集团|能源股份|能源公司|电力|煤业|煤炭|矿业|石化|钢铁|有色|水务集团|投资集团|控股集团"),
    ("金融机构", r"银行|保险|证券|资产管理"),
    ("第三方机构与服务商", r"研究院|研究所|设计院|环境科学|评估|认证|咨询|事务所"),
]


# ---------------------------------------------------------------- 金额


def amount_buckets(records: list[TenderRecord]) -> list[dict]:
    """中标金额分档统计。

    只统计有金额的记录；金额缺失的记录单独计数并在 ``金额未披露`` 一档里返回 ——
    悄悄丢掉会让分档占比虚高。
    """
    counts: Counter[str] = Counter()
    totals: dict[str, float] = defaultdict(float)
    missing = 0

    for record in records:
        if record.amount_yuan is None:
            missing += 1
            continue
        wan = record.amount_yuan / 1e4
        for low, high, label in AMOUNT_BUCKETS:
            if low <= wan < high:
                counts[label] += 1
                totals[label] += record.amount_yuan
                break

    total_amount = sum(totals.values())
    total_count = sum(counts.values())

    buckets = [
        {
            "bucket": label,
            "count": counts[label],
            "total_yuan": round(totals[label], 2),
            "ratio": round(counts[label] / total_count, 4) if total_count else 0.0,
            "amount_ratio": (
                round(totals[label] / total_amount, 4) if total_amount else 0.0
            ),
        }
        for _, _, label in AMOUNT_BUCKETS
    ]
    buckets.append(
        {
            "bucket": "金额未披露",
            "count": missing,
            "total_yuan": 0.0,
            "ratio": 0.0,
            "amount_ratio": 0.0,
        }
    )
    return buckets


def amount_stats(records: list[TenderRecord]) -> dict:
    """金额的集中趋势。"""
    amounts = [r.amount_yuan for r in records if r.amount_yuan is not None]
    if not amounts:
        return {
            "count": 0,
            "total_yuan": 0.0,
            "mean_yuan": 0.0,
            "median_yuan": 0.0,
            "min_yuan": None,
            "max_yuan": None,
            "missing": len(records),
        }

    return {
        "count": len(amounts),
        "total_yuan": round(sum(amounts), 2),
        "mean_yuan": round(statistics.mean(amounts), 2),
        "median_yuan": round(statistics.median(amounts), 2),
        "min_yuan": min(amounts),
        "max_yuan": max(amounts),
        "missing": len(records) - len(amounts),
    }


# ---------------------------------------------------------------- 热点方向


def extract_directions(text: str) -> list[str]:
    """从文本里识别出命中的 ESG 方向词。

    做"短形优先"处理：同一段文本若同时命中"温室气体排放"和"温室气体"，
    只留较短的"温室气体"—— 榜单要的是方向，不是限定语。
    """
    if not text:
        return []

    hits = [word for word in ESG_DIRECTIONS if word in text]
    return [
        word
        for word in hits
        if not any(other != word and len(other) < len(word) and other in word for other in hits)
    ]


def hotspot_keywords(records: list[TenderRecord], top_n: int = 15) -> list[dict]:
    """热点方向统计。

    语料只用**项目标题** —— "热点招标方向"问的是"在买什么"，标题才是答案；
    采购人属于"谁买"，由 :func:`buyer_classification` 单独呈现。

    只统计出现次数达到阈值的方向：只出现一两次的方向不是热点，是噪声。
    """
    if not records:
        return []

    counter: Counter[str] = Counter()
    for record in records:
        for direction in sorted(set(extract_directions(record.title))):
            counter[direction] += 1

    min_count = max(2, math.ceil(0.03 * len(records)))

    return [
        {
            "term": term,
            "count": count,
            "share": round(count / len(records), 4),
            "category": DIRECTION_CATEGORY.get(term, "其他方向"),
        }
        for term, count in counter.most_common()
        if count >= min_count
    ][:top_n]


# ---------------------------------------------------------------- 分布


def monthly_trend(records: list[TenderRecord]) -> list[dict]:
    """按月的条数与金额走势。"""
    buckets: dict[str, dict] = defaultdict(lambda: {"count": 0, "total_yuan": 0.0})

    for record in records:
        if not record.published:
            continue
        month = record.published[:7]
        buckets[month]["count"] += 1
        if record.amount_yuan:
            buckets[month]["total_yuan"] += record.amount_yuan

    return [
        {
            "month": month,
            "count": data["count"],
            "total_yuan": round(data["total_yuan"], 2),
        }
        for month, data in sorted(buckets.items())
    ]


def region_distribution(records: list[TenderRecord]) -> list[dict]:
    """按省份分布。"""
    buckets: dict[str, dict] = defaultdict(lambda: {"count": 0, "total_yuan": 0.0})

    for record in records:
        key = record.province or "未识别"
        buckets[key]["count"] += 1
        if record.amount_yuan:
            buckets[key]["total_yuan"] += record.amount_yuan

    return [
        {
            "region": region,
            "count": data["count"],
            "total_yuan": round(data["total_yuan"], 2),
        }
        for region, data in sorted(
            buckets.items(), key=lambda kv: kv[1]["count"], reverse=True
        )
    ]


def buyer_classification(records: list[TenderRecord]) -> dict[str, int]:
    """按采购人类型分组计数。"""
    counter: Counter[str] = Counter()

    for record in records:
        text = f"{record.buyer} {record.extra.get('buyer_raw', '')}"
        matched = "其他"
        for label, pattern in BUYER_RULES:
            if pattern and _search(pattern, text):
                matched = label
                break
        counter[matched] += 1

    return dict(counter.most_common())


def category_distribution(records: list[TenderRecord]) -> list[dict]:
    """按 ESG 细分方向分布。"""
    counter: Counter[str] = Counter()
    totals: dict[str, float] = defaultdict(float)

    for record in records:
        key = record.category or "未分类"
        counter[key] += 1
        if record.amount_yuan:
            totals[key] += record.amount_yuan

    return [
        {
            "category": category,
            "count": count,
            "total_yuan": round(totals[category], 2),
            "ratio": round(count / len(records), 4) if records else 0.0,
        }
        for category, count in counter.most_common()
    ]


def summarize(records: list[TenderRecord]) -> dict:
    """一次性产出报告需要的全部统计口径。"""
    return {
        "total": len(records),
        "with_amount": sum(1 for r in records if r.amount_yuan is not None),
        #: 解析不出发布日期的条数 —— 它们没法证明落在统计区间里，要单独披露
        "undated": sum(1 for r in records if not r.published),
        "amount": amount_stats(records),
        "buckets": amount_buckets(records),
        "hotspots": hotspot_keywords(records),
        "trend": monthly_trend(records),
        "regions": region_distribution(records),
        "buyers": buyer_classification(records),
        "categories": category_distribution(records),
    }


def _search(pattern: str, text: str) -> bool:
    """``re.search`` 的安全封装：text 为空时返回 False。"""
    if not text:
        return False
    return bool(re.search(pattern, text))
