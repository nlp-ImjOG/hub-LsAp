"""工具层的数据模型。

字段名与《作业一/docs/01-设计说明.md》附录 A.1 保持一致 —— 那是本项目的接口契约，
改这里之前先改那份文档。

全部使用 dataclass：脚本层要在测试里构造大量样例，dataclass 比 dict 更不容易写错字段名。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .urls import canonical_url, site_of


@dataclass(frozen=True)
class SearchHit:
    """一条搜索结果。

    ``published`` 一律是 ISO 日期字符串（``YYYY-MM-DD``）；判断不出就留 None，
    绝不填一个猜的日期 —— 报告里"发布时间未标注"比一个错日期诚实得多。
    """

    title: str
    url: str
    snippet: str = ""
    published: str | None = None
    source: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class TenderRecord:
    """一条结构化的招标 / 中标记录。

    金额一律归一到 **元** 存在 ``amount_yuan``；``amount_raw`` 保留原文串，
    这样报告里可以逐字引用、也能人工核对归一是否正确。
    """

    title: str
    url: str
    buyer: str = ""  # 招标人 / 采购人
    winner: str = ""  # 中标（成交）供应商
    amount_yuan: float | None = None
    amount_raw: str = ""
    published: str | None = None  # ISO 日期
    package: str = ""  # 标段 / 包号
    province: str = ""  # 省份
    category: str = ""  # ESG 细分方向
    extra: dict[str, str] = field(default_factory=dict)

    @property
    def record_id(self) -> str:
        """公告唯一标识。

        优先用规范化后的 URL；URL 为空时退化为"标题+日期"，
        这样同一条公告在多个站点转载时仍能识别为同一条。
        """
        canon = canonical_url(self.url)
        if canon:
            return canon
        return f"{self.title}|{self.published or ''}"

    @property
    def site(self) -> str:
        return site_of(self.url)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["record_id"] = self.record_id
        data["site"] = self.site
        return data


@dataclass
class NewsItem:
    """一条新闻 / 公告动态（ESG 月报用）。

    ``source_tier`` 是信源分级：A 监管/官方、B 主流财经媒体、C 行业媒体、D 其他。
    ``topic`` 与 ``impact`` 是"这条动态对客户 ESG 意味着什么"的映射结果，
    由 Skill 侧（LLM）填写，脚本侧只做兜底默认值。
    """

    title: str
    url: str
    published: str | None = None
    source: str = ""
    source_tier: str = "D"
    topic: str = ""  # 映射到的 ESG 议题，如 E1 / G1
    impact: str = ""  # 利好 / 中性 / 风险
    summary: str = ""

    @property
    def record_id(self) -> str:
        canon = canonical_url(self.url)
        if canon:
            return canon
        return f"{self.title}|{self.published or ''}"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["record_id"] = self.record_id
        data["site"] = site_of(self.url)
        return data
