"""关键词与分类矩阵 —— 脚本层与 Skill 层共用的单一真源。

为什么单独抽一个模块：ESG 相关性判定是一套**可枚举的规则**（哪些词算 ESG 方向、
哪些词只是普通采购）。让它同时服务于脚本的自动分类和 Skill 的检索式生成，
两边才不会各说各话。Skill 的 ``references/keyword-matrix.md`` 讲的就是这份表。
"""

from __future__ import annotations

# ESG 细分方向 -> 关键词（含中英文与常见缩写）
ESG_CATEGORIES: dict[str, list[str]] = {
    "ESG评价": ["ESG评价", "ESG评估", "ESG认证", "ESG咨询", "ESG评价技术服务", "ESG报告"],
    "双碳与碳中和": [
        "双碳", "碳达峰", "碳中和", "碳排放管控", "碳排放管理", "碳目标",
        "碳路图", "碳规划", "低碳转型",
    ],
    "碳足迹与核算": [
        "碳足迹", "碳核算", "温室气体", "温室气体清单", "温室气体排放", "碳盘查",
        "碳排放核算", "产品碳足迹", "组织碳足迹", "碳核查", "CCER",
    ],
    "绿色低碳与节能": [
        "绿色低碳", "节能降碳", "节能减排", "节能改造", "绿色制造", "绿色工厂",
        "绿色园区", "绿色工业园区", "绿色建筑", "超低能耗", "清洁生产", "循环经济",
        "零碳", "零碳园区", "零碳工厂", "绿色矿山",
    ],
    "生态产品价值GEP": [
        "生态产品价值", "GEP", "生态价值实现", "生态产品",
    ],
    "绿色金融": [
        "绿色金融", "绿色信贷", "绿色债券", "碳金融", "转型金融", "碳基金",
    ],
    "环境与生态治理": [
        "污染防治", "污染管控", "生态保护", "生态修复", "环境保护", "环境监测",
        "自然保护地", "生物多样性", "土壤污染", "排污许可",
    ],
    "水与资源": [
        "水资源", "节水", "水务", "取水许可", "流域治理",
    ],
    "ESG披露与鉴证": [
        "可持续发展报告", "ESG信息披露", "可持续披露", "温室气体核算体系",
        "鉴证", "审验", "双重重要性",
    ],
    "供应链与责任": [
        "绿色供应链", "负责任采购", "供应链 ESG", "产业链减碳", "供应链管理",
    ],
    # 「可持续发展」「社会责任」本身没有更细的子类，但它们是招标公告里
    # 最常见的泛化表述 —— 不收进矩阵的话，这类公告会分类失败（category 为空）。
    "可持续与社会责任": [
        "可持续发展", "可持续", "社会责任", "ESG", "社会价值", "负责任",
        "公益", "乡村振兴", "共同富裕",
    ],
}

# 命中这些词说明"至少是 ESG 相关"，用于粗筛
ESG_STRONG_KEYWORDS: list[str] = [
    "ESG",
    "双碳",
    "碳达峰",
    "碳中和",
    "可持续",
    "可持续发展",
    "碳足迹",
    "温室气体",
    "绿色低碳",
    "节能降碳",
    "GEP",
    "生态产品价值",
    "绿色金融",
    "绿色矿山",
    "碳核查",
    "CCER",
    "ESG评价",
    "零碳园区",
    "合同能源管理",
    "生态产品价值实现",
]

#: **月报**（新闻/政策动态）用的相关性词表 —— 比 :data:`ESG_STRONG_KEYWORDS` 宽。
#:
#: 两份表分开是有原因的：
#:
#: - :data:`ESG_STRONG_KEYWORDS` 用来从**招标公告**里筛采购项目，
#:   宁严勿宽 —— 放进"绿色""生态"这种宽词，进来一堆绿化养护、办公用品采购；
#: - 月报要看的是**政策与行业动态**，"全国碳市场扩围""碳排放管控"
#:   这种条目没有"双碳""碳中和"字样，却恰恰是客户最该知道的。
#:
#: 放宽的代价是月报里可能混进泛环保新闻 —— 但月报本来就要讲行业动态，
#: 这个代价是划算的。
ESG_NEWS_KEYWORDS: list[str] = [
    "ESG",
    "双碳",
    "碳达峰",
    "碳中和",
    "碳排放",
    "碳减排",
    "碳市场",
    "碳管理",
    "碳足迹",
    "碳核算",
    "碳计量",
    "碳监测",
    "碳普惠",
    "碳汇",
    "碳交易",
    "温室气体",
    "可持续",
    "可持续发展",
    "绿色低碳",
    "节能降碳",
    "节能减排",
    "绿色发展",
    "绿色矿山",
    "绿色工厂",
    "绿色园区",
    "零碳",
    "生态产品价值",
    "GEP",
    "绿色金融",
    "绿色信贷",
    "绿色债券",
    "生态保护",
    "生态修复",
    "环境保护",
    "污染防治",
    "环境监测",
    "生物多样性",
    "碳核查",
    "CCER",
    "ESG评价",
    "零碳园区",
    "合同能源管理",
    "生态产品价值实现",
    "社会责任",
]

# 排除词：命中这些的采购多半与 ESG 无关（土建、设备、通用服务）
EXCLUDE_KEYWORDS: list[str] = [
    "办公用品",
    "物业管理",
    "劳务派遣",
    "食堂",
    "车辆采购",
    "打印耗材",
    "机房改造",
    "道路维修",
    "绿化养护",
    "安保服务",
    "会议服务",
    "印刷服务",
    "家具采购",
    "食堂食材",
    "药品采购",
    "工程施工",
    "土建施工",
    "装修工程",
    "电梯采购",
    "空调采购",
    "电脑采购",
    "台式机采购",
    "网络设备采购",
]

# 补充方向词：不在上面 10 个分类里、但确实是 ESG 采购方向的词
EXTRA_DIRECTIONS: list[str] = [
    "节能服务", "合同能源管理", "能效", "清洁能源", "可再生能源", "光伏", "风电",
    "储能", "氢能", "绿色矿山", "智慧矿山", "生态治理", "污染防治", "环境咨询",
    "碳汇交易", "环境权益交易", "碳普惠", "零碳", "碳交易", "节能改造",
]

# ---------------------------------------------------------------- 方向词表

#: 全部规范方向词（去重后按长度降序，短形优先用）
#:
#: 排序键是 ``(-长度, 词)`` 而不是 ``长度`` —— 只按长度排的话，同长度词之间的
#: 相对顺序取决于集合迭代顺序，而字符串哈希默认每进程随机化，结果就是
#: 每次生成的文档都不一样。文档要能 diff，这里必须完全确定。
ESG_DIRECTIONS: list[str] = sorted(
    {word for words in ESG_CATEGORIES.values() for word in words}
    | set(EXTRA_DIRECTIONS),
    key=lambda word: (-len(word), word),
)

#: 方向词 -> 所属分类。未出现在任何分类里的归到"其他方向"
DIRECTION_CATEGORY: dict[str, str] = {}
for _category, _words in ESG_CATEGORIES.items():
    for _word in _words:
        DIRECTION_CATEGORY.setdefault(_word, _category)
for _word in EXTRA_DIRECTIONS:
    DIRECTION_CATEGORY.setdefault(_word, "其他方向")


# 省级行政区，用于从 URL / 正文推断省份
PROVINCES: list[str] = [
    "北京", "天津", "河北", "山西", "内蒙古", "辽宁", "吉林", "黑龙江",
    "上海", "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南",
    "湖北", "湖南", "广东", "广西", "海南", "重庆", "四川", "贵州",
    "云南", "西藏", "陕西", "甘肃", "青海", "宁夏", "新疆", "台湾",
    "香港", "澳门",
]

# 城市名 → 省份，用于正文里出现"××市"时定位
CITY_TO_PROVINCE: dict[str, str] = {
    "石家庄": "河北", "唐山": "河北", "太原": "山西", "呼和浩特": "内蒙古",
    "沈阳": "辽宁", "大连": "辽宁", "长春": "吉林", "哈尔滨": "黑龙江",
    "南京": "江苏", "苏州": "江苏", "无锡": "江苏", "徐州": "江苏",
    "杭州": "浙江", "宁波": "浙江", "温州": "浙江", "嘉兴": "浙江",
    "合肥": "安徽", "芜湖": "安徽", "福州": "福建", "厦门": "福建", "泉州": "福建",
    "南昌": "江西", "济南": "山东", "青岛": "山东", "烟台": "山东", "潍坊": "山东",
    "郑州": "河南", "洛阳": "河南", "武汉": "湖北", "宜昌": "湖北",
    "长沙": "湖南", "株洲": "湖南", "广州": "广东", "深圳": "广东", "珠海": "广东",
    "东莞": "广东", "佛山": "广东", "南宁": "广西", "桂林": "广西",
    "海口": "海南", "三亚": "海南", "重庆": "重庆",
    "成都": "四川", "绵阳": "四川", "贵阳": "贵州", "遵义": "贵州",
    "昆明": "云南", "大理": "云南", "拉萨": "西藏",
    "西安": "陕西", "咸阳": "陕西", "兰州": "甘肃", "西宁": "青海",
    "银川": "宁夏",
    # 新疆的地级市多，招标公告里出现的频率也高
    "乌鲁木齐": "新疆", "库尔勒": "新疆", "喀什": "新疆", "和田": "新疆",
    "伊宁": "新疆", "库车": "新疆", "沙湾": "新疆", "新和": "新疆",
    "塔城": "新疆", "克拉玛依": "新疆", "奎屯": "新疆", "阿勒泰": "新疆",
    "昌吉": "新疆", "博尔塔拉": "新疆", "巴音郭楞": "新疆", "阿克苏": "新疆",
    "吐鲁番": "新疆", "哈密": "新疆", "石河子": "新疆",
}

# 信源分级：A 监管/官方，B 主流财经媒体，C 行业媒体，D 其他
SOURCE_TIER_RULES: list[tuple[str, str]] = [
    ("gov.cn", "A"),
    ("ccgp.gov.cn", "A"),
    ("ggzy", "A"),
    ("mee.gov.cn", "A"),
    ("ndrc.gov.cn", "A"),
    ("csrc.gov.cn", "A"),
    ("sse.com.cn", "A"),
    ("szse.cn", "A"),
    ("sac.gov.cn", "A"),
    ("pbc.gov.cn", "A"),
    ("chinabond.com.cn", "A"),
    ("sasac.gov.cn", "A"),
    ("cninfo.com.cn", "A"),
    ("hkexnews.hk", "A"),
    ("shenhuachina.com.cn", "A"),
    ("chnenergy.com.cn", "A"),
    ("xinhuanet.com", "B"),
    ("people.com.cn", "B"),
    ("chinanews.com.cn", "B"),
    ("cnstock.com", "B"),
    ("stcn.com", "B"),
    ("cs.com.cn", "B"),
    ("21jingji.com", "B"),
    ("caixin.com", "B"),
    ("yicai.com", "B"),
    ("jiemian.com", "B"),
    ("thepaper.cn", "B"),
    ("cls.cn", "B"),
    ("sina.com.cn", "B"),
    ("163.com", "B"),
    ("qq.com", "B"),
    ("sohu.com", "C"),
    ("eastmoney.com", "C"),
    ("wind.com.cn", "C"),
    ("hexun.com", "C"),
    ("chinanews.com", "B"),
]

# 默认兜底分级
DEFAULT_SOURCE_TIER = "D"


def classify_category(text: str) -> str:
    """判断一段文本属于哪个 ESG 细分方向。

    命中关键词最多的类别胜出；都没命中时再看**补充方向词**
    （``EXTRA_DIRECTIONS``），命中就归到「其他方向」。

    两级都落空才返回空串（表示"无法判定"），由上层决定是丢弃还是交给 LLM 判读。
    """
    if not text:
        return ""
    best_category = ""
    best_score = 0
    for category, words in ESG_CATEGORIES.items():
        score = sum(1 for word in words if word in text)
        if score > best_score:
            best_category, best_score = category, score
    if best_category:
        return best_category
    if any(word in text for word in EXTRA_DIRECTIONS):
        return "其他方向"
    return ""


def is_esg_related(text: str) -> bool:
    """粗筛：文本是否命中 ESG 关键词。"""
    if not text:
        return False
    return any(word in text for word in ESG_STRONG_KEYWORDS)


def is_excluded(text: str) -> bool:
    """排除词判定 —— 命中的采购多半与 ESG 无关。"""
    if not text:
        return False
    return any(word in text for word in EXCLUDE_KEYWORDS)


def source_tier(domain: str) -> str:
    """按域名给信源分级。"""
    if not domain:
        return DEFAULT_SOURCE_TIER
    domain = domain.lower()
    for pattern, tier in SOURCE_TIER_RULES:
        if pattern in domain:
            return tier
    return DEFAULT_SOURCE_TIER


def infer_province(text: str, url: str = "") -> str:
    """从 URL 域名或正文推断省份。

    正文里命中多个地名时，取**出现位置最靠前**的那个，而不是按 ``PROVINCES``
    的固定顺序逐个找。固定顺序会先撞上网站页脚里的"北京市"，把一篇厦门的
    公告判成北京 —— 实测踩过。

    域名优先于正文：``plan.hainan.gov.cn`` 里的省份线索比正文可靠。
    """
    if url:
        host = url.lower()
        for province in PROVINCES:
            for hint in _PROVINCE_HINTS.get(province, ()):
                if _host_has_hint(host, hint):
                    return province

    if text:
        candidates: list[tuple[int, str]] = []
        for province in PROVINCES:
            position = text.find(province)
            if position != -1:
                candidates.append((position, province))
        for city, province in CITY_TO_PROVINCE.items():
            position = text.find(city)
            if position != -1:
                candidates.append((position, province))
        if candidates:
            # 位置相同时取更长的地名（"海南" 优于 "海口"？不，两者位置不同）
            candidates.sort(key=lambda item: (item[0], -len(item[1])))
            return candidates[0][1]

    return ""


def _host_has_hint(host: str, hint: str) -> bool:
    """域名里是否含有该省份线索。

    两字母缩写（``bj``/``hb``/``sx``…）太短，直接 ``in`` 会误判
    （``ccgp-hb`` 之类的无关串）。要求它作为一个独立的域名片段出现。
    """
    if len(hint) > 2:
        return hint in host
    return f".{hint}." in host or f"-{hint}." in host or f".{hint}-" in host


# 省份在域名里的拼音/英文缩写线索
_PROVINCE_HINTS: dict[str, tuple[str, ...]] = {
    "北京": ("beijing", "bj"),
    "天津": ("tianjin", "tj"),
    "河北": ("hebei", "hb"),
    "山西": ("shanxi", "sx"),
    "内蒙古": ("neimenggu", "nmg"),
    "辽宁": ("liaoning", "ln"),
    "吉林": ("jilin", "jl"),
    "黑龙江": ("heilongjiang", "hlj"),
    "上海": ("shanghai", "sh"),
    "江苏": ("jiangsu", "js"),
    "浙江": ("zhejiang", "zj"),
    "安徽": ("anhui", "ah"),
    "福建": ("fujian", "fj"),
    "江西": ("jiangxi", "jx"),
    "山东": ("shandong", "sd"),
    "河南": ("henan", "ha"),
    "湖北": ("hubei", "hb"),
    "湖南": ("hunan", "hn"),
    "广东": ("guangdong", "gd"),
    "广西": ("guangxi", "gx"),
    "海南": ("hainan", "hi"),
    "重庆": ("chongqing", "cq"),
    "四川": ("sichuan", "sc"),
    "贵州": ("guizhou", "gz"),
    "云南": ("yunnan", "yn"),
    "西藏": ("xizang", "xz"),
    "陕西": ("shaanxi", "sx"),
    "甘肃": ("gansu", "gs"),
    "青海": ("qinghai", "qh"),
    "宁夏": ("ningxia", "nx"),
    "新疆": ("xinjiang", "xj"),
}
