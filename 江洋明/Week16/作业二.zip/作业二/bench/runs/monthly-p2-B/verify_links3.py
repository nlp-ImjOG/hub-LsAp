#!/usr/bin/env python
"""ESG 月报：第三轮候选来源核验（贵州洗选办法、财政部气候准则原文）。"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL = Path(
    r"E:/个人/AI学习/AI大模型应用/作业/16-江洋明-第十六周作业/作业二/bench/runs/monthly-p2-B"
    r"/.claude/skills/esg-monthly-report/scripts"
)
sys.path.insert(0, str(SKILL))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.htmlutil import extract_body  # noqa: E402
from esg_toolkit.parse_news import (  # noqa: E402
    classify_tier,
    published_from_html,
    published_from_url,
)

OUT = Path(__file__).resolve().parent / "verify_out3"
OUT.mkdir(exist_ok=True)

CANDIDATES: list[tuple[str, str]] = [
    ("贵州煤炭洗选管理办法 通知原文(铜仁市政府)", "https://www.trs.gov.cn/zwgk/zdlyxxgk/nyzy/202610/t20261009_90970727.html"),
    ("贵州煤炭洗选管理办法 政策解读(省能源局)", "https://nyj.guizhou.gov.cn/zwgk/xxgkml/zcwj_2/zcjj_2/wzjd/202610/t20261009_90970612.html"),
    ("贵州煤炭洗选管理办法 全文(中国煤炭市场网)", "https://www.cctd.com.cn/show-26-257410-1.html"),
    ("贵州煤炭洗选办法(国家能源集团报10/21)", "https://epaper.ceic.com/pc/content/202610/21/content_24799.html"),
    ("财政部气候准则应用指南征求意见 原文(会计司)", "https://kjs.mof.gov.cn/gongzuotongzhi/202609/t20260929_3998329.htm"),
    ("财政部气候准则应用指南征求意见 转载(部预算司)", "https://bgt.mof.gov.cn/zhuantilanmu/rdwyh/czyw/202609/t20260929_3998329.htm"),
    ("气候披露标准对标国际 九行业碳账本(中国证券网)", "https://www.cnstock.com/commonDetail/811798"),
]


def main() -> int:
    config = Config.load()
    config.browser_fallback = True
    fetcher = Fetcher(config, use_cache=True)
    records = []
    for label, url in CANDIDATES:
        print(f"→ 抓取：{label}")
        res = fetcher.fetch(url)
        body = ""
        if res.ok and res.html:
            try:
                body = extract_body(res.html)
            except Exception as exc:  # noqa: BLE001
                body = f"[正文抽取失败：{exc}]"
        rec = {
            "label": label,
            "url": url,
            "ok": res.ok,
            "status": res.status,
            "error": res.error,
            "date_from_url": published_from_url(url),
            "date_from_html": published_from_html(res.html) if res.ok else None,
            "tier": classify_tier(url),
            "body_len": len(body),
            "body_head": body[:2500],
        }
        records.append(rec)
        print(
            f"   ok={res.ok} status={res.status} "
            f"date_url={rec['date_from_url']} date_html={rec['date_from_html']} "
            f"len={rec['body_len']}"
        )

    (OUT / "links.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (OUT / "links.txt").open("w", encoding="utf-8") as fh:
        for rec in records:
            fh.write("=" * 100 + "\n")
            fh.write(f"[{rec['label']}]\n{rec['url']}\n")
            fh.write(
                f"ok={rec['ok']} status={rec['status']} tier={rec['tier']} "
                f"date_url={rec['date_from_url']} date_html={rec['date_from_html']}\n"
            )
            if rec["error"]:
                fh.write(f"error={rec['error']}\n")
            fh.write("-" * 60 + "\n")
            fh.write(rec["body_head"] + "\n")
    print(f"\n已写出：{OUT/'links.json'} / {OUT/'links.txt'}")
    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
