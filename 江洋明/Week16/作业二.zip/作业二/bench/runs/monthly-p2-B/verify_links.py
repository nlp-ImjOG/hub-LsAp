#!/usr/bin/env python
"""ESG 月报：逐条核验候选来源链接。

抓原文页 → 抽发布日期（URL 里的日期 + 页面元数据）→ 抽正文前若干字。
输出 verify_out/links.json 与 links.txt，供人工逐条确认"日期对不对、内容对不对"。
"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL = Path(
    r"E:/个人/AI学习/AI大模型应用/作业/16-江洋明-第十六周作业/作业二/bench/runs/monthly-p2-B"
    r"/.claude/skills/esg-monthly-report/scripts"
)
sys.path.insert(0, str(SKILL))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.htmlutil import extract_body  # noqa: E402
from esg_toolkit.parse_news import (  # noqa: E402
    classify_tier,
    published_from_html,
    published_from_url,
)

OUT = Path(__file__).resolve().parent / "verify_out"
OUT.mkdir(exist_ok=True)

CANDIDATES: list[tuple[str, str]] = [
    # ---- 板块一：政策 / 评级 / 标准 ----
    ("国新办发布会·碳市场扩围(经参)", "http://jjckb.xinhuanet.com/20261021/edaecbdc66ba42f3829c4f078deb8d6f/c.html"),
    ("生态环境部·双碳牵引全面绿色转型(新华)", "https://www.cets.org.cn/zjsj/7506.jhtml"),
    ("国新办发布会全文实录(cets)", "https://www.cets.org.cn/xyyw/7504.jhtml"),
    ("碳排放权交易管理暂行条例全文(生态环境部10/11转载)", "http://sthj.shandong.gov.cn/dtxx/hbyw/202610/t20261011_5009365.html"),
    ("证监会13号公告 三项行业标准(新浪10/31)", "https://finance.sina.com.cn/roll/2026-10-31/doc-inixakvf4137805.shtml"),
    ("上市公司可持续发展报告电子化规范 JR/T 0356(证监会法规库)", "https://neris.csrc.gov.cn/falvfagui/rdqsHeader/mainbody?secFutrsLawId=d885aab6230c47d7918058280bb5b793"),
    ("资本市场ESG建设从有到优(中国网/新浪10/26)", "https://finance.sina.com.cn/roll/2026-10-26/doc-iniwqart2127162.shtml"),
    ("气候披露标准对标国际 九行业碳账本(上证报/新浪10/27)", "https://finance.sina.com.cn/roll/2026-10-27/doc-iniwqtpi5115236.shtml"),
    ("企业气候账本怎么算(中证网10/12)", "https://www.cs.com.cn/esg/2026/10/12/detail_2026101210043995.html"),
    ("财政部首发电力等9大行业气候披露要求(腾讯10/08)", "https://news.qq.com/rain/a/20261008A0BHPW00"),
    ("生态环境部政策法规简报(腾讯10/16)", "https://news.qq.com/rain/a/20261016A0BG0500"),
    ("合规周讯 可持续披露准则明确2030建成时点", "http://www.csrcare.com/Cultrue/Show?id=4061"),
    ("ESG报告从给人看到给系统用 298项元素(csrcare)", "http://www.csrcare.com/Cultrue/Show?id=4060"),
    ("工信部绿色供应链领航企业 苏州可持续披露试点(中财10/10)", "https://www.cfen.com.cn/cy/cyqygc/202610/t20261010_915646.html"),
    # ---- 板块二：行业动态 ----
    ("国家能源局 煤电与新能源融合实施意见(中国能源网10/23)", "https://www.cei.cn//defaultsite/s/article/2026/10/23/4b4ff607-9d914745-01a1-666609fa-4a76_2026.html?columnId=4028c7ca-39905444-0139-906733da-02b3&referCode=sxp0b"),
    ("国家能源局 答记者问(煤炭工业协会)", "https://www.coalchina.org.cn/index.php?a=show&catid=39&id=163220"),
    ("解读 煤电与新能源融合(新浪/中国电力新闻网10/21)", "https://finance.sina.com.cn/jjxw/2026-10-21/doc-inivyxhf5374585.shtml"),
    ("能源保供中长期合同管理办法 发改委令50号(新浪10/23)", "https://finance.sina.com.cn/esg/2026-10-23/doc-iniwfwak2513423.shtml"),
    ("贵州省煤炭洗选管理办法(试行)(中国能源网10/12)", "https://www.cei.cn/defaultsite/s/article/2026/10/12/4b4ff607-9d914745-01a1-2dd1cf5f-68dd_home.html?referCode=sxn0c"),
    ("云南能源集团绿色矿山 恩洪煤业(云南省国资委10/13)", "https://gzw.yn.gov.cn/xwzx/ssqy/202610/t20261013_4342484.html"),
    ("云南能源集团绿色矿山(四川国资委10/14)", "https://gzw.sc.gov.cn/scsgzw/CU230202/2026/10/14/fda46076eeea4e06b362d0e7ad61a3cb.shtml"),
    ("中国中煤 煤海向绿(中国电力报10/28)", "https://cpnn.com.cn/qiye/fadianPD2023/202610/t20261028_1922850.html"),
    ("国家电投白音华自备电厂完成年度碳履约(中国电力报10/28)", "https://www.cpnn.com.cn/qiye/zggdsPD2023/202610/t20261028_1922846.html"),
    ("申能集团 能源实业+绿色金融(新浪香港10/21)", "https://portal.sina.com.hk/others/sina/2026/10/21/1961786/"),
    ("乌金变绿 转型还在爬坡(10/09)", "https://www.worldmr.net/Law/LawList/Info/2026-10-09/326447.shtml"),
    ("中国自然资源报 优化矿区生态保护修复全程监管机制", "https://www.cgs.gov.cn/ddzt/zgkydh/2026kydh/ywkb2026kydh/202609/t20260910_868235.html"),
    ("生态环境部 CCER 方法学征求意见(检索用)", "https://www.mee.gov.cn/xxgk2018/xxgk/xxgk06/202610/"),
    # ---- 板块三：公司动态与对标企业 ----
    ("中国神华 2026年第三季度报告(上证报10/24)", "https://paper.cnstock.com/html/2026-10/24/content_2280574.htm"),
    ("中国神华 2026年第三季度报告(中国金融信息网)", "https://www.cnfin.com/announ/detail/index.html?id=846101977805&dannoun=lcdetail&announ=lc"),
    ("中国神华 前三季度归母净利444亿(中证网)", "https://lid@stcn.com/article/detail/4241798.html"),
    ("中国神华 董事会决议公告(新浪财经公告)", "https://vip.stock.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12657707"),
    ("中国神华 2026年10月主要运营数据公告(新浪公告)", "https://money.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12705587&stockid=601088"),
    ("中国神华 公司新闻栏目(官网)", "http://www.shenhuachina.cc/zgshww/gsxw/newslist_5.shtml"),
    ("国华投资山东分公司绿证全部售罄(能源报10/30)", "https://www.nybsweb.com/shny/20261030/html/content_20261030002003.htm"),
    ("中国中煤 第七届国企开放日(10/24)", "http://www.cwestc.com/newshtml/2026-10-24/911619.shtml"),
    ("中国神华 2026年第三季度业绩说明会", "https://fxbaogao.com/detail/5830599"),
    ("国家能源局 推动煤电与新能源融合发展(新浪10/21)", "https://finance.sina.com.cn/roll/2026-10-21/doc-inivynsq8026262.shtml"),
]


def main() -> int:
    config = Config.load()
    config.browser_fallback = True
    fetcher = Fetcher(config, use_cache=True)
    records = []
    for label, url in CANDIDATES:
        print(f"→ 抓取：{label}")
        res = fetcher.fetch(url)
        body = ""
        if res.ok and res.html:
            try:
                body = extract_body(res.html)
            except Exception as exc:  # noqa: BLE001
                body = f"[正文抽取失败：{exc}]"
        rec = {
            "label": label,
            "url": url,
            "ok": res.ok,
            "status": res.status,
            "error": res.error,
            "date_from_url": published_from_url(url),
            "date_from_html": published_from_html(res.html) if res.ok else None,
            "tier": classify_tier(url),
            "body_len": len(body),
            "body_head": body[:1500],
        }
        records.append(rec)
        print(
            f"   ok={res.ok} status={res.status} "
            f"date_url={rec['date_from_url']} date_html={rec['date_from_html']} "
            f"len={rec['body_len']}"
        )

    (OUT / "links.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (OUT / "links.txt").open("w", encoding="utf-8") as fh:
        for rec in records:
            fh.write("=" * 100 + "\n")
            fh.write(f"[{rec['label']}]\n{rec['url']}\n")
            fh.write(
                f"ok={rec['ok']} status={rec['status']} tier={rec['tier']} "
                f"date_url={rec['date_from_url']} date_html={rec['date_from_html']}\n"
            )
            if rec["error"]:
                fh.write(f"error={rec['error']}\n")
            fh.write("-" * 60 + "\n")
            fh.write(rec["body_head"] + "\n")
    print(f"\n已写出：{OUT/'links.json'} / {OUT/'links.txt'}")
    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
