#!/usr/bin/env python
"""ESG 月报：第四轮候选来源核验（平朔绿色转型、一手政策原文页）。"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL = Path(
    r"E:/个人/AI学习/AI大模型应用/作业/16-江洋明-第十六周作业/作业二/bench/runs/monthly-p2-B"
    r"/.claude/skills/esg-monthly-report/scripts"
)
sys.path.insert(0, str(SKILL))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.htmlutil import extract_body  # noqa: E402
from esg_toolkit.parse_news import (  # noqa: E402
    classify_tier,
    published_from_html,
    published_from_url,
)

OUT = Path(__file__).resolve().parent / "verify_out4"
OUT.mkdir(exist_ok=True)

CANDIDATES: list[tuple[str, str]] = [
    ("证券日报 乌金变绿 转型还在爬坡(10/08)", "http://www.zqrb.cn/review/jizheguancha/2026-10-08/A1791182139354.html"),
    ("中国经济网 乌金变绿转载(10/08)", "http://m.ce.cn/bwzg/202610/t20261008_3249131.shtml"),
    ("中证网 平朔 乌金之山长出绿色森林(10/08)", "https://www.cs.com.cn/esg/2026/10/08/detail_2026100810043182.html"),
    ("生态环境部 生态环境基准工作方案原文(10/16)", "https://www.mee.gov.cn/ywgz/fgbz/hjjzgl/gzdt/202610/t20261016_1183179.shtml"),
    ("财政部 气候准则应用指南原文(m.mof.gov.cn)", "https://m.mof.gov.cn/czxw/202609/t20260929_3998329.htm"),
    ("神华 ESG动态栏目(官网)", "http://www.shenhuachina.cc/zgshww/hjcsz/qt/esgdt/"),
    ("神华 头条要闻栏目(官网)", "http://www.shenhuachina.cc/zgshww/gsxw/newslist.shtml"),
]


def main() -> int:
    config = Config.load()
    config.browser_fallback = True
    fetcher = Fetcher(config, use_cache=True)
    records = []
    for label, url in CANDIDATES:
        print(f"→ 抓取：{label}")
        res = fetcher.fetch(url)
        body = ""
        if res.ok and res.html:
            try:
                body = extract_body(res.html)
            except Exception as exc:  # noqa: BLE001
                body = f"[正文抽取失败：{exc}]"
        rec = {
            "label": label,
            "url": url,
            "ok": res.ok,
            "status": res.status,
            "error": res.error,
            "date_from_url": published_from_url(url),
            "date_from_html": published_from_html(res.html) if res.ok else None,
            "tier": classify_tier(url),
            "body_len": len(body),
            "body_head": body[:2500],
        }
        records.append(rec)
        print(
            f"   ok={res.ok} status={res.status} "
            f"date_url={rec['date_from_url']} date_html={rec['date_from_html']} "
            f"len={rec['body_len']}"
        )

    (OUT / "links.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (OUT / "links.txt").open("w", encoding="utf-8") as fh:
        for rec in records:
            fh.write("=" * 100 + "\n")
            fh.write(f"[{rec['label']}]\n{rec['url']}\n")
            fh.write(
                f"ok={rec['ok']} status={rec['status']} tier={rec['tier']} "
                f"date_url={rec['date_from_url']} date_html={rec['date_from_html']}\n"
            )
            if rec["error"]:
                fh.write(f"error={rec['error']}\n")
            fh.write("-" * 60 + "\n")
            fh.write(rec["body_head"] + "\n")
    print(f"\n已写出：{OUT/'links.json'} / {OUT/'links.txt'}")
    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
