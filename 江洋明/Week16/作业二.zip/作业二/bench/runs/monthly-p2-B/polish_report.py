#!/usr/bin/env python
"""交付前校对：修正 report.md 中的笔误与措辞。"""

from __future__ import annotations

import io
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

OUT = Path(__file__).resolve().parent / "report.md"

FIXES: list[tuple[str, str]] = [
    # 笔误：法律淘汰退出 → 依法淘汰退出
    (
        "不能按期改造完成的法律淘汰退出",
        "不能按期改造完成的依法淘汰退出",
    ),
    # 原文表述过长且有重复修饰，精简为原意
    (
        "到 2028 年实现重点基础能源、原材料及产业链供应链带动作用明显的中间产品碳足迹国标基本覆盖",
        "到 2028 年实现重点基础能源、原材料及中间产品碳足迹国标基本覆盖",
    ),
    # 标题口语化，改为中性表述
    (
        "标杆 / 基准 / 限期淘汰三档定生死",
        "标杆、基准、限期淘汰三档定门槛",
    ),
    # 「排除清单」实为窗口外事项表，去重说明与之不符
    (
        "同一事件的多家报道只保留一条，优先保留监管/政府原文，其次正文更完整的报道；被排除的同源报道计入下方「排除清单」。",
        "同一事件的多家报道只保留一条，优先保留监管/政府原文，其次正文更完整的报道；同源重复报道不另行计数。",
    ),
    # 贵州办法的适用范围表述更准确
    (
        "贵州办法本身不直接约束客户，但它是本期检索到的第一份省级煤炭洗选专项规章",
        "贵州办法适用于贵州省，对客户不构成直接约束；但它是本期检索到的第一份省级煤炭洗选专项规章",
    ),
]


def main() -> int:
    report = OUT.read_text(encoding="utf-8")
    for old, new in FIXES:
        if old in report:
            report = report.replace(old, new)
            print(f"[已修正] {old[:32]}… → {new[:32]}…")
        else:
            print(f"[未找到，跳过] {old[:32]}…")
    OUT.write_text(report, encoding="utf-8")

    # 复核
    item_re = re.compile(r"^### (\d+)\. ", re.M)
    link_re = re.compile(r"\[([^\]]+)\]\((https?://[^)]+)\)")
    for name, start, end in (
        ("一", "## 一、", "## 二、"),
        ("二", "## 二、", "## 三、"),
        ("三", "## 三、", "## 可落地建议"),
    ):
        b = report.split(start, 1)[1].split(end, 1)[0]
        nums = [int(x) for x in item_re.findall(b)]
        assert nums == list(range(1, len(nums) + 1)), nums
        assert b.count("- **日期**：") == len(nums)
        assert b.count("- **来源**：") == len(nums)
        assert b.count("- **议题 / 影响方向**：") == len(nums)
        assert b.count("**对客户意味着什么**") == len(nums)
        print(f"板块{name}：{len(nums)} 条，日期/来源/议题/影响说明齐全")
    adv = report.split("## 可落地建议", 1)[1].split("## 数据说明与局限", 1)[0]
    print(f"建议条数：{len(re.findall(r'^### 建议 \d+｜', adv, re.M))}")
    print(f"链接实例 {len(link_re.findall(report))} 个")
    print(f"字符数 {len(report)}，行数 {report.count(chr(10)) + 1}")
    print("校对复核全部通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
