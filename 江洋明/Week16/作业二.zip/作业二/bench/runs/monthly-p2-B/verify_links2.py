#!/usr/bin/env python
"""ESG 月报：第二轮候选来源核验（补缺口 + 抓一手原文）。

沿用第一轮的做法：抓原文页 → 抽发布日期 → 抽正文前若干字，
输出 verify_out2/links.json 与 links.txt 供人工逐条确认。
"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL = Path(
    r"E:/个人/AI学习/AI大模型应用/作业/16-江洋明-第十六周作业/作业二/bench/runs/monthly-p2-B"
    r"/.claude/skills/esg-monthly-report/scripts"
)
sys.path.insert(0, str(SKILL))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.htmlutil import extract_body  # noqa: E402
from esg_toolkit.parse_news import (  # noqa: E402
    classify_tier,
    published_from_html,
    published_from_url,
)

OUT = Path(__file__).resolve().parent / "verify_out2"
OUT.mkdir(exist_ok=True)

CANDIDATES: list[tuple[str, str]] = [
    # ---- 发改委令 50 号（能源保供中长期合同）----
    ("发改委令50号原文(政府信息公开平台)", "https://zfxxgk.ndrc.gov.cn/web/iteminfo.jsp?id=20668"),
    ("发改委令50号 答记者问(ndrc.gov.cn)", "https://www.ndrc.gov.cn/xxgk/jd/jd/202610/t20261023_1408366.html"),
    ("发改委令50号 答记者问(gov.cn繁体)", "https://big5.www.gov.cn/gate/big5/www.gov.cn/zhengce/202610/content_7084348.htm"),
    ("中国能源报 软约束变成硬规矩(10/30)", "https://epaper.ceic.com/pad/content/202610/30/content_25010.html"),
    ("央广网 煤电气保供有了新办法(10/27)", "https://finance.cnr.cn/ycbd/20261027/t20261027_527854337.shtml"),
    # ---- 重点产品碳足迹行动方案 ----
    ("市场监管总局 碳足迹行动方案原文", "https://www.samr.gov.cn/xw/zj/art/2026/art_9a87cc1660434645be61321840d8041e.html"),
    ("央视网 碳足迹行动方案(10/30)", "https://big5.cctv.com/gate/big5/jingji.cctv.com/2026/10/30/ARTI35TTCWHCF603C8gzIOTU261030.shtml"),
    ("中国质量新闻网 碳足迹行动方案(10/30)", "https://www.cqn.com.cn/zj/content/2026-10/30/content_9178740.htm"),
    ("中国能源网 碳足迹通知原文", "https://www.cnenergynews.cn/article/4TsR2M1FyPF"),
    ("sac.gov.cn 碳足迹行动方案", "https://www.sac.gov.cn/xw/bzhdt/art/2026/art_51060306b6aa4062a077cbc744de448d.html"),
    # ---- 港交所绿色股权认证 ----
    ("港交所 绿色股权认证 新闻稿(10/20)", "https://www.hkex.com.hk/News/News-Release/2026/261020news"),
    ("港交所 绿色股权认证 新浪(10/20)", "https://finance.sina.com.cn/roll/2026-10-20/doc-inivwitp6462340.shtml"),
    ("港交所 绿色股权 中证网(11/02)", "https://www.cs.com.cn/esg/2026/11/02/detail_2026110210049022.html"),
    # ---- 中国神华三季报业绩说明会 ----
    ("神华 业绩说明会公告(10/22)", "https://vip.stock.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12654391"),
    ("神华 投资者关系活动记录表(新浪公告)", "https://money.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12699554&stockid=601088"),
    ("神华 投资者关系活动记录表(东方财富)", "https://data.eastmoney.com/notices/detail/601088/AN202611101831591711,JUU0JUI4JUFEJUU1JTlCJUJEJUU3JUE1JTlFJUU1JThEJThF.html"),
    ("神华 三季度业绩说明会(发现报告)", "https://www.fxbaogao.com/detail/5830599"),
    ("神华 业绩会要点(北极星11/11)", "https://news.bjx.com.cn/html/20261111/1519809.shtml"),
    # ---- 煤行业与政策补充 ----
    ("生态环境基准工作方案(腾讯10/16)", "https://news.qq.com/rain/a/20261016A0BG0500"),
    ("新质生产力与煤炭 解读(煤炭工业协会10/29)", "https://www.coalchina.org.cn/index.php?a=show&catid=52&id=163273"),
    ("中国神华公司新闻栏目(官网)", "http://www.shenhuachina.cc/zgshww/gsxw/newslist_5.shtml"),
    ("神华三季报(中国金融信息网)", "https://www.cnfin.com/announ/detail/index.html?id=846101977805&dannoun=lcdetail&announ=lc"),
    ("神华 三季报(证券时报10/23)", "https://www.stcn.com/article/detail/4241798.html"),
]


def main() -> int:
    config = Config.load()
    config.browser_fallback = True
    fetcher = Fetcher(config, use_cache=True)
    records = []
    for label, url in CANDIDATES:
        print(f"→ 抓取：{label}")
        res = fetcher.fetch(url)
        body = ""
        if res.ok and res.html:
            try:
                body = extract_body(res.html)
            except Exception as exc:  # noqa: BLE001
                body = f"[正文抽取失败：{exc}]"
        rec = {
            "label": label,
            "url": url,
            "ok": res.ok,
            "status": res.status,
            "error": res.error,
            "date_from_url": published_from_url(url),
            "date_from_html": published_from_html(res.html) if res.ok else None,
            "tier": classify_tier(url),
            "body_len": len(body),
            "body_head": body[:2500],
        }
        records.append(rec)
        print(
            f"   ok={res.ok} status={res.status} "
            f"date_url={rec['date_from_url']} date_html={rec['date_from_html']} "
            f"len={rec['body_len']}"
        )

    (OUT / "links.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (OUT / "links.txt").open("w", encoding="utf-8") as fh:
        for rec in records:
            fh.write("=" * 100 + "\n")
            fh.write(f"[{rec['label']}]\n{rec['url']}\n")
            fh.write(
                f"ok={rec['ok']} status={rec['status']} tier={rec['tier']} "
                f"date_url={rec['date_from_url']} date_html={rec['date_from_html']}\n"
            )
            if rec["error"]:
                fh.write(f"error={rec['error']}\n")
            fh.write("-" * 60 + "\n")
            fh.write(rec["body_head"] + "\n")
    print(f"\n已写出：{OUT/'links.json'} / {OUT/'links.txt'}")
    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
