#!/usr/bin/env python
"""ESG 月报：第五轮 —— 打印指定页面的完整正文，用于核对细节。"""

from __future__ import annotations

import io
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL = Path(
    r"E:/个人/AI学习/AI大模型应用/作业/16-江洋明-第十六周作业/作业二/bench/runs/monthly-p2-B"
    r"/.claude/skills/esg-monthly-report/scripts"
)
sys.path.insert(0, str(SKILL))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.htmlutil import extract_body  # noqa: E402

TARGETS: list[tuple[str, str, int]] = [
    ("神华董事会决议公告", "https://vip.stock.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12657707", 4000),
    ("中煤开放日(中国能源新闻网)", "https://cpnn.com.cn/qiye/fadianPD2023/202610/t20261028_1922850.html", 6000),
    ("碳足迹行动方案解读(北京碳中和学会)", "https://www.bjtzh.org.cn/sy_details182.html", 6000),
    ("碳足迹行动方案全文(我的钢铁网)", "https://news.mysteel.com/a/26110214/FA37550A55AE5588.html", 9000),
]


def main() -> int:
    config = Config.load()
    config.browser_fallback = True
    fetcher = Fetcher(config, use_cache=True)
    for label, url, limit in TARGETS:
        print("=" * 100)
        print(f"[{label}]\n{url}")
        res = fetcher.fetch(url)
        print(f"ok={res.ok} status={res.status} error={res.error}")
        if res.ok and res.html:
            try:
                body = extract_body(res.html)
            except Exception as exc:  # noqa: BLE001
                body = f"[正文抽取失败：{exc}]"
            print(f"len={len(body)}")
            print(body[:limit])
        print()
    fetcher.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
