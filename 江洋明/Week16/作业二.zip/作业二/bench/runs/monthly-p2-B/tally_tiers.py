#!/usr/bin/env python
"""统计报告正文实际引用的主链接的条目数与信源分级分布。"""

from __future__ import annotations

import io
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL = Path(
    r"E:/个人/AI学习/AI大模型应用/作业/16-江洋明-第十六周作业/作业二/bench/runs/monthly-p2-B"
    r"/.claude/skills/esg-monthly-report/scripts"
)
sys.path.insert(0, str(SKILL))

from esg_toolkit.parse_news import classify_tier  # noqa: E402

# (板块, 条目标题, 主链接) —— 与 report.md 正文 23 条一一对应
CITED: list[tuple[str, str, str]] = [
    ("一", "全国碳市场2027扩围、碳价98.11元/吨", "http://jjckb.xinhuanet.com/20261021/edaecbdc66ba42f3829c4f078deb8d6f/c.html"),
    ("一", "重点产品碳足迹标准体系建设行动方案", "https://www.samr.gov.cn/xw/zj/art/2026/art_9a87cc1660434645be61321840d8041e.html"),
    ("一", "上市公司可持续发展报告电子化规范JR/T0356", "https://neris.csrc.gov.cn/falvfagui/rdqsHeader/mainbody?secFutrsLawId=d885aab6230c47d7918058280bb5b793"),
    ("一", "财政部气候准则应用指南及9项行业指南征求意见", "https://kjs.mof.gov.cn/gongzuotongzhi/202609/t20260929_3998329.htm"),
    ("一", "煤电与新能源融合发展的实施意见", "https://finance.sina.com.cn/roll/2026-10-21/doc-inivynsq8026262.shtml"),
    ("一", "港交所绿色股权认证计划", "https://www.hkex.com.hk/News/News-Release/2026/261020news"),
    ("一", "碳排放权交易管理暂行条例修订后全文", "http://sthj.shandong.gov.cn/dtxx/hbyw/202610/t20261011_5009365.html"),
    ("一", "生态环境基准工作方案(2026—2030年)", "https://www.mee.gov.cn/ywgz/fgbz/hjjzgl/gzdt/202610/t20261016_1183179.shtml"),
    ("一", "绿色供应链领航企业赛道与四地可持续披露试点", "https://www.cfen.com.cn/cy/cyqygc/202610/t20261010_915646.html"),
    ("二", "发改委令50号能源保供中长期合同管理办法", "https://zfxxgk.ndrc.gov.cn/web/iteminfo.jsp?id=20668"),
    ("二", "贵州省煤炭洗选管理办法(试行)", "https://www.trs.gov.cn/zwgk/zdlyxxgk/nyzy/202610/t20261009_90970727.html"),
    ("二", "平朔集团绿色化智能化转型", "https://www.cs.com.cn/esg/2026/10/08/detail_2026100810043182.html"),
    ("二", "云南能源集团恩洪煤业入选省级绿色矿山", "https://gzw.yn.gov.cn/xwzx/ssqy/202610/t20261013_4342484.html"),
    ("二", "中国中煤第七届国企开放日", "https://cpnn.com.cn/qiye/fadianPD2023/202610/t20261028_1922850.html"),
    ("二", "国家电投白音华自备电厂完成年度碳履约", "https://www.cpnn.com.cn/qiye/zggdsPD2023/202610/t20261028_1922846.html"),
    ("二", "发展新质生产力的意见与煤炭产业新质生产力", "https://www.coalchina.org.cn/index.php?a=show&catid=52&id=163273"),
    ("三", "中国神华2026年三季报", "https://www.stcn.com/article/detail/4241798.html"),
    ("三", "中国神华三季度业绩说明会", "https://vip.stock.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12654391"),
    ("三", "国华投资山东分公司绿证全部售罄", "https://www.nybsweb.com/shny/20261030/html/content_20261030002003.htm"),
    ("三", "第六届董事会第二十三次会议决议公告", "https://vip.stock.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12657707"),
    ("三", "准能集团诚信案例(官网公司新闻)", "http://www.shenhuachina.cc/zgshww/gsxw/newslist_5.shtml"),
    ("三", "煤化工与铁路三项进展(官网公司新闻)", "http://www.shenhuachina.cc/zgshww/gsxw/newslist_5.shtml"),
    ("三", "申能集团能源实业+绿色金融", "https://portal.sina.com.hk/others/sina/2026/10/21/1961786/"),
]


def main() -> int:
    tiers: dict[str, int] = {}
    per_board: dict[str, dict[str, int]] = {}
    for board, title, url in CITED:
        tier = classify_tier(url)
        tiers[tier] = tiers.get(tier, 0) + 1
        per_board.setdefault(board, {})
        per_board[board][tier] = per_board[board].get(tier, 0) + 1
        print(f"[{board}] {tier}  {title}")
    print(f"\n合计 {len(CITED)} 条")
    print(f"分级分布：{dict(sorted(tiers.items()))}")
    for board, dist in per_board.items():
        print(f"  板块{board}：{dict(sorted(dist.items()))}，共 {sum(dist.values())} 条")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
