#!/usr/bin/env python
"""统一板块一的第 7 条标题格式（编号与标题之间补空格），随后重新自查。"""

from __future__ import annotations

import io
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = Path(__file__).resolve().parent
OUT = BASE / "report.md"

OLD = "### 7.《碳排放权交易管理暂行条例》修订后全文公布"
NEW = "### 7. 《碳排放权交易管理暂行条例》修订后全文公布"

ITEM_RE = re.compile(r"^### (\d+)\. ", re.M)
LINK_RE = re.compile(r"\[([^\]]+)\]\((https?://[^)]+)\)")


def main() -> int:
    report = OUT.read_text(encoding="utf-8")
    if OLD in report:
        report = report.replace(OLD, NEW)
        OUT.write_text(report, encoding="utf-8")
        print(f"已修正标题：{OLD} → {NEW}")
    else:
        print("未找到待修正标题（可能已修正）")

    splits = [
        ("一", "## 一、", "## 二、"),
        ("二", "## 二、", "## 三、"),
        ("三", "## 三、", "## 可落地建议"),
    ]
    blocks = []
    for name, start, end in splits:
        b = report.split(start, 1)[1].split(end, 1)[0]
        nums = [int(x) for x in ITEM_RE.findall(b)]
        blocks.append(nums)
        print(
            f"板块{name}：条目 {len(nums)} 条，编号 {nums} | 日期行 {b.count('- **日期**：')} "
            f"| 来源行 {b.count('- **来源**：')} | 议题行 {b.count('- **议题 / 影响方向**：')} "
            f"| 「对客户意味着什么」{b.count('**对客户意味着什么**')}"
        )
    ok = all(b == list(range(1, len(b) + 1)) for b in blocks)
    print(f"[{'OK' if ok else '异常'}] 各板块编号从 1 连续；正文条目合计 {sum(len(b) for b in blocks)}")

    adv = report.split("## 可落地建议", 1)[1].split("## 数据说明与局限", 1)[0]
    print(f"建议条数：{len(re.findall(r'^### 建议 \d+｜', adv, re.M))}")
    links = LINK_RE.findall(report)
    print(f"可点击链接实例 {len(links)} 个，唯一 URL {len({u for _, u in links})} 个")
    print(f"字符数 {len(report)}，行数 {report.count(chr(10)) + 1}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
