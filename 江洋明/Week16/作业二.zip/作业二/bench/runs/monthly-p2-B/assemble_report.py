#!/usr/bin/env python
"""把三段正文拼接成 report.md，并做交付前自查。"""

from __future__ import annotations

import io
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = Path(__file__).resolve().parent
PARTS = [BASE / "_part1.md", BASE / "_part2.md", BASE / "_part3.md"]
OUT = BASE / "report.md"

ITEM_RE = re.compile(r"^### (\d+)\. ", re.M)
LINK_RE = re.compile(r"\[([^\]]+)\]\((https?://[^)]+)\)")


def main() -> int:
    chunks = []
    for part in PARTS:
        text = part.read_text(encoding="utf-8")
        chunks.append(text.rstrip() + "\n")
    report = "\n".join(chunks)
    OUT.write_text(report, encoding="utf-8")
    for part in PARTS:
        part.unlink()
    print(f"已生成 {OUT}（{len(report)} 字符 / {report.count(chr(10)) + 1} 行）")

    print("\n=== 自查 ===")
    # 1. 板块标题齐全
    for title in (
        "一、ESG 政策、评级与标准动态",
        "二、行业动态与最佳实践",
        "三、公司动态、对标企业行动与建议",
        "数据说明与局限",
        "可落地建议",
    ):
        print(f"[{'OK' if title in report else '缺失'}] {title}")

    # 2. 按板块切分，统计条目数与"来源"行
    splits = [
        ("一", "## 一、", "## 二、"),
        ("二", "## 二、", "## 三、"),
        ("三", "## 三、", "## 可落地建议"),
    ]
    total_items = 0
    for name, start, end in splits:
        block = report.split(start, 1)[1].split(end, 1)[0]
        items = ITEM_RE.findall(block)
        src_lines = block.count("- **来源**：")
        dates = block.count("- **日期**：")
        impact = block.count("- **议题 / 影响方向**：")
        means = block.count("**对客户意味着什么**")
        total_items += len(items)
        print(
            f"板块{name}：条目 {len(items)} 条 | 日期行 {dates} | 来源行 {src_lines} "
            f"| 议题行 {impact} | 「对客户意味着什么」{means}"
        )

    # 3. 建议条数
    adv = report.split("## 可落地建议", 1)[1].split("## 数据说明与局限", 1)[0]
    adv_items = re.findall(r"^### 建议 \d+｜", adv, re.M)
    print(f"建议条数：{len(adv_items)}（要求 3~5 条）")

    # 4. 链接检查：全部为 http(s)，无空链接、无搜索结果页
    links = LINK_RE.findall(report)
    bad = [(t, u) for t, u in links if not u.startswith(("http://", "https://"))]
    print(f"可点击链接总数：{len(links)}，唯一 URL 数：{len({u for _, u in links})}")
    print(f"[{'OK' if not bad else '异常'}] 链接协议检查")
    searchish = [(t, u) for t, u in links if "search?" in u or "baidu.com/s?" in u or "bing.com/search" in u]
    print(f"[{'OK' if not searchish else '异常'}] 无搜索结果页链接（发现 {len(searchish)} 条）")

    # 5. 占位符检查
    for token in ("TODO", "待补", "XXX", "未检索到可核", "{{"):
        n = report.count(token)
        print(f"[{'OK' if n == 0 else '注意'}] 无占位符 '{token}'（出现 {n} 次）")

    # 6. 编号连续性
    nums = [int(x) for x in ITEM_RE.findall(report)]
    blocks = []
    for name, start, end in splits:
        b = report.split(start, 1)[1].split(end, 1)[0]
        blocks.append([int(x) for x in ITEM_RE.findall(b)])
    ok = all(b == list(range(1, len(b) + 1)) for b in blocks)
    print(f"[{'OK' if ok else '异常'}] 各板块条目编号从 1 连续：{blocks}")
    print(f"正文条目合计：{total_items}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
