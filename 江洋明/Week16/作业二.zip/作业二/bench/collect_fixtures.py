#!/usr/bin/env python
"""采集真实招标公告快照 —— 离线评测的输入。

为什么要"快照"而不是每次现抓：

1. **可复现**：公告页面会改版、会下线，评测结果不能随时间漂移；
2. **可对比**：A/B 两臂必须看到**完全一样**的输入，否则测的是网络抖动；
3. **可审阅**：老师可以直接打开 ``bench/fixtures/*.html`` 看解析依据。

流程：按检索式拿到真实公告 URL → 抓页面 → 只保留**能解析出结构化字段**的公告
→ 存成 HTML 快照 + manifest。

用法::

    python bench/collect_fixtures.py --target 30
    python bench/collect_fixtures.py --target 30 --queries 3   # 只跑前 3 组检索式
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime
from pathlib import Path

BENCH_DIR = Path(__file__).resolve().parent
HOME_DIR = BENCH_DIR.parent
sys.path.insert(0, str(HOME_DIR / "scripts"))

from esg_toolkit.config import Config  # noqa: E402
from esg_toolkit.fetch import Fetcher  # noqa: E402
from esg_toolkit.parse_tender import parse_tender_page  # noqa: E402
from esg_toolkit.pipeline import TENDER_QUERIES, search_many  # noqa: E402
from esg_toolkit.providers import build_provider  # noqa: E402
from esg_toolkit.providers.base import SearchUnavailable  # noqa: E402

FIXTURES_DIR = BENCH_DIR / "fixtures"

# 只收这些站点的公告 —— 其它搜索结果（新闻、解读、转载）不是解析对象
ANNOUNCEMENT_HINTS = (
    "ccgp.gov.cn",
    "ccgp-",
    "ggzy.gov.cn",
    "ggzy.",
    "zfcg.",
    "ctbpsp.com",
    "chinabidding.com",
    "bidcenter.com.cn",
    "sthjt",
    "gov.cn",
)


def looks_like_announcement(url: str) -> bool:
    return any(hint in url.lower() for hint in ANNOUNCEMENT_HINTS)


def slugify(url: str) -> str:
    """从 URL 生成一个短且稳定的文件名。"""
    tail = url.rstrip("/").split("/")[-1]
    cleaned = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in tail)
    if len(cleaned) > 48:
        cleaned = cleaned[:48]
    digest = hashlib.sha1(url.encode("utf-8")).hexdigest()[:8]
    return f"{cleaned or 'notice'}_{digest}"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="采集真实招标公告快照")
    parser.add_argument("--target", type=int, default=25, help="目标快照数")
    parser.add_argument("--queries", type=int, default=0, help="只用前 N 组检索式（0 = 全部）")
    parser.add_argument("--count", type=int, default=10, help="每组检索式取回的结果数")
    parser.add_argument("--provider", default="", help="搜索后端")
    args = parser.parse_args(argv)

    config = Config.load()
    if args.provider:
        config.search_provider = args.provider
    config.ensure_dirs()

    FIXTURES_DIR.mkdir(parents=True, exist_ok=True)

    try:
        provider = build_provider(config)
    except SearchUnavailable as exc:
        print(f"搜索后端不可用：{exc}", file=sys.stderr)
        return 2

    queries = TENDER_QUERIES[: args.queries] if args.queries else TENDER_QUERIES
    print(f"搜索后端：{provider.name}，检索式 {len(queries)} 组", file=sys.stderr)

    hits = search_many(provider, queries, count=args.count, log=lambda m: print(m, file=sys.stderr))

    candidates = []
    seen: set[str] = set()
    for hit in hits:
        if not hit.url or not looks_like_announcement(hit.url):
            continue
        if hit.url in seen:
            continue
        seen.add(hit.url)
        candidates.append(hit)

    print(f"候选公告 URL {len(candidates)} 个，开始抓取…", file=sys.stderr)

    fetcher = Fetcher(config)
    manifest: list[dict] = []
    kept = 0

    for hit in candidates:
        if kept >= args.target:
            break
        result = fetcher.fetch(hit.url)
        if not result.ok or not result.html:
            print(f"  ! 抓取失败 {hit.url}：{result.error}", file=sys.stderr)
            continue

        record = parse_tender_page(result.html, hit.url, hit.title)
        if record is None or not record.title:
            print(f"  ! 解析不出标题 {hit.url}", file=sys.stderr)
            continue
        # 至少要有金额或中标单位之一，否则没什么可评测的
        if record.amount_yuan is None and not record.winner:
            print(f"  ! 关键字段缺失 {hit.url}", file=sys.stderr)
            continue

        name = slugify(hit.url)
        html_path = FIXTURES_DIR / f"{name}.html"
        html_path.write_text(result.html, encoding="utf-8")

        manifest.append(
            {
                "file": html_path.name,
                "url": hit.url,
                "title": record.title,
                "fetched_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "sha1": hashlib.sha1(result.html.encode("utf-8")).hexdigest(),
            }
        )
        kept += 1
        print(f"  + {html_path.name}｜{record.title[:50]}", file=sys.stderr)
        time.sleep(0.5)

    manifest_path = FIXTURES_DIR / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"完成：{kept} 个快照 → {FIXTURES_DIR}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
