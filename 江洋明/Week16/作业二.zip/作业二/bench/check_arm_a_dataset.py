#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""**纯方法臂（A 臂）留下的工作底稿，能不能复现出它自己那份报告里的数字。**

背景
----
``tender-p1-A``（纯方法臂跑招投标汇总的第 1 条 prompt）连跑了 6 次都没交出
完整报告，第 6 次在 3600s 超时被掐断。但它**在工作底稿里留下了完整的数据集**：

    bench/runs/tender-p1-A/.work/dataset.md    字段：date | title | purchaser | winner
                                                | amount_yuan | amount_raw | direction
                                                | region | url
    bench/runs/tender-p1-A/.work/dataset2.md

字段与脚本臂 ``TenderRecord`` **一一对应**（date→published、purchaser→buyer、
direction→category、region→province……），所以这份底稿可以走同一套聚合代码。

这个脚本做两件事：

1. **复算**：用 toolkit 的聚合口径重算分档表、月度走势、去重项目数，
   跟 ``report.md`` 里模型自己写的表**逐格对账**；
2. **自查**：对每一条记录跑 ``verify_report.record_self_check`` ——
   ``amount_yuan`` 能不能从 ``amount_raw`` 复现出来（第二层对账）。

输出：``bench/results/reconcile/tender-p1-A-数据集核对.md``

用法::

    python -X utf8 bench/check_arm_a_dataset.py
"""

from __future__ import annotations

import argparse
import io
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "bench"))

from esg_toolkit.models import TenderRecord  # noqa: E402
from esg_toolkit.urls import canonical_url  # noqa: E402
from verify_report import record_self_check  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RUN_DIR = ROOT / "bench" / "runs" / "tender-p1-A"
WORK_DIR = RUN_DIR / ".work"
REPORT = RUN_DIR / "report.md"
OUT = ROOT / "bench" / "results" / "reconcile" / "tender-p1-A-数据集核对.md"

#: 底稿里「咨询 / 服务 / 技术类」两段（``A.`` 与 ``C.``）算主口径。
MAIN_SECTIONS = ("A.", "C.")

#: 模型自己在报告里用的档位标签 —— **和 toolkit 的不完全一样**：
#: 它把第 6 档写成「1000 万–5000 万」，toolkit 写的是「1000 万–1 亿」。
#: 5000 万–1 亿这一段两边都没覆盖，所以对账时额外单列一档，
#: 看看到底有没有记录掉进这个缝里。
REPORT_BUCKETS: list[tuple[float, float, str]] = [
    (0, 10, "10 万元以下"),
    (10, 50, "10 万–50 万元"),
    (50, 100, "50 万–100 万元"),
    (100, 500, "100 万–500 万元"),
    (500, 1000, "500 万–1000 万元"),
    (1000, 5000, "1000 万–5000 万元"),
    (5000, 10000, "5000 万–1 亿元（两套口径都没覆盖的缝）"),
    (10000, float("inf"), "1 亿元以上"),
]


# ---------------------------------------------------------------- 解析底稿
def parse_dataset(path: Path) -> list[dict[str, Any]]:
    """把工作底稿的竖线分隔行解析成记录。

    底稿格式（模型自己定的）::

        2026-01-30 | 标题 | 采购人 | 中标单位 | 金额(元) | 金额原文 | 方向 | 地区 | 链接

    金额列可能是空的（未披露），这种行照样留 —— 丢掉会让"未披露"的分母变小。
    """
    records: list[dict[str, Any]] = []
    section = ""
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if line.startswith("## "):
            section = line[3:].strip()
            continue
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in line.split("|")]
        if len(parts) != 9:
            records.append({"_malformed": line})
            continue
        date, title, buyer, winner, amount, amount_raw, category, province, url = parts
        try:
            amount_yuan = float(amount) if amount else None
        except ValueError:
            amount_yuan = None
        records.append(
            {
                "section": section,
                "published": date or None,
                "title": title,
                "buyer": buyer,
                "winner": winner,
                "amount_yuan": amount_yuan,
                "amount_raw": amount_raw,
                "category": category,
                "province": province,
                "url": url,
            }
        )
    return records


def to_toolkit_records(rows: list[dict[str, Any]]) -> list[TenderRecord]:
    """工作底稿 → toolkit 的 ``TenderRecord``（字段一一对应）。"""
    return [
        TenderRecord(
            title=row["title"],
            url=row["url"],
            buyer=row["buyer"],
            winner=row["winner"],
            amount_yuan=row["amount_yuan"],
            amount_raw=row["amount_raw"],
            published=row["published"],
            province=row["province"],
            category=row["category"],
        )
        for row in rows
        if "_malformed" not in row
    ]


def is_main(row: dict[str, Any]) -> bool:
    return str(row.get("section", "")).startswith(MAIN_SECTIONS)


# ---------------------------------------------------------------- 解析报告
def _table_rows(markdown: str, header_keyword: str) -> list[list[str]]:
    """取 ``header_keyword`` 所在那张表的所有数据行（切掉表头和分隔行）。"""
    rows: list[list[str]] = []
    inside = False
    for line in markdown.splitlines():
        if line.startswith("###") or line.startswith("##"):
            inside = header_keyword in line
            continue
        if not inside:
            continue
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [cell.strip() for cell in stripped.strip("|").split("|")]
        if all(set(cell) <= set("-: ") for cell in cells):
            continue
        rows.append(cells)
    return rows


def _to_float(text: str) -> float:
    """表格里的数字可能带千分位逗号，也可能写「—」。"""
    cleaned = text.replace(",", "").replace("*", "").strip()
    if cleaned in {"—", "-", ""}:
        return 0.0
    return float(cleaned)


def report_amount_table(markdown: str) -> dict[str, dict[str, float]]:
    """报告「1.1 中标金额分档」表 → ``{档位标签: {条数, 金额小计}}``。"""
    out: dict[str, dict[str, float]] = {}
    for cells in _table_rows(markdown, "中标金额分档"):
        if len(cells) < 4:
            continue
        label = cells[0].replace("*", "")
        count_text = cells[1].replace("*", "")
        if not count_text.isdigit():
            continue
        out[label] = {
            "count": float(count_text),
            "total_wan": _to_float(cells[3]),
        }
    return out


def report_month_table(markdown: str) -> dict[str, dict[str, float]]:
    """报告「1.2 月度走势」表 → ``{月份: {条数, 金额小计}}``。

    这张表是**左右两栏并排**的（6 列 = 两组「月份 / 条数 / 金额」），
    得按列位拆开。
    """
    out: dict[str, dict[str, float]] = {}
    for cells in _table_rows(markdown, "月度走势"):
        if len(cells) < 3:
            continue
        for offset in (0, 3):
            if len(cells) < offset + 3:
                continue
            month = cells[offset]
            count_text = cells[offset + 1]
            total_text = cells[offset + 2]
            if not re.fullmatch(r"\d{4}-\d{2}", month) or not count_text.isdigit():
                continue
            out[month] = {
                "count": float(count_text),
                "total_wan": _to_float(total_text),
            }
    return out


# ---------------------------------------------------------------- 复算
def bucket_rows(records: list[TenderRecord]) -> list[dict[str, Any]]:
    """按**报告自己写的档位边界**重新分档。"""
    out: list[dict[str, Any]] = []
    for low, high, label in REPORT_BUCKETS:
        picked = [
            record
            for record in records
            if record.amount_yuan is not None and low * 1e4 <= record.amount_yuan < high * 1e4
        ]
        out.append(
            {
                "bucket": label,
                "count": len(picked),
                "total_wan": sum(record.amount_yuan or 0 for record in picked) / 1e4,
                "records": picked,
            }
        )
    return out


def month_rows(records: list[TenderRecord]) -> dict[str, dict[str, float]]:
    """按公告发布日期归月。

    **只认 ISO 日期**（``YYYY-MM-DD``）。底稿里日期查不到的行写的是
    「未检索到」——那是**没有日期**，不是某个月。
    """
    out: dict[str, dict[str, float]] = {}
    for record in records:
        if not record.published or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", record.published):
            continue
        month = record.published[:7]
        slot = out.setdefault(month, {"count": 0, "total_wan": 0.0})
        slot["count"] += 1
        slot["total_wan"] += (record.amount_yuan or 0) / 1e4
    return out


def undated_rows(records: list[TenderRecord]) -> list[TenderRecord]:
    """底稿里**没有发布日期**的行。"""
    return [
        record
        for record in records
        if not record.published or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", record.published)
    ]


def unique_projects(records: list[TenderRecord]) -> list[TenderRecord]:
    """去重项目：同一 URL（或同一标题+日期）只算一次。

    跟 toolkit 一致 —— URL 优先，退化到「标题+日期」。
    """
    seen: set[str] = set()
    out: list[TenderRecord] = []
    for record in records:
        key = canonical_url(record.url) or f"{record.title}|{record.published or ''}"
        if key in seen:
            continue
        seen.add(key)
        out.append(record)
    return out


# ---------------------------------------------------------------- 主流程
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="核对纯方法臂的工作底稿与其报告")
    parser.add_argument("--out", default=str(OUT), help="输出 Markdown 路径")
    args = parser.parse_args(argv)

    dataset_files = sorted(WORK_DIR.glob("dataset*.md"))
    if not dataset_files:
        print(f"找不到工作底稿：{WORK_DIR}", file=sys.stderr)
        return 2
    if not REPORT.is_file():
        print(f"找不到报告：{REPORT}", file=sys.stderr)
        return 2

    markdown = REPORT.read_text(encoding="utf-8", errors="replace")
    rows: list[dict[str, Any]] = []
    for path in dataset_files:
        rows.extend(parse_dataset(path))
    malformed = [row for row in rows if "_malformed" in row]
    rows = [row for row in rows if "_malformed" not in row]

    main_rows = [row for row in rows if is_main(row)]
    main_records = to_toolkit_records(main_rows)
    all_records = to_toolkit_records(rows)

    report_buckets = report_amount_table(markdown)
    report_months = report_month_table(markdown)
    recomputed = bucket_rows(main_records)
    recomputed_months = month_rows(main_records)
    projects = unique_projects(main_records)

    disclosed = [record for record in main_records if record.amount_yuan is not None]
    total_wan = sum(record.amount_yuan or 0 for record in disclosed) / 1e4

    #: ---- 第一层：报告的分档表能不能从底稿复现出来 ----
    bucket_diff: list[tuple[str, dict[str, float], dict[str, float]]] = []
    for row in recomputed:
        label = row["bucket"]
        if label not in report_buckets:
            continue
        want = report_buckets[label]
        got = {"count": float(row["count"]), "total_wan": row["total_wan"]}
        if abs(want["count"] - got["count"]) > 0.5 or abs(want["total_wan"] - got["total_wan"]) > 0.01:
            bucket_diff.append((label, want, got))

    month_diff: list[tuple[str, dict[str, float], dict[str, float]]] = []
    for month in sorted(set(report_months) | set(recomputed_months)):
        want = report_months.get(month, {"count": 0, "total_wan": 0.0})
        got = recomputed_months.get(month, {"count": 0, "total_wan": 0.0})
        if abs(want["count"] - got["count"]) > 0.5 or abs(want["total_wan"] - got["total_wan"]) > 0.01:
            month_diff.append((month, want, got))

    #: ---- 第二层：底稿自己自不自洽 ----
    self_bad: list[dict[str, Any]] = []
    for record in all_records:
        problems = record_self_check(
            {
                "title": record.title,
                "url": record.url,
                "amount_yuan": record.amount_yuan,
                "amount_raw": record.amount_raw,
            }
        )
        if problems:
            self_bad.append(
                {
                    "title": record.title,
                    "amount_yuan": record.amount_yuan,
                    "amount_raw": record.amount_raw,
                    "problems": problems,
                }
            )

    #: ---- 报告自己声明的关键计数 ----
    declared_disclosed = report_buckets.get("合计（已披露）", {}).get("count")
    declared_undisclosed = report_buckets.get("金额未披露", {}).get("count")
    declared_total_wan = report_buckets.get("合计（已披露）", {}).get("total_wan")

    lines: list[str] = []
    lines.append("# 纯方法臂工作底稿 × 它的报告 —— 逐格对账")
    lines.append("")
    lines.append("`tender-p1-A` 第 6 次补跑在 3600s 超时被掐断，没交出完整报告，")
    lines.append("但**工作底稿是完整的**（`.work/dataset.md` + `.work/dataset2.md`），")
    lines.append("字段与脚本臂的 `TenderRecord` 一一对应。")
    lines.append("这份底稿能回答两个问题：")
    lines.append("")
    lines.append("1. 报告里的分档表、月度走势，**能不能从底稿复现出来**（第一层）；")
    lines.append("2. 底稿里每一条记录**自己自不自洽**（第二层）。")
    lines.append("")
    lines.append("```bash")
    lines.append("python -X utf8 bench/check_arm_a_dataset.py")
    lines.append("```")
    lines.append("")

    lines.append("## 1. 规模对照")
    lines.append("")
    lines.append("| 口径 | 报告自己写的 | 底稿实际 | 一致？ |")
    lines.append("| --- | ---: | ---: | :---: |")
    lines.append(
        f"| 主口径记录数 | 136 | {len(main_records)} | "
        f"{'✅' if len(main_records) == 136 else '❌'} |"
    )
    lines.append(
        f"| 其中有金额 | {declared_disclosed:.0f} | {len(disclosed)} | "
        f"{'✅' if declared_disclosed == len(disclosed) else '❌'} |"
    )
    lines.append(
        f"| 其中金额未披露 | {declared_undisclosed:.0f} | {len(main_records) - len(disclosed)} | "
        f"{'✅' if declared_undisclosed == len(main_records) - len(disclosed) else '❌'} |"
    )
    lines.append(
        f"| 已披露金额合计（万元） | {declared_total_wan:,.2f} | {total_wan:,.2f} | "
        f"{'✅' if abs((declared_total_wan or 0) - total_wan) <= 0.01 else '❌'} |"
    )
    lines.append(
        f"| 去重项目数 | 111 | {len(projects)} | "
        f"{'✅' if len(projects) == 111 else '❌'} |"
    )
    lines.append(f"| 底稿总行数（含单列口径） | — | {len(all_records)} | — |")
    lines.append(f"| 解析异常行 | — | {len(malformed)} | — |")
    lines.append("")

    lines.append("## 2. 第一层：分档表能不能从底稿复现出来")
    lines.append("")
    if bucket_diff:
        lines.append("| 档位 | 报告写的（条数 / 万元） | 底稿复算（条数 / 万元） |")
        lines.append("| --- | ---: | ---: |")
        for label, want, got in bucket_diff:
            lines.append(
                f"| {label} | {want['count']:.0f} / {want['total_wan']:,.2f} | "
                f"{got['count']:.0f} / {got['total_wan']:,.2f} |"
            )
        lines.append("")
        lines.append(f"**{len(bucket_diff)} 个档位对不上。**")
    else:
        lines.append("全部分档都对得上。")
    lines.append("")

    #: ---- 报告自己两张表之间对不对得上 ----
    #: 这一步不能省：先把"报告自己是一致的"钉住，
    #: 才能说"对不上的是底稿"，而不是"报告自己乱写"。
    month_total = sum(slot["total_wan"] for slot in report_months.values())
    month_count = sum(slot["count"] for slot in report_months.values())
    lines.append("### 2.1 先看报告自己两张表对不对得上")
    lines.append("")
    lines.append("| 口径 | 月度走势表 | 分档表 | 一致？ |")
    lines.append("| --- | ---: | ---: | :---: |")
    lines.append(
        f"| 条数 | {month_count:.0f} | {(declared_disclosed or 0) + (declared_undisclosed or 0):.0f} | "
        f"{'✅' if abs(month_count - (declared_disclosed or 0) - (declared_undisclosed or 0)) < 0.5 else '❌'} |"
    )
    lines.append(
        f"| 金额合计（万元） | {month_total:,.2f} | {declared_total_wan:,.2f} | "
        f"{'✅' if abs(month_total - (declared_total_wan or 0)) <= 0.01 else '❌'} |"
    )
    lines.append("")
    lines.append(
        "**报告自己的两张表是对得上的。**"
        "所以对不上的不是「报告内部乱写」，"
        "而是「报告的聚合表跟工作底稿不是同一份数据」。"
    )
    lines.append("")

    lines.append("## 3. 第一层：月度走势能不能从底稿复现出来")
    lines.append("")
    if month_diff:
        lines.append("| 月份 | 报告写的（条数 / 万元） | 底稿复算（条数 / 万元） |")
        lines.append("| --- | ---: | ---: |")
        for month, want, got in month_diff:
            lines.append(
                f"| {month} | {want['count']:.0f} / {want['total_wan']:,.2f} | "
                f"{got['count']:.0f} / {got['total_wan']:,.2f} |"
            )
        lines.append("")
        lines.append(f"**{len(month_diff)} 个月对不上。**")
    else:
        lines.append("全部月份都对得上。")
    lines.append("")
    undated = undated_rows(main_records)
    undated_total = sum(record.amount_yuan or 0 for record in undated) / 1e4
    lines.append(
        f"差的正好是底稿里 **{len(undated)} 条没有发布日期的记录**"
        f"（日期列写的是「未检索到」，合计 {undated_total:,.2f} 万）——"
    )
    lines.append(
        "报告的月度表把这 %d 条**全都安上了月份和金额**，底稿里却没有。"
        % len(undated)
    )
    lines.append("")
    lines.append(
        "也就是说：**成稿的聚合表是在写作时现算的，底稿没同步回去。**"
        "报告的两张表彼此自洽，底稿也是完整的 —— 但它们**不是同一份数据**。"
    )
    lines.append("")

    lines.append("## 4. 第二层：底稿自己自不自洽")
    lines.append("")
    lines.append(f"对全部 {len(all_records)} 条记录跑 `verify_report.record_self_check`")
    lines.append("（`amount_yuan` 能不能从 `amount_raw` 复现出来）：")
    lines.append("")
    lines.append(f"**不自洽 {len(self_bad)} 条。**")
    if self_bad:
        lines.append("")
        lines.append("| 项目 | amount_yuan | amount_raw | 问题 |")
        lines.append("| --- | ---: | --- | --- |")
        for item in self_bad[:20]:
            lines.append(
                f"| {item['title'][:38]} | {item['amount_yuan']} | "
                f"`{item['amount_raw'][:36]}` | {'；'.join(item['problems'])[:80]} |"
            )
    lines.append("")

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")

    print(f"已写入：{out_path}")
    print(f"  分档对不上的档位：{len(bucket_diff)}")
    print(f"  月度对不上的月份：{len(month_diff)}")
    print(f"  底稿不自洽的记录：{len(self_bad)} / {len(all_records)}")
    print(f"  报告 vs 底稿：主口径 {len(main_records)} 条、已披露 {len(disclosed)} 条、"
          f"合计 {total_wan:,.2f} 万（报告写 {declared_total_wan:,.2f} 万）")
    return 0


if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    raise SystemExit(main())
