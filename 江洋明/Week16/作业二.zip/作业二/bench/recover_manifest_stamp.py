"""一次性排查脚本：从方法层指纹反推 manifest.json 原来的 generated_at。

背景：``bench/run_ab.py`` 的 ``method_fingerprint()`` 把
``作业一/skills/`` 下**所有文件**（含 ``manifest.json``）的内容哈希进指纹。
而 ``manifest.json`` 里有一个 ``generated_at`` 时间戳 —— 重跑一次
``scripts/build_skills.py``，方法层内容一字没改，指纹却变了。

本脚本按时间戳逐秒枚举，反推能算出已记录指纹（63e2db58898a）的那一秒。
用它恢复原样的 manifest.json，让指纹与结果文件重新对得上。
"""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT.parent / "作业一" / "skills"
TARGET = "63e2db58898a"
ARM = "method"


def manifest_bytes(stamp: str) -> bytes:
    payload = {
        "generated_at": stamp,
        "source": "作业二/scripts/esg_toolkit",
        "arm": ARM,
        "skills": ["esg-monthly-report", "esg-tender-monitor"],
    }
    return (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main() -> int:
    paths = [
        p
        for p in sorted(SKILLS.rglob("*"))
        if not p.is_dir() and "__pycache__" not in p.parts
    ]
    if paths[-1].name != "manifest.json":
        print("manifest.json 不是最后一个，枚举法不适用")
        return 2

    base = hashlib.sha256()
    for path in paths[:-1]:
        base.update(str(path.relative_to(SKILLS)).encode("utf-8"))
        base.update(path.read_bytes())
    rel = str(paths[-1].relative_to(SKILLS)).encode("utf-8")

    start = datetime(2026, 11, 1, 0, 0, 0)
    end = datetime(2026, 11, 27, 16, 30, 0)
    hits: list[str] = []
    moment = start
    while moment <= end:
        stamp = moment.strftime("%Y-%m-%d %H:%M:%S")
        digest = base.copy()
        digest.update(rel)
        digest.update(manifest_bytes(stamp))
        if digest.hexdigest()[:12] == TARGET:
            hits.append(stamp)
        moment += timedelta(seconds=1)

    print(f"命中：{hits}")
    return 0 if hits else 1


if __name__ == "__main__":
    raise SystemExit(main())
