#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""A/B 跑批 —— 作业二的核心实验。

对比的是**两条臂**：

===========  ==================================================  ======================
臂            Skill                                               抽取与聚合由谁做
===========  ==================================================  ======================
A（作业一）    纯方法 Skill，**没有 scripts/**                       模型自己读、自己算
B（作业二）    同一方法 + 确定性脚本层                               脚本抽、脚本算
===========  ==================================================  ======================

两臂的 SKILL.md **逐字相同**（作业二那份只是在末尾注入「确定性脚本层」一节），
搜索后端也**是同一个**（``claude -p`` 自带的 WebSearch）。所以实验里唯一变化的
变量是"抽取与聚合由谁完成"，结论才站得住。

跑批规模：2 案例 × 3 个测试 prompt × 2 臂 = **12 次真实运行**，
外加 6 轮**盲评**（主观指标：结构 / 洞见 / 建议可执行性）。

盲评怎么做：把同一次任务的两份报告**打乱顺序**、抹掉来源标识，交给一个
不知道哪份是哪臂的评委打分。顺序由固定种子决定 —— 可复现，但不会总是"A 在前"。

用法::

    python bench/run_ab.py                 # 跑全量 12 次
    python bench/run_ab.py --cases monthly # 只跑月报
    python bench/run_ab.py --dry-run       # 只打印将要跑什么
    python bench/run_ab.py --judge-only    # 只重跑盲评（复用已有报告）

产物::

    bench/runs/<run_id>/report.txt     两臂的原始报告
    bench/runs/<run_id>/meta.json      用量、耗时、评分
    bench/results/ab-results.json      汇总
    bench/results/ab-report.md         人能读的对比报告
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

BENCH_DIR = Path(__file__).resolve().parent
ROOT = BENCH_DIR.parent
sys.path.insert(0, str(ROOT / "scripts"))

from esg_toolkit.llm import extract_json_object  # noqa: E402
from esg_toolkit.parse_news import previous_month_window  # noqa: E402
from esg_toolkit.providers.claude_cli import (  # noqa: E402
    extract_envelope,
    resolve_cli,
)

METHOD_SKILLS_DIR = ROOT.parent / "作业一" / "skills"
ENHANCED_SKILLS_DIR = ROOT / "skills"
RUNS_DIR = BENCH_DIR / "runs"
RESULTS_DIR = BENCH_DIR / "results"
GROUND_TRUTH = BENCH_DIR / "ground_truth.json"

#: 单次运行的花费上限（美元）。跑偏了就停，别把配额烧光。
#: 注意这个数字是 Claude Code 按 **Claude 定价**对 token 做的本地估算，
#: 而实际走的可能是别家兼容端点（见 ANTHROPIC_BASE_URL）。
#: 之前设 3.0 时两次真实运行都恰好在这个数上被截断、报告没写完 ——
#: 截断出来的空报告没法评分，等于白跑，所以给够。
#:
#: 后来又调回 10.0 试过一轮，**纯方法臂在招投标案例上撞了这个上限**：
#: 检索"近 2 年"的招标公告要翻很多页，模型自己读、自己记，token 消耗远高于
#: 脚本臂（脚本层用固定检索式 + 结构化抽取，模型只看已经归一好的数据）。
#: 撞上限 = 报告没写完 = 这一格是空的，不是"这一臂效果差"。
#: 上限是**安全网**，不该是**约束**——给到两臂都用不完的量，
#: 真实花费照实记进结果里（"成本"那一栏本来就是实验要测的东西）。
MAX_BUDGET_USD = 25.0
#: 单次运行超时（秒）。脚本臂要跑一整套检索 + 抓取，留够时间。
RUN_TIMEOUT = 3600
#: **单次响应**的输出 token 上限（Claude Code 默认 32000）。
#:
#: 纯方法臂习惯把整份报告一次写完 —— 近 2 年的招投标汇总有好几百条，
#: 一次响应写不完就会撞上限（实测报
#: ``API Error: Claude's response exceeded the 32000 output token maximum``）。
#: 抬到 64k 是为了不让**平台配置**把某一臂判成失败；
#: 方法层同时也补了"长报告分段写"的规矩，两边都兜住。
MAX_OUTPUT_TOKENS = 64000
#: 盲评超时（秒）。一次盲评要把两份报告都读完再打分，比单次运行慢不了太多。
JUDGE_TIMEOUT = 600
#: 盲评输出解析不出来时的重试次数。
#:
#: 实测踩过：模型写的 ``reason`` 太长，输出被截断在 JSON 中间，整轮作废 ——
#: 6 轮里丢 1 轮，主观指标就少一个样本。重来一次不亏。
JUDGE_RETRIES = 2


def _run_meta_from_disk(run_dir: Path) -> dict[str, Any]:
    """读回 ``run_meta.json`` —— 这次运行当时用的上限。

    补跑的运行可能跟别的不一样（上限放宽），事后要能一眼看出。
    """
    meta_file = run_dir / "run_meta.json"
    if not meta_file.is_file():
        return {}
    try:
        return json.loads(meta_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


# ---------------------------------------------------------------- 实验定义


@dataclass(frozen=True)
class Arm:
    """一条臂。"""

    key: str
    label: str
    skills_dir: Path
    #: 允许模型使用的工具。两臂的差别就在 Bash —— A 臂压根不给。
    tools: tuple[str, ...]


ARMS: tuple[Arm, ...] = (
    Arm(
        key="A",
        label="A · 纯方法（无脚本）",
        skills_dir=METHOD_SKILLS_DIR,
        # Write 两臂都有：模型被要求把报告写成 report.md，
        # 两臂的产物形态必须一致才好比 —— 能不能写文件不是这次的实验变量，
        # 变量只有「抽取与聚合由谁完成」。
        tools=("WebSearch", "WebFetch", "Read", "Write", "Skill"),
    ),
    Arm(
        key="B",
        label="B · 方法 + 确定性脚本",
        skills_dir=ENHANCED_SKILLS_DIR,
        # 只放行跑脚本需要的那几条命令，不给无限制的 Bash。
        # ``cd`` / ``ls`` 是为了让模型能走进 Skill 目录再跑脚本
        # （脚本的相对路径以 Skill 目录为根）。
        tools=(
            "WebSearch",
            "WebFetch",
            "Read",
            "Write",
            "Skill",
            "Bash(python *)",
            "Bash(cd *)",
            "Bash(ls *)",
        ),
    ),
)


@dataclass(frozen=True)
class Case:
    """一个案例（一组测试 prompt）。"""

    key: str
    title: str
    skill: str
    #: 报告里必须出现的板块标题（用于板块覆盖率）
    required_sections: tuple[str, ...]
    prompts: tuple[str, ...]
    #: 固定时间窗（单元测试用）
    window: tuple[str, str] | None = None
    #: 时间窗**规则**（真实实验用）：``previous_month`` / ``last_2_years``
    #:
    #: 写死日期会随日历失效 —— 跑批跨过零点，"近 2 年"的起点就差一天。
    #: 规则在**跑批当天**求值，口径跟被测对象（模型自己算的窗口）一致。
    window_rule: str = ""


CASES: tuple[Case, ...] = (
    Case(
        key="monthly",
        title="案例一 · ESG 月报",
        skill="esg-monthly-report",
        required_sections=(
            "ESG 政策、评级与标准动态",
            "行业动态与最佳实践",
            "公司动态、对标企业行动与建议",
        ),
        window_rule="previous_month",
        prompts=(
            "请生成中国神华 2026 年 10 月的 ESG 月报。",
            "请生成中国神华的 ESG 月报（上一个自然月），重点关注双碳政策与煤炭行业动态。",
            "给中国神华出一份上个月的 ESG 月报，要包含对标企业的 ESG 关键行动和对客户的建议。",
        ),
    ),
    Case(
        key="tender",
        title="案例二 · ESG 招投标汇总与监控",
        skill="esg-tender-monitor",
        required_sections=("金额分布", "热点招标方向", "中标明细"),
        window_rule="last_2_years",
        prompts=(
            "请汇总近 2 年 ESG / 可持续发展 / 双碳相关的中标情况，"
            "分析热点招标方向与中标金额分布。",
            "汇总近 2 年的双碳与节能改造类中标公告，给我中标金额分布和最热的方向。",
            "做一份 ESG 招投标汇总报告，并说明每天怎么监控新的相关招标。",
        ),
    ),
)


def resolve_window(
    case: Case, today: date | None = None
) -> tuple[str, str] | None:
    """算出这个案例该用的时间窗。

    为什么不写死日期：跑批可能跨过零点，写死的窗口会随日历失效 ——
    "近 2 年"的起点差一天，落在边界上的记录就被误判成"日期越界"。
    规则在**跑批当天**求值，跟被测对象（模型自己算的窗口）口径一致。

    ``last_2_years`` 的起点**对齐到当月 1 号**，跟脚本层
    ``tender_report.py`` 的口径**逐字相同**（它也是 ``date(y-2, m, 1)``）。
    两边不一致不是小事：脚本臂的报告白纸黑字写着「统计区间 2024-11-01 起」，
    评分器却拿 2024-11-27 去判它 —— 拿尺子比人还短，比出来的"越界"是假的。
    对 A 臂同样公平：模型把窗口理解成"往前推 2 年"或"含起始月整月"都合理，
    评分器应当取**较宽**的那一个，只惩罚两边都认的错。

    ``window`` 优先于 ``window_rule``（单元测试用固定窗口）。
    """
    if case.window:
        return case.window

    today = today or date.today()
    if case.window_rule == "previous_month":
        return previous_month_window(today)
    if case.window_rule == "last_2_years":
        start = date(today.year - 2, today.month, 1)
        return start.isoformat(), today.isoformat()
    return None


# ---------------------------------------------------------------- 工具函数


def _norm(text: str) -> str:
    """归一化标题：去空白与常见标点，只留实义字符。"""
    return re.sub(r"[\s（）()【】\[\]、,，.。:：;；\-—_·|/\\\"'“”‘’《》…!！?？]+", "", str(text or ""))


def _is_search_url(url: str) -> bool:
    """搜索引擎结果页不算内容来源 —— 它没有原文。"""
    return any(host in url.lower() for host in ("google.com", "bing.com", "baidu.com", "so.com"))


_URL_RE = re.compile(r"https?://[^\s\)\]<>。，；、！？\"']+")
_MD_LINK_RE = re.compile(r"\[([^\]\n]{2,120})\]\((https?://[^)\s]+)\)")
_ISO_DATE_RE = re.compile(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b")
_SLASH_DATE_RE = re.compile(r"\b(\d{4})/(\d{1,2})/(\d{1,2})\b")
_CN_DATE_RE = re.compile(r"(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日")
#: 费率 / 折扣 —— 不是金额，读成数字就是错的
_RATE_CELL_RE = re.compile(r"%|费率|折扣|下浮|费率%")
_ROW_RE = re.compile(r"^\s*\|(.+)\|\s*$")
#: Markdown 标题行 —— 用来记住"这张表在上面哪一节"
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*\S)\s*$")
#: 跑批目录的命名：``<案例>-p<N>-<臂>``（如 ``tender-p1-A``）。
_RUN_ID_RE = re.compile(r"^[A-Za-z0-9_-]+-p\d+-[AB]$")


#: 报告条目相关性判定用的词表 —— 与脚本层的 ``ESG_STRONG_KEYWORDS`` **不是一回事**。
#: 脚本层那份是"从搜索结果里筛出 ESG 采购"的粗筛，宁严勿宽；
#: 这里判的是"这条报告条目讲的是不是 ESG"，覆盖面可以宽一些，
#: 否则"碳计量监督管理办法"这种条目会被误判成无关。
#: 相关性判定词表 —— **独立于脚本层的过滤词表**。
#:
#: 为什么不能直接拿脚本层的 ``ESG_NEWS_KEYWORDS`` 当尺子：那是**被测对象自己的
#: 分类器**。用它量 B 臂等于"用 B 臂的尺子量 B 臂" —— 脚本层筛进来的条目必然
#: 命中、没筛进来的必然不命中，这个指标就成了同义反复。
#:
#: 这份词表的来源是**方法层自己的两份参考文件**：
#:
#: - ``references/esg-taxonomy.md``（ESG 议题分类法）—— E 面的议题词；
#: - ``references/client-profile.md``（客户档案）—— 煤炭/电力/铁路/煤化工/新能源
#:   五个板块的关键 ESG 议题词。
#:
#: 两份文件**两臂都拿到过**，所以它不是某一臂的私有尺子；
#: 它又是**定义**（"我们关心哪些议题"）而不是分类器（"这条属不属于"），
#: 拿来判相关性不会构成同义反复。
#:
#: 词表覆盖 ESG 的三个面：
#:
#: - **环境 E**：双碳、碳市场、绿色、节能、生态修复……
#: - **社会 S**：安全生产、安全监管、职业健康、社区、乡村振兴、供应链……
#: - **治理 G**：合规、行政处罚、环保督察、ESG 披露、公司治理、标准……
#:
#: 只认「双碳」「绿色」的词表会把煤炭行业最实在的一批 ESG 议题判成无关 ——
#: 「安全生产月」「环保督察通报」「处罚决定书」都是正经 ESG 动态，
#: 却是**治理与社会面**的事，不在"双碳"这个词里。
#:
#: 口径说明（也要写在报告里）：这是**字面相关性**，不是专业相关性。
#: 两臂的行文用词不同（一条写成"保供增产督导"，一条写成"安全生产督导"），
#: 这个指标对**用词**敏感，不能当成"专业相关性"来读。
#: 被判无关的条目会抽样记进结果文件，读者可以自己核。
REPORT_TOPIC_KEYWORDS: tuple[str, ...] = (
    # ---- 环境 E：碳
    "ESG", "双碳", "碳达峰", "碳中和", "碳排放", "碳减排", "碳足迹", "碳计量",
    "碳核算", "碳交易", "碳市场", "碳汇", "碳普惠", "CCER", "温室气体",
    "碳配额", "碳盘查", "碳核查", "碳强度", "碳价", "碳披露", "碳因子",
    "低碳", "零碳", "CCUS", "二氧化碳", "碳捕集", "碳目标", "碳路图", "碳规划",
    # ---- 环境 E：能源与绿色制造
    "可持续", "绿色", "节能", "减排", "生态", "环境保护", "污染防治",
    "新能源", "清洁能源", "能效", "ESG评价", "社会责任", "环境风险",
    "光伏", "风电", "储能", "绿电", "绿证", "氢能", "生物质", "超低排放",
    "合同能源管理", "合同能源", "能源托管", "节能服务", "清洁生产",
    "绿色工厂", "绿色矿山", "绿色制造", "绿色供应链", "循环经济",
    # ---- 社会 S
    "安全生产", "安全监管", "安全责任", "安全隐患", "安全风险", "安全检查",
    "隐患排查", "应急管理", "应急演练", "职业健康", "职业病", "工伤",
    "员工权益", "劳务派遣", "用工", "社区", "乡村振兴", "公益", "慈善",
    "扶贫", "供应链", "供应商", "产品质量", "产品安全", "召回",
    "采煤沉陷", "矿井水", "煤矸石", "智能化开采",
    # ---- 治理 G
    "公司治理", "董事会", "监事会", "股东大会", "内部控制", "合规", "廉政",
    "反腐", "处罚", "约谈", "行政处罚", "整改", "督察", "信息披露",
    "ESG披露", "可持续披露", "披露要求", "审计", "评级", "评级机构",
    "标准", "认证", "白皮书", "环境监测", "排污", "节能改造",
)

#: 纯标签行：只有「议题」「影响方向」这类字段名加一个值。
#:
#: 判定相关性之前必须先剥掉它们 ——
#: 纯方法臂的条目带「**议题**：双碳与碳中和」，脚本臂的条目不带；
#: 不剥掉的话，"写议题"这个排版差异会白送一条关键词命中，
#: 指标就变成了"谁写议题谁加分"，而不是"谁的内容更相关"。
_LABEL_LINE_RE = re.compile(
    r"^\s*(?:[-*+]\s*)?\**\s*(?:议题|影响方向|方向)\s*\**\s*[：:].*$"
)


def strip_label_lines(text: str) -> str:
    """剥掉纯标签行，只留实质内容（标题、日期、来源、要点、所以呢）。"""
    lines = [
        line
        for line in (text or "").splitlines()
        if not _LABEL_LINE_RE.match(line)
    ]
    return "\n".join(lines)


def is_report_on_topic(text: str) -> bool:
    """判断一条报告条目是不是在讲 ESG。

    判定前做两件事 —— 理由都写在 :data:`_LABEL_LINE_RE` 与 :data:`_URL_RE` 那里：

    1. 剥掉「议题」「影响方向」这类**标签行**（臂自己打的标签不作数）；
    2. 剥掉 **URL** —— 链接里带 ``green`` / ``ccer`` 这类词很常见，
       那是站点路径，不是内容。
    """
    body = strip_label_lines(text)
    body = _URL_RE.sub(" ", body)
    if not body.strip():
        return False
    return any(word in body for word in REPORT_TOPIC_KEYWORDS)


#: 标题（### 及更深）与列表项 —— 用来切块
_HEADING_RE = re.compile(r"^(#{2,6})\s+(.*)$")
_ITEM_RE = re.compile(r"^\s*(?:[-*+]|\d+[.、])\s+(.*)$")


def extract_blocks(text: str) -> list[tuple[str, str]]:
    """把报告切成**逻辑条目**，返回 ``(标题, 整块正文)``。

    为什么必须切块：一条新闻在报告里是好几行。按行统计时，
    "来源"那一行既没有日期也没有 ESG 关键词，整条好内容会被判成"无关"
    —— 实测无关率虚高到 84%，指标直接失真。

    切块规则：

    - ``##`` 是**板块**，块在它这里断开；
    - ``###`` 及更深是**条目**的起点，它下面的列表项算这条目的一部分；
    - 板块里没有小标题时，列表项各自算一条。
    """
    blocks: list[tuple[str, str]] = []
    title = ""
    buf: list[str] = []
    in_item = False

    def flush() -> None:
        nonlocal title, buf
        body = "\n".join(buf).strip()
        if body:
            blocks.append((title, body))
        title = ""
        buf = []

    for raw_line in (text or "").splitlines():
        line = raw_line.rstrip()

        heading = _HEADING_RE.match(line)
        if heading:
            flush()
            if len(heading.group(1)) >= 3:
                title = heading.group(2).strip()
                buf = [line]
                in_item = True
            else:
                in_item = False
            continue

        if in_item:
            buf.append(line)
            continue

        item = _ITEM_RE.match(line)
        if item:
            flush()
            title = item.group(1).strip()
            buf = [line]
            continue

        if line.strip():
            buf.append(line)

    flush()
    return blocks


def extract_entries(text: str) -> list[tuple[str, str]]:
    """所有 Markdown 链接，**按出现顺序不去重** —— 条目级统计用。

    同一份公告在报告里出现两次，本身就是质量缺陷，所以条目统计必须
    保留重复项（``extract_links`` 会去重，那是给链接探测用的）。
    """
    entries: list[tuple[str, str]] = []
    for title, url in _MD_LINK_RE.findall(text or ""):
        url = url.rstrip(".,;")
        if _is_search_url(url):
            continue
        entries.append((title.strip(), url))
    return entries


def extract_links(text: str) -> list[tuple[str, str]]:
    """抽出 Markdown 里的 ``(标题, 链接)``，**按 URL 去重** —— 探测链接可用性用。"""
    pairs: list[tuple[str, str]] = []
    seen: set[str] = set()
    for title, url in _MD_LINK_RE.findall(text or ""):
        url = url.rstrip(".,;")
        if url in seen or _is_search_url(url):
            continue
        seen.add(url)
        pairs.append((title.strip(), url))
    for url in _URL_RE.findall(text or ""):
        url = url.rstrip(".,;")
        if url in seen or _is_search_url(url):
            continue
        seen.add(url)
        pairs.append(("", url))
    return pairs


def extract_dates(text: str) -> list[str]:
    """抽出所有能识别的日期，归一成 ISO。"""
    dates: list[str] = []
    for year, month, day in _ISO_DATE_RE.findall(text or ""):
        dates.append(f"{int(year):04d}-{int(month):02d}-{int(day):02d}")
    for year, month, day in _SLASH_DATE_RE.findall(text or ""):
        dates.append(f"{int(year):04d}-{int(month):02d}-{int(day):02d}")
    for year, month, day in _CN_DATE_RE.findall(text or ""):
        dates.append(f"{int(year):04d}-{int(month):02d}-{int(day):02d}")
    return dates


#: 明细表表头的特征列 —— 用来在一堆表里认出"哪张才是明细表"。
#:
#: 一份招投标报告里往往有十几张表：金额分档表、指标表、月度走势表、
#: 热点方向表、地区分布表……还有真正的**中标明细表**。
#: 只认这些词，是因为分布表的表头是"金额档 / 记录数 / 占全部记录"这种
#: 统计口径，跟明细表的"发布日期 / 项目名称 / 中标单位"完全不是一回事。
_DETAIL_HEADER_HINTS = (
    "发布日期", "日期", "项目", "名称", "标题", "采购人", "中标单位", "中标人",
    "供应商", "金额", "方向", "地区", "来源", "议题", "要点", "链接", "内容", "摘要",
)


#: 明细表表头的特征列 —— 用来在一堆表里认出"哪张才是明细表"。
#:
#: 一份招投标报告里往往有十几张表：金额分档表、指标表、月度走势表、
#: 热点方向表、地区分布表……还有真正的**中标明细表**。
#: 只认这些词，是因为分布表的表头是"金额档 / 记录数 / 占全部记录"这种
#: 统计口径，跟明细表的"发布日期 / 项目名称 / 中标单位"完全不是一回事。
_DETAIL_HEADER_HINTS = (
    "发布日期", "日期", "项目", "名称", "标题", "采购人", "中标单位", "中标人",
    "供应商", "金额", "方向", "地区", "来源", "议题", "要点", "链接", "内容", "摘要",
)

#: 明细表**必须**具备的三类列 —— 缺任何一类都不可能是中标明细表。
#:
#: 为什么要这么严：月报里也会有表格（评级对照表：机构 / 评级与关键分项 /
#: 评级日期 / 来源），它有"日期"也有"来源"，光看这两个词就会被误认成
#: 明细表 —— 误认的后果是整份月报被当成"表形态报告"统计，
#: 条目数从 30 多掉到 4，所有指标一起废掉（实测踩过）。
#: 中标明细表的身份特征是**有项目名、有金额、有发布日期**，三者齐全。
_DETAIL_REQUIRED_HINTS: tuple[tuple[str, ...], ...] = (
    ("项目", "名称", "标题"),  # 项目名称
    ("金额", "预算"),  # 金额
    ("日期", "时间", "发布"),  # 发布日期
)

#: 小节标题里出现这些词，说明下面放的是**中标明细**。
#:
#: 方法层规定招投标报告的明细表放在「中标明细」一节；
#: 实测三种写法都有：「三、中标明细」「三、中标明细表」「七、中标明细表
#: （185 条，按方向分组）」。
_DETAIL_SECTION_HINTS = ("明细",)

#: **兜底**认表用的最低门槛：有项目名列，且金额列、日期列至少有一个。
#:
#: 比三件套松一档，是因为真实公告里"金额未披露"很常见，
#: 明细表不一定有金额列；但"项目名"这一列是少不了的 ——
#: 少了它，月报里的评级对照表（机构 / 评级与关键分项 / 评级日期 / 来源）
#: 会被当成明细表，整份月报被当"表形态报告"统计，
#: 条目数从 30 多掉到 4，所有指标一起废掉（实测踩过）。
_DETAIL_LOOSE_HINTS: tuple[tuple[str, ...], ...] = (
    ("项目", "名称", "标题"),  # 项目名称
    ("金额", "预算"),  # 金额（可缺）
    ("日期", "时间", "发布"),  # 发布日期（可缺）
)


def _split_tables(text: str) -> list[tuple[list[str], list[list[str]], list[str]]]:
    """把报告里的 Markdown 表格按**连续性**切开。

    返回 ``[(表头, 数据行, 所在小节标题栈), ...]``。

    切分规则：**任何非表格行都切断表格**（空行也算 —— Markdown 里空行本来就
    终结一张表），只有分隔行（``| --- | --- |``）例外：它跳过但不断表。

    标题栈是这张表**上面**所有 ``#``/``##``/``###`` 标题（从外到内）。
    拿它是为了认表：明细表可能被拆成多张（按方向分组），
    只有靠"这段小节叫不叫明细"才能把它们认成一组。
    """
    tables: list[tuple[list[str], list[list[str]], list[str]]] = []
    header: list[str] | None = None
    rows: list[list[str]] = []
    #: 当前标题栈：[('##', '三、中标明细'), ('###', '7.1 绿色低碳与节能')]
    heading_stack: list[tuple[str, str]] = []

    def flush() -> None:
        nonlocal header, rows
        if header is not None and rows:
            tables.append((header, rows, [text for _, text in heading_stack]))
        header = None
        rows = []

    for line in (text or "").splitlines():
        heading = _HEADING_RE.match(line)
        if heading:
            flush()
            level = len(heading.group(1))
            title = heading.group(2).strip()
            # 栈里只保留层级比当前标题浅的，再把当前标题压进去
            while heading_stack and len(heading_stack[-1][0]) >= level:
                heading_stack.pop()
            heading_stack.append((heading.group(1), title))
            continue

        match = _ROW_RE.match(line)
        if not match:
            flush()
            continue
        cells = [cell.strip() for cell in match.group(1).split("|")]
        if not cells or all(re.fullmatch(r":?-{2,}:?", cell) for cell in cells):
            continue  # 分隔行，跳过但不断表
        if header is None:
            header = cells
        else:
            rows.append(cells)

    flush()
    return tables


def _is_detail_header(header: list[str]) -> bool:
    """表头是不是中标明细表的表头：项目名 + 金额 + 发布日期，三者齐全。"""
    if len(header) < 3:
        return False
    for group in _DETAIL_REQUIRED_HINTS:
        if not any(any(hint in cell for hint in group) for cell in header):
            return False
    return True


def _looks_like_detail_header(header: list[str]) -> bool:
    """兜底认表：有项目名列，且金额列、日期列至少有一个。"""
    if len(header) < 3:
        return False
    if not any(any(hint in cell for hint in _DETAIL_LOOSE_HINTS[0]) for cell in header):
        return False
    return any(
        any(any(hint in cell for hint in group) for cell in header)
        for group in _DETAIL_LOOSE_HINTS[1:]
    )


def _detail_row_key(record: dict[str, str]) -> str:
    """明细行的去重键：发布日期 + 项目名。"""
    date = ""
    title = ""
    for key, value in record.items():
        if not date and any(hint in key for hint in ("日期", "时间", "发布")):
            date = _norm(value)[:16]
        if not title and any(hint in key for hint in ("项目", "名称", "标题")):
            title = _norm(value)[:80]
    return f"{date}|{title}"


def parse_detail_table(text: str) -> list[dict[str, str]]:
    """解析报告里的**明细表**，返回每行一个字典。

    为什么不能把所有表堆在一起：早先的实现把全文所有表格行拉平成一张表，
    再用**第一张表**的表头去切所有行 —— 一份招投标报告的第一张表是
    「金额分档分布表」，于是明细表的 93 行全被套上了"金额档/记录数/占比"
    这些列名，「影响方向标注率」「关键字段完整率」「金额准确率」全是废数
    （实测：方向标注率 0%，条目数虚高到 166）。

    现在按表格切开，用两个信号认表，**两个都要过**：

    1. 表头三件套齐全（项目名 + 金额 + 发布日期）；
    2. 所在小节标题里有「明细」。

    第 2 条解决的是"明细表被拆成多张"的情况 —— 实测有一份报告按方向
    分组，把 185 条明细拆成了 11 张表，只认一张的话会少算 156 条。
    第 1 条挡住的是"月报里也有表"的情况 —— 评级对照表（机构 / 评级与关键分项 /
    评级日期 / 来源）长得也有日期，不挡会被误当成明细表。

    两条都挡不住时（比如报告没按方法层的章节名写），退回到
    "表头最像明细表且行数最多"的老路 —— 分布表天生只有几行，
    明细表才是报告的主体。
    """
    tables = _split_tables(text)

    # ---- 信号 2：小节标题里有「明细」
    in_detail_section = [
        (header, rows)
        for header, rows, headings in tables
        if any(
            hint in heading
            for heading in headings
            for hint in _DETAIL_SECTION_HINTS
        )
    ]
    detail_tables = [
        (header, rows) for header, rows in in_detail_section if _is_detail_header(header)
    ]
    if detail_tables:
        # 同一小节里的多张表合并 —— 明细表按方向分组时会被拆开。
        # 同一行在多张表里重复出现（典型：先给「金额最大的 10 笔」，
        # 后面再给完整明细）只算一条 —— 重复计入会让条目数虚高。
        merged: list[dict[str, str]] = []
        seen: set[str] = set()
        for header, rows in detail_tables:
            for cells in rows:
                if len(cells) < 4:
                    continue
                record = {
                    header[i] if i < len(header) else f"col{i}": cells[i]
                    for i in range(len(cells))
                }
                key = _detail_row_key(record)
                if key and key in seen:
                    continue
                seen.add(key)
                merged.append(record)
        return merged

    # ---- 兜底：表头像明细表，取行数最多的那张
    candidates: list[tuple[int, int, list[str], list[list[str]]]] = []
    for header, rows, _headings in tables:
        if len(header) < 3 or not rows:
            continue
        if not _looks_like_detail_header(header):
            continue  # 这不是明细表（统计口径表），跳过
        matched = sum(
            1 for cell in header if any(hint in cell for hint in _DETAIL_HEADER_HINTS)
        )
        candidates.append((matched, len(rows), header, rows))

    if not candidates:
        return []

    _, _, header, rows = max(candidates, key=lambda item: (item[0], item[1]))
    records: list[dict[str, str]] = []
    for cells in rows:
        if len(cells) < 4:
            continue
        record = {header[i] if i < len(header) else f"col{i}": cells[i] for i in range(len(cells))}
        records.append(record)
    return records


#: 明细表里算"关键字段"的四组列名。
#: 方法层要求：**项目名 / 中标单位 / 中标金额 / 发布日期**缺一不可；
#: 采购人、方向、地区允许写"未检索到"。
#:
#: 每组是若干个**备选写法**，一个备选是一串必须**全部出现**的词。
#: 为什么不直接用整串子串匹配：真实表头写的是「中标（成交）单位」，
#: 按"中标单位"整串去匹配会一个都配不上，整列被判成缺失 ——
#: 关键字段完整率直接掉到 0%（实测踩过）。
_CORE_FIELDS: tuple[tuple[tuple[str, ...], ...], ...] = (
    (("项目",), ("名称",), ("标题",)),  # 项目名称
    (("中标", "单位"), ("中标", "人"), ("成交", "单位"), ("供应商",)),  # 中标单位
    (("金额",), ("预算",), ("中标额",)),  # 中标金额
    (("日期",), ("时间",), ("发布",)),  # 发布日期
)

#: 空值占位符 —— 写了等于没写。
_EMPTY_CELLS = {"", "—", "-", "未披露", "/", "N/A", "无", "待定", "未知", "未检索到"}


def _record_field(record: dict[str, str], alternatives: tuple[tuple[str, ...], ...]) -> str:
    """从明细表一行里按列名找第一个**有值**的字段，找不到返回空串。

    ``alternatives`` 是若干个备选写法，每个备选是一串必须全部出现在列名里的词。
    """
    for key, value in record.items():
        for tokens in alternatives:
            if all(token in key for token in tokens):
                text = str(value).strip()
                if text and text not in _EMPTY_CELLS:
                    return text
                break
    return ""


#: 明细表里属于**分类标签**的列。判定相关性时不能拿它们当证据：
#: 「方向：合同能源管理」是臂自己打的分类，用它证明"这条是 ESG 相关"，
#: 等于让被测对象给自己作证 —— 和标签行白送关键词是同一个毛病。
_LABEL_COLUMN_HINTS = ("议题", "方向")


def _record_body(record: dict[str, str]) -> str:
    """明细表一行的**实质内容**：去掉分类标签列，拼成一段文本。"""
    return " ".join(
        str(value)
        for key, value in record.items()
        if not any(hint in key for hint in _LABEL_COLUMN_HINTS)
    )


# ---------------------------------------------------------------- 客观评分


#: 标签字段里的占位值 —— 写了等于没写。
_LABEL_PLACEHOLDERS = {"", "—", "-", "未披露", "/", "N/A", "无", "待定", "未知", "不适用"}

#: 条目里的「议题」标签。方法层要求每条动态都标一个最贴近的细分方向。
#: 两臂的写法不一样（``- **议题**：X`` / ``- 议题：X``），中间可能夹着 ``**``，
#: 正则得容得下这些排版差异 —— 否则测的是"谁加了粗体"。
_TOPIC_LABEL_RE = re.compile(r"议题\s*\**\s*[：:]\s*([^\n|｜]{1,40})")
#: 条目里的「影响方向」标签（利好 / 中性 / 风险）。
_DIRECTION_LABEL_RE = re.compile(r"(?:影响方向|方向)\s*\**\s*[：:]\s*([^\n|｜]{1,20})")
#: **合并写法**的标签：``- **议题 / 影响方向**：E·碳市场与碳交易 / 风险``。
#:
#: 为什么要单独认：两个标签挤在一行时，``_TOPIC_LABEL_RE`` 匹配不上
#: （"议题"后面跟的是 " / 影响方向**："，不是冒号），
#: 于是明明标了议题，指标却判成"没标注"（实测踩过：议题标注率 0%）。
#: 合并写法的标签值也是合并的（``X / Y``）：议题取分隔符**前**那段，
#: 方向取**后**那段 —— 只有一段就说明方向没标。
_COMBINED_LABEL_RE = re.compile(
    r"议题\s*[/／|｜]\s*(?:影响方向|方向)\s*\**\s*[：:]\s*([^\n]+)"
)


def _clean_label(value: str) -> str:
    """把标签值洗一遍：去星号、去空白、占位值当空。"""
    value = (value or "").strip().strip("＊*").strip()
    return "" if value in _LABEL_PLACEHOLDERS else value


def _block_label(block: str, kind: str) -> str:
    """从**块**里取标签值（``kind`` 取 ``"议题"`` / ``"方向"``）。"""
    block = block or ""
    combined = _COMBINED_LABEL_RE.search(block)
    if combined:
        parts = [
            part.strip()
            for part in re.split(r"[/／]", combined.group(1).strip())
            if part.strip()
        ]
        if kind == "议题":
            return _clean_label(parts[0]) if parts else ""
        return _clean_label(parts[-1]) if len(parts) >= 2 else ""
    pattern = _TOPIC_LABEL_RE if kind == "议题" else _DIRECTION_LABEL_RE
    match = pattern.search(block)
    return _clean_label(match.group(1)) if match else ""


def _table_label(record: dict[str, str], needle: str) -> str:
    """从**明细表行**里取标签值 —— 按列名找（``方向`` / ``议题``）。"""
    for key, value in record.items():
        if needle in key:
            return _clean_label(str(value))
    return ""


@dataclass
class Score:
    """一次运行的客观指标。"""

    entries: int = 0
    section_coverage: float = 0.0
    missing_sections: list[str] = field(default_factory=list)
    duplicate_ratio: float = 0.0
    offtopic_ratio: float = 0.0
    #: 被判无关的条目标题（抽样，最多 5 条）。
    #: 相关性是**词表匹配**，会误伤；把样本记进结果文件，读者才能自己核。
    offtopic_samples: list[str] = field(default_factory=list)
    date_coverage: float = 0.0
    #: 日期**全部**落在统计窗口之外的条目占比（只统计有日期的条目）。
    #: 没有就查不出这个毛病，所以是 None 而不是 0。
    date_out_of_window_ratio: float | None = None
    link_ok: int = 0
    link_checked: int = 0
    #: 没探测过链接时是 None（不是 0.0）——「没查」和「全挂」不是一回事
    link_valid_ratio: float | None = None
    table_rows: int = 0
    #: 明细表里「项目名 / 中标单位 / 中标金额 / 发布日期」四项齐全的行占比。
    #: 没有明细表（新闻月报形态）时是 None（"不适用"）——
    #: 月报本来就没有"中标字段"，报 0 会被误读成"一条都没抽出来"。
    field_completeness: float | None = None
    amount_checked: int = 0
    amount_correct: int = 0
    #: 一条都没比对过时是 None（"不适用"）——
    #: 月报里根本没有中标金额，比对数是 0；报 0% 会被读成"一条都没抽对"。
    amount_accuracy: float | None = None
    #: 报告里出现了基准里多少条公告 / 基准一共多少条。
    #:
    #: 基准这 32 份是用**脚本层自己的检索式**抓的，所以脚本臂天然占优 ——
    #: 这个指标量的是"脚本层沉淀下来的检索式能不能稳定复现"，
    #: 不是"谁搜得更全"。纯方法臂用的是方法层自己的检索式，
    #: 找到的是另一批公告（不在基准里，金额无法自动核对）。
    gt_covered: int = 0
    gt_total: int = 0
    gt_recall: float | None = None
    #: 条目里带「议题」标注的比例。方法层要求每条动态都标一个细分方向 ——
    #: 脚本层一旦接管渲染，这个字段最容易被悄悄吃掉，所以单独测。
    #: 明细表形态（招投标报告）按设计没有议题列，这种情况是 None（"不适用"）。
    topic_label_ratio: float | None = None
    #: 条目里带「影响方向」标注的比例。
    direction_label_ratio: float | None = None
    #: 「金额分档表」与「明细表」是否自洽（分档能不能由明细复现出来）。
    #:
    #: 聚合表是最容易出错的地方 —— 每行单看都合理，加起来就不对。
    #: 报告里没有分档表时是 None（"不适用"，比如月报形态）。
    bucket_self_consistent: bool | None = None
    #: 分档分布能不能由明细表复现（对应三种金额口径里的某一种）。
    bucket_reproducible: bool | None = None
    #: 复现成功时用的口径（首金额 / 单元格求和 / 单元格最大）。
    bucket_basis: str = ""
    #: 分档表「合计」条数 − 明细表行数。
    bucket_count_diff: int | None = None
    #: 分档表合计金额与明细表合计金额的相对差（取最接近的口径）。
    bucket_amount_diff: float | None = None
    #: 分档表逐档对不上的地方（人可读）。
    bucket_mismatches: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "条目数": self.entries,
            "板块覆盖率": round(self.section_coverage, 4),
            "缺失板块": self.missing_sections,
            "重复条目占比": round(self.duplicate_ratio, 4),
            "无关条目占比": round(self.offtopic_ratio, 4),
            "无关条目抽样": self.offtopic_samples,
            "日期可解析率": round(self.date_coverage, 4),
            "日期越界条目占比": (
                round(self.date_out_of_window_ratio, 4)
                if self.date_out_of_window_ratio is not None
                else "未统计"
            ),
            "链接可用率": (
                round(self.link_valid_ratio, 4)
                if self.link_valid_ratio is not None
                else "未探测"
            ),
            "链接已探测": f"{self.link_ok}/{self.link_checked}",
            "明细表行数": self.table_rows,
            "关键字段完整率": (
                round(self.field_completeness, 4)
                if self.field_completeness is not None
                else "不适用"
            ),
            "金额准确率": (
                round(self.amount_accuracy, 4)
                if self.amount_accuracy is not None
                else "不适用"
            ),
            "金额已比对": f"{self.amount_correct}/{self.amount_checked}",
            "基准公告复现率": (
                round(self.gt_recall, 4) if self.gt_recall is not None else "不适用"
            ),
            "基准公告复现": f"{self.gt_covered}/{self.gt_total}",
            "议题标注率": (
                round(self.topic_label_ratio, 4)
                if self.topic_label_ratio is not None
                else "不适用"
            ),
            "影响方向标注率": (
                round(self.direction_label_ratio, 4)
                if self.direction_label_ratio is not None
                else "不适用"
            ),
            "分档表自洽": (
                "是" if self.bucket_self_consistent else ("否" if self.bucket_self_consistent is False else "不适用")
            ),
            "分档分布可复现": (
                "是" if self.bucket_reproducible else ("否" if self.bucket_reproducible is False else "不适用")
            ),
            "分档复现口径": self.bucket_basis or "—",
            "分档条数差": (
                self.bucket_count_diff if self.bucket_count_diff is not None else "不适用"
            ),
            "分档金额相对差": (
                f"{self.bucket_amount_diff:.4%}"
                if self.bucket_amount_diff is not None
                else "不适用"
            ),
            "分档不一致明细": self.bucket_mismatches[:5],
        }


def score_report(text: str, case: Case, ground_truth: dict[str, dict]) -> Score:
    """给一份报告打客观分。

    全部用**规则**判定，不请模型 —— 客观指标一旦掺进模型判断就不可复现了。
    """
    score = Score()
    body = text or ""

    # ---- 板块覆盖率
    missing = [section for section in case.required_sections if section not in body]
    score.missing_sections = missing
    score.section_coverage = 1 - len(missing) / len(case.required_sections)

    # ---- 条目、重复、无关
    # **统计单位是"条目"，不是"行"。**
    # 报告里一条信息是"标题 + 日期 + 来源 + 议题 + 要点 + 所以呢"好几行；
    # 按行统计时"来源"那一行既没日期也没 ESG 关键词，整条好内容会被判成无关
    # —— 实测无关率虚高到 84%。所以先切块，再对整块判定。
    records = parse_detail_table(body)
    #: 每条目的（议题标注, 影响方向标注）—— 用来测"方法层要求的字段有没有落实"。
    labels: list[tuple[str, str]] = []
    #: 明细表形态按方法层的七列设计，**没有议题列** —— 议题标注率对它不适用。
    topic_applicable = True
    if records:
        # 有明细表 → 表的每一行就是一条（招投标报告的形态）
        entries = [
            (
                next(
                    (
                        value
                        for key, value in record.items()
                        if "项目" in key or "名称" in key
                    ),
                    "",
                ),
                _record_body(record),
            )
            for record in records
        ]
        labels = [
            (_table_label(record, "议题"), _table_label(record, "方向"))
            for record in records
        ]
        topic_applicable = False
    else:
        # 没有明细表 → 含链接的标题块（新闻月报的形态）
        entries = [
            (title, block)
            for title, block in extract_blocks(body)
            if _MD_LINK_RE.search(block)
        ]
        labels = [
            (_block_label(block, "议题"), _block_label(block, "方向"))
            for _, block in entries
        ]

    # ---- 标注落实率：方法层要求每条都带的两个标签，有没有真的带上
    if entries:
        if topic_applicable:
            score.topic_label_ratio = (
                sum(1 for topic, _ in labels if topic) / len(entries)
            )
        score.direction_label_ratio = (
            sum(1 for _, direction in labels if direction) / len(entries)
        )

    score.entries = len(entries)

    # 重复：同一条写两遍本身就是缺陷。条目按出现顺序统计，不去重。
    normalized = [_norm(title) for title, _ in entries if _norm(title)]
    if normalized:
        score.duplicate_ratio = 1 - len(set(normalized)) / len(normalized)

    # 相关性：看**整块正文**，不只看标题
    if entries:
        on_topic = 0
        for title, block in entries:
            if is_report_on_topic(block):
                on_topic += 1
            elif len(score.offtopic_samples) < 5:
                score.offtopic_samples.append(title[:80])
        score.offtopic_ratio = 1 - on_topic / len(entries)

        # 日期可解析率：条目里有没有能认出的日期
        dated = sum(1 for _, block in entries if extract_dates(block))
        score.date_coverage = dated / len(entries)

        # ---- 日期越界：条目的日期是不是全落在统计窗口之外
        #
        # 这是"口径稳不稳"的直接检验。月报讲的是"过去一个月"，
        # 条目却标着 2026-02 的日期 —— 报告的前提就塌了。
        # 只统计**有日期**的条目；一条日期都解析不出来的条目不参与
        # （那是"没查到日期"，不是"日期越界"）。
        window = resolve_window(case)
        if window and dated:
            start, end = window
            out_of_window = 0
            dated_entries = 0
            for _, block in entries:
                dates = extract_dates(block)
                if not dates:
                    continue
                dated_entries += 1
                if not any(start <= date <= end for date in dates):
                    out_of_window += 1
            score.date_out_of_window_ratio = (
                out_of_window / dated_entries if dated_entries else None
            )

    # ---- 明细表与字段完整率
    score.table_rows = len(records)
    if records:
        keys = list(records[0].keys())
        amount_key = next(
            (key for key in keys if "金额" in key),
            None,
        )
        # 「关键字段」的口径：**项目名 / 中标单位 / 中标金额 / 发布日期**，
        # 四项齐全才算这一行完整。
        #
        # 为什么不用"所有列都填"：采购人、地区本来就常是"未检索到" ——
        # 那是**公告本身没披露**，不是抽取失败。拿它扣分等于
        # 用"信息不存在"来惩罚"抽不出来"，指标就歪了。
        filled = 0
        for record in records:
            if all(_record_field(record, needles) for needles in _CORE_FIELDS):
                filled += 1
        score.field_completeness = filled / len(records)

        # ---- 金额准确率：与人工标注基准逐条比对
        if amount_key:
            checked = 0
            correct = 0
            covered: set[str] = set()
            for record in records:
                title = next(
                    (record.get(key, "") for key in keys if "项目" in key or "名称" in key),
                    "",
                )
                entry = _match_ground_truth_entry(title, ground_truth)
                if entry is None:
                    continue
                covered.add(str(entry.get("title", "")))
                actuals = _parse_amount_cell_all(record.get(amount_key, ""), amount_key)
                if not actuals:
                    continue
                checked += 1
                accepted = _accepted_amounts(entry)
                # 一格里可能有多个金额（分包明细）：**逐个都对**，
                # 或者**加起来等于**某个合法取值，都算抽对。
                hit = all(_amount_close(value, accepted) for value in actuals) or _amount_close(
                    sum(actuals), accepted
                )
                if hit:
                    correct += 1
            score.amount_checked = checked
            score.amount_correct = correct
            score.amount_accuracy = correct / checked if checked else None
            # ---- 基准公告复现率：报告里出现了基准里多少条公告
            score.gt_total = len(ground_truth)
            score.gt_covered = len(covered)
            score.gt_recall = (
                score.gt_covered / score.gt_total if score.gt_total else None
            )

    # ---- 分档表与明细表的自洽性
    #
    # 报告里的「金额分档分布」是**聚合表**，是模型（或脚本）自己算的。
    # 聚合表和明细表来自同一份数据，必须能对上 —— 这是纯表 vs 表的校验。
    consistency = bucket_consistency(body, records)
    if consistency["有分档表"]:
        score.bucket_self_consistent = consistency["自洽"]
        score.bucket_reproducible = consistency["分布可复现"]
        score.bucket_basis = consistency["复现口径"] or ""
        score.bucket_count_diff = consistency["条数差"]
        score.bucket_amount_diff = consistency["最小金额相对差"]
        mismatches: list[str] = []
        for entry in consistency["明细"]:
            mismatches.extend(f"[{entry['口径']}] {item}" for item in entry["不一致"])
        score.bucket_mismatches = mismatches

    return score


def _match_ground_truth_entry(title: str, ground_truth: dict[str, dict]) -> dict | None:
    """按归一化标题在人工基准里找到对应的**整条**标注。"""
    key = _norm(title)
    if not key:
        return None
    for entry in ground_truth.values():
        entry_key = _norm(entry.get("title", ""))
        if not entry_key:
            continue
        if entry_key == key or entry_key in key or key in entry_key:
            return entry
    return None


def _match_ground_truth(title: str, ground_truth: dict[str, dict]) -> float | None:
    """按归一化标题在人工基准里找对应的中标金额（元）。"""
    entry = _match_ground_truth_entry(title, ground_truth)
    if entry is None:
        return None
    amount = entry.get("amount_yuan")
    return float(amount) if amount is not None else None


def _accepted_amounts(entry: dict) -> set[float]:
    """这条公告的**哪些金额**算抽对了。

    分包公告下「中标金额」有多个口径：报任一合同包、报公告总额，
    都是原文披露过的真实数字。只认基准里那一个数字，就是在拿
    基准自己的口径挑人（实测踩过：脚本臂报的是公告总额，被判成错）。
    """
    accepted: set[float] = set()
    for key in ("amount_yuan", "amount_yuan_total"):
        value = entry.get(key)
        if value is not None:
            accepted.add(float(value))
    for value in entry.get("packages") or []:
        if value is not None:
            accepted.add(float(value))
    return accepted


def _amount_close(value: float, accepted: set[float]) -> bool:
    """金额是否落在合法取值集合里（相对误差 0.5%）。"""
    return any(abs(value - candidate) < max(1.0, candidate * 0.005) for candidate in accepted)


def _unit_from_header(header: str) -> str:
    """从**表头**里读金额单位。

    为什么必须读表头：真实报告有两种写法 ——
    单元格里带单位（「1200 万元」），或者**单位写在表头**、格子里是纯数字
    （表头「中标金额（万元）」，格子「55.00」）。
    只看格子会把 55 万元读成 55 元，差一万倍 ——
    金额准确率直接掉到 0%（实测踩过：脚本臂 20 条全判错）。
    """
    for unit in ("亿元", "万元", "千元"):
        if unit in (header or ""):
            return unit
    return ""


#: 金额数字（可带千分位）+ **紧跟其后**的单位。
#:
#: 单位必须紧跟：只有「74.6万元」这种才算金额，「包7」里的 7 后面
#: 没有单位 —— 它是标段编号，不是钱（实测踩过：以前取第一个数字，
#: 于是「包7 74.6万元／包8 42万元」被读成 7 元，差着 10 万倍）。
_AMOUNT_TOKEN_RE = re.compile(r"(?P<num>\d[\d,]*(?:\.\d+)?)\s*(?P<unit>亿元|万元|千元|元)?")

#: 金额单位 → 换算成「元」的倍数。
_AMOUNT_SCALE = {"亿元": 1e8, "万元": 1e4, "千元": 1e3, "元": 1.0}


def _parse_amount_cell_all(cell: str, header: str = "") -> list[float]:
    """把一格里的**所有**金额读出来。

    为什么不是一个：真实公告里分包很常见，一格里可能写
    「包7 74.6万元／包8 42万元」，也可能写「22.8万元／60万元」。

    单位判定：

    - 数字后面紧跟单位（万元 / 亿元 / 千元 / 元）→ 就是金额；
    - 数字前面有货币符号（￥ / ¥）→ 单位是元；
    - 整格都没有单位 → 用**表头**的单位（表头写「中标金额（万元）」时，
      格子里的「55.00」是 55 万元，不是 55 元 —— 实测踩过，
      金额准确率直接掉到 0%）。

    整格里只要有带单位的金额，**不带单位的数字就不算金额**（那是标段编号）。
    """
    text = str(cell or "").strip()
    if not text or text in {"—", "-", "未披露", "/", "N/A"}:
        return []
    if _RATE_CELL_RE.search(text):
        return []

    with_unit: list[tuple[float, str]] = []
    bare: list[float] = []
    for match in _AMOUNT_TOKEN_RE.finditer(text):
        try:
            value = float(match.group("num").replace(",", ""))
        except ValueError:
            continue
        unit = match.group("unit") or ""
        if not unit:
            prefix = text[: match.start()].rstrip()
            if prefix and prefix[-1] in "￥¥":
                unit = "元"
        if unit:
            with_unit.append((value, unit))
        else:
            bare.append(value)

    if with_unit:
        return [value * _AMOUNT_SCALE[unit] for value, unit in with_unit]
    if not bare:
        return []
    # 整格没有单位 → 用表头的单位；表头也没写就只能按「元」算。
    unit = _unit_from_header(header) or "元"
    return [value * _AMOUNT_SCALE[unit] for value in bare]


def _parse_amount_cell(cell: str, header: str = "") -> float | None:
    """从明细表的一格里读出**第一个**金额（支持「万元」「亿元」）。

    费率与折扣**不是金额** —— 合同能源管理类项目只给「95.00%」，
    把它读成 95 元就是凭空造数，直接返回 ``None``。
    """
    amounts = _parse_amount_cell_all(cell, header)
    return amounts[0] if amounts else None


# ------------------------------------------------------- 分档表 vs 明细表自洽性


#: 档位标签里的数字 + 单位（「10 万」「1 亿」）。
_BUCKET_NUM_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(亿|万)?")

#: 单元格里的第一个数字 —— 容忍 ``**185**`` 这种加粗写法。
_FIRST_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")

#: 分档表里不是"金额"的列（占比、比例）。
_NOT_AMOUNT_HINTS = ("占比", "比例", "率")

#: 档位标签里的"合计/小计"字样 —— 这行是总计，不是档位。
_TOTAL_LABELS = ("合计", "总计", "小计")

#: 金额对账的相对容差：0.5%。
_BUCKET_REL_TOLERANCE = 0.005


def _parse_bucket_bounds(label: str) -> tuple[float, float] | None:
    """把档位标签解析成 ``(下界, 上界)``，单位统一成**元**。

    认得这几种写法（都是实测报告里出现过的）：

    - ``10 万以下``  → ``(0, 10万)``
    - ``10 万–50 万`` → ``(10万, 50万)``
    - ``1 亿以上``   → ``(1亿, +∞)``

    ``未披露`` / ``合计`` 这类行不是档位，返回 ``None``。
    """
    text = str(label or "").strip().strip("*")
    if not text or "未披露" in text or any(word in text for word in _TOTAL_LABELS):
        return None
    text = text.replace("～", "-").replace("–", "-").replace("—", "-")
    pairs = [
        (float(match.group(1)), match.group(2) or "")
        for match in _BUCKET_NUM_RE.finditer(text)
    ]
    if not pairs:
        return None
    # 单位统一到**元**。
    #
    # 档位标签里单位有两种写法：
    #   「10–50 万」   —— 单位只写在最后一个数后面，两个数共用它；
    #   「1000 万–1 亿」—— 两边各带自己的单位。
    # 两种都要认对，否则会得到「10 元～50 万」或「1000 亿～1 万」这种荒唐区间。
    scale = {"万": 1e4, "亿": 1e8, "": 1.0}
    shared = next((u for _, u in reversed(pairs) if u), "")
    numbers = [value * scale[unit or shared] for value, unit in pairs]
    if "以上" in text:
        return (numbers[0], float("inf"))
    if "以下" in text:
        return (0.0, numbers[0])
    if len(numbers) >= 2:
        return (numbers[0], numbers[1])
    return None


def _first_number(cell: str) -> float | None:
    """取单元格里的第一个数字（``**185**`` → 185.0）。"""
    match = _FIRST_NUM_RE.search(str(cell or ""))
    return float(match.group(0)) if match else None


def parse_bucket_table(text: str) -> dict[str, Any] | None:
    """找出报告里的「金额分档表」。

    认表条件：表头里有「档 / 区间」列，且同时有**条数列**和**金额列**。
    返回 ``{"buckets": [...], "total": {...} | None}``；找不到返回 ``None``。
    """
    for header, rows, _headings in _split_tables(text or ""):
        bucket_key = next(
            (i for i, cell in enumerate(header) if "档" in cell or "区间" in cell), None
        )
        if bucket_key is None:
            continue
        count_key = next(
            (
                i
                for i, cell in enumerate(header)
                if any(hint in cell for hint in ("条数", "记录数", "公告数", "数量"))
            ),
            None,
        )
        amount_key = next(
            (
                i
                for i, cell in enumerate(header)
                if i != bucket_key
                and "金额" in cell
                and not any(hint in cell for hint in _NOT_AMOUNT_HINTS)
            ),
            None,
        )
        if count_key is None or amount_key is None:
            continue

        buckets: list[dict[str, Any]] = []
        total: dict[str, Any] | None = None
        for row in rows:
            if len(row) <= max(bucket_key, count_key, amount_key):
                continue
            label = row[bucket_key].strip().strip("*")
            count = _first_number(row[count_key])
            amounts = _parse_amount_cell_all(row[amount_key], header[amount_key])
            amount = amounts[0] if amounts else None
            if any(word in label for word in _TOTAL_LABELS):
                total = {"label": label, "count": count, "amount": amount}
                continue
            buckets.append(
                {
                    "label": label,
                    "count": int(count) if count is not None else None,
                    "amount": amount,
                    "bounds": _parse_bucket_bounds(label),
                }
            )
        if buckets:
            return {"header": header, "buckets": buckets, "total": total}
    return None


def bucket_consistency(text: str, records: list[dict[str, str]]) -> dict[str, Any]:
    """分档表与明细表是否自洽。

    **为什么要有这个指标**：报告里的「金额分档分布」是一张**聚合表**，
    它是模型（或脚本）自己算出来的。聚合表最容易出的错，
    明细表一点错都看不出来 —— 每行单看都合理，加起来就不对。
    而聚合表和明细表**来自同一份数据**，所以它们必须能对上：
    这是纯客观的表 vs 表校验，不涉及任何模型判断。

    怎么对：报告写了几档、每档几条、每档多少钱，都是**报告自己说的**；
    我们用报告给出的**档位边界**把明细表重新分一次档，
    看能不能复现出同样的（条数, 金额）。

    一格里可能有多个金额（分包公告），分档用哪个数字，报告没写，
    所以三种口径都试一遍：**首金额 / 单元格求和 / 单元格最大**。
    任一口径能复现全部档位，就算自洽。
    """
    result: dict[str, Any] = {
        "有分档表": False,
        "分档条数": None,
        "明细行数": len(records),
        "条数差": None,
        "分档金额合计": None,
        "明细金额合计": {},
        "金额相对差": {},
        "最小金额相对差": None,
        "分布可复现": None,
        "复现口径": None,
        "自洽": None,
        "明细": [],
    }
    table = parse_bucket_table(text or "")
    if table is None:
        return result
    result["有分档表"] = True

    buckets = table["buckets"]
    total = table["total"]

    # ---- 报告自己说的合计
    if total is not None:
        result["分档条数"] = total.get("count")
        result["分档金额合计"] = total.get("amount")
    else:
        # 没有合计行就自己加（各档金额之和、条数之和）
        counts = [b["count"] for b in buckets if b["count"] is not None]
        amounts = [b["amount"] for b in buckets if b["amount"] is not None]
        result["分档条数"] = sum(counts) if counts else None
        result["分档金额合计"] = sum(amounts) if amounts else None
    if result["分档条数"] is not None:
        result["条数差"] = int(result["分档条数"]) - len(records)

    # ---- 明细表按报告的档位边界重新分档
    if not records:
        return result
    keys = list(records[0].keys())
    amount_key = next((key for key in keys if "金额" in key), None)
    if amount_key is None:
        return result

    rows_amounts: list[list[float]] = []
    for record in records:
        rows_amounts.append(_parse_amount_cell_all(record.get(amount_key, ""), amount_key))
    without_amount = sum(1 for values in rows_amounts if not values)

    bases = {
        "首金额": lambda values: values[0],
        "单元格求和": lambda values: sum(values),
        "单元格最大": lambda values: max(values),
    }
    ranged = [b for b in buckets if b["bounds"] is not None]
    undisclosed = next((b for b in buckets if b["bounds"] is None), None)

    for basis_name, pick in bases.items():
        # 按基准分档。金额一律用**元**做内部单位 —— 报告里的档位金额
        # 也是元，两边同一把尺子才能比。
        computed: dict[str, list[float]] = {
            bucket["label"]: [0, 0.0] for bucket in ranged
        }
        total_amount = 0.0
        fell_out = 0
        for values in rows_amounts:
            if not values:
                continue
            value = pick(values)
            total_amount += value
            for bucket in ranged:
                low, high = bucket["bounds"]
                if low <= value < high:
                    computed[bucket["label"]][0] += 1
                    computed[bucket["label"]][1] += value
                    break
            else:
                fell_out += 1
        result["明细金额合计"][basis_name] = total_amount

        # 与报告的合计行对总账
        if result["分档金额合计"]:
            diff = (total_amount - result["分档金额合计"]) / result["分档金额合计"]
            result["金额相对差"][basis_name] = diff

        # 逐档复现
        mismatches: list[str] = []
        for bucket in ranged:
            count, amount = computed[bucket["label"]]
            if bucket["count"] is not None and int(bucket["count"]) != int(count):
                mismatches.append(
                    f"{bucket['label']}：报告 {bucket['count']} 条 / 复现 {int(count)} 条"
                )
            if bucket["amount"] is not None and amount:
                tolerance = max(200.0, abs(bucket["amount"]) * _BUCKET_REL_TOLERANCE)
                if abs(amount - bucket["amount"]) > tolerance:
                    mismatches.append(
                        f"{bucket['label']}：报告 {bucket['amount'] / 1e4:,.2f} 万 / "
                        f"复现 {amount / 1e4:,.2f} 万"
                    )
        if undisclosed is not None and undisclosed["count"] is not None:
            if int(undisclosed["count"]) != without_amount:
                mismatches.append(
                    f"未披露：报告 {undisclosed['count']} 条 / 复现 {without_amount} 条"
                )
        elif without_amount:
            mismatches.append(f"未披露：报告没这一档 / 复现 {without_amount} 条")
        if fell_out:
            mismatches.append(f"{fell_out} 条明细落在报告没写的档位里")

        if not mismatches:
            result["分布可复现"] = True
            result["复现口径"] = basis_name
            break
        result["明细"].append({"口径": basis_name, "不一致": mismatches})

    diffs = [abs(value) for value in result["金额相对差"].values() if value is not None]
    if diffs:
        result["最小金额相对差"] = min(diffs)
    if result["分布可复现"] is None:
        result["分布可复现"] = False

    result["自洽"] = bool(
        result["分布可复现"]
        and result["条数差"] == 0
        and (
            result["最小金额相对差"] is None
            or result["最小金额相对差"] <= _BUCKET_REL_TOLERANCE
        )
    )
    return result


# ---------------------------------------------------------------- 链接探测


def probe_links(urls: list[str], timeout: float = 8.0, workers: int = 8) -> dict[str, bool]:
    """并发探测链接可用性。

    只发 ``GET``（很多站点对 ``HEAD`` 返回 405），带浏览器 UA，
    读一点点就断开 —— 这是**只读**访问，不提交任何表单。
    """
    import urllib.error
    import urllib.request

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
    }

    def probe(url: str) -> tuple[str, bool]:
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                response.read(2048)
                return url, 200 <= response.status < 400
        except urllib.error.HTTPError as exc:
            # 403 常见于政务站点的反爬 —— 记为"可达但被拦"，算有效
            return url, exc.code in (401, 403, 405)
        except Exception:
            return url, False

    results: dict[str, bool] = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(probe, url) for url in urls]
        for future in as_completed(futures):
            url, ok = future.result()
            results[url] = ok
    return results


# ---------------------------------------------------------------- 运行


@dataclass
class RunResult:
    run_id: str
    case: str
    prompt_index: int
    prompt: str
    arm: str
    ok: bool
    error: str = ""
    report_path: str = ""
    elapsed_s: float = 0.0
    usage: dict[str, Any] = field(default_factory=dict)
    score: dict[str, Any] = field(default_factory=dict)
    raw: str = ""
    #: 这次运行当时用的上限（超时 / 预算 / 输出上限），从 ``run_meta.json`` 读回
    run_meta: dict[str, Any] = field(default_factory=dict)


def _usage_from_disk(run_dir: Path) -> dict[str, Any]:
    """从落盘的 ``envelope.json`` 里把用量和耗时捡回来。

    **重评（``--judge-only``）时用得上**：重评只重算指标，不重跑模型，
    但表格里要是有 token / 花费 / 耗时的数字，就不能让它变空 ——
    "没跑"和"跑了但没记录"在报告里长得一模一样。
    """
    envelope_file = run_dir / "envelope.json"
    if not envelope_file.is_file():
        return {}
    try:
        envelope = json.loads(envelope_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

    usage = envelope.get("usage") or {}
    duration_ms = envelope.get("duration_api_ms")
    return {
        "usage": {
            "input_tokens": usage.get("input_tokens"),
            "output_tokens": usage.get("output_tokens"),
            "cache_read_tokens": usage.get("cache_read_input_tokens"),
            "cost_usd": envelope.get("total_cost_usd"),
            "duration_api_ms": duration_ms,
            "subagent_stats": envelope.get("subagent_stats"),
        },
        #: 信封里只有 API 耗时，比墙钟时间短；当量用它，至少量级是真的
        "elapsed_s": round(duration_ms / 1000.0, 1) if isinstance(duration_ms, (int, float)) else 0.0,
    }


def prepare_run_dir(run_id: str, arm: Arm, skill: str) -> Path:
    """建一个临时项目目录，把该臂的 Skill 装进 ``.claude/skills/``。

    这样 ``claude -p`` 会**原生发现**这个 Skill（就像真实使用时一样），
    而不是把 SKILL.md 当普通提示词贴进去 —— 前者才是在测"Skill"。
    """
    run_dir = RUNS_DIR / run_id
    if run_dir.exists():
        shutil.rmtree(run_dir)
    skills_root = run_dir / ".claude" / "skills" / skill
    skills_root.parent.mkdir(parents=True, exist_ok=True)
    source = arm.skills_dir / skill
    if not source.is_dir():
        raise FileNotFoundError(f"找不到 Skill 目录：{source}")
    shutil.copytree(source, skills_root, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def _looks_like_api_error(report: str) -> bool:
    """这份「报告」其实是 API 报错信息吗？

    CLI 撞上限、限流、鉴权失败时，``result`` 里放的是一句报错文本。
    它非空，但拿去评分只会污染结果 —— 必须当成"这次没跑出来"。
    """
    text = str(report or "").strip()
    if not text:
        return False
    head = text[:200]
    return head.startswith("API Error") or head.startswith("Error:") or "已达到 Token Plan 用量上限" in head


def _empty_report_reason(envelope: dict[str, Any], max_budget_usd: float) -> str:
    """报告为空时，给出**可行动**的原因。

    分不清「被预算截断」和「模型自己没写」，后面就只能干看着两个空报告。
    这两种情况的处置完全不同：前者调预算，后者调提示词或 Skill。
    """
    reasons: list[str] = []

    cost = envelope.get("total_cost_usd")
    if isinstance(cost, (int, float)) and max_budget_usd > 0:
        if cost >= max_budget_usd * 0.95:
            reasons.append(
                f"疑似被预算上限截断（花费 ${cost:.2f} / 上限 ${max_budget_usd:.2f}）"
            )

    if envelope.get("is_error"):
        subtype = envelope.get("subtype") or "unknown"
        reasons.append(f"claude 侧报错（subtype={subtype}）")

    result_text = str(envelope.get("result", "") or "").strip()
    if not result_text:
        reasons.append("信封里 result 也是空的")

    if not reasons:
        reasons.append("信封正常但没找到 report.md")
    return "（" + "；".join(reasons) + "）"


def run_skill(
    cli: str,
    arm: Arm,
    case: Case,
    prompt_index: int,
    prompt: str,
    log,
    max_budget_usd: float = MAX_BUDGET_USD,
    timeout: int = RUN_TIMEOUT,
) -> RunResult:
    """跑一次 Skill。"""
    run_id = f"{case.key}-p{prompt_index + 1}-{arm.key}"
    result = RunResult(
        run_id=run_id,
        case=case.key,
        prompt_index=prompt_index,
        prompt=prompt,
        arm=arm.key,
        ok=False,
    )

    try:
        run_dir = prepare_run_dir(run_id, arm, case.skill)
    except FileNotFoundError as exc:
        result.error = str(exc)
        return result

    # 明确要求把报告写成 Markdown 文件 —— 两臂的产物形态一致才好比。
    full_prompt = (
        f"{prompt}\n\n"
        "请使用本项目的 esg 技能完成这个任务，并把**最终报告正文**写到当前目录下的 "
        "`report.md`（Markdown，包含各板块标题、每条的日期与来源链接、末尾的数据说明与局限）。\n"
        "要求：报告里的每一条内容都要有可点击的原始来源链接；"
        "没有把握的内容写「未检索到」，不要编造。"
    )

    cmd = [
        cli,
        "-p",
        full_prompt,
        "--allowedTools",
        ",".join(arm.tools),
        "--permission-mode",
        "dontAsk",
        "--output-format",
        "json",
        "--max-budget-usd",
        str(max_budget_usd),
        "--no-session-persistence",
    ]

    log(f"  ▶ {run_id}：{prompt[:30]}…")
    started = time.monotonic()
    #: 墙钟起点 —— ``monotonic`` 是"过了多久"，不是"几点几分"，
    #: 拿它当地图时间戳会写出 1970-01-02 这种日期（实测踩过）。
    started_at = time.time()
    # 单次响应的输出上限抬到 :data:`MAX_OUTPUT_TOKENS` —— 见那里的说明。
    # 环境变量对**两臂一视同仁**，不改变实验变量。
    env = dict(os.environ)
    env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = str(MAX_OUTPUT_TOKENS)
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            stdin=subprocess.DEVNULL,
            cwd=run_dir,
            env=env,
        )
    except subprocess.TimeoutExpired:
        result.error = f"超时（{timeout}s）"
        result.elapsed_s = time.monotonic() - started
        return result

    result.elapsed_s = time.monotonic() - started

    # 原始输出先落盘 —— 跑挂了要能复盘，不能只剩一句「报告为空」。
    (run_dir / "stdout.log").write_text(proc.stdout or "", encoding="utf-8", newline="\n")
    if proc.stderr:
        (run_dir / "stderr.log").write_text(proc.stderr, encoding="utf-8", newline="\n")

    envelope = extract_envelope(proc.stdout)
    if not envelope:
        result.error = f"未拿到 JSON 信封（rc={proc.returncode}）：{(proc.stderr or '')[:200]}"
        return result
    (run_dir / "envelope.json").write_text(
        json.dumps(envelope, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n"
    )
    # 每次尝试的信封都留一份底 —— 补跑会覆盖 ``envelope.json``，
    # 而「这一条失败过几次、每次花了多少、卡在哪」本身就是结论的一部分。
    # 丢了底稿，就只剩"这条没跑出来"一句，没法复盘。
    attempts_dir = RUNS_DIR.parent / "_attempts"
    attempts_dir.mkdir(parents=True, exist_ok=True)
    (attempts_dir / f"{run_id}-{time.strftime('%Y%m%d-%H%M%S', time.localtime(started_at))}.json").write_text(
        json.dumps(
            {
                "run_id": run_id,
                "arm": arm.key,
                "case": case.key,
                "prompt_index": prompt_index,
                "started_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(started_at)),
                "max_budget_usd": max_budget_usd,
                "timeout_seconds": timeout,
                "terminal_reason": envelope.get("terminal_reason"),
                "subtype": envelope.get("subtype"),
                "total_cost_usd": envelope.get("total_cost_usd"),
                "duration_api_ms": envelope.get("duration_api_ms"),
                "num_turns": envelope.get("num_turns"),
                "result_head": str(envelope.get("result", "") or "")[:200],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
        newline="\n",
    )
    # 把这次运行的**上限**记下来。补跑时上限可能和别的不一样，
    # 结果文件里要能看出"这一条是用什么上限跑的"，
    # 否则事后看到某条超时失败，会分不清是方法不行还是上限卡住了。
    (run_dir / "run_meta.json").write_text(
        json.dumps(
            {
                "run_id": run_id,
                "arm": arm.key,
                "case": case.key,
                "prompt_index": prompt_index,
                "timeout_seconds": timeout,
                "max_budget_usd": max_budget_usd,
                "max_output_tokens": MAX_OUTPUT_TOKENS,
                "started_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(started_at)),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
        newline="\n",
    )
    result.run_meta = {
        "timeout_seconds": timeout,
        "max_budget_usd": max_budget_usd,
        "max_output_tokens": MAX_OUTPUT_TOKENS,
    }

    usage = envelope.get("usage") or {}
    result.usage = {
        "input_tokens": usage.get("input_tokens"),
        "output_tokens": usage.get("output_tokens"),
        "cache_read_tokens": usage.get("cache_read_input_tokens"),
        "cost_usd": envelope.get("total_cost_usd"),
        "duration_api_ms": envelope.get("duration_api_ms"),
        "subagent_stats": envelope.get("subagent_stats"),
    }

    # 报告正文优先取文件（模型被要求写文件），拿不到再退回信封里的 result。
    # 脚本臂可能会把报告写进 Skill 目录（它 ``cd`` 过去跑脚本），所以全目录找一遍。
    report = ""
    candidates = sorted(run_dir.rglob("report.md"))
    for candidate in candidates:
        if candidate.is_file():
            content = candidate.read_text(encoding="utf-8", errors="replace")
            if content.strip():
                report = content
                break
    if not report.strip():
        report = str(envelope.get("result", "") or "")
    result.raw = report
    (run_dir / "report.txt").write_text(report, encoding="utf-8", newline="\n")

    if not report.strip():
        result.error = "报告为空" + _empty_report_reason(envelope, max_budget_usd)
        return result

    # **API 报错不是报告。**
    #
    # CLI 把「API Error: Request rejected (429) …」这种字符串放在 result 里，
    # 它非空 —— 但它不是报告。实测踩过：A 臂 tender-p1 撞上限后，
    # report.txt 里躺着一句 429 报错，评分器把它当成一份 90 字的报告给打了分。
    if _looks_like_api_error(report):
        result.error = f"API 报错（不是报告）：{report.strip()[:120]}"
        return result

    result.ok = True
    log(f"    ✓ {run_id}（{result.elapsed_s:.0f}s，{len(report)} 字）")
    return result


# ---------------------------------------------------------------- 盲评


_JUDGE_PROMPT = """你是资深的 ESG 咨询报告评审。下面是**两份**同一任务产出的报告，
标签是 X 和 Y —— 它们由**两种不同的做法**生成，但哪份是哪做法你不知道，也不需要知道。

请你**只依据报告本身**打分。三个维度各 1-5 分（5 分最好）：

1. `structure` 结构：板块是否齐全、层次清晰、有没有该有的要素（日期、来源链接、数据说明）；
2. `insight` 洞见：有没有说清"所以呢"，还是只复述标题；
3. `actionability` 可执行性：建议/结论是否落到具体动作，而不是正确的废话。

对**链接**，不要自己联网去点，只看报告里有没有给出链接、链接是不是指向原始页面。

===== 报告 X =====
{x}

===== 报告 Y =====
{y}

只输出一个 JSON 对象，格式：
{{"X": {{"structure": 4, "insight": 3, "actionability": 4, "reason": "一句话"}},
 "Y": {{"structure": 3, "insight": 5, "actionability": 2, "reason": "一句话"}}}}

**reason 控制在 60 字以内**，写最关键的一条理由即可，不要复述细节
（输出太长会被截断，整轮评分就废了）。**不要输出 JSON 以外的任何内容。**
"""


def judge_swap(case_key: str, prompt_index: int, len_a: int, len_b: int) -> bool:
    """盲评的报告顺序：返回 True 表示把 B 臂放到 X 位。

    种子必须用**确定性**哈希：Python 内置 ``hash()`` 对字符串默认按
    ``PYTHONHASHSEED`` 随机化，同一份输入换个进程就是另一个顺序 ——
    "可复现"就成了一句空话，盲评结果也没法互相印证。
    """
    seed = f"{case_key}:{prompt_index}:{len_a}:{len_b}".encode("utf-8")
    return hashlib.md5(seed).digest()[0] % 2 == 1


def pairs_to_judge(
    results: list["RunResult"], judge_rows: list[dict[str, Any]]
) -> list[tuple[tuple[str, int], dict[str, "RunResult"]]]:
    """还需要盲评的（案例, prompt）对。

    已经评过的（案例, prompt）对不再重评 —— 复用上一轮结果时**只补没评过的那些**。
    实测踩过：先跑出 5 对评完，后来才补跑出第 6 对，
    全量重评既多花钱又会因为模型抖动让前后两轮的分数对不上。

    只有**两臂都在**的成对运行才评 —— 缺一条臂就没法匿名对比。
    """
    by_case: dict[tuple[str, int], dict[str, "RunResult"]] = {}
    for result in results:
        if result.ok:
            by_case.setdefault((result.case, result.prompt_index), {})[result.arm] = result

    #: **评失败的不算评过** —— 上一轮留下的 error 行要重评，
    #: 否则那一轮的主观分就永远是空的。
    judged = {
        (row.get("case"), row.get("prompt_index"))
        for row in judge_rows
        if not row.get("error")
    }
    return [
        (key, pair)
        for key, pair in sorted(by_case.items())
        if "A" in pair and "B" in pair and key not in judged
    ]


def judge_blind(
    cli: str,
    case: Case,
    report_a: str,
    report_b: str,
    log,
    prompt_index: int = 0,
) -> dict[str, Any]:
    """盲评：打乱顺序 → 打分 → 映射回两臂。

    顺序用固定种子（案例 + prompt 序号）决定，可复现，
    但不会每次都是 A 在前 —— 否则先读的那份会有位置优势。
    """
    swap = judge_swap(case.key, prompt_index, len(report_a), len(report_b))

    x_report, y_report = (report_b, report_a) if swap else (report_a, report_b)
    prompt = _JUDGE_PROMPT.format(x=x_report, y=y_report)

    #: 提示词走 **stdin**，不走命令行参数。
    #:
    #: 两份报告拼起来有十万字上下，Windows 的命令行长度上限是 32767 字符 ——
    #: 当成 argv 传会直接 ``WinError 206：文件名或扩展名太长``，
    #: 盲评会在第一条就崩掉，实验只剩客观指标。
    #: ``claude -p`` 不带位置参数时从 stdin 读提示词，这条路没有长度限制。
    cmd = [cli, "-p", "--output-format", "text", "--no-session-persistence"]

    stdout = ""
    data: dict[str, Any] | None = None
    #: 解析不出来就**再试一次**。
    #:
    #: 实测踩过：模型写的 ``reason`` 太长，输出被截断在 JSON 中间，
    #: 整轮盲评作废 —— 6 轮里丢 1 轮，主观指标就少一个样本。
    #: 重试不是"多花一次钱换一次机会"，是让这一轮不至于白跑。
    #: 第二次还不行才记成失败，并把失败原因原样留下来。
    for attempt in range(1, JUDGE_RETRIES + 1):
        try:
            proc = subprocess.run(
                cmd,
                input=prompt,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=JUDGE_TIMEOUT,
            )
        except subprocess.TimeoutExpired:
            return {"error": "盲评超时"}

        stdout = proc.stdout or ""
        data = extract_json_object(stdout)
        if data:
            break
        if attempt < JUDGE_RETRIES:
            log(f"    ⚖ 盲评输出解析失败，重试（第 {attempt} 次）")

    if not data:
        return {"error": f"盲评未返回可解析 JSON：{(stdout or '')[:200]}"}

    def side(label: str) -> dict[str, Any]:
        raw = data.get(label) or {}
        return {
            "structure": _int_or_none(raw.get("structure")),
            "insight": _int_or_none(raw.get("insight")),
            "actionability": _int_or_none(raw.get("actionability")),
            "reason": str(raw.get("reason") or "").strip(),
        }

    x_score, y_score = side("X"), side("Y")
    # 映射回 A / B
    a_score, b_score = (y_score, x_score) if swap else (x_score, y_score)
    log(f"    ⚖ 盲评完成（A:{a_score.get('insight')} B:{b_score.get('insight')}）")
    return {"swap": swap, "A": a_score, "B": b_score}


def _int_or_none(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _load_previous_judge() -> list[dict]:
    """从上一轮结果文件里取回盲评记录。

    只用于「重算客观指标」的场景：报告没变，盲评的结论也不该变，
    没必要再花一次模型调用。取不到就返回空列表，调用方改跑盲评。
    """
    path = RESULTS_DIR / "ab-results.json"
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    rows = data.get("盲评")
    if not isinstance(rows, list):
        return []
    return [row for row in rows if isinstance(row, dict)]


# ---------------------------------------------------------------- 汇总


def _mean(values: list[float | None]) -> float:
    """求均值。

    只收**数值** —— ``链接可用率`` 在没探测过时是字符串 ``"未探测"``，
    混进来会让 ``sum()`` 直接抛 ``TypeError``：跑完一小时的最后一步炸掉，
    前面所有跑批白费。
    """
    real = [
        float(value)
        for value in values
        if isinstance(value, (int, float)) and not isinstance(value, bool)
    ]
    return sum(real) / len(real) if real else 0.0


def _mean_optional(values: list[Any]) -> float | None:
    """求均值；一个数都取不到时返回 ``None``（而不是 0.0）。

    "没探测过"和"探测了、全挂"是两回事 —— 后者该显示 0%，前者该显示"未探测"。
    """
    real = [
        float(value)
        for value in values
        if isinstance(value, (int, float)) and not isinstance(value, bool)
    ]
    return sum(real) / len(real) if real else None


def _mean_label(values: list[Any]) -> float | str:
    """求均值；一个数都取不到时返回 ``"不适用"``。

    与 :func:`_mean_optional` 的区别：``None`` 在这里表示"这个指标对这个形态
    没有意义"（比如明细表没有议题列），不是"没测"。显示成 0% 会把
    "按设计就没有这一列"说成"两臂都没做到"。
    """
    real = [
        float(value)
        for value in values
        if isinstance(value, (int, float)) and not isinstance(value, bool)
    ]
    if real:
        return sum(real) / len(real)
    return "不适用"


def _bucket_consistent_ratio(scores: list[dict]) -> float | str:
    """「分档表自洽」的比例。

    分母只算**有分档表的报告**（月报形态没有分档表，不该算进分母）。
    """
    values = [s.get("分档表自洽") for s in scores]
    real = [value for value in values if value in ("是", "否")]
    if not real:
        return "不适用"
    return sum(1 for value in real if value == "是") / len(real)


def _objective_metrics(scores: list[dict]) -> dict[str, Any]:
    """把一组评分汇成客观指标字典。"""
    return {
        "板块覆盖率": _mean([s.get("板块覆盖率") for s in scores]),
        "链接可用率": _mean_optional([s.get("链接可用率") for s in scores]),
        "日期可解析率": _mean([s.get("日期可解析率") for s in scores]),
        "日期越界条目占比": _mean_optional([s.get("日期越界条目占比") for s in scores]),
        "重复条目占比": _mean([s.get("重复条目占比") for s in scores]),
        "无关条目占比": _mean([s.get("无关条目占比") for s in scores]),
        "关键字段完整率": _mean_label([s.get("关键字段完整率") for s in scores]),
        "金额准确率": _mean_label([s.get("金额准确率") for s in scores]),
        "基准公告复现率": _mean_label([s.get("基准公告复现率") for s in scores]),
        "议题标注率": _mean_label([s.get("议题标注率") for s in scores]),
        "影响方向标注率": _mean_label([s.get("影响方向标注率") for s in scores]),
        "分档表自洽率": _bucket_consistent_ratio(scores),
        "平均条目数": _mean([float(s.get("条目数", 0)) for s in scores]),
    }


def load_attempts() -> list[dict[str, Any]]:
    """读出历次尝试的记录（``bench/_attempts/*.json``）。

    补跑会覆盖 ``envelope.json``，所以每次尝试都另存一份底稿。
    这一节回答的是："这条**失败过几次、每次卡在哪、每次花了多少**" ——
    失败掉的运行也是数据，抹掉它，读者看到的成功率就不是真的了。
    """
    attempts_dir = RUNS_DIR.parent / "_attempts"
    if not attempts_dir.is_dir():
        return []
    records: list[dict[str, Any]] = []
    for path in sorted(attempts_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        data["底稿"] = path.name
        records.append(data)
    return records


def summarize(results: list[RunResult], judge_rows: list[dict]) -> dict[str, Any]:
    """按臂汇总。"""
    summary: dict[str, Any] = {}
    for arm in ARMS:
        runs = [r for r in results if r.arm == arm.key and r.ok]
        if not runs:
            continue
        scores = [r.score for r in runs]
        judge_scores = [row[arm.key] for row in judge_rows if arm.key in row]

        # 按案例再分一次。月报没有明细表，「关键字段完整率」「金额准确率」
        # 对它是「不适用」；不适用的那几格不参与平均，招投标那一半的真实数字
        # 不会被稀释掉 —— 看总表会以为两臂都只有一半分数。
        by_case: dict[str, Any] = {}
        for case_key in sorted({r.case for r in runs}):
            case_scores = [r.score for r in runs if r.case == case_key]
            case_judge = [
                row[arm.key]
                for row in judge_rows
                if arm.key in row and row.get("case") == case_key
            ]
            by_case[case_key] = {
                "成功运行数": len(case_scores),
                "客观": _objective_metrics(case_scores),
                "主观": {
                    "结构": _mean([j.get("structure") for j in case_judge]),
                    "洞见": _mean([j.get("insight") for j in case_judge]),
                    "可执行性": _mean([j.get("actionability") for j in case_judge]),
                },
            }

        summary[arm.key] = {
            "臂": arm.label,
            "成功运行数": len(runs),
            "客观": _objective_metrics(scores),
            "主观": {
                "结构": _mean([j.get("structure") for j in judge_scores]),
                "洞见": _mean([j.get("insight") for j in judge_scores]),
                "可执行性": _mean([j.get("actionability") for j in judge_scores]),
            },
            "成本": {
                "平均耗时秒": _mean([r.elapsed_s for r in runs]),
                "总花费美元": sum(float(r.usage.get("cost_usd") or 0) for r in runs),
                "平均输出 token": _mean([float(r.usage.get("output_tokens") or 0) for r in runs]),
            },
            "按案例": by_case,
        }
    return summary


def _fmt_cell(value: Any, fmt: str = "{:.1%}") -> str:
    """表格单元格的格式化。

    ``None`` 显示成「未探测」而不是 0% —— 没查过和查了全挂不是一回事，
    混成 0% 就是把"没测"说成"测了"。
    """
    if value is None:
        return "未探测"
    if isinstance(value, str):
        return value
    try:
        return fmt.format(value)
    except (TypeError, ValueError):
        return str(value)


def render_markdown(
    summary: dict[str, Any],
    results: list[RunResult],
    judge_rows: list[dict],
    settings: dict[str, Any] | None = None,
) -> str:
    """渲染人能读的对比报告。"""
    lines: list[str] = []
    lines.append("# A/B 对比报告 · 有脚本 vs 无脚本")
    lines.append("")
    lines.append("两臂 SKILL.md 逐字相同，搜索后端相同，**唯一变量是抽取与聚合由谁完成**。")
    lines.append("")

    if settings:
        lines.append("## 〇、实验设置")
        lines.append("")
        for key, value in settings.items():
            lines.append(f"- **{key}**：{value}")
        lines.append("")

    if not summary:
        lines.append("> 没有成功的运行，无法比较。")
        return "\n".join(lines) + "\n"

    lines.append("## 一、总体对比")
    lines.append("")
    lines.append("| 指标 | 性质 | A · 纯方法（无脚本） | B · 方法 + 确定性脚本 |")
    lines.append("| --- | --- | --- | --- |")

    def row(label: str, nature: str, getter, fmt: str = "{:.1%}") -> None:
        a = summary.get("A", {})
        b = summary.get("B", {})
        lines.append(
            f"| {label} | {nature} | {_fmt_cell(getter(a), fmt)} | {_fmt_cell(getter(b), fmt)} |"
        )

    def objective(key: str):
        return lambda arm: arm.get("客观", {}).get(key, 0.0)

    def subjective(key: str):
        return lambda arm: arm.get("主观", {}).get(key, 0.0)

    row("板块覆盖率", "客观", objective("板块覆盖率"))
    row("链接可用率", "客观", objective("链接可用率"))
    row("日期可解析率", "客观", objective("日期可解析率"))
    row("日期越界条目占比", "客观（越低越好）", objective("日期越界条目占比"))
    row("关键字段完整率", "客观", objective("关键字段完整率"))
    row("中标金额准确率", "客观", objective("金额准确率"))
    row("基准公告复现率", "客观", objective("基准公告复现率"))
    row("重复条目占比", "客观（越低越好）", objective("重复条目占比"))
    row("无关条目占比", "客观（越低越好）", objective("无关条目占比"))
    row("议题标注率", "客观", objective("议题标注率"))
    row("影响方向标注率", "客观", objective("影响方向标注率"))
    row("分档表自洽率", "客观（分档能由明细复现）", objective("分档表自洽率"))
    row("报告结构", "主观（盲评 1-5）", subjective("结构"), "{:.2f}")
    row("洞见深度", "主观（盲评 1-5）", subjective("洞见"), "{:.2f}")
    row("建议可执行性", "主观（盲评 1-5）", subjective("可执行性"), "{:.2f}")
    row("平均条目数", "客观", objective("平均条目数"), "{:.1f}")

    lines.append("")
    lines.append("### 按案例拆开看")
    lines.append("")
    lines.append(
        "> 月报**没有明细表**，「关键字段完整率」「中标金额准确率」对它**不适用**"
        "（不适用的格子不参与平均）。混在一起平均会把招投标那一半的真实数字稀释掉 —— 所以分案例看。"
    )
    lines.append("")
    for case_key in sorted(summary.get("A", {}).get("按案例", {})):
        lines.append(f"#### {case_key}")
        lines.append("")
        lines.append("| 指标 | A · 纯方法 | B · 方法 + 确定性脚本 |")
        lines.append("| --- | --- | --- |")
        a_case = summary.get("A", {}).get("按案例", {}).get(case_key, {})
        b_case = summary.get("B", {}).get("按案例", {}).get(case_key, {})

        def case_row(label: str, getter, fmt: str = "{:.1%}") -> None:
            lines.append(
                f"| {label} | {_fmt_cell(getter(a_case), fmt)} | {_fmt_cell(getter(b_case), fmt)} |"
            )

        case_row("板块覆盖率", lambda c: c.get("客观", {}).get("板块覆盖率"))
        case_row("链接可用率", lambda c: c.get("客观", {}).get("链接可用率"))
        case_row("日期可解析率", lambda c: c.get("客观", {}).get("日期可解析率"))
        case_row("日期越界条目占比", lambda c: c.get("客观", {}).get("日期越界条目占比"))
        case_row("关键字段完整率", lambda c: c.get("客观", {}).get("关键字段完整率"))
        case_row("中标金额准确率", lambda c: c.get("客观", {}).get("金额准确率"))
        case_row("基准公告复现率", lambda c: c.get("客观", {}).get("基准公告复现率"))
        case_row("重复条目占比", lambda c: c.get("客观", {}).get("重复条目占比"))
        case_row("无关条目占比", lambda c: c.get("客观", {}).get("无关条目占比"))
        case_row("议题标注率", lambda c: c.get("客观", {}).get("议题标注率"))
        case_row("影响方向标注率", lambda c: c.get("客观", {}).get("影响方向标注率"))
        case_row("分档表自洽率", lambda c: c.get("客观", {}).get("分档表自洽率"))
        case_row("平均条目数", lambda c: c.get("客观", {}).get("平均条目数"), "{:.1f}")
        case_row("结构（盲评 1-5）", lambda c: c.get("主观", {}).get("结构"), "{:.2f}")
        case_row("洞见（盲评 1-5）", lambda c: c.get("主观", {}).get("洞见"), "{:.2f}")
        case_row("可执行性（盲评 1-5）", lambda c: c.get("主观", {}).get("可执行性"), "{:.2f}")
        lines.append("")

    lines.append("")
    lines.append("## 二、成本")
    lines.append("")
    lines.append("| 指标 | A · 纯方法 | B · 脚本臂 |")
    lines.append("| --- | --- | --- |")
    for key, label, fmt in (
        ("平均耗时秒", "平均耗时（秒）", "{:.0f}"),
        ("总花费美元", "总花费（美元）", "{:.3f}"),
        ("平均输出 token", "平均输出 token", "{:.0f}"),
    ):
        a = summary.get("A", {}).get("成本", {}).get(key, 0)
        b = summary.get("B", {}).get("成本", {}).get(key, 0)
        lines.append(f"| {label} | {fmt.format(a)} | {fmt.format(b)} |")
    lines.append("")

    lines.append("## 三、逐次运行明细")
    lines.append("")
    lines.append("| 案例 | prompt | 臂 | 状态 | 条目 | 板块 | 链接 | 日期 | 越界 | 金额 | 基准复现 | 分档自洽 |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
    for result in sorted(results, key=lambda r: (r.case, r.prompt_index, r.arm)):
        if not result.ok:
            lines.append(
                f"| {result.case} | P{result.prompt_index + 1} | {result.arm} | "
                f"失败：{result.error[:40]} | — | — | — | — | — | — | — | — |"
            )
            continue
        score = result.score
        lines.append(
            f"| {result.case} | P{result.prompt_index + 1} | {result.arm} | ok | "
            f"{score.get('条目数', 0)} | {_fmt_cell(score.get('板块覆盖率'), '{:.0%}')} | "
            f"{_fmt_cell(score.get('链接可用率'), '{:.0%}')} | "
            f"{_fmt_cell(score.get('日期可解析率'), '{:.0%}')} | "
            f"{_fmt_cell(score.get('日期越界条目占比'), '{:.0%}')} | "
            f"{_fmt_cell(score.get('金额准确率'), '{:.0%}')} | "
            f"{score.get('基准公告复现', '—')} | "
            f"{score.get('分档表自洽', '—')} |"
        )
    lines.append("")

    # ---- 被判无关的条目抽样：判定是词表匹配，会误伤，摆出来让读者自己核
    samples = [
        (result.run_id, sample)
        for result in results
        if result.ok
        for sample in (result.score.get("无关条目抽样") or [])
    ]
    if samples:
        lines.append("## 四、被判无关的条目（抽样）")
        lines.append("")
        lines.append(
            "> 相关性是**词表匹配**，只量字面相关性。这几行被判成无关，"
            "读者可以自己核 —— 词表覆盖不到的正经 ESG 议题也会落进来。"
        )
        lines.append("")
        for run_id, sample in samples:
            lines.append(f"- `{run_id}`：{sample}")
        lines.append("")

    if judge_rows:
        lines.append("## 五、盲评逐条理由")
        lines.append("")
        for row_data in judge_rows:
            lines.append(f"### {row_data.get('case', '?')} · P{row_data.get('prompt_index', 0) + 1}")
            lines.append("")
            for arm_key in ("A", "B"):
                side = row_data.get(arm_key, {})
                lines.append(
                    f"- **{arm_key}**（结构 {side.get('structure')} / 洞见 {side.get('insight')} / "
                    f"可执行 {side.get('actionability')}）：{side.get('reason', '')}"
                )
            lines.append("")

    attempts = load_attempts()
    if attempts:
        lines.append("## 六、历次尝试记录")
        lines.append("")
        lines.append(
            "> 补跑会覆盖 `envelope.json`，所以每次尝试都另存了一份底稿（`bench/_attempts/`）。"
            "**失败掉的运行也是数据** —— 把它抹掉，读者看到的就是一份筛选过的成功率。"
        )
        lines.append("")
        lines.append("| 运行 | 开始时间 | 结束原因 | 花费 | 轮数 | 耗时 | 预算上限 | 来源 |")
        lines.append("| --- | --- | --- | ---: | ---: | ---: | ---: | --- |")
        for item in attempts:
            cost = item.get("total_cost_usd")
            duration = item.get("duration_api_ms")
            cost_text = f"{cost:.2f}" if isinstance(cost, (int, float)) else "—"
            duration_text = (
                f"{duration / 1000:.0f}s" if isinstance(duration, (int, float)) else "—"
            )
            lines.append(
                f"| `{item.get('run_id')}` | {item.get('started_at', '')} | "
                f"{item.get('terminal_reason') or '—'} | {cost_text} | "
                f"{item.get('num_turns') or '—'} | {duration_text} | "
                f"{item.get('max_budget_usd', '—')} | {item.get('来源', '底稿')} |"
            )
        lines.append("")
        spent = sum(
            float(item.get("total_cost_usd") or 0) for item in attempts
        )
        by_run: dict[str, float] = {}
        for item in attempts:
            by_run[item.get("run_id", "?")] = by_run.get(item.get("run_id", "?"), 0.0) + float(
                item.get("total_cost_usd") or 0
            )
        lines.append(
            f"- **历次尝试合计花费：${spent:.2f}**"
            + "".join(f"（{run_id} ${cost:.2f}）" for run_id, cost in sorted(by_run.items()))
        )
        lines.append("")

    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------- 主流程


def toolkit_fingerprint() -> str:
    """脚本层指纹：把确定性层所有 .py 的内容哈希成一个短串。

    12 次运行是并发的，中途改脚本会让先跑的那几次用旧脚本、后跑的用新脚本 ——
    两臂的脚本层版本不同，比较就不成立。把指纹写进结果文件，
    事后能一眼看出"这批结果是哪一版脚本跑出来的"。
    """
    import hashlib

    digest = hashlib.sha256()
    toolkit = ROOT / "scripts" / "esg_toolkit"
    for path in sorted(toolkit.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()[:12]


def method_fingerprint() -> str:
    """方法层指纹：两臂共用的那份 Skill（SKILL.md + references/ + assets/）。

    改了方法层（比如给"长报告分段写"补一条规矩），两臂的产出就都变了，
    旧结果不能跟新结果混着比。把指纹写进结果文件，一眼能看出
    "这批结果是哪一版方法跑出来的"。
    """
    digest = hashlib.sha256()
    for path in sorted(METHOD_SKILLS_DIR.rglob("*")):
        if path.is_dir() or "__pycache__" in path.parts:
            continue
        digest.update(str(path.relative_to(METHOD_SKILLS_DIR)).encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()[:12]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="A/B 跑批")
    parser.add_argument("--cases", nargs="*", default=[], help="只跑指定案例")
    parser.add_argument("--arms", nargs="*", default=[], help="只跑指定臂（A / B）")
    parser.add_argument("--prompts", type=int, default=0, help="每个案例跑前 N 个 prompt")
    parser.add_argument("--workers", type=int, default=3, help="并发数")
    parser.add_argument("--dry-run", action="store_true", help="只打印将要跑什么")
    parser.add_argument("--judge-only", action="store_true", help="复用已有报告，只重跑盲评")
    parser.add_argument(
        "--no-judge",
        action="store_true",
        help="只重算客观指标，不做盲评（盲评要花模型调用，调试测量口径时用）",
    )
    parser.add_argument(
        "--reuse-judge",
        action="store_true",
        help="复用上一轮结果文件里的盲评记录（报告没变就别再花模型调用）",
    )
    parser.add_argument("--no-probe", action="store_true", help="不探测链接可用性")
    parser.add_argument(
        "--only",
        nargs="*",
        default=[],
        help="只跑这些 run_id（如 tender-p1-A）；跑完别写结果文件，用 --judge-only 统一汇总",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=RUN_TIMEOUT,
        help=f"单次运行超时秒（默认 {RUN_TIMEOUT}）",
    )
    parser.add_argument(
        "--no-write",
        action="store_true",
        help="只跑，不写 ab-results.json / ab-report.md（配合 --only 用）",
    )
    parser.add_argument("--cli", default="claude", help="claude CLI 名字")
    parser.add_argument(
        "--max-budget",
        type=float,
        default=MAX_BUDGET_USD,
        help="单次运行的花费上限（美元）",
    )
    args = parser.parse_args(argv)

    cases = [c for c in CASES if not args.cases or c.key in args.cases]
    arms = [a for a in ARMS if not args.arms or a.key in args.arms]
    if args.prompts:
        cases = [
            Case(
                key=c.key,
                title=c.title,
                skill=c.skill,
                required_sections=c.required_sections,
                prompts=c.prompts[: args.prompts],
                window=c.window,
                window_rule=c.window_rule,
            )
            for c in cases
        ]

    jobs = [(arm, case, index, prompt) for case in cases for arm in arms for index, prompt in enumerate(case.prompts)]
    if args.only:
        wanted = set(args.only)
        jobs = [
            (arm, case, index, prompt)
            for arm, case, index, prompt in jobs
            if f"{case.key}-p{index + 1}-{arm.key}" in wanted
        ]

    print(f"将要跑 {len(jobs)} 次真实运行：")
    for arm, case, index, prompt in jobs:
        print(f"  [{arm.key}] {case.key} P{index + 1}  {prompt[:36]}")
    if args.dry_run:
        return 0

    cli = resolve_cli(args.cli)
    ground_truth = {
        entry["title"]: entry
        for entry in json.loads(GROUND_TRUTH.read_text(encoding="utf-8"))["fixtures"]
    }
    # 基准索引按归一化标题建一份，便于比对
    gt_by_norm = {_norm(entry.get("title", "")): entry for entry in ground_truth.values()}

    RUNS_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------- 跑批
    results: list[RunResult] = []
    if args.judge_only:
        for run_dir in sorted(RUNS_DIR.iterdir()):
            if not run_dir.is_dir():
                continue
            # 只认 ``<案例>-p<N>-<臂>`` 命名的目录。
            # 归档目录（比如 ``_attempts/``）不按这个命名，跳过 ——
            # 否则会把归档里的旧报告当成一次新的运行算进去。
            if not _RUN_ID_RE.match(run_dir.name):
                continue
            report_file = run_dir / "report.txt"
            case_key = run_dir.name.split("-p")[0]
            arm_key = run_dir.name.rsplit("-", 1)[-1]
            if not report_file.is_file():
                # 没跑完的也要**在册** —— "这条没跑出来"本身是数据，
                # 从结果文件里抹掉，读者看到的成功率和真实情况就不是一回事。
                results.append(
                    RunResult(
                        run_id=run_dir.name,
                        case=case_key,
                        prompt_index=int(run_dir.name.split("-p")[1].split("-")[0]) - 1,
                        prompt="",
                        arm=arm_key,
                        ok=False,
                        error="报告缺失（这次运行没跑完）",
                        run_meta=_run_meta_from_disk(run_dir),
                    )
                )
                continue
            raw = report_file.read_text(encoding="utf-8", errors="replace")
            if _looks_like_api_error(raw):
                # 补跑留下的 API 报错不是报告 —— 当成"这次没跑出来"。
                results.append(
                    RunResult(
                        run_id=run_dir.name,
                        case=case_key,
                        prompt_index=int(run_dir.name.split("-p")[1].split("-")[0]) - 1,
                        prompt="",
                        arm=arm_key,
                        ok=False,
                        error=f"API 报错（不是报告）：{raw.strip()[:120]}",
                        run_meta=_run_meta_from_disk(run_dir),
                        **_usage_from_disk(run_dir),
                    )
                )
                continue
            results.append(
                RunResult(
                    run_id=run_dir.name,
                    case=case_key,
                    prompt_index=int(run_dir.name.split("-p")[1].split("-")[0]) - 1,
                    prompt="",
                    arm=arm_key,
                    ok=True,
                    report_path=str(report_file),
                    raw=raw,
                    run_meta=_run_meta_from_disk(run_dir),
                    **_usage_from_disk(run_dir),
                )
            )
    else:
        with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
            futures = {
                pool.submit(
                    run_skill,
                    cli,
                    arm,
                    case,
                    index,
                    prompt,
                    print,
                    args.max_budget,
                    args.timeout,
                ): (arm, case, index)
                for arm, case, index, prompt in jobs
            }
            for future in as_completed(futures):
                result = future.result()
                results.append(result)
                if not result.ok:
                    print(f"    ✗ {result.run_id}：{result.error}")

    if args.no_write:
        # 只补跑，不汇总。补跑的产物落在 bench/runs/ 里，
        # 汇总统一由最后一次 ``--judge-only`` 出 —— 免得中间结果覆盖最终结果。
        print("\n（--no-write：只补跑，不评分、不盲评、不写结果文件）")
        return 0

    # ---------------------------------------------------------- 客观评分
    print("\n客观评分…")
    for result in results:
        if not result.ok:
            continue
        case = next((c for c in cases if c.key == result.case), None)
        if case is None:
            continue
        score = score_report(result.raw, case, gt_by_norm)

        if not args.no_probe:
            links = [url for _, url in extract_links(result.raw) if not _is_search_url(url)]
            links = list(dict.fromkeys(links))[:25]
            if links:
                probe = probe_links(links)
                score.link_ok = sum(1 for ok in probe.values() if ok)
                score.link_checked = len(probe)
                score.link_valid_ratio = (
                    score.link_ok / score.link_checked if score.link_checked else None
                )

        result.score = score.as_dict()

    # ---------------------------------------------------------- 盲评
    judge_rows: list[dict] = []
    if args.no_judge:
        print("\n盲评… 跳过（--no-judge：只重算客观指标）")
    elif args.reuse_judge:
        # 复用上一轮的盲评结果：只重算客观指标时不必再花一次模型调用。
        # 盲评看的是**报告质量**，而报告本身没动 ——
        # 修完测量口径重算一遍，分数该是多少还是多少。
        judge_rows = _load_previous_judge()
        if judge_rows:
            print(f"\n盲评… 复用上一轮结果（{len(judge_rows)} 轮）")
    if not args.no_judge:
        #: 已经评过的（案例, prompt）对不再重评 —— 复用时**只补没评过的那些**。
        todo = pairs_to_judge(results, judge_rows)
        if todo:
            print(f"\n盲评… {len(todo)} 轮" + (f"（复用 {len(judge_rows)} 轮）" if judge_rows else ""))
            for (case_key, prompt_index), pair in todo:
                case = next((c for c in cases if c.key == case_key), None)
                if case is None:
                    continue
                #: 重评之前把这一对**旧的失败行**清掉 ——
                #: 留着的话，同一个 prompt 会有两行（一个 error 一个成功），
                #: 汇总时这一对就被数了两遍。
                judge_rows[:] = [
                    row
                    for row in judge_rows
                    if not (
                        row.get("error")
                        and row.get("case") == case_key
                        and row.get("prompt_index") == prompt_index
                    )
                ]
                verdict = judge_blind(cli, case, pair["A"].raw, pair["B"].raw, print, prompt_index)
                verdict["case"] = case_key
                verdict["prompt_index"] = prompt_index
                judge_rows.append(verdict)

    # ---------------------------------------------------------- 汇总落盘
    summary = summarize(results, judge_rows)
    settings = {
        "案例数": len(cases),
        "每案例 prompt 数": len(cases[0].prompts) if cases else 0,
        "臂数": len(arms),
        "总运行数": len(jobs),
        "盲评轮数": len(judge_rows),
        "单次预算上限美元": args.max_budget,
        "单次超时秒": args.timeout,
        "单次响应输出 token 上限": MAX_OUTPUT_TOKENS,
        "并发数": args.workers,
        # 两臂必须跑在**同一个模型**上，否则对比会被模型差异污染。
        # 这里把实际生效的模型记下来，结果文件里能查。
        "模型": os.environ.get("ANTHROPIC_MODEL") or "(继承 CLI 默认)",
        "模型端点": os.environ.get("ANTHROPIC_BASE_URL") or "(官方端点)",
        #: 脚本层指纹 —— 事后能核对"这批结果是哪一版脚本跑出来的"
        "脚本层指纹": toolkit_fingerprint(),
        #: 方法层指纹 —— 两臂共用的那份 SKILL.md。改了方法层，指标要重算。
        "方法层指纹": method_fingerprint(),
        #: 统计窗口 —— "日期越界"这条指标拿它当尺子，尺子得写出来
        "时间窗": {
            case.key: resolve_window(case) for case in cases
        },
        "相关性词表条数": len(REPORT_TOPIC_KEYWORDS),
        "相关性判定口径": (
            "按词表命中判定（字面相关性）；判定前剥掉被测对象自己打的分类标签"
            "（条目形态的「议题／影响方向」标签行、明细表形态的「方向」等标签列）与 URL —— "
            "不让被测对象给自己作证"
        ),
        "相关性词表来源": "方法层自带的 references/esg-taxonomy.md + references/client-profile.md（非脚本层分类器）",
        "金额比对口径": (
            "逐条与人工标注基准比对（相对误差 0.5%）。分包公告下，"
            "报告里的金额只要等于基准的 amount_yuan、packages 里的任一合同包、"
            "或 amount_yuan_total（公告总额），都算抽对 —— 三者都是公告披露过的真实数字。"
            "一格里写多个金额（分包明细）时，逐个都对、或加起来等于某个合法取值，都算对。"
            "（实测踩过：只认基准里那一个数字时，脚本臂报公告总额被判成错，"
            "金额准确率凭空少了几十个点。）"
        ),
        "金额单位来源": "单元格自带单位 > 表头里的单位（『中标金额（万元）』）> 元",
        "基准公告复现率口径": (
            "报告的明细表里出现了基准里多少条公告（基准共 32 条）。"
            "基准这 32 份是用**脚本层自己的检索式**抓的，所以脚本臂天然占优 —— "
            "这个指标量的是「脚本层沉淀下来的检索式能不能稳定复现」，"
            "不是「谁搜得更全」。纯方法臂用的是方法层自己的检索式，"
            "找到的是另一批公告（不在基准里，金额无法自动核对）。"
        ),
    }
    payload = {
        "实验设置": settings,
        "汇总": summary,
        "逐次运行": [
            {
                "run_id": r.run_id,
                "案例": r.case,
                "prompt": r.prompt,
                "臂": r.arm,
                "成功": r.ok,
                "错误": r.error,
                "耗时秒": round(r.elapsed_s, 1),
                "超时上限秒": r.run_meta.get("timeout_seconds"),
                "预算上限美元": r.run_meta.get("max_budget_usd"),
                "用量": r.usage,
                "评分": r.score,
            }
            for r in sorted(results, key=lambda r: (r.case, r.prompt_index, r.arm))
        ],
        "盲评": judge_rows,
        "尝试记录": load_attempts(),
    }
    (RESULTS_DIR / "ab-results.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    (RESULTS_DIR / "ab-report.md").write_text(
        render_markdown(summary, results, judge_rows, settings),
        encoding="utf-8",
        newline="\n",
    )

    print(f"\n结果已写入：{RESULTS_DIR / 'ab-results.json'}")
    print(f"报告已写入：{RESULTS_DIR / 'ab-report.md'}")
    return 0


if __name__ == "__main__":
    if hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    raise SystemExit(main())
